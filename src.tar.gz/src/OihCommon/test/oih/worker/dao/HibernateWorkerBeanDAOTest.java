package oih.worker.dao;

import java.util.Properties;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class HibernateWorkerBeanDAOTest {

    private SessionFactory sessionFactory;
    private HibernateWorkerBeanDAO dao;

    public IWorkerBeanDAO getDao() {
        return dao;
    }

    @BeforeClass
    public static void theLogThe(){
        //Plz see http://tinyurl.com/a5zcel bullet 3, item 3 for more information on the method name
        Logger.getRootLogger().setLevel(Level.ERROR);
    }

    @Before
    public void setup() {
        
        //SessionFactory/HSQLDB/schema is built for each test.  
        //Not fast, but we have a clean DB each test
        //Setup all config properties by hand.
        Properties props = new Properties();
        props.setProperty("hibernate.connection.driver_class", "org.hsqldb.jdbcDriver");
        //to connect to server running on localhost, use url like: jdbc:hsqldb:hsql://localhost/xdb
        props.setProperty("hibernate.connection.url", "jdbc:hsqldb:file:/var/tmp/testdb");
        //props.setProperty("hibernate.connection.url", "jdbc:hsqldb:hsql://josiaho.desktop/oih" ); // for testing a local hsql server
        props.setProperty("hibernate.connection.username", "sa");
        props.setProperty("hibernate.connection.password", "");
        props.setProperty("hibernate.dialect", "org.hibernate.dialect.HSQLDialect");
        props.setProperty("connection.pool_size", "5");
        props.setProperty("hibernate.hbm2ddl.auto", "create");
        props.setProperty("show_sql", "true");
        
        /*
        props.setProperty( "hibernate.connection.driver_class", "com.mysql.jdbc.Driver" );
        props.setProperty( "hibernate.connection.url", "jdbc:mysql://localhost:3306/workflow_db");
        props.setProperty( "hibernate.connection.username", "oihadmin" );
        props.setProperty( "hibernate.connection.password", "" );
        props.setProperty( "hibernate.dialect", "org.hibernate.dialect.MySQL5Dialect" );
        props.setProperty( "connection.pool_size", "5" );
        */
            
        Configuration config = new Configuration();
        
        config.setProperties(props);
        try {
            //need to specify classes to be mapped by hand too
            
            config.addResource( "oih/worker/WorkerProgressBean.hbm.xml" );
            
            sessionFactory = config.buildSessionFactory();
        } catch (RuntimeException e) {
            e.printStackTrace();
        }
        
        dao = HibernateWorkerBeanDAO.getInstance();
        dao.setSessionFactory( sessionFactory );
    }
    
    @Test
    public void testIt() {
        
    }
}
