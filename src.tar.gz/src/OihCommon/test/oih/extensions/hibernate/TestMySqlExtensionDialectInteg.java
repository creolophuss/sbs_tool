package oih.extensions.hibernate;

import java.util.List;
import java.util.Properties;

import oih.business.AmazonOrg;
import oih.business.removals.exclusions.ExclusionHibernateDAO;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class TestMySqlExtensionDialectInteg {

	private TestMySqlExtensionDialectInteg() {

	}

	public static void main(String[] args) {
		TestMySqlExtensionDialectInteg test = new TestMySqlExtensionDialectInteg();
		SessionFactory factory = test.getSessionFactory();
		test.execute(factory);
		test.validationOfDateAirthmetic(factory);
	}

	private void validationOfDateAirthmetic(SessionFactory factory) {
		ExclusionHibernateDAO dao = new ExclusionHibernateDAO();
		dao.setSessionFactory(factory);
		boolean valid = dao
				.validateWhereClause(14, AmazonOrg.US,
						"( vendor = 'PONY' ) and (product_site_launch_date > subdate(30))");
		if(!valid){
			throw new RuntimeException("Failed validating date airthment for exclusions");
		}
	}

	private void execute(SessionFactory factory) {
		Session s = factory.openSession();

		Query q = s
				.createQuery("select subdate(current_date, 40, DAY), subdate(current_date, 40), subdate(now(), 40), subdate(40), adddate(current_date, 40, day), adddate(current_date, 40), adddate(now(), 40), adddate(40) from GlConfig");
		@SuppressWarnings("unchecked")
		List<Object[]> r = q.list();
		for (Object[] i : r) {
			for (Object j : i)
				System.out.println("@@@ " + j);
		}
	}

	public SessionFactory getSessionFactory() {
		System.out
				.println("base domain hibernate DAO is constructing a session factory for "
						+ this.getClass().getName());

		Properties props = new Properties();

		props.setProperty("hibernate.connection.driver_class",
				"com.mysql.jdbc.Driver");

		props.setProperty("hibernate.connection.url",
				"jdbc:mysql://bhagybet.desktop.amazon.com/workflow_db");

		props.setProperty("hibernate.connection.username", "oihadmin");

		props.setProperty("hibernate.connection.password", "");

		props.setProperty("hibernate.dialect",
				"oih.extensions.hibernate.MySqlExtensionDialect");

		props.setProperty("connection.pool_size", "5");

		props.setProperty("show_sql", "true");

		Configuration config = new Configuration();

		config.addResource("oih/business/removals/GlConfig.hbm.xml");
        config.addResource("oih/business/removals/exclusions/ExclusionDefinition.hbm.xml");
        config.addResource("oih/business/buyer/BuyerUnhealthyDetail.hbm.xml");
        config.addResource("oih/business/buyer/BuyerUnhealthyDetailExpand.hbm.xml");

		config.setProperties(props);

		return config.buildSessionFactory();

	}

}
