package oih.business.removals.exclusions.monitor.dao;

import java.util.Date;
import java.util.List;

import oih.business.AmazonOrg;
import oih.business.removals.exclusions.monitor.dao.OihAutomationRate;
import oih.business.removals.exclusions.monitor.dao.OihAutomationRateHibernateDAO;
import oih.business.removals.exclusions.monitor.util.TestUtil;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.mortbay.log.Log;

public class OihAutomationRateHibernateDAOTest {
    private OihAutomationRateHibernateDAO dao;
    
    @BeforeClass
    public static void theLogThe() {
        // Plz see http://tinyurl.com/a5zcel bullet 3, item 3 for more information on the method name
        Logger.getRootLogger().setLevel(Level.INFO);
    }

    @Before
    public void setup() {
        dao = HibernateDAOTestUtil.getRateDao();
    }

    private OihAutomationRate newOihRate(
                     Date rundate, String org, int gl, Integer automatedUnits, 
                     Integer actionableUnits, Double automationRate, Date createdDate, String isSunday){
        OihAutomationRate rate = new OihAutomationRate();
        rate.setRundate(rundate);
        rate.setOrg(org);
        rate.setGl(gl);
        rate.setAutomatedUnits(automatedUnits);
        rate.setActionableUnits(actionableUnits);
        rate.setAutomationRate(automationRate);
        rate.setCreatedDate(createdDate);
        rate.setIsSunday(isSunday);
        return rate;
    }
    
    private void generateTestTable() {
        Date rundate = TestUtil.convertToDate("2014-07-20");
        String org = "USAmazon";
        Integer gl = 14;
        Integer automatedUnits = 10;
        Integer actionableUnits = 100;
        Double automationRate = 0.99;
        Date createdDate = TestUtil.convertToDate("2014-07-29");
        OihAutomationRate newRate = this.newOihRate(rundate, org, gl, 
                automatedUnits, actionableUnits, automationRate, createdDate, "Y");
        dao.save(newRate);
    }
    
    
    public void testFindOihAutomationRatesByCreatedDate() {
        this.generateTestTable();
        Date rundate = TestUtil.convertToDate("2014-07-20");
        Date createdDate = TestUtil.convertToDate("2014-07-29");
        Integer gl = 15;
        try{
            List<OihAutomationRate> rates 
            = dao.findOihAutomationRatesByCreatedDate(AmazonOrg.US, rundate, createdDate, gl);
            if(rates == null || rates.size() == 0)
                Log.info("No result");
            Log.info("Totally got " + rates.size() + " results.");
            for(int i = 0; i < rates.size(); i++){
                Log.info("rate:" + rates.get(i));
            }
        }catch(Exception e){
            e.printStackTrace();
            Log.info("Got exception:" + e.getMessage(), e);
        }
    }
    
    @Test
    public void testFindSundayAutomationRates() {
        this.generateTestTable();
        try{
            Date rundate = TestUtil.convertToDate("2014-07-20");
            List<OihAutomationRate> rates 
            = dao.findSundayOihAutomationRates(AmazonOrg.US, rundate, 15);
            if(rates == null || rates.size() == 0)
                Log.info("No result");
            Log.info("Totally got " + rates.size() + " results.");
            for(int i = 0; i < rates.size(); i++){
                Log.info("rate:" + rates.get(i));
            }
        }catch(Exception e){
            e.printStackTrace();
            Log.info("Got exception:" + e.getMessage(), e);
        }
    }
}
