package oih.business.removals.exclusions.monitor;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.junit.BeforeClass;
import org.junit.Test;
import org.mortbay.log.Log;

import oih.business.AmazonOrg;
import oih.business.removals.exclusions.monitor.ExclusionMonitorTestUtil;
import oih.business.removals.exclusions.monitor.object.AutomationRateRecord;
import oih.business.removals.exclusions.monitor.dao.OihAutomationRate;

public class TestAutomationRateChecker {
    @BeforeClass
    public static void theLogThe() {
        // Plz see http://tinyurl.com/a5zcel bullet 3, item 3 for more information on the method name
        Logger.getRootLogger().setLevel(Level.INFO);
    }
    static{ExclusionMonitorTestUtil.configEnv();}

    public void testCheckMeetExclusionChange() {
        Double glDistribution = 0.8;
        OihAutomationRate sundayRate = new OihAutomationRate();
        OihAutomationRate currentRate = new OihAutomationRate();
        sundayRate.setOrg(AmazonOrg.US.getRealm());
        sundayRate.setGl(14);
        sundayRate.setActionableUnits(10);
        sundayRate.setAutomatedUnits(10);
        sundayRate.setAutomationRate(5.0);
        currentRate.setOrg(AmazonOrg.US.getRealm());
        currentRate.setGl(14);
        currentRate.setActionableUnits(10);
        currentRate.setAutomatedUnits(1);
        currentRate.setAutomationRate(4.0);
        AutomationRateRecord record 
            = new AutomationRateRecord(14, sundayRate, currentRate, glDistribution);
    
        try{
            record = AutomationRateChecker.checkMeetThreshold(14, record);
            Log.info("Result record:" + record);
        }catch(Exception e) {
            e.printStackTrace();
        }
    }
}
