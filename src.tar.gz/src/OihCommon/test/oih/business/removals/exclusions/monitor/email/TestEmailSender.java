package oih.business.removals.exclusions.monitor.email;

import java.util.Date;
import java.util.List;
import java.util.ArrayList;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.junit.BeforeClass;
import org.junit.Test;
import org.mortbay.log.Log;

import oih.business.AmazonOrg;
import oih.business.removals.exclusions.monitor.email.*;
import oih.business.removals.exclusions.monitor.object.*;
import oih.business.removals.exclusions.monitor.dao.OihAutomationRate;
import oih.business.removals.exclusions.monitor.ExclusionMonitorTestUtil;
import oih.business.removals.exclusions.ExclusionDefinition;
import oih.business.removals.exclusions.monitor.util.TestUtil;

public class TestEmailSender {
    @BeforeClass
    public static void theLogThe() {
        // Plz see http://tinyurl.com/a5zcel bullet 3, item 3 for more information on the method name
        Logger.getRootLogger().setLevel(Level.INFO);
    }
    static{ExclusionMonitorTestUtil.configEnv();}
    
    private AutomationRateRecord generateRateRecord() {
        OihAutomationRate sundayRate = new OihAutomationRate();
        OihAutomationRate currRate = new OihAutomationRate();
        Double glDistribution = 1.0;
        AutomationRateRecord rateRecord = new AutomationRateRecord(14, sundayRate, currRate, glDistribution);
        rateRecord.setCountryLevelDroppedRate(0.99);
        rateRecord.setDroppedUnits(10);
        rateRecord.setEscalationLevel(2);
        rateRecord.setGlLevelDroppedRate(0.2);
        return rateRecord;
    }
    
    private ExclusionDefinition newExclusion(
            Integer gl, AmazonOrg org, String reason, Date startDate, 
            Date endDate, Integer lastRows, String whereClause, Integer rulePosition,
            String reasonCode, String overrideRemovalType, String clearActioningQty, 
            String createdBy, Date createdDate, String isGlobal, String isRun){

        ExclusionDefinition exclusion = new ExclusionDefinition();
        exclusion.setGl(gl);
        exclusion.setOrg(org);
        exclusion.setReason(reason);
        exclusion.setStartDate(startDate);
        exclusion.setEndDate(endDate);
        exclusion.setLastRowsMatched(lastRows);
        exclusion.setWhereClause(whereClause);
        exclusion.setRulePosition(rulePosition);
        exclusion.setExclusionReasonCode(reasonCode);
        exclusion.setOverrideRemovalType(overrideRemovalType);
        exclusion.setClearActioningQuantity(clearActioningQty);
        exclusion.setCreatedBy(createdBy);
        exclusion.setCreatedDate(createdDate);
        exclusion.setIsGlobal(isGlobal);
        exclusion.setIsRun(isRun);
        return exclusion;
    }
    
    private ExclusionDefinition generateExclusionData1() {
        Integer gl = 14;
        AmazonOrg org = AmazonOrg.US;
        String reason = "testReason2";
        Date startDate = TestUtil.convertToDate("2014-07-01");
        Date endDate = TestUtil.convertToDate("2014-07-2");
        Integer lastRows = 2;
        String whereClause = "testClause1";
        Integer rulePosition = 3;
        String reasonCode = "testReasonCode1";
        String overrideRemovalType = "TestOverride1";
        String clearActioningQty = "TestClearQty1";
        String createdBy = "lingwang";
        Date createdDate = TestUtil.convertToDate("2014-07-02");
        String isGlobal = "N";
        String isRun = "N";
        ExclusionDefinition e = this.newExclusion(gl, org, reason, startDate, endDate, lastRows, 
                                whereClause, rulePosition, reasonCode, overrideRemovalType, 
                                clearActioningQty, createdBy, createdDate, isGlobal, isRun);
        return e;
    }
    
    private ExclusionDefinition generateExclusionData2() {
        Integer gl = 14;
        AmazonOrg org = AmazonOrg.US;
        String reason = "testReason2";
        Date startDate = TestUtil.convertToDate("2014-07-03");
        Date endDate = TestUtil.convertToDate("2014-07-04");
        Integer lastRows = 1;
        String whereClause = "testClause2";
        Integer rulePosition = 4;
        String reasonCode = "testReasonCode2";
        String overrideRemovalType = "TestOverride2";
        String clearActioningQty = "TestClearQty2";
        String createdBy = "lingwang";
        Date createdDate = TestUtil.convertToDate("2014-07-01");
        String isGlobal = "N";
        String isRun = "N";
        ExclusionDefinition e = this.newExclusion(gl, org, reason, startDate, endDate, lastRows, 
                                whereClause, rulePosition, reasonCode, overrideRemovalType, 
                                clearActioningQty, createdBy, createdDate, isGlobal, isRun);
        return e;
    }
    
    private List<ExclusionDefinition> generateAddedExclusions() {
        List<ExclusionDefinition> addedExclusions = new ArrayList<ExclusionDefinition>();
        addedExclusions.add(this.generateExclusionData1());
        return addedExclusions;
    }
    
    private List<ExclusionDefinition> generateDeletedExclusions() {
        List<ExclusionDefinition> deletedExclusions = new ArrayList<ExclusionDefinition>();
        deletedExclusions.add(this.generateExclusionData2());
        return deletedExclusions;
    }
    
    private ExclusionRecord generateExclusionRecord() {
        List<ExclusionDefinition> addedExclusions = this.generateAddedExclusions();
        List<ExclusionDefinition> deletedExclusions = this.generateDeletedExclusions();
        ExclusionRecord exclusionRecord 
            = new ExclusionRecord(14);
        exclusionRecord.setHasChangedExclusions(true);
        exclusionRecord.setAddedExclusions(addedExclusions);
        exclusionRecord.setDeletedExclusions(deletedExclusions);
        return exclusionRecord;
    }
    
    public void testEmailSender() {
        try{
            AutomationRateRecord rateRecord = this.generateRateRecord();
            ExclusionRecord exclusionRecord = this.generateExclusionRecord();
            EmailGeneratorPrepareData prepareData 
                = new EmailGeneratorPrepareData(AmazonOrg.US, rateRecord, exclusionRecord);
            Integer escalation = rateRecord.getEscalationLevel();
            EmailGenerator emailGenerator 
                = EmailGeneratorFactory.getEmailGenerator(prepareData, escalation);
            EmailObject emailObject = emailGenerator.generateEmailObject();
            EmailSender.sendEmails(emailObject.getParamList(),
                                   emailObject.getRenders(),
                                   emailObject.getAttachments());
        }catch(Exception e){
            e.printStackTrace();
        }
    }
}
