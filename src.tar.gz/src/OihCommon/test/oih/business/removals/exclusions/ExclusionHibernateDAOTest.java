package oih.business.removals.exclusions;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

import oih.business.AmazonOrg;
import oih.business.buyer.BuyerUnhealthyDetail;
import oih.business.buyer.BuyerUnhealthyDetailHibernateDAO;
import oih.business.removals.GlConfigDAO;
import oih.util.DateUtils;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.amazon.oih.dao.exception.OihPersistenceException;

import testutils.HSQLDBUtils;

public class ExclusionHibernateDAOTest {
    private SessionFactory sessionFactory;
    private ExclusionHibernateDAO dao;
    BuyerUnhealthyDetailHibernateDAO daoU = null;

    private ExclusionExecutor executor = null;
    
    @BeforeClass
    public static void theLogThe() {
        // Plz see http://tinyurl.com/a5zcel bullet 3, item 3 for more information on the method name
        Logger.getRootLogger().setLevel(Level.INFO);
    }

    @Before
    public void setup() {
        Properties props = new Properties();

        HSQLDBUtils.cleanupHSQLDBFiles("/var/tmp", "testdb");

        props.setProperty("hibernate.connection.driver_class", "org.hsqldb.jdbcDriver");
        props.setProperty("hibernate.connection.url", "jdbc:hsqldb:file:/var/tmp/testdb");
        props.setProperty("hibernate.connection.username", "sa");
        props.setProperty("hibernate.connection.password", "");
        props.setProperty("hibernate.dialect", "org.hibernate.dialect.HSQLDialect");
        props.setProperty("hibernate.hbm2ddl.auto", "create");
        props.setProperty("connection.pool_size", "5");
        props.setProperty("show_sql", "true");

        Configuration config = new Configuration();

        config.setProperties(props);
        try {
            // need to specify classes to be mapped by hand too

            config.addResource("oih/business/removals/exclusions/ExclusionDefinition.hbm.xml");
            config.addResource("oih/business/buyer/BuyerUnhealthyDetail.hbm.xml");
            config.addResource("oih/business/buyer/BuyerUnhealthyDetailExpand.hbm.xml");
            config.addResource("oih/business/removals/exclusions/ExclusionReasonCode.hbm.xml");
            config.addResource("oih/business/removals/GlConfig.hbm.xml");

            sessionFactory = config.buildSessionFactory();
        } catch (RuntimeException e) {
            e.printStackTrace();
        }

        dao = new ExclusionHibernateDAO();
        dao.setSessionFactory(sessionFactory);
        daoU = new BuyerUnhealthyDetailHibernateDAO();
        daoU.setSessionFactory(sessionFactory);
        
        GlConfigDAO.getInstance().setSessionFactory(sessionFactory);

        sessionFactory.openSession().createSQLQuery("DELETE FROM " + ExclusionHibernateDAO._TABLE).executeUpdate();

        executor = ExclusionExecutor.getInstance();
        executor.setExclusionDAO(dao);
    }

    
    
    private static ExclusionDefinition newExclusionDefinition(AmazonOrg org, int gl, Date s, Date e, String r,
            String w, String reasonCode, int position, String overrideRemovalType, String clearActioniningQuantity) {
        return newExclusionDefinition(org, gl, s, e, r, w, reasonCode, position, overrideRemovalType, clearActioniningQuantity, ExclusionDefinition.IsRunValue.N.name());
    }
    
    private static ExclusionDefinition newExclusionDefinition(AmazonOrg org, int gl, Date s, Date e, String r,
            String w, String reasonCode, int position, String overrideRemovalType, String clearActioniningQuantity, String isRun) {
        ExclusionDefinition ed = new ExclusionDefinition();
        ed.setOrg(org);
        ed.setGl(gl);
        ed.setEndDate(e);
        ed.setStartDate(s);
        ed.setWhereClause(w);
        ed.setReason(r);
        ed.setExclusionReasonCode(reasonCode);
        ed.setRulePosition(new Integer(position));
        ed.setOverrideRemovalType(overrideRemovalType);
        ed.setClearActioningQuantity(clearActioniningQuantity);
        ed.setIsGlobal(ExclusionDefinition.IsGlobalValue.N.name());
        ed.setIsRun(isRun);
        return ed;
    }

    private static BuyerUnhealthyDetail newBuyerUnhealthyDetail(String asin, String vendor, AmazonOrg org,
            Date rundate, Integer gl, String category, String removalType) {
        BuyerUnhealthyDetail b = new BuyerUnhealthyDetail();

        b.setAsin(asin);
        b.setVendor(vendor);
        b.setOrg(org);
        b.setRundate(rundate);
        b.setGl(gl);
        b.setCategory(category);
        b.setIog(1);
        b.setActioningQty(1);
        b.setUnhealthyQty(1);
        b.setRemovalType(removalType);
        b.setRecommendedRemovalType(removalType);
        return b;
    }

    @Test
    public void testDownload() {

        dao.save(ExclusionHibernateDAOTest.newExclusionDefinition(AmazonOrg.US, 14, null, null, "test",
                "( vendor = 'TEST1' )", "TEST_CODE", 1, null, "YES"));

        Iterator<ExclusionDefinition> oMg = dao.downloadExclusion(14, AmazonOrg.US);
        Assert.assertTrue(oMg.hasNext());

        ExclusionDefinition ed = oMg.next();
        System.out.println(ed.getId());
        Assert.assertNotNull(ed.getId());
        Assert.assertEquals(AmazonOrg.US, ed.getOrg());
        Assert.assertEquals(14, ed.getGl().intValue());
        Assert.assertEquals("test", ed.getReason());
        Assert.assertEquals("TEST_CODE", ed.getExclusionReasonCode());

        // clear the state
        dao.deleteNotRunExclusionDefinitions(14, AmazonOrg.US);

    }

    @Test
    public void testDownloadOrder() {
        for (int i = 0; i < 10; i++) {
            dao.save(ExclusionHibernateDAOTest.newExclusionDefinition(AmazonOrg.US, 14, null, null, "test" + i,
                    "( vendor = 'TEST1' )", "TEST_CODE" + i, i, null, "YES"));
        }

        // we expect 10 rules to be returned, and in asc order
        Iterator<ExclusionDefinition> oMg = dao.downloadExclusion(14, AmazonOrg.US);
        int numReturned = 0;
        while (oMg.hasNext()) {
            ExclusionDefinition ed = oMg.next();
            Assert.assertNotNull(ed.getId());
            Assert.assertEquals(AmazonOrg.US, ed.getOrg());
            Assert.assertEquals(14, ed.getGl().intValue());
            Assert.assertEquals("test" + numReturned, ed.getReason());
            Assert.assertEquals("TEST_CODE" + numReturned, ed.getExclusionReasonCode());
            numReturned++;
        }

        Assert.assertEquals(10, numReturned);

        // clear the state
        dao.deleteNotRunExclusionDefinitions(14, AmazonOrg.US);

    }

    @Test
    public void testExecuteEmpty() {
        ExclusionDefinition ed = dao.save(ExclusionHibernateDAOTest.newExclusionDefinition(AmazonOrg.US, 14, null,
                null, "test", "( vendor = 'EMPTY' )", "TEST_CODE1", 2, null, "YES"));

        executor.executeExclusions(AmazonOrg.US, 14, DateUtils.lastSunday(), "test", null);
        ExclusionDefinition p = dao.find(ed.getId());
        Assert.assertNotNull(p.getLastRowsMatched());
        Assert.assertEquals((Integer) 0, p.getLastRowsMatched());

        dao.deleteNotRunExclusionDefinitions(14, AmazonOrg.US);
    }

    @Test
    public void testExecuteAll() {
        List<BuyerUnhealthyDetail> buList = new ArrayList<BuyerUnhealthyDetail>(3);
        ExclusionDefinition ed = dao.save(ExclusionHibernateDAOTest.newExclusionDefinition(AmazonOrg.US, 14, null,
                null, "test", "( vendor = 'PONY' )", "TEST_CODE", 1, null, "YES"));
        buList.add(daoU.save(ExclusionHibernateDAOTest.newBuyerUnhealthyDetail("0000000000", "PONY", AmazonOrg.US,
                DateUtils.lastSunday(), 14, "9", "Return")));
        buList.add(daoU.save(ExclusionHibernateDAOTest.newBuyerUnhealthyDetail("0000000001", "PONY", AmazonOrg.US,
                DateUtils.lastSunday(), 14, "9", "Return")));
        buList.add(daoU.save(ExclusionHibernateDAOTest.newBuyerUnhealthyDetail("0000000002", "PONY", AmazonOrg.US,
                DateUtils.lastSunday(), 14, "9", "Return")));

        executor.executeExclusions(AmazonOrg.US, 14, DateUtils.lastSunday(), "test", null);
        ExclusionDefinition p = dao.find(ed.getId());

        Assert.assertNotNull(p.getLastRowsMatched());
        Assert.assertEquals((Integer) 3, p.getLastRowsMatched());

        // check that the exclusion reason, reason code, and actioning qty are set correctly
        BuyerUnhealthyDetail found = null;
        for (BuyerUnhealthyDetail b : buList) {
            found = daoU.find(b.getId());
            Assert.assertNotNull(found);
            Assert.assertTrue("test".equals(found.getBuyerExclusionReason()));
            Assert.assertTrue("TEST_CODE".equals(found.getBuyerExclusionReasonCode()));
            Assert.assertEquals(0, found.getActioningQty().intValue());
        }

        dao.deleteNotRunExclusionDefinitions(14, AmazonOrg.US);
    }

    @Test
    public void testExecuteSomeWithOrder() {
        dao.deleteNotRunExclusionDefinitions(14, AmazonOrg.US);
        List<BuyerUnhealthyDetail> buList = new ArrayList<BuyerUnhealthyDetail>(3);
        ExclusionDefinition higherPrecedenceExclusion = dao.save(ExclusionHibernateDAOTest.newExclusionDefinition(
                AmazonOrg.US, 14, null, null, "higher", "( vendor = 'PONY' )", "TEST_CODE_HIGHER", 1, null, "YES"));
        ExclusionDefinition lowerPrecedenceExclusion = dao.save(ExclusionHibernateDAOTest.newExclusionDefinition(
                AmazonOrg.US, 14, null, null, "lower", "( vendor = 'PONY' )", "TEST_CODE_LOWER", 2, null, "YES"));

        buList.add(daoU.save(ExclusionHibernateDAOTest.newBuyerUnhealthyDetail("0000000000", "PONY", AmazonOrg.US,
                DateUtils.lastSunday(), 14, "9", "Return")));
        buList.add(daoU.save(ExclusionHibernateDAOTest.newBuyerUnhealthyDetail("0000000001", "PONY", AmazonOrg.US,
                DateUtils.lastSunday(), 14, "9", "Return")));
        buList.add(daoU.save(ExclusionHibernateDAOTest.newBuyerUnhealthyDetail("0000000002", "PONY", AmazonOrg.US,
                DateUtils.lastSunday(), 14, "9", "Return")));
        BuyerUnhealthyDetail notExcluded = daoU.save(ExclusionHibernateDAOTest.newBuyerUnhealthyDetail("0000002340",
                "SONY", AmazonOrg.US, DateUtils.lastSunday(), 14, "9", "Return"));

        executor.executeExclusions(AmazonOrg.US, 14, DateUtils.lastSunday(), "test", null);
        ExclusionDefinition lower = dao.find(lowerPrecedenceExclusion.getId());
        ExclusionDefinition higher = dao.find(higherPrecedenceExclusion.getId());

        // lower rule should match 0 records
        Assert.assertNotNull(lower.getLastRowsMatched());
        Assert.assertEquals((Integer) 0, lower.getLastRowsMatched());

        // higher rule should match 3 records
        Assert.assertNotNull(higher.getLastRowsMatched());
        Assert.assertEquals((Integer) 3, higher.getLastRowsMatched());

        // check that the exclusion reason, reason code, and actioning qty are set correctly
        BuyerUnhealthyDetail found = null;
        for (BuyerUnhealthyDetail b : buList) {
            found = daoU.find(b.getId());
            Assert.assertNotNull(found);
            Assert.assertTrue("higher".equals(found.getBuyerExclusionReason()));
            Assert.assertTrue("TEST_CODE_HIGHER".equals(found.getBuyerExclusionReasonCode()));
            Assert.assertEquals(0, found.getActioningQty().intValue());
        }

        // make sure that the 4th record is not excluded by checking actioning qty
        Assert.assertEquals(1, notExcluded.getActioningQty().intValue());

        dao.deleteNotRunExclusionDefinitions(14, AmazonOrg.US);
    }

    @Test
    public void testExecuteValidStartEndDates() {
        ExclusionDefinition ed = dao.save(ExclusionHibernateDAOTest.newExclusionDefinition(AmazonOrg.US, 14, DateUtils
                .add(DateUtils.lastSaturday(), -7, 0, 0), DateUtils.add(DateUtils.lastSaturday(), 7, 0, 0),
                "test exclusion", "( vendor = 'DATE1' )", "TEST_CODE", 1, null, "YES"));
        BuyerUnhealthyDetail b = ExclusionHibernateDAOTest.newBuyerUnhealthyDetail("0000000000", "DATE1", AmazonOrg.US,
                DateUtils.lastSunday(), 14, "9", "Return");
        BuyerUnhealthyDetail saved = daoU.save(b);

        executor.executeExclusions(AmazonOrg.US, 14, DateUtils.lastSunday(), "test", null);
        ExclusionDefinition p = dao.find(ed.getId());
        BuyerUnhealthyDetail found = daoU.find(saved.getId());
        Assert.assertNotNull(found);
        Assert.assertTrue("test exclusion".equals(found.getBuyerExclusionReason()));
        Assert.assertTrue("TEST_CODE".equals(found.getBuyerExclusionReasonCode()));
        Assert.assertEquals(0, found.getActioningQty().intValue());

        Assert.assertNotNull(p.getLastRowsMatched());
        Assert.assertEquals((Integer) 1, p.getLastRowsMatched());

        dao.deleteNotRunExclusionDefinitions(14, AmazonOrg.US);
    }

    @Test
    public void testExecuteInValidStartEndDatesInFuture() {
        ExclusionDefinition ed = dao.save(ExclusionHibernateDAOTest.newExclusionDefinition(AmazonOrg.US, 14, DateUtils
                .add(DateUtils.lastSaturday(), 7, 0, 0), DateUtils.add(DateUtils.lastSaturday(), 17, 0, 0),
                "test exclusion", "( vendor = 'DATE2' )", "TEST_CODE", 1, null, "YES"));
        BuyerUnhealthyDetail b = ExclusionHibernateDAOTest.newBuyerUnhealthyDetail("0000000000", "DATE2", AmazonOrg.US,
                DateUtils.lastSunday(), 14, "9", "Return");
        BuyerUnhealthyDetail saved = daoU.save(b);

        executor.executeExclusions(AmazonOrg.US, 14, DateUtils.lastSunday(), "test", null);
        ExclusionDefinition p = dao.find(ed.getId());
        BuyerUnhealthyDetail found = daoU.find(saved.getId());
        Assert.assertNotNull(found);
        Assert.assertEquals(1, found.getActioningQty().intValue());

        Assert.assertNotNull(p.getLastRowsMatched());
        Assert.assertEquals((Integer) 0, p.getLastRowsMatched());

        dao.deleteNotRunExclusionDefinitions(14, AmazonOrg.US);
    }

    @Test
    public void testExecuteInValidStartEndDatesInPast() {
        ExclusionDefinition ed = dao.save(ExclusionHibernateDAOTest.newExclusionDefinition(AmazonOrg.US, 14, DateUtils
                .add(DateUtils.lastSaturday(), -20, 0, 0), DateUtils.add(DateUtils.lastSaturday(), -10, 0, 0),
                "test exclusion", "( vendor = 'DATE1' )", "TEST_CODE", 1, null, "YES"));
        BuyerUnhealthyDetail b = ExclusionHibernateDAOTest.newBuyerUnhealthyDetail("0000000000", "DATE1", AmazonOrg.US,
                DateUtils.lastSunday(), 14, "9", "Return");
        BuyerUnhealthyDetail saved = daoU.save(b);

        executor.executeExclusions(AmazonOrg.US, 14, DateUtils.lastSunday(), "test", null);
        ExclusionDefinition p = dao.find(ed.getId());
        BuyerUnhealthyDetail found = daoU.find(saved.getId());
        Assert.assertNotNull(found);
        Assert.assertEquals(1, found.getActioningQty().intValue());

        Assert.assertNotNull(p.getLastRowsMatched());
        Assert.assertEquals((Integer) 0, p.getLastRowsMatched());

        dao.deleteNotRunExclusionDefinitions(14, AmazonOrg.US);
    }

    @Test
    public void testValidateWhereClause() {
        boolean valid = dao.validateWhereClause(14, AmazonOrg.US, "( vendor = 'PONY' )");
        Assert.assertTrue(valid);

        boolean notValid = dao.validateWhereClause(14, AmazonOrg.US, "( a blarfsnag )");
        Assert.assertFalse(notValid);
    }

    @Test
    public void testDeleteExclusions() {
        dao.save(ExclusionHibernateDAOTest.newExclusionDefinition(AmazonOrg.US, 14, null, null, "test1",
                "( vendor = 'PONY' )", "TEST_CODE1", 1, null, "YES"));
        dao.save(ExclusionHibernateDAOTest.newExclusionDefinition(AmazonOrg.US, 14, null, null, "test2",
                "( vendor = 'PONY' )", "TEST_CODE2", 2, null, "YES"));
        dao.save(ExclusionHibernateDAOTest.newExclusionDefinition(AmazonOrg.US, 15, null, null, "test3",
                "( vendor = 'PONY' )", "TEST_CODE3", 3, null, "YES"));
        dao.save(ExclusionHibernateDAOTest.newExclusionDefinition(AmazonOrg.CA, 14, null, null, "test4",
                "( vendor = 'PONY' )", "TEST_CODE4", 4, null, "YES"));

        dao.deleteNotRunExclusionDefinitions(14, AmazonOrg.US);
        Iterator<ExclusionDefinition> iter;

        iter = dao.downloadExclusion(14, AmazonOrg.US);
        Assert.assertFalse(iter.hasNext());

        iter = dao.downloadExclusion(15, AmazonOrg.US);
        Assert.assertTrue(iter.hasNext());

        iter = dao.downloadExclusion(14, AmazonOrg.CA);
        Assert.assertTrue(iter.hasNext());

    }

    @Test
    public void testFindConfiguredGLs() {
        dao.save(ExclusionHibernateDAOTest.newExclusionDefinition(AmazonOrg.US, 14, null, null, "test1",
                "( vendor = 'PONY' )", "TEST_CODE1", 1, null, "YES"));
        dao.save(ExclusionHibernateDAOTest.newExclusionDefinition(AmazonOrg.US, 14, null, null, "test2",
                "( vendor = 'PONY' )", "TEST_CODE2", 2, null, "YES"));
        dao.save(ExclusionHibernateDAOTest.newExclusionDefinition(AmazonOrg.US, 15, null, null, "test3",
                "( vendor = 'PONY' )", "TEST_CODE3", 3, null, "YES"));
        dao.save(ExclusionHibernateDAOTest.newExclusionDefinition(AmazonOrg.CA, 14, null, null, "test4",
                "( vendor = 'PONY' )", "TEST_CODE4", 4, null, "YES"));

        List<Integer> gls = dao.findConfiguredGLs(AmazonOrg.CA);

        Assert.assertEquals("Expect 1 gl", 1, gls.size());

        Assert.assertEquals("Expect gl 14", 14, gls.get(0).intValue());
    }

    @Test
    public void testChangeRTNoDates() {
        dao.deleteNotRunExclusionDefinitions(14, AmazonOrg.US);
        dao.save(ExclusionHibernateDAOTest.newExclusionDefinition(AmazonOrg.US, 14, null, null, "test1",
                "( vendor = 'PONY' )", "TEST_CODE1", 1, "Liquidate", "NO"));

        BuyerUnhealthyDetail b = ExclusionHibernateDAOTest.newBuyerUnhealthyDetail("0000000000", "PONY", AmazonOrg.US,
                DateUtils.lastSunday(), 14, "9", "Return");

        daoU.save(b);
        executor.executeExclusions(AmazonOrg.US, 14, null, "isaacUser", null);
        b = daoU.find(b.getId());
        Assert.assertEquals("Actioning quantity is the same", 1, b.getActioningQty().intValue());
        Assert.assertEquals("Removal type has changed ", "Liquidate", b.getRemovalType());
        Assert.assertEquals("Recommended rt has not changed", "Return", b.getRecommendedRemovalType());
        Assert.assertEquals("Reason is set", "test1", b.getBuyerExclusionReason());
        Assert.assertEquals("Reason Code is set", "TEST_CODE1", b.getBuyerExclusionReasonCode());
    }

    @Test
    public void testChangeRTWithDates() {
        Calendar c = Calendar.getInstance();
        c.set(2010, 0, 1);
        Date start = c.getTime();
        c.set(2010, 1, 1);
        Date end = c.getTime();
        c.set(2010, 0, 15);
        Date runDate = c.getTime();
        dao.deleteNotRunExclusionDefinitions(14, AmazonOrg.US);
        dao.save(ExclusionHibernateDAOTest.newExclusionDefinition(AmazonOrg.US, 14, start, end, "test1",
                "( vendor = 'PONY' )", "TEST_CODE1", 1, "Liquidate", "NO"));

        BuyerUnhealthyDetail b = ExclusionHibernateDAOTest.newBuyerUnhealthyDetail("0000000000", "PONY", AmazonOrg.US,
                runDate, 14, "9", "Return");

        daoU.save(b);
        executor.executeExclusions(AmazonOrg.US, 14, null, "isaacUser", null);
        b = daoU.find(b.getId());
        Assert.assertEquals("Actioning quantity is the same", 1, b.getActioningQty().intValue());
        Assert.assertEquals("Removal type has changed ", "Liquidate", b.getRemovalType());
        Assert.assertEquals("Recommended rt has not changed", "Return", b.getRecommendedRemovalType());
        Assert.assertEquals("Reason is set", "test1", b.getBuyerExclusionReason());
        Assert.assertEquals("Reason Code is set", "TEST_CODE1", b.getBuyerExclusionReasonCode());
    }

    @Test
    public void testWithDatesOutOfRangeRT() {
        Calendar c = Calendar.getInstance();
        c.set(2010, 0, 1);
        Date start = c.getTime();
        c.set(2010, 1, 1);
        Date end = c.getTime();
        c.set(2010, 3, 15);
        Date runDate = c.getTime();
        dao.deleteNotRunExclusionDefinitions(14, AmazonOrg.US);
        dao.save(ExclusionHibernateDAOTest.newExclusionDefinition(AmazonOrg.US, 14, start, end, "test1",
                "( vendor = 'PONY' )", "TEST_CODE1", 1, "Liquidate", "NO"));

        BuyerUnhealthyDetail b = ExclusionHibernateDAOTest.newBuyerUnhealthyDetail("0000000000", "PONY", AmazonOrg.US,
                runDate, 14, "9", "Return");

        daoU.save(b);
        executor.executeExclusions(AmazonOrg.US, 14, null, "isaacUser", null);
        b = daoU.find(b.getId());
        Assert.assertEquals("Actioning quantity is the same", 1, b.getActioningQty().intValue());
        Assert.assertEquals("Removal type has changed ", "Return", b.getRemovalType());
        Assert.assertEquals("Recommended rt has not changed", "Return", b.getRecommendedRemovalType());
        Assert.assertNull("Reason is set", b.getBuyerExclusionReason());
        Assert.assertNull("Reason Code is set", b.getBuyerExclusionReasonCode());
    }

    @Test
    public void testChangeAQNoDates() {
        dao.deleteNotRunExclusionDefinitions(14, AmazonOrg.US);
        dao.save(ExclusionHibernateDAOTest.newExclusionDefinition(AmazonOrg.US, 14, null, null, "test1",
                "( vendor = 'PONY' )", "TEST_CODE1", 1, null, "YES"));

        BuyerUnhealthyDetail b = ExclusionHibernateDAOTest.newBuyerUnhealthyDetail("0000000000", "PONY", AmazonOrg.US,
                DateUtils.lastSunday(), 14, "9", "Return");

        daoU.save(b);
        executor.executeExclusions(AmazonOrg.US, 14, null, "isaacUser", null);
        b = daoU.find(b.getId());
        Assert.assertEquals("Actioning quantity is the same", 0, b.getActioningQty().intValue());
        Assert.assertEquals("Removal type has changed ", "Return", b.getRemovalType());
        Assert.assertEquals("Recommended rt has not changed", "Return", b.getRecommendedRemovalType());
        Assert.assertEquals("Reason is set", "test1", b.getBuyerExclusionReason());
        Assert.assertEquals("Reason Code is set", "TEST_CODE1", b.getBuyerExclusionReasonCode());
    }

    @Test
    public void testChangeAQWithDates() {
        Calendar c = Calendar.getInstance();
        c.set(2010, 0, 1);
        Date start = c.getTime();
        c.set(2010, 1, 1);
        Date end = c.getTime();
        c.set(2010, 0, 15);
        Date runDate = c.getTime();
        dao.deleteNotRunExclusionDefinitions(14, AmazonOrg.US);
        dao.save(ExclusionHibernateDAOTest.newExclusionDefinition(AmazonOrg.US, 14, start, end, "test1",
                "( vendor = 'PONY' )", "TEST_CODE1", 1, null, "YES"));

        BuyerUnhealthyDetail b = ExclusionHibernateDAOTest.newBuyerUnhealthyDetail("0000000000", "PONY", AmazonOrg.US,
                runDate, 14, "9", "Return");

        daoU.save(b);
        executor.executeExclusions(AmazonOrg.US, 14, null, "isaacUser", null);
        b = daoU.find(b.getId());
        Assert.assertEquals("Actioning quantity is the same", 0, b.getActioningQty().intValue());
        Assert.assertEquals("Removal type has changed ", "Return", b.getRemovalType());
        Assert.assertEquals("Recommended rt has not changed", "Return", b.getRecommendedRemovalType());
        Assert.assertEquals("Reason is set", "test1", b.getBuyerExclusionReason());
        Assert.assertEquals("Reason Code is set", "TEST_CODE1", b.getBuyerExclusionReasonCode());
    }

    @Test
    public void testWithDatesOutOfRangeAQ() {
        Calendar c = Calendar.getInstance();
        c.set(2010, 0, 1);
        Date start = c.getTime();
        c.set(2010, 1, 1);
        Date end = c.getTime();
        c.set(2010, 3, 15);
        Date runDate = c.getTime();
        dao.deleteNotRunExclusionDefinitions(14, AmazonOrg.US);
        dao.save(ExclusionHibernateDAOTest.newExclusionDefinition(AmazonOrg.US, 14, start, end, "test1",
                "( vendor = 'PONY' )", "TEST_CODE1", 1, null, "YES"));

        BuyerUnhealthyDetail b = ExclusionHibernateDAOTest.newBuyerUnhealthyDetail("0000000000", "PONY", AmazonOrg.US,
                runDate, 14, "9", "Return");

        daoU.save(b);
        executor.executeExclusions(AmazonOrg.US, 14, null, "isaacUser", null);
        b = daoU.find(b.getId());
        Assert.assertEquals("Actioning quantity is the same", 1, b.getActioningQty().intValue());
        Assert.assertEquals("Removal type has changed ", "Return", b.getRemovalType());
        Assert.assertEquals("Recommended rt has not changed", "Return", b.getRecommendedRemovalType());
        Assert.assertNull("Reason is set", b.getBuyerExclusionReason());
        Assert.assertNull("Reason Code is set", b.getBuyerExclusionReasonCode());
    }

    @Test
    public void testMultipleWithRt() {
        dao.deleteNotRunExclusionDefinitions(14, AmazonOrg.US);
        List<BuyerUnhealthyDetail> buList = new ArrayList<BuyerUnhealthyDetail>(3);
        ExclusionDefinition higherPrecedenceExclusion = dao.save(ExclusionHibernateDAOTest
                .newExclusionDefinition(AmazonOrg.US, 14, null, null, "higher", "( vendor = 'PONY' )",
                        "TEST_CODE_HIGHER", 1, "Liquidate", "NO"));
        ExclusionDefinition lowerPrecedenceExclusion = dao.save(ExclusionHibernateDAOTest.newExclusionDefinition(
                AmazonOrg.US, 14, null, null, "lower", "( vendor = 'PONY' )", "TEST_CODE_LOWER", 2, "markdown", "NO"));

        buList.add(daoU.save(ExclusionHibernateDAOTest.newBuyerUnhealthyDetail("0000000000", "PONY", AmazonOrg.US,
                DateUtils.lastSunday(), 14, "9", "Return")));
        buList.add(daoU.save(ExclusionHibernateDAOTest.newBuyerUnhealthyDetail("0000000001", "PONY", AmazonOrg.US,
                DateUtils.lastSunday(), 14, "9", "Return")));
        buList.add(daoU.save(ExclusionHibernateDAOTest.newBuyerUnhealthyDetail("0000000002", "PONY", AmazonOrg.US,
                DateUtils.lastSunday(), 14, "9", "Return")));
        BuyerUnhealthyDetail notExcluded = daoU.save(ExclusionHibernateDAOTest.newBuyerUnhealthyDetail("0000002340",
                "SONY", AmazonOrg.US, DateUtils.lastSunday(), 14, "9", "Return"));

        executor.executeExclusions(AmazonOrg.US, 14, DateUtils.lastSunday(), "test", null);
        ExclusionDefinition lower = dao.find(lowerPrecedenceExclusion.getId());
        ExclusionDefinition higher = dao.find(higherPrecedenceExclusion.getId());

        // lower rule should match 0 records
        Assert.assertNotNull(lower.getLastRowsMatched());
        Assert.assertEquals((Integer) 0, lower.getLastRowsMatched());

        // higher rule should match 3 records
        Assert.assertNotNull(higher.getLastRowsMatched());
        Assert.assertEquals((Integer) 3, higher.getLastRowsMatched());

        // check that the exclusion reason, reason code, and actioning qty are set correctly
        BuyerUnhealthyDetail found = null;
        for (BuyerUnhealthyDetail b : buList) {
            found = daoU.find(b.getId());
            Assert.assertNotNull(found);
            Assert.assertTrue("higher".equals(found.getBuyerExclusionReason()));
            Assert.assertTrue("TEST_CODE_HIGHER".equals(found.getBuyerExclusionReasonCode()));
            Assert.assertEquals(1, found.getActioningQty().intValue());
            Assert.assertEquals("Liquidate", found.getRemovalType());
            Assert.assertEquals("Return", found.getRecommendedRemovalType());
        }

        // make sure that the 4th record is not excluded by checking removal type
        Assert.assertEquals("Return", notExcluded.getRemovalType());
        Assert.assertEquals(1, notExcluded.getActioningQty().intValue());
    }

    @Test
    public void testResetOfUnhealthyDetails() {
        dao.deleteNotRunExclusionDefinitions(14, AmazonOrg.US);
        List<BuyerUnhealthyDetail> buList = new ArrayList<BuyerUnhealthyDetail>(3);
        ExclusionDefinition higherPrecedenceExclusion = dao.save(ExclusionHibernateDAOTest.newExclusionDefinition(
                AmazonOrg.US, 14, null, null, "higher", "( removalType = 'Return' )", "TEST_CODE_HIGHER", 1,
                "Liquidate", "NO"));
        ExclusionDefinition lowerPrecedenceExclusion = dao
                .save(ExclusionHibernateDAOTest.newExclusionDefinition(AmazonOrg.US, 14, null, null, "lower",
                        "( removalType = 'Return' )", "TEST_CODE_LOWER", 2, null, "YES"));

        buList.add(daoU.save(ExclusionHibernateDAOTest.newBuyerUnhealthyDetail("0000000000", "PONY", AmazonOrg.US,
                DateUtils.lastSunday(), 14, "9", "Return")));
        buList.add(daoU.save(ExclusionHibernateDAOTest.newBuyerUnhealthyDetail("0000000001", "PONY", AmazonOrg.US,
                DateUtils.lastSunday(), 14, "9", "Return")));
        buList.add(daoU.save(ExclusionHibernateDAOTest.newBuyerUnhealthyDetail("0000000002", "PONY", AmazonOrg.US,
                DateUtils.lastSunday(), 14, "9", "Return")));
        BuyerUnhealthyDetail notExcluded = daoU.save(ExclusionHibernateDAOTest.newBuyerUnhealthyDetail("0000002340",
                "SONY", AmazonOrg.US, DateUtils.lastSunday(), 14, "9", "Liquidate"));

        executor.executeExclusions(AmazonOrg.US, 14, DateUtils.lastSunday(), "test", null);
        ExclusionDefinition lower = dao.find(lowerPrecedenceExclusion.getId());
        ExclusionDefinition higher = dao.find(higherPrecedenceExclusion.getId());

        // lower rule should match 0 records
        Assert.assertNotNull(lower.getLastRowsMatched());
        Assert.assertEquals((Integer) 0, lower.getLastRowsMatched());

        // higher rule should match 3 records
        Assert.assertNotNull(higher.getLastRowsMatched());
        Assert.assertEquals((Integer) 3, higher.getLastRowsMatched());

        // check that the exclusion reason, reason code, and actioning qty are set correctly
        BuyerUnhealthyDetail found = null;
        for (BuyerUnhealthyDetail b : buList) {
            found = daoU.find(b.getId());
            Assert.assertNotNull(found);
            Assert.assertTrue("higher".equals(found.getBuyerExclusionReason()));
            Assert.assertTrue("TEST_CODE_HIGHER".equals(found.getBuyerExclusionReasonCode()));
            Assert.assertEquals(1, found.getActioningQty().intValue());
            Assert.assertEquals("Liquidate", found.getRemovalType());
            Assert.assertEquals("Return", found.getRecommendedRemovalType());
        }

        // make sure that the 4th record is not excluded by checking removal type
        Assert.assertEquals("Liquidate", notExcluded.getRemovalType());
        Assert.assertEquals(1, notExcluded.getActioningQty().intValue());
    }

    @Test
    public void testResetOfUnhealthyDetails2() {
        dao.deleteNotRunExclusionDefinitions(14, AmazonOrg.US);
        List<BuyerUnhealthyDetail> buList = new ArrayList<BuyerUnhealthyDetail>(3);
        ExclusionDefinition higherPrecedenceExclusion = dao.save(ExclusionHibernateDAOTest.newExclusionDefinition(
                AmazonOrg.US, 14, null, null, "higher", "( removal_type = 'Return' )", "TEST_CODE_HIGHER", 1,
                "Liquidate", "NO"));
        ExclusionDefinition lowerPrecedenceExclusion = dao.save(ExclusionHibernateDAOTest
                .newExclusionDefinition(AmazonOrg.US, 14, null, null, "lower", "( removal_type = 'Return' )",
                        "TEST_CODE_LOWER", 2, null, "YES"));

        buList.add(daoU.save(ExclusionHibernateDAOTest.newBuyerUnhealthyDetail("0000000000", "PONY", AmazonOrg.US,
                DateUtils.lastSunday(), 14, "9", "Return")));
        buList.add(daoU.save(ExclusionHibernateDAOTest.newBuyerUnhealthyDetail("0000000001", "PONY", AmazonOrg.US,
                DateUtils.lastSunday(), 14, "9", "Return")));
        buList.add(daoU.save(ExclusionHibernateDAOTest.newBuyerUnhealthyDetail("0000000002", "PONY", AmazonOrg.US,
                DateUtils.lastSunday(), 14, "9", "Return")));
        BuyerUnhealthyDetail notExcluded = daoU.save(ExclusionHibernateDAOTest.newBuyerUnhealthyDetail("0000002340",
                "SONY", AmazonOrg.US, DateUtils.lastSunday(), 14, "9", "Liquidate"));

        executor.executeExclusions(AmazonOrg.US, 14, DateUtils.lastSunday(), "test", null);
        ExclusionDefinition lower = dao.find(lowerPrecedenceExclusion.getId());
        ExclusionDefinition higher = dao.find(higherPrecedenceExclusion.getId());

        // lower rule should match 0 records
        Assert.assertNotNull(lower.getLastRowsMatched());
        Assert.assertEquals((Integer) 0, lower.getLastRowsMatched());

        // higher rule should match 3 records
        Assert.assertNotNull(higher.getLastRowsMatched());
        Assert.assertEquals((Integer) 3, higher.getLastRowsMatched());

        // check that the exclusion reason, reason code, and actioning qty are set correctly
        BuyerUnhealthyDetail found = null;
        for (BuyerUnhealthyDetail b : buList) {
            found = daoU.find(b.getId());
            Assert.assertNotNull(found);
            Assert.assertTrue("higher".equals(found.getBuyerExclusionReason()));
            Assert.assertTrue("TEST_CODE_HIGHER".equals(found.getBuyerExclusionReasonCode()));
            Assert.assertEquals(1, found.getActioningQty().intValue());
            Assert.assertEquals("Liquidate", found.getRemovalType());
            Assert.assertEquals("Return", found.getRecommendedRemovalType());
        }

        // make sure that the 4th record is not excluded by checking removal type
        Assert.assertEquals("Liquidate", notExcluded.getRemovalType());
        Assert.assertEquals(1, notExcluded.getActioningQty().intValue());
    }

    @Test
    public void testResetsOutOfDateRange() {
        dao.deleteNotRunExclusionDefinitions(14, AmazonOrg.US);

        Calendar c = Calendar.getInstance();
        c.set(1982, 0, 1);
        Date start = c.getTime();
        c.set(1982, 1, 1);
        Date end = c.getTime();

        List<BuyerUnhealthyDetail> buList = new ArrayList<BuyerUnhealthyDetail>(3);
        ExclusionDefinition highestPrecedenceExclusion = dao.save(ExclusionHibernateDAOTest.newExclusionDefinition(
                AmazonOrg.US, 14, start, end, "highest", "( recommended_removal_type = 'Return' )", "TEST_CODE_HIGHER",
                1, "Liquidate", "NO"));
        ExclusionDefinition higherPrecedenceExclusion = dao.save(ExclusionHibernateDAOTest.newExclusionDefinition(
                AmazonOrg.US, 14, start, end, "higher", "( recommended_removal_type = 'Return' )", "TEST_CODE_HIGHER",
                2, "Liquidate", "NO"));
        ExclusionDefinition lowerPrecedenceExclusion = dao.save(ExclusionHibernateDAOTest.newExclusionDefinition(
                AmazonOrg.US, 14, null, null, "lower", "( recommended_removal_type = 'Return' )", "TEST_CODE_LOWER", 3,
                null, "YES"));
        ExclusionDefinition lowestPrecedenceExclusion = dao.save(ExclusionHibernateDAOTest.newExclusionDefinition(
                AmazonOrg.US, 14, null, null, "lowest", "( recommended_removal_type = 'Return' )", "TEST_CODE_LOWEST",
                4, "Markdown", "NO"));

        buList.add(daoU.save(ExclusionHibernateDAOTest.newBuyerUnhealthyDetail("0000000000", "PONY", AmazonOrg.US,
                DateUtils.lastSunday(), 14, "9", "Return")));
        buList.add(daoU.save(ExclusionHibernateDAOTest.newBuyerUnhealthyDetail("0000000001", "PONY", AmazonOrg.US,
                DateUtils.lastSunday(), 14, "9", "Return")));
        buList.add(daoU.save(ExclusionHibernateDAOTest.newBuyerUnhealthyDetail("0000000002", "PONY", AmazonOrg.US,
                DateUtils.lastSunday(), 14, "9", "Return")));
        BuyerUnhealthyDetail notExcluded = daoU.save(ExclusionHibernateDAOTest.newBuyerUnhealthyDetail("0000002340",
                "SONY", AmazonOrg.US, DateUtils.lastSunday(), 14, "9", "Liquidate"));

        executor.executeExclusions(AmazonOrg.US, 14, DateUtils.lastSunday(), "test", null);

        ExclusionDefinition lowest = dao.find(lowestPrecedenceExclusion.getId());
        ExclusionDefinition lower = dao.find(lowerPrecedenceExclusion.getId());
        ExclusionDefinition higher = dao.find(higherPrecedenceExclusion.getId());
        ExclusionDefinition highest = dao.find(highestPrecedenceExclusion.getId());

        // lowest should match 0 rows
        Assert.assertNotNull(lowest.getLastRowsMatched());
        Assert.assertEquals((Integer) 0, lowest.getLastRowsMatched());

        // lower should match 3 rows
        Assert.assertNotNull(lower.getLastRowsMatched());
        Assert.assertEquals((Integer) 3, lower.getLastRowsMatched());

        // higher and higest should match 0 rows
        Assert.assertNotNull(higher.getLastRowsMatched());
        Assert.assertEquals((Integer) 0, higher.getLastRowsMatched());

        Assert.assertNotNull(highest.getLastRowsMatched());
        Assert.assertEquals((Integer) 0, highest.getLastRowsMatched());

        // check that the exclusion reason, reason code, and actioning qty are set correctly
        BuyerUnhealthyDetail found = null;
        for (BuyerUnhealthyDetail b : buList) {
            found = daoU.find(b.getId());
            Assert.assertNotNull(found);
            Assert.assertTrue("lower".equals(found.getBuyerExclusionReason()));
            Assert.assertTrue("TEST_CODE_LOWER".equals(found.getBuyerExclusionReasonCode()));
            Assert.assertEquals(0, found.getActioningQty().intValue());
            Assert.assertEquals("Return", found.getRemovalType());
            Assert.assertEquals("Return", found.getRecommendedRemovalType());
        }

        // make sure that the 4th record is not excluded by checking removal type
        Assert.assertEquals("Liquidate", notExcluded.getRemovalType());
        Assert.assertEquals(1, notExcluded.getActioningQty().intValue());
    }

    @Test
    public void testClearExclusionsWithQty() {
        dao.deleteNotRunExclusionDefinitions(14, AmazonOrg.US);
        dao.save(ExclusionHibernateDAOTest.newExclusionDefinition(AmazonOrg.US, 14, null, null, "test1",
                "( vendor = 'PONY' )", "TEST_CODE1", 1, null, "YES"));

        BuyerUnhealthyDetail b = ExclusionHibernateDAOTest.newBuyerUnhealthyDetail("0000000000", "PONY", AmazonOrg.US,
                DateUtils.lastSunday(), 14, "9", "Return");

        daoU.save(b);
        executor.executeExclusions(AmazonOrg.US, 14, null, "isaacUser", null);
        b = daoU.find(b.getId());
        Assert.assertEquals("Actioning quantity is the same", 0, b.getActioningQty().intValue());
        Assert.assertEquals("Removal type has changed ", "Return", b.getRemovalType());
        Assert.assertEquals("Recommended rt has not changed", "Return", b.getRecommendedRemovalType());
        Assert.assertEquals("Reason is set", "test1", b.getBuyerExclusionReason());
        Assert.assertEquals("Reason Code is set", "TEST_CODE1", b.getBuyerExclusionReasonCode());
        dao.clearExclusions(14, AmazonOrg.US, null);
        b = daoU.find(b.getId());
        Assert.assertEquals("Actioning quantity is set to original", 1, b.getActioningQty().intValue());
        Assert.assertEquals("Removal type is set to original", "Return", b.getRemovalType());
        Assert.assertEquals("Recommended rt has not changed", "Return", b.getRecommendedRemovalType());
        Assert.assertEquals("Reason is cleared", "", b.getBuyerExclusionReason());
        Assert.assertEquals("Reason Code is cleared", "", b.getBuyerExclusionReasonCode());
    }

    
    public void testClearExclusionsWithRemovalType() {
        dao.deleteNotRunExclusionDefinitions(14, AmazonOrg.US);
        dao.save(ExclusionHibernateDAOTest.newExclusionDefinition(AmazonOrg.US, 14, null, null, "test1",
                "( vendor = 'PONY' )", "TEST_CODE1", 1, "Liquidate", "NO"));

        BuyerUnhealthyDetail b = ExclusionHibernateDAOTest.newBuyerUnhealthyDetail("0000000000", "PONY", AmazonOrg.US,
                DateUtils.lastSunday(), 14, "9", "Return");

        daoU.save(b);
        executor.executeExclusions(AmazonOrg.US, 14, null, "isaacUser", null);
        b = daoU.find(b.getId());
        Assert.assertEquals("Actioning quantity is the same", 1, b.getActioningQty().intValue());
        Assert.assertEquals("Removal type has changed ", "Liquidate", b.getRemovalType());
        Assert.assertEquals("Recommended rt has not changed", "Return", b.getRecommendedRemovalType());
        Assert.assertEquals("Reason is set", "test1", b.getBuyerExclusionReason());
        Assert.assertEquals("Reason Code is set", "TEST_CODE1", b.getBuyerExclusionReasonCode());
        dao.clearExclusions(14, AmazonOrg.US, null);
        b = daoU.find(b.getId());
        Assert.assertEquals("Actioning quantity is set to original", 1, b.getActioningQty().intValue());
        Assert.assertEquals("Removal type is set to original", "Return", b.getRemovalType());
        Assert.assertEquals("Recommended rt has not changed", "Return", b.getRecommendedRemovalType());
        Assert.assertEquals("Reason is cleared", "", b.getBuyerExclusionReason());
        Assert.assertEquals("Reason Code is cleared", "", b.getBuyerExclusionReasonCode());
    }

    @Test
    public void testResetExclusions() {
        dao.deleteNotRunExclusionDefinitions(14, AmazonOrg.US);
        List<BuyerUnhealthyDetail> buList = new ArrayList<BuyerUnhealthyDetail>(3);
        ExclusionDefinition higherPrecedenceExclusion = dao.save(ExclusionHibernateDAOTest
                .newExclusionDefinition(AmazonOrg.US, 14, null, null, "higher", "( vendor = 'PONY' )",
                        "TEST_CODE_HIGHER", 1, "Liquidate", "NO"));
        ExclusionDefinition lowerPrecedenceExclusion = dao.save(ExclusionHibernateDAOTest.newExclusionDefinition(
                AmazonOrg.US, 14, null, null, "lower", "( vendor = 'PONY' )", "TEST_CODE_LOWER", 2, "markdown", "NO"));

        buList.add(daoU.save(ExclusionHibernateDAOTest.newBuyerUnhealthyDetail("0000000000", "PONY", AmazonOrg.US,
                DateUtils.lastSunday(), 14, "9", "Return")));
        buList.add(daoU.save(ExclusionHibernateDAOTest.newBuyerUnhealthyDetail("0000000001", "PONY", AmazonOrg.US,
                DateUtils.lastSunday(), 14, "9", "Return")));
        buList.add(daoU.save(ExclusionHibernateDAOTest.newBuyerUnhealthyDetail("0000000002", "PONY", AmazonOrg.US,
                DateUtils.lastSunday(), 14, "9", "Return")));
        BuyerUnhealthyDetail notExcluded = daoU.save(ExclusionHibernateDAOTest.newBuyerUnhealthyDetail("0000002340",
                "SONY", AmazonOrg.US, DateUtils.lastSunday(), 14, "9", "Return"));

        executor.executeExclusions(AmazonOrg.US, 14, DateUtils.lastSunday(), "test", null);
        ExclusionDefinition lower = dao.find(lowerPrecedenceExclusion.getId());
        ExclusionDefinition higher = dao.find(higherPrecedenceExclusion.getId());

        // lower rule should match 0 records
        Assert.assertNotNull(lower.getLastRowsMatched());
        Assert.assertEquals((Integer) 0, lower.getLastRowsMatched());
        
        // higher rule should match 3 records
        Assert.assertNotNull(higher.getLastRowsMatched());
        Assert.assertEquals((Integer) 3, higher.getLastRowsMatched());

        // check that the exclusion reason, reason code, and actioning qty are set correctly
        BuyerUnhealthyDetail found = null;
        for (BuyerUnhealthyDetail b : buList) {
            found = daoU.find(b.getId());
            Assert.assertNotNull(found);
            Assert.assertTrue("higher".equals(found.getBuyerExclusionReason()));
            Assert.assertTrue("TEST_CODE_HIGHER".equals(found.getBuyerExclusionReasonCode()));
            Assert.assertEquals(1, found.getActioningQty().intValue());
            Assert.assertEquals("Liquidate", found.getRemovalType());
            Assert.assertEquals("Return", found.getRecommendedRemovalType());
        }

        // make sure that the 4th record is not excluded by checking removal type
        notExcluded = daoU.find(notExcluded.getId());
        Assert.assertEquals("Return", notExcluded.getRemovalType());
        Assert.assertEquals(1, notExcluded.getActioningQty().intValue());

        // force an update on the 4 th record
        notExcluded.setActioningQty(0);
        notExcluded.setBuyerExclusionReasonCode("Some Code");
        notExcluded.setBuyerExclusionReason("Some Code");
        daoU.save(notExcluded);

        // invoke reset
        executor.resetExclusions(AmazonOrg.US, 14, DateUtils.lastSunday(), "test", null);
        
        //verify the 4th record was not reset
        notExcluded = daoU.find(notExcluded.getId());
        Assert.assertEquals(0, notExcluded.getActioningQty().intValue());
        Assert.assertEquals("Some Code", notExcluded.getBuyerExclusionReasonCode());
        Assert.assertEquals("Some Code", notExcluded.getBuyerExclusionReason());
    }
    
    @Test
    public void testFindCBMExclusionByWhereClause() throws OihPersistenceException {
        dao.save(ExclusionHibernateDAOTest.newExclusionDefinition(AmazonOrg.US, 14, null, null, "test1",
                "( asin = 'ASIN1' ) AND (source_id = 'CBM')", "TEST_CODE1", 1, null, "YES"));
        dao.save(ExclusionHibernateDAOTest.newExclusionDefinition(AmazonOrg.US, 14, null, null, "test2",
                "( brand_code = 'brand1' ) AND (source_id = 'CBM')", "TEST_CODE2", 2, null, "YES"));
        dao.save(ExclusionHibernateDAOTest.newExclusionDefinition(AmazonOrg.US, 14, null, null, "test3",
                "( vendor = 'PONY' )", "TEST_CODE3", 3, null, "YES"));
        dao.save(ExclusionHibernateDAOTest.newExclusionDefinition(AmazonOrg.US, 14, null, null, "test4",
                "( asin = 'ASIN1' ) AND (brand_code = 'brand1')", "TEST_CODE4", 4, null, "YES"));
        dao.save(ExclusionHibernateDAOTest.newExclusionDefinition(AmazonOrg.US, 15, null, null, "test4",
                "( asin = 'ASIN2' ) AND (source_id = 'OIH') AND ( brand_code = 'brand1' )", "TEST_CODE4", 4, null, "YES"));
        dao.save(ExclusionHibernateDAOTest.newExclusionDefinition(AmazonOrg.US, 16, null, null, "test1",
                "( asin = 'ASIN2' ) AND (source_id = 'CBM')", "TEST_CODE1", 1, null, "YES", "Y"));
        
        List<String> whereClauses = new ArrayList<String>();
        whereClauses.add("asin = 'ASIN1'");
        whereClauses.add("brand_code = 'brand1'");
        List<ExclusionDefinition> exclusions = dao.findCBMExclusionByWhereClause(14, AmazonOrg.US, whereClauses);
        Assert.assertEquals(2, exclusions.size());
        
        whereClauses = new ArrayList<String>();
        whereClauses.add("asin = 'ASIN2'");
        whereClauses.add("brand_code = 'brand1'");
        exclusions = dao.findCBMExclusionByWhereClause(15, AmazonOrg.US, whereClauses);
        Assert.assertEquals(0, exclusions.size());
        exclusions = dao.findCBMExclusionByWhereClause(16, AmazonOrg.US, whereClauses);
        Assert.assertEquals(1, exclusions.size());
    }
    
    @Test
    public void testFindExclusions() {
    	ExclusionDefinition d1 = newExclusionDefinition(AmazonOrg.US, 14, null, null, "test1",
                "( vendor = 'PONY' )", "TEST_CODE1", 1, null, "YES");
    	d1.setIsRun(ExclusionDefinition.IsRunValue.Y.name());
    	ExclusionDefinition d2 = newExclusionDefinition(AmazonOrg.US, 14, null, null, "test2",
                "( vendor = 'PONY' )", "TEST_CODE2", 2, null, "YES");
    	d2.setIsRun(ExclusionDefinition.IsRunValue.Y.name());
    	ExclusionDefinition d3 = ExclusionHibernateDAOTest.newExclusionDefinition(AmazonOrg.US, 15, null, null, "test3",
                "( vendor = 'PONY' )", "TEST_CODE3", 3, null, "YES");
    	ExclusionDefinition d4 = newExclusionDefinition(AmazonOrg.CA, 14, null, null, "test4",
                "( vendor = 'PONY' )", "TEST_CODE4", 4, null, "YES");
        dao.save(d1);
        dao.save(d2);

        Iterator<ExclusionDefinition> iter;
        iter = dao.downloadExclusion(14, AmazonOrg.US);
        while(iter.hasNext()) {
        	ExclusionDefinition d = iter.next();
        	System.out.println(d);
        }
    }
    
    @Test
    public void testDeleteExclusionDefinitions() {
    	ExclusionDefinition d1 = newExclusionDefinition(AmazonOrg.US, 14, null, null, "test1",
                "( vendor = 'PONY' )", "TEST_CODE1", 1, null, "YES");
    	d1.setIsRun(ExclusionDefinition.IsRunValue.Y.name());
    	ExclusionDefinition d2 = newExclusionDefinition(AmazonOrg.US, 14, null, null, "test2",
                "( vendor = 'PONY' )", "TEST_CODE2", 2, null, "YES");
    	d2.setIsRun(ExclusionDefinition.IsRunValue.N.name());
    	ExclusionDefinition d3 = ExclusionHibernateDAOTest.newExclusionDefinition(AmazonOrg.US, 15, null, null, "test3",
                "( vendor = 'PONY' )", "TEST_CODE3", 3, null, "YES");
    	ExclusionDefinition d4 = newExclusionDefinition(AmazonOrg.CA, 14, null, null, "test4",
                "( vendor = 'PONY' )", "TEST_CODE4", 4, null, "YES");
        dao.save(d1);
        dao.save(d2);

        System.out.print("Before deleting:");
        Iterator<ExclusionDefinition> iter;
        iter = dao.findAllExclusionsIgnoreIsRunValue(14, AmazonOrg.US);
        while(iter.hasNext()) {
        	ExclusionDefinition d = iter.next();
        	System.out.println(d);
        }
        dao.deleteAllExclusionsIgnoreIsRunValue(14, AmazonOrg.US);
        System.out.print("After deleting:");
        iter = dao.findAllExclusionsIgnoreIsRunValue(14, AmazonOrg.US);
        while(iter.hasNext()) {
        	ExclusionDefinition d = iter.next();
        	System.out.println(d);
        }
        
    }
    
    @Test
    public void testGetExclusionCount() {
    	ExclusionDefinition d1 = newExclusionDefinition(AmazonOrg.US, 14, null, null, "test1",
                "( vendor = 'PONY' )", "TEST_CODE1", 1, null, "YES");
    	//d1.setIsRun(ExclusionDefinition.IsRunValue.Y.name());
    	ExclusionDefinition d2 = newExclusionDefinition(AmazonOrg.US, 14, null, null, "test2",
                "( vendor = 'PONY' )", "TEST_CODE2", 2, null, "YES");
    	d2.setIsRun(ExclusionDefinition.IsRunValue.Y.name());
    	ExclusionDefinition d3 = ExclusionHibernateDAOTest.newExclusionDefinition(AmazonOrg.US, 15, null, null, "test3",
                "( vendor = 'PONY' )", "TEST_CODE3", 3, null, "YES");
    	ExclusionDefinition d4 = newExclusionDefinition(AmazonOrg.CA, 14, null, null, "test4",
                "( vendor = 'PONY' )", "TEST_CODE4", 4, null, "YES");
        //dao.save(d1);
       // dao.save(d2);

        Integer ruleCount = dao.getTotalCountByOrgGl(AmazonOrg.US, 14);
        System.out.println(ruleCount);
    }
    
    @Test
    public void testUpdateExclusionStatusAfterRunnings() {
    	dao.deleteAllExclusionsIgnoreIsRunValue(14, AmazonOrg.US);
    	ExclusionDefinition d1 = newExclusionDefinition(AmazonOrg.US, 14, null, null, "test1",
                "( vendor = 'PONY' )", "TEST_CODE1", 1, null, "YES");
    	d1.setIsRun(ExclusionDefinition.IsRunValue.N.name());
    	ExclusionDefinition d2 = newExclusionDefinition(AmazonOrg.US, 14, null, null, "test2",
                "( vendor = 'PONY' )", "TEST_CODE2", 2, null, "YES");
    	d2.setIsRun(ExclusionDefinition.IsRunValue.Y.name());
    	ExclusionDefinition d3 = ExclusionHibernateDAOTest.newExclusionDefinition(AmazonOrg.US, 14, null, null, "test3",
                "( vendor = 'PONY' )", "TEST_CODE3", 3, null, "YES");
    	ExclusionDefinition d4 = newExclusionDefinition(AmazonOrg.CA, 14, null, null, "test4",
                "( vendor = 'PONY' )", "TEST_CODE4", 4, null, "YES");
        dao.save(d1);
        dao.save(d2);

        System.out.print("Before updating:");
        Iterator<ExclusionDefinition> iter;
        iter = dao.findAllExclusionsIgnoreIsRunValue(14, AmazonOrg.US);
        while(iter.hasNext()) {
        	ExclusionDefinition d = iter.next();
        	System.out.println(d);
        }
        dao.updateExclusionStatusAfterRunning(14, AmazonOrg.US);
        System.out.print("After updating:");
        iter = dao.findAllExclusionsIgnoreIsRunValue(14, AmazonOrg.US);
        while(iter.hasNext()) {
        	ExclusionDefinition d = iter.next();
        	System.out.println(d);
        }
        
    }
}
