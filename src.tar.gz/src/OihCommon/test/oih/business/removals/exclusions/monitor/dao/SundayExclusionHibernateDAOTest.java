package oih.business.removals.exclusions.monitor.dao;

import java.util.Date;
import java.util.List;
import java.util.Map;

import oih.business.AmazonOrg;
import oih.business.removals.exclusions.monitor.dao.SundayExclusionDefinition;
import oih.business.removals.exclusions.monitor.dao.SundayExclusionHibernateDAO;
import oih.business.removals.exclusions.ExclusionDAO;
import oih.business.removals.exclusions.ExclusionDefinition;
import oih.business.removals.exclusions.monitor.util.TestUtil;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.mortbay.log.Log;

public class SundayExclusionHibernateDAOTest {
    private SundayExclusionHibernateDAO sundayExclusionDao;
    private ExclusionDAO exclusionDao;
    
    @BeforeClass
    public static void theLogThe() {
        // Plz see http://tinyurl.com/a5zcel bullet 3, item 3 for more information on the method name
        Logger.getRootLogger().setLevel(Level.INFO);
    }

    @Before
    public void setup() {
        sundayExclusionDao = HibernateDAOTestUtil.getSundayExclusionDao();
        exclusionDao = HibernateDAOTestUtil.getExclusionDao();
    }

    public ExclusionDefinition newExclusion(
                     Integer gl, AmazonOrg org, String reason, Date startDate, 
                     Date endDate, Integer lastRows, String whereClause, Integer rulePosition,
                     String reasonCode, String overrideRemovalType, String clearActioningQty, 
                     String createdBy, Date createdDate, String isGlobal, String isRun){
        
        ExclusionDefinition exclusion = new ExclusionDefinition();
        exclusion.setGl(gl);
        exclusion.setOrg(org);
        exclusion.setReason(reason);
        exclusion.setStartDate(startDate);
        exclusion.setEndDate(endDate);
        exclusion.setLastRowsMatched(lastRows);
        exclusion.setWhereClause(whereClause);
        exclusion.setRulePosition(rulePosition);
        exclusion.setExclusionReasonCode(reasonCode);
        exclusion.setOverrideRemovalType(overrideRemovalType);
        exclusion.setClearActioningQuantity(clearActioningQty);
        exclusion.setCreatedBy(createdBy);
        exclusion.setCreatedDate(createdDate);
        exclusion.setIsGlobal(isGlobal);
        exclusion.setIsRun(isRun);
        return exclusion;
    }
    
    public SundayExclusionDefinition newSundayExclusion(
            Integer gl, AmazonOrg org, String reason, Date startDate, 
            Date endDate, Integer lastRows, String whereClause, Integer rulePosition,
            String reasonCode, String overrideRemovalType, String clearActioningQty, 
            String createdBy, Date createdDate, String isGlobal, Date rundate){

        SundayExclusionDefinition sundayExclusion = new SundayExclusionDefinition();
        sundayExclusion.setGl(gl);
        sundayExclusion.setOrg(org);
        sundayExclusion.setReason(reason);
        sundayExclusion.setStartDate(startDate);
        sundayExclusion.setEndDate(endDate);
        sundayExclusion.setLastRowsMatched(lastRows);
        sundayExclusion.setWhereClause(whereClause);
        sundayExclusion.setRulePosition(rulePosition);
        sundayExclusion.setExclusionReasonCode(reasonCode);
        sundayExclusion.setOverrideRemovalType(overrideRemovalType);
        sundayExclusion.setClearActioningQuantity(clearActioningQty);
        sundayExclusion.setCreatedBy(createdBy);
        sundayExclusion.setCreatedDate(createdDate);
        sundayExclusion.setIsGlobal(isGlobal);
        sundayExclusion.setRundate(rundate);
        return sundayExclusion;
    }
    
    public void generateExclusionData1() {
        Integer gl = 14;
        AmazonOrg org = AmazonOrg.US;
        String reason = "testReason2";
        Date startDate = TestUtil.convertToDate("2014-07-02");
        Date endDate = TestUtil.convertToDate("2014-07-31");
        Integer lastRows = 2;
        String whereClause = "testClause1";
        Integer rulePosition = 3;
        String reasonCode = "testReasonCode1";
        String overrideRemovalType = "TestOverride1";
        String clearActioningQty = "TestClearQty1";
        String createdBy = "lingwang2";
        Date createdDate = TestUtil.convertToDate("2014-07-02");
        String isGlobal = "N";
        String isRun = "N";
        ExclusionDefinition e = this.newExclusion(gl, org, reason, startDate, endDate, lastRows, 
                                whereClause, rulePosition, reasonCode, overrideRemovalType, 
                                clearActioningQty, createdBy, createdDate, isGlobal, isRun);
        exclusionDao.save(e);
    }
    
    public void generateExclusionData2() {
        Integer gl = 14;
        AmazonOrg org = AmazonOrg.US;
        String reason = "testReason2";
        //Date startDate = TestUtil.convertToDate("2014-07-02");
        Date endDate = TestUtil.convertToDate("2014-07-31");
        Date startDate = null;
        Integer lastRows = 1;
        //String whereClause = "testClause2";
        String whereClause = "";
        Integer rulePosition = 2;
        String reasonCode = "testReasonCode2";
        String overrideRemovalType = "TestOverride2";
        String clearActioningQty = "TestClearQty2";
        String createdBy = "lingwang1";
        Date createdDate = TestUtil.convertToDate("2014-07-01");
        String isGlobal = "N";
        String isRun = "N";
        ExclusionDefinition e = this.newExclusion(gl, org, reason, startDate, endDate, lastRows, 
                                whereClause, rulePosition, reasonCode, overrideRemovalType, 
                                clearActioningQty, createdBy, createdDate, isGlobal, isRun);
        exclusionDao.save(e);
    }
    
    public void generateSundayExclusionData1() {
        Integer gl = 14;
        AmazonOrg org = AmazonOrg.US;
        String reason = "testReason1";
        Date startDate = TestUtil.convertToDate("2014-07-02");
        Date endDate = TestUtil.convertToDate("2014-07-31");
        Integer lastRows = 1;
        String whereClause = "testClause1";
        Integer rulePosition = 2;
        String reasonCode = "testReasonCode1";
        String overrideRemovalType = "TestOverride1";
        String clearActioningQty = "TestClearQty1";
        String createdBy = "lingwang";
        Date createdDate = TestUtil.convertToDate("2014-07-01");
        String isGlobal = "N";
        Date rundate = TestUtil.convertToDate("2014-07-05");
        SundayExclusionDefinition e = this.newSundayExclusion(gl, org, reason, startDate, endDate, 
                            lastRows, whereClause, rulePosition, reasonCode, overrideRemovalType,
                            clearActioningQty, createdBy, createdDate, isGlobal, rundate);
        sundayExclusionDao.save(e);
    }
    
    public void generateTestTable() {
        this.generateExclusionData1();
        //this.generateExclusionData2();
        this.generateSundayExclusionData1();
    }
    
    @Test
    public void testFindIsStatus() {
        this.generateTestTable();
        try{
            Map<Integer, String> isRunStatus = sundayExclusionDao.findExclusionIsRunStatus(AmazonOrg.US);
            if(isRunStatus == null || isRunStatus.size() == 0)
                Log.info("No result");
            Log.info("Totally got " + isRunStatus.size() + " results.");
            for(Integer gl : isRunStatus.keySet()) {
                Log.info("gl:" + gl + ", status:" + isRunStatus.get(gl));
            }
        }catch(Exception e){
            e.printStackTrace();
            Log.info("Got exception:" + e.getMessage(), e);
        }
    }

    public List<ExclusionDefinition> findDeletedExclusions() {
        this.generateTestTable();
        Date rundate = TestUtil.convertToDate("2014-07-06");
        List<ExclusionDefinition> exclusions = null;
        try{
            exclusions = sundayExclusionDao.findDeletedExclusionsByOrgGl(rundate, AmazonOrg.CA, 14, "N");
            if(exclusions == null || exclusions.size() == 0)
                Log.info("No result");
            Log.info("Totally got " + exclusions.size() + " results.");
            for(int i = 0; i < exclusions.size(); i++) {
                Log.info("exclusion " + i + ":" + exclusions.get(i));
            }
        }catch(Exception e){
            e.printStackTrace();
            Log.info("Got exception:" + e.getMessage(), e);
        }
        return exclusions;
    }
    
    
    public void findAddedExclusions() {
        this.generateTestTable();
        Date rundate = TestUtil.convertToDate("2014-07-05");
        List<ExclusionDefinition> exclusions = null;
        try{
            exclusions 
                = sundayExclusionDao.findAddedExclusionsByOrgGl(rundate, AmazonOrg.US, 14, "N");
            if(exclusions == null || exclusions.size() == 0)
                Log.info("No result");
            Log.info("Totally got " + exclusions.size() + " results.");
            for(int i = 0; i < exclusions.size(); i++) {
                Log.info("exclusion " + i + ":" + exclusions.get(i));
            }
        }catch(Exception e){
            e.printStackTrace();
            Log.info("Got exception:" + e.getMessage(), e);
        }
    }
}
