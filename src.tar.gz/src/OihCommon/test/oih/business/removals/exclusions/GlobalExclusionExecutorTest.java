package oih.business.removals.exclusions;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;

import junit.framework.Assert;

import oih.business.AmazonOrg;
import oih.business.YesOrNo;
import oih.business.buyer.BuyerUnhealthyDetail;
import oih.business.buyer.BuyerUnhealthyDetailDAO;
import oih.business.buyer.BuyerUnhealthyDetailHibernateDAO;
import oih.business.removals.GlConfigDAO;

import org.hibernate.Transaction;
import org.hibernate.Session;
import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import testutils.BaseTestDaoSetup;

public class GlobalExclusionExecutorTest extends BaseTestDaoSetup{

    private static IGlobalExclusionDefinitionDAO dao = null;
    private static BuyerUnhealthyDetailDAO bdao = null;
    
    private final static SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    
    private static Date rundate = null;
    
    @BeforeClass
    public static void setup() throws ParseException {
        config.addResource("oih/business/buyer/BuyerUnhealthyDetail.hbm.xml");
        config.addResource("oih/business/buyer/BuyerUnhealthyDetailExpand.hbm.xml");
        config.addResource("oih/business/removals/exclusions/GlobalExclusionDefinition.hbm.xml");
        config.addResource("oih/business/removals/GlConfig.hbm.xml");
        sessionFactory = config.buildSessionFactory();
        
        dao = GlobalExclusionDefinitionDAO.getInstance();
        bdao = BuyerUnhealthyDetailHibernateDAO.getInstance();
        
        GlConfigDAO.getInstance().setSessionFactory(sessionFactory);
        dao.setSessionFactory(sessionFactory);
        bdao.setSessionFactory(sessionFactory);
        
        rundate = sdf.parse("2012-05-20");
        
    }
    
    @Before
    public void beforeCase() {
        GlobalExclusionExecutor.getInstance().setGlobalExclusionDefinitionDAO(dao);
        prepareData();
    }
    
    @After
    public void afterCase() {
        cleanBuyerUnhealthyDetails();
        cleanGlobalExclusionRules();
    }
    
    @Test
    public void testExecuteExclusions() {
        GlobalExclusionExecutor.getInstance().executeExclusions(
                AmazonOrg.US, 14, rundate, "unit", null);
        
        Iterator<GlobalExclusionDefinition> it = dao.findValidGlobalExclusions(AmazonOrg.US);
        
        while(it.hasNext()) {
            GlobalExclusionDefinition ged = it.next();
            if (ged.getRulePosition() == 0) {
                Assert.assertTrue(ged.getLastRowsMatched() == 2);
            } else {
                Assert.assertTrue(ged.getLastRowsMatched() == 0);
            }
        }
        
        Iterator<BuyerUnhealthyDetail> bit = bdao.findByOrgGl(AmazonOrg.US, 14);
        
        while(bit.hasNext()) {
            BuyerUnhealthyDetail bud = bit.next();
            if (bud.getOnMarkdown()) {
                Assert.assertEquals("Liquidate", bud.getRemovalType());
                Assert.assertEquals("GlobalExclusion1", bud.getBuyerExclusionReason());
                Assert.assertTrue(bud.getActioningQty() == 2);
            }else {
                Assert.assertEquals("Return", bud.getRemovalType());
                Assert.assertEquals("0000000003", bud.getAsin());
                Assert.assertTrue(bud.getActioningQty() == 2);
            }   
        }
        
        Iterator<BuyerUnhealthyDetail> bit15 = bdao.findByOrgGl(AmazonOrg.US, 15);
        while(bit15.hasNext()) {
            BuyerUnhealthyDetail bud = bit15.next();
            Assert.assertEquals("Return", bud.getRemovalType());
            Assert.assertTrue(bud.getActioningQty() == 2);   
        }
    }
    
    @Test
    public void testExecuteExclusionsForOrg() {
        GlobalExclusionExecutor.getInstance().executeExclusionsForOrg(
                AmazonOrg.US, rundate, "unit", null);
        
        Iterator<GlobalExclusionDefinition> it = dao.findValidGlobalExclusions(AmazonOrg.US);
        while(it.hasNext()) {
            GlobalExclusionDefinition ged = it.next();
            if (ged.getRulePosition() == 0) {
                Assert.assertTrue(ged.getLastRowsMatched() == 4);
            } else {
                Assert.assertTrue(ged.getLastRowsMatched() == 0);
            }
        }
        
        Iterator<BuyerUnhealthyDetail> bit14 = bdao.findByOrgGl(AmazonOrg.US, 14);
        Iterator<BuyerUnhealthyDetail> bit15 = bdao.findByOrgGl(AmazonOrg.US, 15);
        while(bit14.hasNext()) {
            BuyerUnhealthyDetail bud = bit14.next();
            if (bud.getOnMarkdown()) {
                Assert.assertEquals("Liquidate", bud.getRemovalType());
                Assert.assertEquals("GlobalExclusion1", bud.getBuyerExclusionReason());
                Assert.assertTrue(bud.getActioningQty() == 2);
            }else {
                Assert.assertEquals("Return", bud.getRemovalType());
                Assert.assertEquals("0000000003", bud.getAsin());
                Assert.assertTrue(bud.getActioningQty() == 2);
            }   
        }
        
        while(bit15.hasNext()) {
            BuyerUnhealthyDetail bud = bit15.next();
            if (bud.getOnMarkdown()) {
                Assert.assertEquals("Liquidate", bud.getRemovalType());
                Assert.assertEquals("GlobalExclusion1", bud.getBuyerExclusionReason());
                Assert.assertTrue(bud.getActioningQty() == 2);
            }else {
                Assert.assertEquals("Return", bud.getRemovalType());
                Assert.assertEquals("0000000003", bud.getAsin());
                Assert.assertTrue(bud.getActioningQty() == 2);
            }   
        }       
    }
    
    @Test
    public void testResetExclusions() {
        GlobalExclusionExecutor.getInstance().resetExclusions(
                AmazonOrg.US, 14, rundate, "unit", null);
        Iterator<BuyerUnhealthyDetail> bit14 = bdao.findByOrgGl(AmazonOrg.US, 14);
        Iterator<BuyerUnhealthyDetail> bit15 = bdao.findByOrgGl(AmazonOrg.US, 15);
        
        while(bit14.hasNext()) {
            BuyerUnhealthyDetail bud = bit14.next();
            Assert.assertEquals("Return", bud.getRemovalType());
            if (bud.getOnMarkdown()){
                Assert.assertTrue(4 == bud.getActioningQty());   
            } else {
                Assert.assertTrue(2 == bud.getActioningQty());   
            }       
        }
        
        while(bit15.hasNext()) {
            BuyerUnhealthyDetail bud = bit15.next();
            Assert.assertEquals("Return", bud.getRemovalType());
            Assert.assertTrue(bud.getActioningQty() == 2);   
        }
    }
    
    @Test
    public void testResetExclusionsForOrg () {
        GlobalExclusionExecutor.getInstance().resetExclusionsForOrg(
                AmazonOrg.US, rundate, "unit", null);
        Iterator<BuyerUnhealthyDetail> bit14 = bdao.findByOrgGl(AmazonOrg.US, 14);
        Iterator<BuyerUnhealthyDetail> bit15 = bdao.findByOrgGl(AmazonOrg.US, 15);
        
        while(bit14.hasNext()) {
            BuyerUnhealthyDetail bud = bit14.next();
            Assert.assertEquals("Return", bud.getRemovalType());
            if (bud.getOnMarkdown()){
                Assert.assertTrue(4 == bud.getActioningQty());   
            } else {
                Assert.assertTrue(2 == bud.getActioningQty());   
            } 
        }
        
        while(bit15.hasNext()) {
            BuyerUnhealthyDetail bud = bit15.next();
            Assert.assertEquals("Return", bud.getRemovalType());
            if (bud.getOnMarkdown()){
                Assert.assertTrue(4 == bud.getActioningQty());   
            } else {
                Assert.assertTrue(2 == bud.getActioningQty());   
            }
        }
    }
    
    private static void prepareData() {
        GlobalExclusionDefinition ged = new GlobalExclusionDefinition();
        setBasicGlobalExclusionInfo(ged);
        ged.setClearActioningQuantity(YesOrNo.NO);
        ged.setLastRowsMatched(10);
        ged.setRulePosition(0);
        ged.setWhereClause("is_on_markdown='Y'");
        ged.setOverrideRemovalType("Liquidate");
        ged.setExclusionReason("GlobalExclusion1");
        
        dao.saveGlobalExclusion(ged);
        
        ged = new GlobalExclusionDefinition();
        setBasicGlobalExclusionInfo(ged);
        ged.setClearActioningQuantity(YesOrNo.YES);
        ged.setLastRowsMatched(8);
        ged.setRulePosition(1);
        ged.setWhereClause("is_on_markdown='Y'");
        ged.setExclusionReason("GlobalExclusion2");
        
        dao.saveGlobalExclusion(ged);
        
        BuyerUnhealthyDetail bud = new BuyerUnhealthyDetail();
        setBasicBuyerUnhealthyDetailInfo(bud);
        bud.setAsin("0000000001");
        bud.setOnMarkdown(true);
        bdao.save(bud);
        
        bud = new BuyerUnhealthyDetail();
        setBasicBuyerUnhealthyDetailInfo(bud);
        bud.setAsin("0000000002");
        bud.setOnMarkdown(true);
        bdao.save(bud);
        
        bud = new BuyerUnhealthyDetail();
        setBasicBuyerUnhealthyDetailInfo(bud);
        bud.setAsin("0000000003");
        bud.setOnMarkdown(false);
        bdao.save(bud);
        
        bud = new BuyerUnhealthyDetail();
        setBasicBuyerUnhealthyDetailInfo(bud);
        bud.setAsin("0000000001");
        bud.setGl(15);
        bud.setOnMarkdown(true);
        bdao.save(bud);
        
        bud = new BuyerUnhealthyDetail();
        setBasicBuyerUnhealthyDetailInfo(bud);
        bud.setAsin("0000000002");
        bud.setGl(15);
        bud.setOnMarkdown(true);
        bdao.save(bud);
        
        bud = new BuyerUnhealthyDetail();
        setBasicBuyerUnhealthyDetailInfo(bud);
        bud.setAsin("0000000003");
        bud.setGl(15);
        bud.setOnMarkdown(false);
        bdao.save(bud);
    }
    
    private void cleanBuyerUnhealthyDetails() {
        Session s = bdao.getSessionFactory().openSession();
        Transaction tx = s.beginTransaction();
        try {
            int count = s.createQuery("delete from BuyerUnhealthyDetail").executeUpdate();
            Assert.assertTrue(count == 6);
            tx.commit();
        } catch (Exception e) {
            tx.rollback();
            e.printStackTrace();
        } finally {
            if (s != null)
                s.close();
        }
    }
    
    private void cleanGlobalExclusionRules() {
        Session s = dao.getSessionFactory().openSession();
        Transaction tx = s.beginTransaction();
        try {
            int count = s.createQuery("delete from GlobalExclusionDefinition").executeUpdate();
            Assert.assertTrue(count == 2);
            tx.commit();
        } catch (Exception e) {
            tx.rollback();
            e.printStackTrace();
        } finally {
            if (s != null)
                s.close();
        }
    }
    
    private static void setBasicGlobalExclusionInfo(GlobalExclusionDefinition ged) {
        ged.setCreatedBy("nobody");
        ged.setCreatedDate(new Date());
        ged.setExclusionReasonCode("no");
        ged.setLastUpdatedBy("unit");
        ged.setLastUpdatedDate(new Date());
        ged.setOrg(AmazonOrg.US);
        ged.setOverrideRemovalType("");
        ged.setRangeId(null);
        ged.setIsValid(YesOrNo.YES);
    }
    
    private static void setBasicBuyerUnhealthyDetailInfo(BuyerUnhealthyDetail unhealthy) {       
        unhealthy.setBuyer("unit");
        unhealthy.setOrg(AmazonOrg.US);
        unhealthy.setGl(14);
        unhealthy.setIog(1);
        unhealthy.setUnhealthyQty(4);
        unhealthy.setVendor("unit");
        unhealthy.setStatus("OIH_ADDED");
        unhealthy.setExcludedVendor("excl");
        unhealthy.setRemovalType("Return");
        unhealthy.setCostUsedForCalc(5.0);
        unhealthy.setActioningQty(2);
        unhealthy.setIsBlockedAutomation(true);
        unhealthy.setRundate(rundate);
        unhealthy.setRecommendedRemovalType("Return");
    }
}
