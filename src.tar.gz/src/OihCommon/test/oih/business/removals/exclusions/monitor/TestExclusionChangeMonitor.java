package oih.business.removals.exclusions.monitor;

import java.util.Collections;
import java.util.Date;
import java.util.Map;
import java.util.List;
import java.util.ArrayList;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.junit.BeforeClass;
import org.junit.Test;
import org.mortbay.log.Log;

import oih.business.AmazonOrg;
import oih.business.removals.exclusions.monitor.ExclusionMonitorTestUtil;
import oih.business.removals.exclusions.monitor.ExclusionChangeMonitor;
import oih.business.removals.exclusions.monitor.util.TestUtil;
import oih.business.removals.exclusions.monitor.object.AutomationRateRecord;
import oih.business.removals.exclusions.monitor.object.ExclusionRecord;
import oih.business.removals.exclusions.monitor.dao.OihAutomationRate;
import oih.business.removals.exclusions.ExclusionDefinition;

public class TestExclusionChangeMonitor {
    @BeforeClass
    public static void theLogThe() {
        // Plz see http://tinyurl.com/a5zcel bullet 3, item 3 for more information on the method name
        Logger.getRootLogger().setLevel(Level.INFO);
    }
    static{ExclusionMonitorTestUtil.configEnv();}

    public Map<Integer, Double> testGetGlDistributions() {
        Date rundate = TestUtil.convertToDate("2014-08-08");
        Date executionDate = TestUtil.convertToDate("2014-08-08");
        try{
            ExclusionChangeMonitor monitor 
                = new ExclusionChangeMonitor(AmazonOrg.US, rundate, executionDate, null);
            Map<Integer, Double> glDistributions = monitor.getGlDistributions();
            if(glDistributions == null || glDistributions.size() == 0) {
                Log.info("No result.");
                return Collections.EMPTY_MAP;
            }
            for(Integer gl : glDistributions.keySet())
                Log.info("gl:" + gl + ", percentage:" + glDistributions.get(gl));
            return glDistributions;
        }catch(Exception e){
            e.printStackTrace();
        }
        return Collections.EMPTY_MAP;
    }

    public void testGetRunStatus() {
        Date rundate = TestUtil.convertToDate("2013-04-14");
        Date executionDate = TestUtil.convertToDate("2013-04-14");
        try{
            ExclusionChangeMonitor monitor 
                = new ExclusionChangeMonitor(AmazonOrg.US, rundate, executionDate, null);
            Map<Integer, String> glRunStatus = monitor.getGlExclusionRunStatus();
            if(glRunStatus == null || glRunStatus.size() == 0) {
                Log.info("No result.");
                return;
            }
            for(Integer gl : glRunStatus.keySet())
                Log.info("gl:" + gl + ", Run Status:" + glRunStatus.get(gl));
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    public void testGetSundayAutomationRates() {
        Date rundate = TestUtil.convertToDate("2014-08-08");
        Date executionDate = TestUtil.convertToDate("2014-08-08");
        try{
            ExclusionChangeMonitor monitor 
                = new ExclusionChangeMonitor(AmazonOrg.US, rundate, executionDate, 14);
            List<OihAutomationRate> rates = monitor.getSundayAutomationRates();
            if(rates == null || rates.size() == 0) {
                Log.info("No result.");
                return;
            }
            for(int i = 0; i < rates.size(); i++) {
                Log.info("Rate:" + rates.get(i));
            }
        }catch(Exception e){ 
            e.printStackTrace();
        }
    }
    
    
    public void testGetCurrentAutomationRates() {
        Date rundate = TestUtil.convertToDate("2014-08-08");
        Date executionDate = TestUtil.convertToDate("2014-08-08");
        try{
            ExclusionChangeMonitor monitor 
                = new ExclusionChangeMonitor(AmazonOrg.US, rundate, executionDate, 14);
            List<OihAutomationRate> rates = monitor.getCurrentAutomationRates();
            Map<Integer, OihAutomationRate> convertedRates = monitor.convertCurrentRates(rates);
            if(convertedRates == null || convertedRates.size() == 0) {
                Log.info("No result.");
                return;
            }
            for(Integer gl : convertedRates.keySet()) {
                Log.info("gl:" + gl + ",rates:" + convertedRates.get(gl));
            }
        }catch(Exception e){ 
            e.printStackTrace();
        }
    }
    
    public void testGenerateAutomationRateRecords() {
        Date rundate = TestUtil.convertToDate("2014-08-08");
        Date executionDate = TestUtil.convertToDate("2014-08-08");
        try{
            Map<Integer, Double> glDistributions = this.testGetGlDistributions();
            ExclusionChangeMonitor monitor 
                = new ExclusionChangeMonitor(AmazonOrg.US, rundate, executionDate, null);
            List<AutomationRateRecord> records = monitor.generateAutomationRateRecords(glDistributions);
            if(records == null || records.size() == 0) {
                Log.info("No result.");
                return;
            }
            for(int i = 0; i < records.size(); i++) {
                Log.info("Record:" + records.get(i));
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    
    public void testSendEmail() {
        Date rundate = TestUtil.convertToDate("2014-08-08");
        Date executionDate = TestUtil.convertToDate("2014-08-08");
        try{
            Map<Integer, Double> glDistributions = this.testGetGlDistributions();
            ExclusionChangeMonitor monitor 
                = new ExclusionChangeMonitor(AmazonOrg.US, rundate, executionDate, null);
            List<AutomationRateRecord> rateRecords = monitor.generateAutomationRateRecords(glDistributions);
            if(rateRecords == null || rateRecords.size() == 0)
                throw new Exception("No rate records.");
            AutomationRateRecord rateRecord = rateRecords.get(0);
            rateRecord.setEscalationLevel(1);
            List<ExclusionDefinition> exclusions = new ArrayList<ExclusionDefinition>();
            ExclusionDefinition e = new ExclusionDefinition();
            e.setCreatedBy("lingwang");
            e.setCreatedDate(rundate);
            e.setGl(14);
            e.setOrg(AmazonOrg.US);
            exclusions.add(e);
            ExclusionRecord exclusionRecord = new ExclusionRecord(14);
            exclusionRecord.setAddedExclusions(exclusions);
            exclusionRecord.setHasChangedExclusions(true);
            monitor.sendEmail(rateRecord, exclusionRecord);
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    public void testProcess() {
        Date rundate = TestUtil.convertToDate("2014-08-08");
        Date executionDate = TestUtil.convertToDate("2014-08-08");
        try{
            ExclusionChangeMonitor monitor 
                = new ExclusionChangeMonitor(AmazonOrg.US, rundate, executionDate, null);
            monitor.process();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
}
