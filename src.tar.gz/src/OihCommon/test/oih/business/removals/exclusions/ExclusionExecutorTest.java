package oih.business.removals.exclusions;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;

import junit.framework.Assert;
import oih.business.AmazonOrg;
import oih.business.YesOrNo;
import oih.business.buyer.BuyerUnhealthyDetail;
import oih.business.buyer.BuyerUnhealthyDetailDAO;
import oih.business.buyer.BuyerUnhealthyDetailExpand;
import oih.business.buyer.BuyerUnhealthyDetailExpandDAO;
import oih.business.buyer.BuyerUnhealthyDetailHibernateDAO;
import oih.business.removals.GlConfig;
import oih.business.removals.GlConfigDAO;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import testutils.BaseTestDaoSetup;

public class ExclusionExecutorTest extends BaseTestDaoSetup{

    private static ExclusionHibernateDAO dao = null;
    private static BuyerUnhealthyDetailDAO bdao = null;
    private static GlConfigDAO glDao = null;
    private static ExclusionReasonCodeDAO reasonCodeDao = null;
    private static BuyerUnhealthyDetailExpandDAO budeDao = null;
    
    private final static SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    
    private static Date rundate = null;
    
    @BeforeClass
    public static void setup() throws ParseException {
        config.addResource("oih/business/removals/GlConfig.hbm.xml");
        config.addResource("oih/business/buyer/BuyerUnhealthyDetail.hbm.xml");
        config.addResource("oih/business/buyer/BuyerUnhealthyDetailExpand.hbm.xml");
        config.addResource("oih/business/removals/exclusions/ExclusionDefinition.hbm.xml");
        config.addResource("oih/business/removals/exclusions/ExclusionReasonCode.hbm.xml");
        config.getProperties().setProperty("show_sql", "true");
        sessionFactory = config.buildSessionFactory();
        
        dao = new ExclusionHibernateDAO();
        bdao = BuyerUnhealthyDetailHibernateDAO.getInstance();
        glDao = GlConfigDAO.getInstance();
        reasonCodeDao = ExclusionReasonCodeDAO.getInstance();
        budeDao = BuyerUnhealthyDetailExpandDAO.getInstance();
        
        dao.setSessionFactory(sessionFactory);
        bdao.setSessionFactory(sessionFactory);
        glDao.setSessionFactory(sessionFactory);
        reasonCodeDao.setSessionFactory(sessionFactory);
        budeDao.setSessionFactory(sessionFactory);

        rundate = sdf.parse("2012-05-20");
        
    }
    
    @Before
    public void beforeCase() {
        prepareData();
    }
    
    @After
    public void afterCase() {
        cleanBuyerUnhealthyDetails();
        cleanExclusionRules();
    }
    
    @Test
    public void testExecuteExclusions() {
        ExclusionExecutor.getInstance().setExclusionDAO(dao);
        ExclusionExecutor.getInstance().executeExclusions(AmazonOrg.US, 14, rundate, "nobody", null);
        
        Iterator<ExclusionDefinition> it = dao.findActiveExclusionsWithPriority("RemovalsExclusion.findAllForGlOrgToApply", 14, AmazonOrg.US);
        while(it.hasNext()) {
            ExclusionDefinition ged = it.next();
            if (ged.getRulePosition() == 0) {
                Assert.assertTrue(ged.getLastRowsMatched() == 6);
            } else {
                Assert.assertTrue(ged.getLastRowsMatched() == 0);
            }
        }
        
        Iterator<BuyerUnhealthyDetail> bit14 = bdao.findByOrgGl(AmazonOrg.US, 14);
        Iterator<BuyerUnhealthyDetail> bit15 = bdao.findByOrgGl(AmazonOrg.US, 15);
        while(bit14.hasNext()) {
            BuyerUnhealthyDetail bud = bit14.next();
            if (bud.getOnMarkdown()) {
                Assert.assertEquals("Liquidate", bud.getRemovalType());
                Assert.assertEquals("GlobalExclusion1", bud.getBuyerExclusionReason());
                Assert.assertTrue(bud.getActioningQty() == 2);
            }else {
                Assert.assertEquals("Return", bud.getRemovalType());
                Assert.assertEquals("0000000003", bud.getAsin());
                Assert.assertTrue(bud.getActioningQty() == 2);
            }   
        }
        
        while(bit15.hasNext()) {
            BuyerUnhealthyDetail bud = bit15.next();
            if (bud.getOnMarkdown()) {
                Assert.assertEquals("Liquidate", bud.getRemovalType());
                Assert.assertEquals("GlobalExclusion1", bud.getBuyerExclusionReason());
                Assert.assertTrue(bud.getActioningQty() == 2);
            }else {
                Assert.assertEquals("Return", bud.getRemovalType());
                Assert.assertEquals("0000000003", bud.getAsin());
                Assert.assertTrue(bud.getActioningQty() == 2);
            }   
        }       
    }
    
    
    
    private static void prepareData() {
        GlConfig glConfig = new GlConfig();
        glConfig.setGl(14);
        glConfig.setIsEnabledAutomation(true);
        glConfig.setIsVirtualGl(false);
        glConfig.setIsExpanded(true);
        glConfig.setExpandedFields("warehouse");
        glConfig.setExpandedKey("warehouse");
        glConfig.setOrg(AmazonOrg.US);
        glConfig.setColumnOrder("");
        glDao.save(glConfig);
        
        ExclusionReasonCode reasonCode = new ExclusionReasonCode();
        reasonCode.setExclusionReasonCode("IS_ON_MARKDOWN");
        reasonCode.setPriority(3);
        reasonCodeDao.save(reasonCode);
        
        ExclusionDefinition ged = new ExclusionDefinition();
        setBasicExclusionInfo(ged);
        ged.setClearActioningQuantity(YesOrNo.NO.toString());
        ged.setLastRowsMatched(10);
        ged.setRulePosition(0);
        ged.setWhereClause("( is_on_markdown = 'Y' )");
        ged.setOverrideRemovalType("Liquidate");
        ged.setReason("GlobalExclusion1");
        ged.setGl(14);
        ged.setExclusionReasonCode("IS_ON_MARKDOWN");
        
        dao.save(ged);
        
        ged = new ExclusionDefinition();
        setBasicExclusionInfo(ged);
        ged.setClearActioningQuantity(YesOrNo.YES.toString());
        ged.setLastRowsMatched(8);
        ged.setRulePosition(1);
        ged.setWhereClause("( is_on_markdown = 'Y' )");
        ged.setReason("GlobalExclusion2");
        ged.setGl(14);
        ged.setExclusionReasonCode("IS_ON_MARKDOWN");
        
        dao.save(ged);
        
        BuyerUnhealthyDetail bud = new BuyerUnhealthyDetail();
        setBasicBuyerUnhealthyDetailInfo(bud);
        bud.setAsin("0000000001");
        bud.setOnMarkdown(true);
        bdao.save(bud);
        
        BuyerUnhealthyDetailExpand bude = new BuyerUnhealthyDetailExpand();
        setBasicBuyerUnhealthyDetailExpandInfo(bud, bude, "FC1");
        budeDao.save(bude);
        
        bude = new BuyerUnhealthyDetailExpand();
        setBasicBuyerUnhealthyDetailExpandInfo(bud, bude, "FC2");
        budeDao.save(bude);
        
        bude = new BuyerUnhealthyDetailExpand();
        setBasicBuyerUnhealthyDetailExpandInfo(bud, bude, "FC3");
        budeDao.save(bude);
        
        bud = new BuyerUnhealthyDetail();
        setBasicBuyerUnhealthyDetailInfo(bud);
        bud.setAsin("0000000002");
        bud.setOnMarkdown(true);
        bdao.save(bud);
        
        bude = new BuyerUnhealthyDetailExpand();
        setBasicBuyerUnhealthyDetailExpandInfo(bud, bude, "FC1");
        budeDao.save(bude);
        
        bude = new BuyerUnhealthyDetailExpand();
        setBasicBuyerUnhealthyDetailExpandInfo(bud, bude, "FC2");
        budeDao.save(bude);
        
        bude = new BuyerUnhealthyDetailExpand();
        setBasicBuyerUnhealthyDetailExpandInfo(bud, bude, "FC3");
        budeDao.save(bude);
        
        bud = new BuyerUnhealthyDetail();
        setBasicBuyerUnhealthyDetailInfo(bud);
        bud.setAsin("0000000003");
        bud.setOnMarkdown(false);
        bdao.save(bud);
        
        bude = new BuyerUnhealthyDetailExpand();
        setBasicBuyerUnhealthyDetailExpandInfo(bud, bude, "FC1");
        budeDao.save(bude);
        
        bude = new BuyerUnhealthyDetailExpand();
        setBasicBuyerUnhealthyDetailExpandInfo(bud, bude, "FC2");
        budeDao.save(bude);
        
        bude = new BuyerUnhealthyDetailExpand();
        setBasicBuyerUnhealthyDetailExpandInfo(bud, bude, "FC3");
        budeDao.save(bude);
        
        bud = new BuyerUnhealthyDetail();
        setBasicBuyerUnhealthyDetailInfo(bud);
        bud.setAsin("0000000001");
        bud.setGl(15);
        bud.setOnMarkdown(true);
        bdao.save(bud);
        
        bude = new BuyerUnhealthyDetailExpand();
        setBasicBuyerUnhealthyDetailExpandInfo(bud, bude, "FC1");
        budeDao.save(bude);
        
        bude = new BuyerUnhealthyDetailExpand();
        setBasicBuyerUnhealthyDetailExpandInfo(bud, bude, "FC2");
        budeDao.save(bude);
        
        bude = new BuyerUnhealthyDetailExpand();
        setBasicBuyerUnhealthyDetailExpandInfo(bud, bude, "FC3");
        budeDao.save(bude);
        
        bud = new BuyerUnhealthyDetail();
        setBasicBuyerUnhealthyDetailInfo(bud);
        bud.setAsin("0000000002");
        bud.setGl(15);
        bud.setOnMarkdown(true);
        bdao.save(bud);
        
        bude = new BuyerUnhealthyDetailExpand();
        setBasicBuyerUnhealthyDetailExpandInfo(bud, bude, "FC1");
        budeDao.save(bude);
        
        bude = new BuyerUnhealthyDetailExpand();
        setBasicBuyerUnhealthyDetailExpandInfo(bud, bude, "FC2");
        budeDao.save(bude);
        
        bude = new BuyerUnhealthyDetailExpand();
        setBasicBuyerUnhealthyDetailExpandInfo(bud, bude, "FC3");
        budeDao.save(bude);
        
        bud = new BuyerUnhealthyDetail();
        setBasicBuyerUnhealthyDetailInfo(bud);
        bud.setAsin("0000000003");
        bud.setGl(15);
        bud.setOnMarkdown(false);
        bdao.save(bud);
        
        bude = new BuyerUnhealthyDetailExpand();
        setBasicBuyerUnhealthyDetailExpandInfo(bud, bude, "FC1");
        budeDao.save(bude);
        
        bude = new BuyerUnhealthyDetailExpand();
        setBasicBuyerUnhealthyDetailExpandInfo(bud, bude, "FC2");
        budeDao.save(bude);
        
        bude = new BuyerUnhealthyDetailExpand();
        setBasicBuyerUnhealthyDetailExpandInfo(bud, bude, "FC3");
        budeDao.save(bude);
        
        
    }
    
    private void cleanBuyerUnhealthyDetails() {
        Session s = bdao.getSessionFactory().openSession();
        Transaction tx = s.beginTransaction();
        try {
            s.createQuery("delete from BuyerUnhealthyDetailExpand").executeUpdate();
            int count = s.createQuery("delete from BuyerUnhealthyDetail").executeUpdate();
            Assert.assertTrue(count == 6);
            tx.commit();
        } catch (Exception e) {
            tx.rollback();
            e.printStackTrace();
        } finally {
            if (s != null)
                s.close();
        }
    }
    
    private void cleanExclusionRules() {
        Session s = dao.getSessionFactory().openSession();
        Transaction tx = s.beginTransaction();
        try {
            int count = s.createQuery("delete from ExclusionDefinition").executeUpdate();
            Assert.assertTrue(count == 2);
            tx.commit();
        } catch (Exception e) {
            tx.rollback();
            e.printStackTrace();
        } finally {
            if (s != null)
                s.close();
        }
    }
    
    private static void setBasicExclusionInfo(ExclusionDefinition ged) {
        ged.setCreatedBy("nobody");
        ged.setCreatedDate(new Date());
        ged.setExclusionReasonCode("no");
        ged.setOrg(AmazonOrg.US);
        ged.setOverrideRemovalType("");
        ged.setIsRun("N");
    }
    
    private static void setBasicBuyerUnhealthyDetailInfo(BuyerUnhealthyDetail unhealthy) {       
        unhealthy.setBuyer("unit");
        unhealthy.setOrg(AmazonOrg.US);
        unhealthy.setGl(14);
        unhealthy.setIog(1);
        unhealthy.setUnhealthyQty(4);
        unhealthy.setVendor("unit");
        unhealthy.setStatus("OIH_ADDED");
        unhealthy.setExcludedVendor("excl");
        unhealthy.setRemovalType("Return");
        unhealthy.setCostUsedForCalc(5.0);
        unhealthy.setActioningQty(2);
        unhealthy.setIsBlockedAutomation(true);
        unhealthy.setRundate(rundate);
        unhealthy.setRecommendedRemovalType("Return");
    }
    
    private static void setBasicBuyerUnhealthyDetailExpandInfo(BuyerUnhealthyDetail bud, BuyerUnhealthyDetailExpand unhealthy, String warehouse) {       
        unhealthy.setBuyer("unit");
        unhealthy.setRemovalType("Return");
        unhealthy.setRecommendedRemovalType("Return");
        unhealthy.setActioningQuantity(10);
        unhealthy.setUnhealthyQuantity(10);
        unhealthy.setBudId(bud.getId());
        unhealthy.setBud(bud);
        unhealthy.setWarehouse(warehouse);
        unhealthy.setExcludedDsiId("exdsiid1");
        unhealthy.setDsiId("dsiid1");
    }
}
