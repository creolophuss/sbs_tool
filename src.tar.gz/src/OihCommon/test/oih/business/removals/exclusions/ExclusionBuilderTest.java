package oih.business.removals.exclusions;

import static org.junit.Assert.fail;

import java.io.ByteArrayInputStream;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import oih.business.AmazonOrg;
import oih.business.buyer.BuyerUnhealthyDetail;
import oih.business.buyer.BuyerUnhealthyDetailDAO;
import oih.util.Pair;

import org.apache.commons.lang.StringUtils;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.type.Type;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import testutils.HSQLDBUtils;

public class ExclusionBuilderTest {


    private static Map<String, Pair<String, Type>> props2cols;
    
    @BeforeClass
    public static void setUp() throws Exception {
        String tmpdir = System.getProperty("java.io.tmpdir");
        HSQLDBUtils.cleanupHSQLDBFiles(tmpdir, "testdb");

        // SessionFactory/HSQLDB/schema is built for each test.
        // Not fast, but we have a clean DB each test
        // Setup all config properties by hand.
        Properties props = new Properties();
        props.setProperty("hibernate.connection.driver_class", "org.hsqldb.jdbcDriver");
        props.setProperty("hibernate.connection.url", "jdbc:hsqldb:file:" + tmpdir + "/testdb");
        props.setProperty("hibernate.connection.username", "sa");
        props.setProperty("hibernate.connection.password", "");
        props.setProperty("hibernate.dialect", "org.hibernate.dialect.HSQLDialect");
        props.setProperty("connection.pool_size", "5");
        props.setProperty("hibernate.hbm2ddl.auto", "create");
        props.setProperty("show_sql", "true");
        AnnotationConfiguration config = new AnnotationConfiguration();
        config.addPackage("oih.business.removals.exclusions")
          .addAnnotatedClass(ExclusionRuleFieldCfg.class);

        config.setProperties(props);

        try {
            // need to specify classes to be mapped by hand too

            config.addResource("oih/business/buyer/BuyerUnhealthyDetail.hbm.xml");
            config.addResource("oih/business/buyer/BuyerUnhealthyDetailExpand.hbm.xml");
            SessionFactory sessionFactory = config.buildSessionFactory();
            BuyerUnhealthyDetailDAO.getInstance().setSessionFactory(sessionFactory);
            props2cols = oih.util.hibernate.HibernateUtil.getProperties2ColumnsMapping(sessionFactory, BuyerUnhealthyDetail.class);
            ExclusionConfigProvider.getIntance().setSessionFactory(sessionFactory);

        } catch (Exception e) {
            e.printStackTrace();
            fail();
            System.exit(1);
        }
    }


    @Test
    public void constructSomeWhere() {
        String header[] = {
                "textbook_type", "category", "last_receipt", "subcategory", "buyer", "asin", "promotion_end_date",
                "markdown_price", "parent_asin"
        };
        String values[] = {
                "", "'snarf'", "", "'that'", "> 'poops'", "'B002Y27P3M'", "< now()-12", "> 15.6", "''"
        };

        String where = "";
        try {
            where = ExclusionBuilder.constructWhere(header, values, BuyerUnhealthyDetailDAO.getInstance()
                    .getColumnTypes());
        } catch (ParseException e) {
            Assert.fail();
        }
        Assert.assertNotNull(where);
        Assert.assertEquals(
                "( category = 'snarf' ) AND ( subcategory = 'that' ) AND ( buyer > 'poops' ) AND ( asin = 'B002Y27P3M' ) " +
                "AND ( promotion_end_date < now()-12 ) AND ( markdown_price > 15.6 ) AND ( parent_asin = '' )",
                where);

        String newvalues[] = ExclusionUnbuilder.deconstructWhere(header, where);
        for (int i = 0; i < header.length; i++) {
        	String value = values[i];
        	if (!value.equals("''")) {
        		value = value.replace("'", "");
        	}
        	Assert.assertEquals(value, newvalues[i]);
        }
        
        String header2[] = {
                "textbook_type", "category", "last_receipt", "subcategory", "buyer", "asin", "promotion_end_date",
                "markdown_price", "parent_asin"
        };
        String values2[] = {
                "", "'snarf'", "", "'that'", "> 'poops'", "'B002Y27P3M'", "< now()-12", "> 'AB'", "''"
        };
        
        try {
            ExclusionBuilder.constructWhere(header2, values2, BuyerUnhealthyDetailDAO.getInstance()
                    .getColumnTypes());
        } catch (ParseException e) {
            Assert.assertTrue(true);
            return;
        }
        
        Assert.assertTrue(false); 
    }
    
    @Test
    public void constructSomeWhereWithoutQuotes() {
        String header[] = {
                "textbook_type", "category", "last_receipt", "subcategory", "buyer", "asin", "promotion_end_date",
                "markdown_price", "parent_asin"
        };
        String values[] = {
                "", "snarf", "", "that", "> poops", "B002Y27P3M", "< now()-12", "> 15.6", "''"
        };

        String where = "";
        try {
            where = ExclusionBuilder.constructWhere(header, values, BuyerUnhealthyDetailDAO.getInstance()
                    .getColumnTypes());
        } catch (ParseException e) {
            Assert.fail();
        }
        Assert.assertNotNull(where);
        Assert.assertEquals(
                "( category = 'snarf' ) AND ( subcategory = 'that' ) AND ( buyer > 'poops' ) AND ( asin = 'B002Y27P3M' ) " +
                "AND ( promotion_end_date < now()-12 ) AND ( markdown_price > 15.6 ) AND ( parent_asin = '' )",
                where);

        String newvalues[] = ExclusionUnbuilder.deconstructWhere(header, where);
        for (int i = 0; i < header.length; i++) {
        	String value = values[i];
        	if (!value.equals("''")) {
        		value = value.replace("'", "");
        	}
        	Assert.assertEquals(value, newvalues[i]);
        }
        
        String header2[] = {
                "textbook_type", "category", "last_receipt", "subcategory", "buyer", "asin", "promotion_end_date",
                "markdown_price", "parent_asin"
        };
        String values2[] = {
                "", "snarf", "", "that", "> poops", "B002Y27P3M", "< now()-12", "> AB", "''"
        };
        
        try {
            ExclusionBuilder.constructWhere(header2, values2, BuyerUnhealthyDetailDAO.getInstance()
                    .getColumnTypes());
        } catch (ParseException e) {
            Assert.assertTrue(true);
            return;
        }
        
        Assert.assertTrue(false); 
    }

    @Test
    public void constructWhereClauseOnDateFunctions() {
        String header[] = {
                "promotion_end_date", "rundate"
        };
        String values[] = {
                "> subdate(30)", "> adddate(30)"
        };

        String where = "";
        try {
            where = ExclusionBuilder.constructWhere(header, values, BuyerUnhealthyDetailDAO.getInstance()
                    .getColumnTypes());
        } catch (ParseException e) {
            e.printStackTrace();
            Assert.fail();
        }
        Assert.assertNotNull(where);
        Assert.assertEquals(
                "( promotion_end_date > subdate(30) ) AND ( rundate > adddate(30) )",
                where);

        String newvalues[] = ExclusionUnbuilder.deconstructWhere(header, where);
        for (int i = 0; i < header.length; i++) {
        	if( values[i].startsWith(">")||values[i].startsWith("<") ){
        		Assert.assertEquals(values[i], newvalues[i]);
        	}else{
        		Assert.assertFalse(values[i].equals(newvalues[i]));
        	}
        }
    }

    @Test
    public void deconstructSomeShizzle() {
        String header[] = {
                "foo", "bar", "roo", "magical", "rainbow", "pony", "lol"
        };
        String where = "( foo = 'snarf' ) AND ( magical >= 'funny' ) AND ( lol like '%cat%' ) AND ( roo between 3 and 5 ) AND ( pony is null )";

        String values[] = ExclusionUnbuilder.deconstructWhere(header, where);
        for (int i = 0; i < header.length; i++) {
            Assert.assertNotNull(values[i]);
        }
        Assert.assertEquals("like(cat)", values[6]);
        Assert.assertEquals("snarf", values[0]);
        Assert.assertEquals(">= funny", values[3]);
        Assert.assertEquals("between 3 and 5", values[2]);
        Assert.assertEquals("is null", values[5]);
    }

    @Test
    public void testBadBits() {
        String header[] = {
                "textbook_type", "category", "last_receipt", "subcategory", "buyer", "asin"
        };
        String values[] = {
                "", "'snarf'", "", "'that'", "> 'poops'", "'B002Y27P3M'"
        };

        String where = "";
        try {
            where = ExclusionBuilder.constructWhere(header, values, BuyerUnhealthyDetailDAO.getInstance()
                    .getColumnTypes());
        } catch (ParseException e) {
            e.printStackTrace();
            Assert.fail();
        }
        Assert.assertNotNull(where);
        Assert.assertEquals(
                "( category = 'snarf' ) AND ( subcategory = 'that' ) AND ( buyer > 'poops' ) AND ( asin = 'B002Y27P3M' )",
                where);

        String newvalues[] = ExclusionUnbuilder.deconstructWhere(header, where);
        for (int i = 0; i < header.length; i++) {
        	String value = values[i];
        	if (!"''".equals(value)) {
        		value = value.replaceAll("'", "");        		
        	}
        	Assert.assertTrue(value.equals(newvalues[i]));
        }
    }
    
    @Test
    public void testBadBitsWithoutSingleQuotes() {
        String header[] = {
                "textbook_type", "category", "last_receipt", "subcategory", "buyer", "asin"
        };
        String values[] = {
                "", "snarf", "", "that", "> poops", "B002Y27P3M"
        };

        String where = "";
        try {
            where = ExclusionBuilder.constructWhere(header, values, BuyerUnhealthyDetailDAO.getInstance()
                    .getColumnTypes());
        } catch (ParseException e) {
            e.printStackTrace();
            Assert.fail();
        }
        Assert.assertNotNull(where);
        Assert.assertEquals(
                "( category = 'snarf' ) AND ( subcategory = 'that' ) AND ( buyer > 'poops' ) AND ( asin = 'B002Y27P3M' )",
                where);

        String newvalues[] = ExclusionUnbuilder.deconstructWhere(header, where);
        for (int i = 0; i < header.length; i++) {
        	Assert.assertTrue(values[i].equals(newvalues[i]));
        }
    }

    @Test
    public void testHoles() {
        /* TODO think of some other nifty sql injection methods */
        try {
            ExclusionBuilder.constructWhere(new String[] {
                    "a", "b", "c"
            }, new String[] {
                    "= '' ); --", "drop table exclusion_definition;", "-- doh!"
            }, BuyerUnhealthyDetailDAO.getInstance().getColumnTypes());
            Assert.fail();
        } catch (Exception exc) {
            /* pass */
        }

        try {
            ExclusionBuilder.constructWhere(new String[] {
                    "a", "b", "c"
            }, new String[] {
                    "= ''); drop tables;", ""
            }, BuyerUnhealthyDetailDAO.getInstance().getColumnTypes());
            Assert.fail();
        } catch (Exception exc) {
            /* pass */
        }
    }

    @Test
    public void testSplitString() {
        String phrase = "I have a bunch of words .";
        String expValues[] = {
                "I", "have", "a", "bunch", "of", "words", "."
        };
        String results[] = ExclusionBuilder.splitString(phrase, " ");
        Assert.assertEquals(expValues.length, results.length);
        for (int i = 0; i < expValues.length; i++) {
            Assert.assertEquals(expValues[i], results[i]);
        }
    }

    @Test
    public void testBuilder() {
        String FILE = "exclusion_reason,exclusion_reason_code,override_removal_type,clear_actioning_quantity,start_date,end_date,asin,vendor,product_tier_id,binding_code\n"
                + "test,testcode1,Liquidate,NO,,,'12345678',v,'A',\n"
                + "test2,testcode2,,YES,2009-01-01,,,'FOO',,\n"
                + "test3,testcode3,Markdown,NO,2009-01-01,2009-10-10,,,'FOO',,\n";

        try {
            ExclusionBuilder eb = new ExclusionBuilder(14, AmazonOrg.US, new ByteArrayInputStream(FILE.getBytes()));
            Iterator<ExclusionRule> i = eb.getExclusionBuilds();
            Assert.assertTrue(i.hasNext());
            
            ExclusionDefinition re = ExclusionRuleConvertUtils.convertExclusionRule2ExclusionDefinition(i.next(), props2cols);           

            Assert.assertEquals(AmazonOrg.US, re.getOrg());
            Assert.assertEquals(14, re.getGl().intValue());
            Assert.assertNull(re.getStartDate());
            Assert.assertEquals("test", re.getReason());
            Assert.assertEquals("Liquidate", re.getOverrideRemovalType());

            Assert.assertTrue(i.hasNext());
            re = ExclusionRuleConvertUtils.convertExclusionRule2ExclusionDefinition(i.next(), props2cols);

            Assert.assertNotNull(re.getStartDate());
            Assert.assertNull(re.getEndDate());
            Assert.assertEquals("test2", re.getReason());
            Assert.assertTrue(StringUtils.isBlank(re.getOverrideRemovalType()));

            Assert.assertTrue(i.hasNext());
            re = ExclusionRuleConvertUtils.convertExclusionRule2ExclusionDefinition(i.next(), props2cols);

            Assert.assertNotNull(re.getStartDate());
            Assert.assertNotNull(re.getEndDate());
            Assert.assertEquals("( product_tier_id = 'FOO' )", re.getWhereClause());
            Assert.assertEquals("Markdown", re.getOverrideRemovalType());
        } catch (Exception exc) {
            exc.printStackTrace();
            Assert.fail();
        }
    }
    
    @Test
    public void testBuilderWithoutSingleQuotes() {
        String FILE = "exclusion_reason,exclusion_reason_code,override_removal_type,clear_actioning_quantity,start_date,end_date,asin,vendor,product_tier_id,binding_code\n"
                + "test,testcode1,Liquidate,NO,,,1234567890,v,A,\n"
                + "test2,testcode2,,YES,2009-01-01,,,FOO,,\n"
                + "test3,testcode3,Markdown,NO,2009-01-01,2009-10-10,,,FOO,,\n";

        try {
            ExclusionBuilder eb = new ExclusionBuilder(14, AmazonOrg.US, new ByteArrayInputStream(FILE.getBytes()));
            Iterator<ExclusionRule> i = eb.getExclusionBuilds();
            Assert.assertTrue(i.hasNext());

            ExclusionDefinition re = ExclusionRuleConvertUtils.convertExclusionRule2ExclusionDefinition(i.next(), props2cols);

            Assert.assertEquals(AmazonOrg.US, re.getOrg());
            Assert.assertEquals(14, re.getGl().intValue());
            Assert.assertNull(re.getStartDate());
            Assert.assertEquals("test", re.getReason());
            Assert.assertEquals("Liquidate", re.getOverrideRemovalType());

            Assert.assertTrue(i.hasNext());
            re = ExclusionRuleConvertUtils.convertExclusionRule2ExclusionDefinition(i.next(), props2cols);

            Assert.assertNotNull(re.getStartDate());
            Assert.assertNull(re.getEndDate());
            Assert.assertEquals("test2", re.getReason());
            Assert.assertTrue(StringUtils.isBlank(re.getOverrideRemovalType()));

            Assert.assertTrue(i.hasNext());
            re = ExclusionRuleConvertUtils.convertExclusionRule2ExclusionDefinition(i.next(), props2cols);

            Assert.assertNotNull(re.getStartDate());
            Assert.assertNotNull(re.getEndDate());
            Assert.assertEquals("( product_tier_id = 'FOO' )", re.getWhereClause());
            Assert.assertEquals("Markdown", re.getOverrideRemovalType());
        } catch (Exception exc) {
            exc.printStackTrace();
            Assert.fail();
        }
    }

    private static ExclusionDefinition newExclusionDefinition(Date s, Date e, String r, String w, String reasonCode,
            int position, String overrideRemovalType, String clearActioningQuantity) {
        ExclusionDefinition ed = new ExclusionDefinition();
        ed.setEndDate(s);
        ed.setStartDate(e);
        ed.setWhereClause(w);
        ed.setReason(r);
        ed.setExclusionReasonCode(reasonCode);
        ed.setOverrideRemovalType(overrideRemovalType);
        ed.setClearActioningQuantity(clearActioningQuantity);
        ed.setRulePosition(new Integer(position));
        return ed;
    }

    @Test
    public void testMore() {
        String header[] = {
                "textbook_type", "category", "last_receipt", "subcategory", "buyer", "asin"
        };
        String values[] = {
                "", "'snarf'", "> '2009-10-01'", "'that'", "> 'poops'", "B002Y27P3M"
        };

        String where = "";
        try {
            where = ExclusionBuilder.constructWhere(header, values, BuyerUnhealthyDetailDAO.getInstance()
                    .getColumnTypes());
        } catch (ParseException e) {
            e.printStackTrace();
            Assert.fail();
        }
        Assert.assertNotNull(where);
    }
    
    @Test
    public void testMoreWithoutSingleQuotes() {
        String header[] = {
                "textbook_type", "category", "last_receipt", "subcategory", "buyer", "asin"
        };
        String values[] = {
                "", "snarf", "> 2009-10-01", "that", "> poops", "B002Y27P3M"
        };

        String where = "";
        try {
            where = ExclusionBuilder.constructWhere(header, values, BuyerUnhealthyDetailDAO.getInstance()
                    .getColumnTypes());
        } catch (ParseException e) {
            e.printStackTrace();
            Assert.fail();
        }
        Assert.assertNotNull(where);
    }

    @Test
    public void testNumericDataTypes() {
        String header[] = {
                "textbook_type", "iog", "last_receipt", "subcategory", "buyer", "asin"
        };
        String values[] = {
                "", "2", "> '2009-01-01'", "'that'", "> 'poops'", "B002Y27P3M"
        };
        String where = "";
        try {
            where = ExclusionBuilder.constructWhere(header, values, BuyerUnhealthyDetailDAO.getInstance()
                    .getColumnTypes());
        } catch (ParseException e) {
            e.printStackTrace();
            Assert.fail();
        }
        Assert.assertNotNull(where);
        Assert.assertEquals(
                "( iog = 2 ) AND ( last_receipt > '2009-01-01' ) AND ( subcategory = 'that' ) AND ( buyer > 'poops' ) AND ( asin = 'B002Y27P3M' )",
                where);

        String newvalues[] = ExclusionUnbuilder.deconstructWhere(header, where);
        for (int i = 0; i < header.length; i++) {
        	String value = values[i];
        	if (!"''".equals(value)) {
        		value = value.replaceAll("'", "");        		
        	}
        	Assert.assertEquals(value, newvalues[i]);
        }
    }
    
    @Test
    public void testNumericDataTypesWithoutSingleQuotes() {
        String header[] = {
                "textbook_type", "iog", "last_receipt", "subcategory", "buyer", "asin"
        };
        String values[] = {
                "", "2", "> 2009-01-01", "that", "> poops", "B002Y27P3M"
        };
        String where = "";
        try {
            where = ExclusionBuilder.constructWhere(header, values, BuyerUnhealthyDetailDAO.getInstance()
                    .getColumnTypes());
        } catch (ParseException e) {
            e.printStackTrace();
            Assert.fail();
        }
        Assert.assertNotNull(where);
        Assert.assertEquals(
                "( iog = 2 ) AND ( last_receipt > '2009-01-01' ) AND ( subcategory = 'that' ) AND ( buyer > 'poops' ) AND ( asin = 'B002Y27P3M' )",
                where);

        String newvalues[] = ExclusionUnbuilder.deconstructWhere(header, where);
        for (int i = 0; i < header.length; i++) {
        	Assert.assertEquals(values[i], newvalues[i]);
        }
    }

    @Test
    public void testSimpleBuilderCase() {
        String header[] = {
            "iog",
        };
        String values[] = {
            "2"
        };
        String where = "";
        try {
            where = ExclusionBuilder.constructWhere(header, values, BuyerUnhealthyDetailDAO.getInstance()
                    .getColumnTypes());
        } catch (ParseException e) {
            e.printStackTrace();
            Assert.fail();
        }
        Assert.assertNotNull(where);
        Assert.assertEquals("( iog = 2 )", where);

        String newvalues[] = ExclusionUnbuilder.deconstructWhere(header, where);
        for (int i = 0; i < header.length; i++) {
            Assert.assertEquals(values[i], newvalues[i]);
        }
    }

    @Test
    public void testNumericAndOther() {
        String header[] = {
                "removal_type", "iog",
        };
        String values[] = {
                "Markdown", "2"
        };
        String where = "";
        try {
            where = ExclusionBuilder.constructWhere(header, values, BuyerUnhealthyDetailDAO.getInstance()
                    .getColumnTypes());
        } catch (ParseException e) {
            e.printStackTrace();
            Assert.fail();
        }
        Assert.assertNotNull(where);
        Assert.assertEquals("( removal_type = 'Markdown' ) AND ( iog = 2 )", where);

        String newvalues[] = ExclusionUnbuilder.deconstructWhere(header, where);
        for (int i = 0; i < header.length; i++) {
        	Assert.assertEquals(values[i], newvalues[i]);
        }
    }
    
    /**
     * Verifies where clause (de)construction with numeric fields that may contain quotes.
     */
    @Test
    public void testNumericWithQuotes() {
    	//only in the case of 'x' do we strip out the quotes. In other cases (where a comparison operator is present), we preserve
    	// the quote (mysql tolerates it without problem).
        String header[] = {
                "cost_used_for_calculations", "our_price", "healthy_quantity", "unhealthy_quantity", "total_healthy_quantity", "total_unhealthy_quantity"
        };
        String values[] = {
                "= '0.01'", "'0.01'", "< 3", "< '3'", "> 1", "> '1'"
        };
        String where = "";
        try {
            where = ExclusionBuilder.constructWhere(header, values, BuyerUnhealthyDetailDAO.getInstance()
                    .getColumnTypes());
        } catch (ParseException e) {
            e.printStackTrace();
            Assert.fail();
        }
        Assert.assertNotNull(where);
        //as noted above, verify the our_price has the quotes removed.
        //before the code change that accompanied this unit test, the website would reject this kind of input.
        Assert.assertEquals("( cost_used_for_calculations = 0.01 ) AND ( our_price = 0.01 ) AND ( healthy_quantity < 3 ) AND ( unhealthy_quantity < 3 ) AND ( total_healthy_quantity > 1 ) AND ( total_unhealthy_quantity > 1 )"
        		, where);

        //also note the unbuilder will strip out leading equal signs (i.e, for cost_used_for_calculations).
        String newvalues[] = ExclusionUnbuilder.deconstructWhere(header, where);
        for (int i = 0; i < header.length; i++) {
        	Assert.assertEquals(values[i].replace("= ", "").replaceAll("'", ""), newvalues[i]);
        }
    }

    @Test
    public void testUnbuilder() {
        List<ExclusionDefinition> l = new ArrayList<ExclusionDefinition>();
        l.add(newExclusionDefinition(null, null, "test", "( vendor = 'foo' )", "CODE1", 1, "Liquidate", "NO"));
        
        Calendar calendar = Calendar.getInstance();
        calendar.set(2009, 2, 16, 1, 1, 1);
        
        l.add(newExclusionDefinition(calendar.getTime(), null, "test 2",
                "( asin = '1234' ) AND ( vendor = 'bar' )", "CODE2", 2, null, "YES"));

        ExclusionUnbuilder ub = new ExclusionUnbuilder("asin,vendor,stuff,thing,place,holder", l.iterator());
        Iterator<String> lines = ub.getExclusionUnbuilder();
        Assert.assertEquals(
                "start_date,end_date,exclusion_reason,exclusion_reason_code,override_removal_type,clear_actioning_quantity,asin,vendor,stuff,thing,place,holder",
                ub.getHeaderLine());
        Assert.assertTrue(lines.hasNext());
        Assert.assertEquals(",,test,CODE1,Liquidate,NO,,foo,,,,", lines.next());
        Assert.assertEquals(",2009-03-16,test 2,CODE2,,YES,1234,bar,,,,", lines.next());
    }
    
    @Test
    public void testIsMysqlNumericValue(){
    	
    	String []values  = {"0x2344", null, "", "0345", "0X33", "0xff3fp", "0xfff", "345", "-45", "+45","-0x23f", "+0x23f", "15.6"};
    	boolean[]results = {true, false, false, true, false, false, true, true, true, true, false, false, true};
    	for(int i = 0; i < values.length; i++){
    		Assert.assertEquals(
    				results[i], ExclusionBuilder.isMysqlNumericValue(values[i]));
    	}
    }
    
    /**
     * Verifies where clause (de)construction for BetweenOperator.
     */
    @Test
    public void testBetweenOperator() {
        String header[] = {
                "cost_used_for_calculations", "our_price", "healthy_quantity", "unhealthy_quantity", "total_healthy_quantity", "total_unhealthy_quantity"
        };
        String values[] = {
                "between 100.0 and 200.1", "between -0.01 and 12.00", "between 3 and 5", "between 1232302 and 1343", "between -1 and 100",
                "between -100.0 and -200.0"
        };
        String where = "";
        try {
            where = ExclusionBuilder.constructWhere(header, values, BuyerUnhealthyDetailDAO.getInstance().getColumnTypes());
        } catch (ParseException e) {
            e.printStackTrace();
            Assert.fail();
        }
        Assert.assertNotNull(where);
        Assert.assertEquals(
                "( cost_used_for_calculations between 100.0 and 200.1 ) AND ( our_price between -0.01 and 12.00 ) AND ( healthy_quantity between 3 and 5 ) AND ( unhealthy_quantity between 1232302 and 1343 ) AND ( total_healthy_quantity between -1 and 100 ) AND ( total_unhealthy_quantity between -100.0 and -200.0 )",
                where);

        String newvalues[] = ExclusionUnbuilder.deconstructWhere(header, where);
        for (int i = 0; i < header.length; i++) {
            Assert.assertEquals(values[i], newvalues[i]);
        }
    }
    
    /**
     * Verifies where clause construction for BetweenOperator with unsupported type.
     */
    @Test
    public void testBetweenOperatorWithUnsupportedType() {
        String header[] = {
                "title_description", "our_price", "healthy_quantity", "unhealthy_quantity", "total_healthy_quantity", "total_unhealthy_quantity"
        };
        String values[] = {
                "between 100.0 and 200.1", "between -0.01 and 12.00", "between 3 and 5", "between 1232302 and 1343", "between -1 and 100",
                "between -100.0 and -200.0"
        };
        
        @SuppressWarnings("unused")
		String where = "";
        try {
            where = ExclusionBuilder.constructWhere(header, values, BuyerUnhealthyDetailDAO.getInstance().getColumnTypes());
        } catch (ParseException e) {
        	return;
        }
        Assert.fail();
    }
    
    /**
     * Verifies where clause (de)construction for LikeOperator.
     */
    @Test
    public void testLikeOperator() {
        String header[] = {
                "title_description", "textbook_type", "category", "subcategory"
        };
        String values[] = {
                "like(China Amazon)", "like(123  345)", "like(Amazon-WW)", "like(TEST1%TEST2)"
        };

        String where = "";
        try {
            where = ExclusionBuilder.constructWhere(header, values, BuyerUnhealthyDetailDAO.getInstance().getColumnTypes());
        } catch (ParseException e) {
            Assert.fail();
        }
        Assert.assertNotNull(where);
        Assert.assertEquals("( title_description like '%China Amazon%' )" + " AND ( textbook_type like '%123  345%' )" + " AND ( category like '%Amazon-WW%' )"
                + " AND ( subcategory like '%TEST1%TEST2%' )", where);
        String newvalues[] = ExclusionUnbuilder.deconstructWhere(header, where);
        for (int i = 0; i < header.length; i++) {
            Assert.assertEquals(values[i], newvalues[i]);
        }
    }
    /**
     * Verifies where clause construction for LikeOperator with unsupported type.
     */
    @Test
    public void testLikeOperatorWithUnsupportedType() {
        String header[] = {
                "title_description", "our_price", "last_receipt", "subcategory"
        };
        String values[] = {
                "like(China Amazon)", "like(345)", "like(20090101)", "like(TEST1%TEST2)"
        };

        @SuppressWarnings("unused")
		String where = "";
        try {
            where = ExclusionBuilder.constructWhere(header, values, BuyerUnhealthyDetailDAO.getInstance().getColumnTypes());
        } catch (ParseException e) {
        	return;
        }
        Assert.fail();
    }
    
    /**
     * Verifies where clause (de)construction for IsNullOperator.
     */
    @Test
    public void testIsNullOperator() {
        String header[] = {
                "title_description", "our_price", "last_receipt", "subcategory"
        };
        String values[] = {
                "is null", "is null", "is null", "is null"
        };

        String where = "";
        try {
            where = ExclusionBuilder.constructWhere(header, values, BuyerUnhealthyDetailDAO.getInstance().getColumnTypes());
        } catch (ParseException e) {
            System.out.println(e);
            Assert.fail();
        }
        Assert.assertNotNull(where);
        Assert.assertEquals("( title_description is null or title_description = 'NULL' or title_description = 'null' or title_description = '' )" 
        		+ " AND ( our_price is null )" + " AND ( last_receipt is null )"
                + " AND ( subcategory is null or subcategory = 'NULL' or subcategory = 'null' or subcategory = '' )", where);
        String newvalues[] = ExclusionUnbuilder.deconstructWhere(header, where);
        for (int i = 0; i < header.length; i++) {
            Assert.assertEquals(values[i], newvalues[i]);
        }
    }
    
    /**
     * Verifies where clause (de)construction for IsNullOperatorWithSingleQuotes.
     */
    @Test
    public void testIsNullOperatorWithSingleQuotes() {
        String header[] = {
                "title_description", "our_price", "last_receipt"
        };
        String values[] = {
                "is null", "is null", "is null"
        };

        String where = "";
        try {
            where = ExclusionBuilder.constructWhere(header, values, BuyerUnhealthyDetailDAO.getInstance().getColumnTypes());
        } catch (ParseException e) {
            Assert.fail();
        }
        Assert.assertNotNull(where);
        Assert.assertEquals("( title_description is null or title_description = 'NULL' or title_description = 'null' or title_description = '' )" 
        		+ " AND ( our_price is null )" 
        		+ " AND ( last_receipt is null )", where);
        String newvalues[] = ExclusionUnbuilder.deconstructWhere(header, where);
        for (int i = 0; i < header.length; i++) {
            Assert.assertEquals(values[i], newvalues[i]);
        }
    }
    
    /**
     * Verifies where clause construction for key words(between, and, like and "is null") case insensitive.
     */
	@Test
	public void testKeyWordsCaseInsensitive() {
		String header[] = { "title_description", "our_price", "last_receipt", "subcategory" };
		String values[] = { "LiKe(Amazon)", "BeTween 1 AnD 4", ">=2009-10-01", "Is NuLl" };
		String expectedValues[] = { "like(Amazon)", "between 1 and 4", ">= 2009-10-01", "is null" };

		String where = "";
		try {
			where = ExclusionBuilder.constructWhere(header, values,
					BuyerUnhealthyDetailDAO.getInstance().getColumnTypes());
		} catch (ParseException e) {
			e.printStackTrace();
			Assert.fail();
		}
		Assert.assertNotNull(where);
		Assert.assertEquals("( title_description like '%Amazon%' )"
				+ " AND ( our_price between 1 and 4 )"
				+ " AND ( last_receipt >= '2009-10-01' )"
				+ " AND ( subcategory is null or subcategory = 'NULL' or subcategory = 'null' or subcategory = '' )", where);
		String newvalues[] = ExclusionUnbuilder.deconstructWhere(header, where);
		for (int i = 0; i < header.length; i++) {
			Assert.assertEquals(expectedValues[i], newvalues[i]);
		}
	}
	
    /**
     * Verifies where clause construction for less than and greater than.
     */
	@Test
	public void testLessGreaterEqual() {
		String header[] = { "cost_used_for_calculations", "our_price", "healthy_quantity", "unhealthy_quantity", "total_healthy_quantity", "total_unhealthy_quantity" };
		String values[] = { ">=100.0", ">=   -10.12", "<=-12.34", "<= -12.00", "> 12", "< -12" };
		String expectedValues[] = { ">= 100.0", ">= -10.12", "<= -12.34", "<= -12.00", "> 12", "< -12" };
		

		String where = "";
		try {
			where = ExclusionBuilder.constructWhere(header, values,
					BuyerUnhealthyDetailDAO.getInstance().getColumnTypes());
		} catch (ParseException e) {
			e.printStackTrace();
			Assert.fail();
		}
		Assert.assertNotNull(where);
		Assert.assertEquals("( cost_used_for_calculations >= 100.0 )"
				+ " AND ( our_price >= -10.12 )"
				+ " AND ( healthy_quantity <= -12.34 )"
				+ " AND ( unhealthy_quantity <= -12.00 )"
				+ " AND ( total_healthy_quantity > 12 )"
				+ " AND ( total_unhealthy_quantity < -12 )", where);
		String newvalues[] = ExclusionUnbuilder.deconstructWhere(header, where);
		for (int i = 0; i < header.length; i++) {
			Assert.assertEquals(expectedValues[i], newvalues[i]);
		}

		String newheader[] = { "cost_used_for_calculations", "our_price" };

		String values2[] = { "=>100.0", ">=   -10.12" };
		try {
			ExclusionBuilder.constructWhere(newheader, values2,
					BuyerUnhealthyDetailDAO.getInstance().getColumnTypes());
			Assert.assertTrue(false);
		} catch (ParseException e) {
			Assert.assertTrue(true);
		}

		String values3[] = { "=< 100.0", ">=   -10.12" };
		try {
			ExclusionBuilder.constructWhere(newheader, values3,
					BuyerUnhealthyDetailDAO.getInstance().getColumnTypes());
			Assert.assertTrue(false);
		} catch (ParseException e) {
			Assert.assertTrue(true);
		}

		String values4[] = { ">= -100 .0", ">=   -10.12" };
		try {
			ExclusionBuilder.constructWhere(newheader, values4,
					BuyerUnhealthyDetailDAO.getInstance().getColumnTypes());
			Assert.assertTrue(false);
		} catch (ParseException e) {
			Assert.assertTrue(true);
		}
	}
	
    /**
     * Verifies where clause construction for value starts with "=>"
     */ 
	@Test
	public void testValueMore() {
		String header[] = { "mean_age_band", "title_description", "asin", "parent_asin", "external_id" };
		String values[] = { "0-30 days", "=>120 days", "= >120 days", "= '>120 days'", "='>120 days'" };
		String expectedValues[] = { "0-30 days", "=>120 days", "=>120 days", "=>120 days", "=>120 days"  };

		String where = "";
		try {
			where = ExclusionBuilder.constructWhere(header, values,
					BuyerUnhealthyDetailDAO.getInstance().getColumnTypes());
		} catch (ParseException e) {
			e.printStackTrace();
			Assert.fail();
		}
		Assert.assertNotNull(where);
		Assert.assertEquals("( mean_age_band = '0-30 days' )"
				+ " AND ( title_description = '>120 days' )"
				+ " AND ( asin = '>120 days' )"
				+ " AND ( parent_asin = '>120 days' )"
				+ " AND ( external_id = '>120 days' )", where);
		String newvalues[] = ExclusionUnbuilder.deconstructWhere(header, where);
		for (int i = 0; i < header.length; i++) {
			Assert.assertEquals(expectedValues[i], newvalues[i]);
		}
	}
}
