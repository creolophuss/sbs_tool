package oih.business.removals.exclusions.monitor;

import org.junit.Test;
import org.mortbay.log.Log;

import amazon.platform.config.AppConfig;
import amazon.platform.logging.AppConfigLog4jConfigurator;

public class ExclusionMonitorTestUtil {
    private static String APP_GROUP = "Oih";
    private static String APP_NAME = "OihWebsite";
    
    public static void configEnv() {
        String[] args = new String[] {
                "--domain=test",
                "--realm=USAmazon", 
                "--root=/apollo/env/OihWebsite",
                "--appgroup=" + APP_GROUP,
                "--appname=" + APP_NAME,
                "--override=ExclusionChangeMonitor.cfg",
        };
        
        if (!AppConfig.isInitialized()) {
            AppConfigLog4jConfigurator.configureForBootstrap();
            AppConfig.initialize(APP_NAME, APP_GROUP, args);
            AppConfigLog4jConfigurator.configureFromAppConfig();
        }
    }
}
