package oih.business.removals.exclusions.monitor.dao;

import java.util.Properties;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.junit.BeforeClass;
import testutils.HSQLDBUtils;

import oih.business.removals.exclusions.monitor.dao.*;
import oih.business.removals.exclusions.ExclusionDAO;

public class HibernateDAOTestUtil {
    private static SessionFactory sessionFactory;
    private static OihAutomationRateHibernateDAO rateDao;
    private static SundayExclusionHibernateDAO sundayExclusionDao;
    private static GlDistributionHibernateDAO distributionDao;
    private static ExclusionDAO exclusionDao;
    
    @BeforeClass
    public static void theLogThe() {
        // Plz see http://tinyurl.com/a5zcel bullet 3, item 3 for more information on the method name
        Logger.getRootLogger().setLevel(Level.INFO);
    }

    static{
        Properties props = new Properties();

        HSQLDBUtils.cleanupHSQLDBFiles("/var/tmp", "testdb");

        props.setProperty("hibernate.connection.driver_class", "org.hsqldb.jdbcDriver");
        props.setProperty("hibernate.connection.url", "jdbc:hsqldb:file:/var/tmp/testdb");
        props.setProperty("hibernate.connection.username", "sa");
        props.setProperty("hibernate.connection.password", "");
        props.setProperty("hibernate.dialect", "org.hibernate.dialect.HSQLDialect");
        props.setProperty("hibernate.hbm2ddl.auto", "create");
        props.setProperty("connection.pool_size", "5");
        props.setProperty("show_sql", "true");
        Configuration config = new Configuration();
        config.setProperties(props);
        try {
            config.addResource("oih/business/removals/exclusions/monitor/dao/OihAutomationRate.hbm.xml");
            config.addResource("oih/business/removals/exclusions/monitor/dao/SundayExclusionDefinition.hbm.xml");
            config.addResource("oih/business/removals/exclusions/monitor/dao/GlDistribution.hbm.xml");
            config.addResource("oih/business/removals/exclusions/ExclusionDefinition.hbm.xml");
            sessionFactory = config.buildSessionFactory();
        } catch (RuntimeException e) {
            e.printStackTrace();
        }

        rateDao = OihAutomationRateHibernateDAO.getInstance();
        rateDao.setSessionFactory(sessionFactory);
        sundayExclusionDao = SundayExclusionHibernateDAO.getInstance();
        sundayExclusionDao.setSessionFactory(sessionFactory);
        distributionDao = GlDistributionHibernateDAO.getInstance();
        distributionDao.setSessionFactory(sessionFactory);
        exclusionDao = ExclusionDAO.getInstance();
        exclusionDao.setSessionFactory(sessionFactory);
        
        sessionFactory.openSession().
        createSQLQuery("DELETE FROM " + OihAutomationRateHibernateDAO._TABLE).executeUpdate();
        sessionFactory.openSession().
        createSQLQuery("DELETE FROM " + SundayExclusionHibernateDAO._TABLE).executeUpdate();
        sessionFactory.openSession().
        createSQLQuery("DELETE FROM " + GlDistributionHibernateDAO._TABLE).executeUpdate();
        sessionFactory.openSession().
        createSQLQuery("DELETE FROM " + "exclusion_definition").executeUpdate();
    }
    
    public static OihAutomationRateHibernateDAO getRateDao() {
        return rateDao;
    }

    public static SundayExclusionHibernateDAO getSundayExclusionDao() {
        return sundayExclusionDao;
    }
    
    public static GlDistributionHibernateDAO getDistributionDao() {
        return distributionDao;
    }
    
    public static ExclusionDAO getExclusionDao() {
        return exclusionDao;
    }
}
