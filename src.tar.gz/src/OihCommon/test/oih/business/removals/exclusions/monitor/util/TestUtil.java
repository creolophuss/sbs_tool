package oih.business.removals.exclusions.monitor.util;

import java.text.SimpleDateFormat;
import java.util.Date;

public class TestUtil {
    public static Date convertToDate(String rundateStr) {
        SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd");
        try{
            return sf.parse(rundateStr);
        }catch(Exception e){
            return null;
        }
    }
}
