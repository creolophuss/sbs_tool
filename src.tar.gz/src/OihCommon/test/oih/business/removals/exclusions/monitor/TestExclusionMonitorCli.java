package oih.business.removals.exclusions.monitor;

import java.util.Date;

import oih.business.removals.exclusions.monitor.util.TestUtil;
import oih.util.DateUtils;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.junit.BeforeClass;
import org.junit.Test;
import org.mortbay.log.Log;

public class TestExclusionMonitorCli {
    @BeforeClass
    public static void theLogThe() {
        // Plz see http://tinyurl.com/a5zcel bullet 3, item 3 for more information on the method name
        Logger.getRootLogger().setLevel(Level.INFO);
    }
    
    
    public void configEnvAndProcess() {
        String[] args = new String[] {
                "--domain=test",
                "--realm=USAmazon", 
                "--root=/apollo/env/OihWebsite",
                "--override=ExclusionChangeMonitor.cfg",
                "--executionDate=2014-08-08",
                "--gl=14",
        };
   
        testProcess(args);
    }
    
    
    public void testProcess(String args[]) {
        try{
            ExclusionChangeMonitorCli.main(args);
        }catch(Exception e) {
            e.printStackTrace();
        }
    }
    
    @Test
    public void testConvertToSunday() {
        try{
            Date executionDate = TestUtil.convertToDate("2014-08-17");
            Log.info("Sunday:" + DateUtils.convertToPreviousSunday(executionDate));
        }catch(Exception e) {
            e.printStackTrace();
        }
    }
}
