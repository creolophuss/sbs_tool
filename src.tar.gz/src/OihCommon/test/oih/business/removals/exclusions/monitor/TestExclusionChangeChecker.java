package oih.business.removals.exclusions.monitor;

import java.util.Date;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.junit.BeforeClass;
import org.junit.Test;
import org.mortbay.log.Log;

import oih.business.AmazonOrg;
import oih.business.removals.exclusions.monitor.ExclusionMonitorTestUtil;
import oih.business.removals.exclusions.monitor.util.TestUtil;
import oih.business.removals.exclusions.monitor.object.ExclusionRecord;

public class TestExclusionChangeChecker {
    @BeforeClass
    public static void theLogThe() {
        // Plz see http://tinyurl.com/a5zcel bullet 3, item 3 for more information on the method name
        Logger.getRootLogger().setLevel(Level.INFO);
    }
    static{ExclusionMonitorTestUtil.configEnv();}
    
    public void testCheckMeetExclusionChange() {
        
        Date rundate = TestUtil.convertToDate("2014-07-25");
        try{
            ExclusionRecord record 
            = ExclusionChangeChecker.checkWhetherExclusionChanged(rundate, AmazonOrg.US, 14, "N");
            Log.info("Result record:" + record);
        }catch(Exception e) {
            e.printStackTrace();
        }
    }
}
