package oih.business.removals.exclusions;

import java.util.HashMap;
import java.util.List;
import java.util.Properties;

import oih.business.AmazonOrg;
import oih.business.removals.ValidatorErrorBean;
import oih.config.ConfigFactory;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import testutils.HSQLDBUtils;

public class ExclusionRuleValidatorTest {

    private SessionFactory sessionFactory;

    private ExclusionReasonCodeDAO exclusionReasonCodeDAO;

    ExclusionRuleValidator validator = null;

    @Before
    public void setup() {
        Properties props = new Properties();

        HSQLDBUtils.cleanupHSQLDBFiles("/var/tmp", "testdb");

        props.setProperty("hibernate.connection.driver_class", "org.hsqldb.jdbcDriver");
        props.setProperty("hibernate.connection.url", "jdbc:hsqldb:file:/var/tmp/testdb");
        props.setProperty("hibernate.connection.username", "sa");
        props.setProperty("hibernate.connection.password", "");
        props.setProperty("hibernate.dialect", "org.hibernate.dialect.HSQLDialect");
        props.setProperty("hibernate.hbm2ddl.auto", "create");
        props.setProperty("connection.pool_size", "5");
        props.setProperty("show_sql", "true");

        AnnotationConfiguration config = new AnnotationConfiguration();
		config.addPackage("oih.business.removals.exclusions")
	      .addAnnotatedClass(ExclusionRuleFieldCfg.class);

        config.setProperties(props);
        try {
            // need to specify classes to be mapped by hand too
            config.addResource("oih/business/removals/exclusions/ExclusionDefinition.hbm.xml");
            config.addResource("oih/business/buyer/BuyerUnhealthyDetail.hbm.xml");
            config.addResource("oih/business/buyer/BuyerUnhealthyDetailExpand.hbm.xml");
            config.addResource("oih/business/removals/exclusions/ExclusionReasonCode.hbm.xml");
            config.addResource("oih/business/removals/exclusions/ExclusionRuleEntity.hbm.xml");
            sessionFactory = config.buildSessionFactory();
            ExclusionConfigProvider.getIntance().setSessionFactory(sessionFactory);
        } catch (RuntimeException e) {
            e.printStackTrace();
        }

        exclusionReasonCodeDAO = ExclusionReasonCodeDAO.getInstance();
        exclusionReasonCodeDAO.setSessionFactory(sessionFactory);

        ExclusionReasonCode exclusionReasonCode = new ExclusionReasonCode();
        exclusionReasonCode.setExclusionReasonCode("UNSPECIFIED");
        exclusionReasonCode.setIsDeprecated(false);
        exclusionReasonCodeDAO.save(exclusionReasonCode);
        
        ConfigFactory.useConfigFrom("test", "USAmazon", new HashMap<String, Object>());

        validator = new ExclusionRuleValidatorImpl(sessionFactory);
    }

    private ExclusionRule newValidExclusionRule() {
        ExclusionRule rule = new ExclusionRule();
        rule.setStartDate("2011-01-02");
        rule.setEndDate("2011-03-02");
        rule.setGl(10 + "");
        rule.setOrg(AmazonOrg.CA.toString());
        rule.setOverrideRemovalType("Markdown");
        rule.setClearActioningQuantity("NO");
        rule.Add2AsinLike("asin", "DSBBCD");
        rule.setExclusionReasonCode("UNSPECIFIED");
        return rule;
    }

    @Test
    public void testValidate() {
        ExclusionRule rule = newValidExclusionRule();
        List<ValidatorErrorBean> validatorErrors = validator.validate(rule);
        print(validatorErrors);
        Assert.assertTrue("no error", validatorErrors.size() == 0);

        rule = newValidExclusionRule();
        rule.setEndDate("");
        validatorErrors = validator.validate(rule);
        print(validatorErrors);
        Assert.assertTrue("rule:startdate XOR endDate =0", validatorErrors.size() > 0);

        rule = newValidExclusionRule();
        rule.setEndDate("110-03-02");
        validatorErrors = validator.validate(rule);
        print(validatorErrors);
        Assert.assertTrue("rule:startTime<endDate", validatorErrors.size() > 0);

        rule = newValidExclusionRule();
        rule.setOverrideRemovalType("mark");
        validatorErrors = validator.validate(rule);
        print(validatorErrors);
        Assert.assertTrue("remove type invalid", validatorErrors.size() > 0);

        rule = newValidExclusionRule();
        rule.setClearActioningQuantity("YES");
        validatorErrors = validator.validate(rule);
        print(validatorErrors);
        Assert.assertTrue("removetype XOR ClearActioningQuantity=1", validatorErrors.size() > 0);

        rule = newValidExclusionRule();
        rule.setOverrideRemovalType(null);
        rule.setClearActioningQuantity("NO");
        validatorErrors = validator.validate(rule);
        print(validatorErrors);
        Assert.assertTrue("removetype XOR ClearActioningQuantity=1", validatorErrors.size() > 0);

        rule = newValidExclusionRule();
        rule.Add2AsinLike("asin1", "");
        validatorErrors = validator.validate(rule);
        print(validatorErrors);
        Assert.assertTrue("AsinLike property name error", validatorErrors.size() > 0);

        rule = newValidExclusionRule();
        rule.Add2AsinLike("asin", "*ssddd");
        validatorErrors = validator.validate(rule);
        print(validatorErrors);
        Assert.assertTrue("AsinLike property operator error", validatorErrors.size() > 0);

        rule = newValidExclusionRule();
        rule.Add2AsinLike("iog", "abc");
        validatorErrors = validator.validate(rule);
        print(validatorErrors);
        Assert.assertTrue("AsinLike property type error", validatorErrors.size() > 0);
        
        rule = newValidExclusionRule();
        rule.Add2AsinLike("iog", "=12");
        validatorErrors = validator.validate(rule);
        print(validatorErrors);
        Assert.assertTrue("AsinLike support muti conditions", validatorErrors.size() == 0);  

    }

    private void print(List<ValidatorErrorBean> validatorErrors) {
        System.out.println("print validatorErrors ");
        for (ValidatorErrorBean e : validatorErrors) {
            System.out.println(e.getErrorType() + ":\t" + e.getMessage());
        }
    }

}
