package oih.business.removals.exclusions;

import java.text.ParseException;
import java.util.Map;
import java.util.Properties;

import oih.business.AmazonOrg;
import oih.business.buyer.BuyerUnhealthyDetail;
import oih.util.DateUtils;
import oih.util.Pair;
import oih.util.hibernate.HibernateUtil;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;
import org.hibernate.type.Type;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import testutils.HSQLDBUtils;

public class ExclusionRuleConvertUtilsTest {

    static final int TEST_GL= 14;
    static final AmazonOrg org= AmazonOrg.CA;
    
    private static SessionFactory sessionFactory;
    
    private static Map<String,Pair<String, Type>> cols2props;
    private static Map<String,Pair<String, Type>> props2cols;
    
    @BeforeClass
    public static void setup() {
        setupHSQL();        
    }
    private static void setupHSQL(){
        Properties props = new Properties();        
        HSQLDBUtils.cleanupHSQLDBFiles("/var/tmp", "testdb");
        props.setProperty("hibernate.connection.driver_class", "org.hsqldb.jdbcDriver");
        props.setProperty("hibernate.connection.url", "jdbc:hsqldb:file:/var/tmp/testdb");
        props.setProperty("hibernate.connection.username", "sa");
        props.setProperty("hibernate.connection.password", "");
        props.setProperty("hibernate.dialect", "org.hibernate.dialect.HSQLDialect");
        props.setProperty("hibernate.hbm2ddl.auto", "create");
        props.setProperty("connection.pool_size", "5");
        props.setProperty("hibernate.jdbc.batch_size", "50");
        props.setProperty("show_sql", "true");
        

        AnnotationConfiguration config = new AnnotationConfiguration();
        config.addPackage("oih.business.removals.exclusions")
          .addAnnotatedClass(ExclusionRuleFieldCfg.class);

        config.setProperties(props);
        try {
            // need to specify classes to be mapped by hand too
            config.addResource("oih/business/removals/exclusions/ExclusionDefinition.hbm.xml");
            config.addResource("oih/business/buyer/BuyerUnhealthyDetail.hbm.xml");
            config.addResource("oih/business/buyer/BuyerUnhealthyDetailExpand.hbm.xml");
            config.addResource("oih/business/removals/exclusions/ExclusionReasonCode.hbm.xml");
            config.addResource("oih/business/removals/exclusions/ExclusionRuleEntity.hbm.xml");
            sessionFactory = config.buildSessionFactory();
            ExclusionConfigProvider.getIntance().setSessionFactory(sessionFactory);
        } catch (RuntimeException e) {
            e.printStackTrace();
        }
        
        cols2props = HibernateUtil.getColumns2PropertiesMapping(sessionFactory
                , BuyerUnhealthyDetail.class);
        props2cols = HibernateUtil.getProperties2ColumnsMapping(sessionFactory
                , BuyerUnhealthyDetail.class);

    }
    
    private ExclusionRule newValidExclusionRuleWithEmptyAsinlike() {
        ExclusionRule rule = new ExclusionRule();
        rule.setStartDate("2011-01-02");
        rule.setEndDate("2011-03-02");
        rule.setGl(10 + "");
        rule.setOrg(AmazonOrg.CA.toString());
        rule.setOverrideRemovalType("Markdown");
        rule.setClearActioningQuantity("NO");
        rule.setRulePosition("1");
        return rule;
    }
    
    private ExclusionDefinition newExclusionDefinition() {
        ExclusionDefinition rule = new ExclusionDefinition();
        try {
            rule.setStartDate(DateUtils.parseDate("2011-01-02"));
            rule.setEndDate(DateUtils.parseDate("2011-01-02"));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        rule.setGl(TEST_GL );
        rule.setOrg(AmazonOrg.CA);
        rule.setOverrideRemovalType("Markdown");
        rule.setClearActioningQuantity("NO");
        rule.setWhereClause("( asin = '123d' ) AND ( vendor = 'joe' )");
        rule.setRulePosition(0);
        return rule;
    }   
    
    
    @Test
    public void testConvertExclusionDefintion2ExclusionRule(){
        //is null for string        
        ExclusionDefinition def = this.newExclusionDefinition();
        def.setWhereClause("( asin = '123d' ) AND ( vendor is null )");    
        ExclusionRule rule = ExclusionRuleConvertUtils.convertExclusionDefintion2ExclusionRule(def, cols2props);
        Assert.assertEquals(rule.getAsinLike().get("asin"), "123d");
        Assert.assertEquals(rule.getAsinLike().get("vendor"), "is null");
        
        def.setWhereClause("( vendor is null or vendor = '' or vendor = 'null' or vendor = 'NULL' )");    
        rule = ExclusionRuleConvertUtils.convertExclusionDefintion2ExclusionRule(def, cols2props);
        Assert.assertEquals(rule.getAsinLike().get("vendor"), "is null");
        
        def.setWhereClause("( vendor = 'null' )");         
        rule = ExclusionRuleConvertUtils.convertExclusionDefintion2ExclusionRule(def, cols2props);
        Assert.assertEquals(rule.getAsinLike().get("vendor"), "null");    
        
        //is null for number
        def.setWhereClause("( cost is null' )");         
        rule = ExclusionRuleConvertUtils.convertExclusionDefintion2ExclusionRule(def, cols2props);
        Assert.assertEquals(rule.getAsinLike().get("cost"), "is null");    
        
        //is null for date
        def.setWhereClause("( rundate is null or rundate = '' or rundate = 'null' or rundate = 'NULL' )");    
        rule = ExclusionRuleConvertUtils.convertExclusionDefintion2ExclusionRule(def, cols2props);
        Assert.assertEquals(rule.getAsinLike().get("rundate"), "is null");
        
        def.setWhereClause("( rundate = 'null' )");         
        rule = ExclusionRuleConvertUtils.convertExclusionDefintion2ExclusionRule(def, cols2props);
        Assert.assertEquals(rule.getAsinLike().get("rundate"), "null");  
        
        //'' for string
        def.setWhereClause("( vendor = '' )");    
        rule = ExclusionRuleConvertUtils.convertExclusionDefintion2ExclusionRule(def, cols2props);
        Assert.assertEquals(rule.getAsinLike().get("vendor"), "''");
   
        //like for string
        def.setWhereClause("( vendor like '%joe%' )");
        rule = ExclusionRuleConvertUtils.convertExclusionDefintion2ExclusionRule(def, cols2props);
        Assert.assertEquals(rule.getAsinLike().get("vendor"), "like(joe)");
        
        //between for number
        def.setWhereClause("( cost between 0.1 and 10 )");        
        rule = ExclusionRuleConvertUtils.convertExclusionDefintion2ExclusionRule(def, cols2props);
        Assert.assertEquals(rule.getAsinLike().get("cost"), "between 0.1 and 10");
        
        //operator for number
        def.setWhereClause("( cost = 0.1 )");        
        rule = ExclusionRuleConvertUtils.convertExclusionDefintion2ExclusionRule(def, cols2props);
        Assert.assertEquals(rule.getAsinLike().get("cost"), "0.1");     
        def.setWhereClause("( cost >= 0.1 )");        
        rule = ExclusionRuleConvertUtils.convertExclusionDefintion2ExclusionRule(def, cols2props);
        Assert.assertEquals(rule.getAsinLike().get("cost"), ">= 0.1");   
        def.setWhereClause("( cost > 0.1 )");        
        rule = ExclusionRuleConvertUtils.convertExclusionDefintion2ExclusionRule(def, cols2props);
        Assert.assertEquals(rule.getAsinLike().get("cost"), "> 0.1");  
        def.setWhereClause("( cost <= 0.1 )");        
        rule = ExclusionRuleConvertUtils.convertExclusionDefintion2ExclusionRule(def, cols2props);
        Assert.assertEquals(rule.getAsinLike().get("cost"), "<= 0.1");   
        def.setWhereClause("( cost < 0.1 )");        
        rule = ExclusionRuleConvertUtils.convertExclusionDefintion2ExclusionRule(def, cols2props);
        Assert.assertEquals(rule.getAsinLike().get("cost"), "< 0.1"); 
        
        //operator for date
        def.setWhereClause("( rundate = 2011-01-20 )");        
        rule = ExclusionRuleConvertUtils.convertExclusionDefintion2ExclusionRule(def, cols2props);
        Assert.assertEquals(rule.getAsinLike().get("rundate"), "2011-01-20");     
        def.setWhereClause("( rundate >= 2011-01-20 )");        
        rule = ExclusionRuleConvertUtils.convertExclusionDefintion2ExclusionRule(def, cols2props);
        Assert.assertEquals(rule.getAsinLike().get("rundate"), ">= 2011-01-20");   
        def.setWhereClause("( rundate > 2011-01-20 )");        
        rule = ExclusionRuleConvertUtils.convertExclusionDefintion2ExclusionRule(def, cols2props);
        Assert.assertEquals(rule.getAsinLike().get("rundate"), "> 2011-01-20");  
        def.setWhereClause("( rundate <= 2011-01-20 )");        
        rule = ExclusionRuleConvertUtils.convertExclusionDefintion2ExclusionRule(def, cols2props);
        Assert.assertEquals(rule.getAsinLike().get("rundate"), "<= 2011-01-20");   
        def.setWhereClause("( rundate < 2011-01-20 )");        
        rule = ExclusionRuleConvertUtils.convertExclusionDefintion2ExclusionRule(def, cols2props);
        Assert.assertEquals(rule.getAsinLike().get("rundate"), "< 2011-01-20"); 
        
        def.setWhereClause("( rundate >= subdate(12) ) AND ( map_end_date < adddate(13) )");    
        rule = ExclusionRuleConvertUtils.convertExclusionDefintion2ExclusionRule(def, cols2props);
        Assert.assertEquals(rule.getAsinLike().get("rundate"), ">= subdate(12)");
        Assert.assertEquals(rule.getAsinLike().get("mapEndDate"), "< adddate(13)");
        
        def.setWhereClause("( rundate > now() - 12 ) AND ( map_end_date < now() - 12 )");    
        rule = ExclusionRuleConvertUtils.convertExclusionDefintion2ExclusionRule(def, cols2props);
        Assert.assertEquals(rule.getAsinLike().get("rundate"), "> now() - 12");
        Assert.assertEquals(rule.getAsinLike().get("mapEndDate"), "< now() - 12");        

        def.setWhereClause("( last_receipt > subdate(now(), 30) ) AND ( map_end_date < subdate(now(), 30, DAY) ) AND ( publication_date < adddate(now(), 30, MONTH) )");    
        rule = ExclusionRuleConvertUtils.convertExclusionDefintion2ExclusionRule(def, cols2props);
        Assert.assertEquals(rule.getAsinLike().get("lastReceiptDate"), "> subdate(now(), 30)");
        Assert.assertEquals(rule.getAsinLike().get("mapEndDate"), "< subdate(now(), 30, DAY)");  
        Assert.assertEquals(rule.getAsinLike().get("publicationDate"), "< adddate(now(), 30, MONTH)");      
          
        def.setWhereClause("( rundate = 'null' )");         
        rule = ExclusionRuleConvertUtils.convertExclusionDefintion2ExclusionRule(def, cols2props);
        Assert.assertEquals(rule.getAsinLike().get("rundate"), "null");     
        
    }
    
    @Test
    public void testConvertExclusionDefintion2ExclusionRuleEntity(){
        ExclusionDefinition def = this.newExclusionDefinition();
        def.setWhereClause("( asin = '123d' ) AND ( vendor is null )");    
        ExclusionRuleEntity entity = ExclusionRuleConvertUtils.convertExclusionDefintion2ExclusionRuleEntity(def, cols2props);
        Assert.assertEquals(entity.getAsinLike(), "{\"asin\":\"123d\",\"vendor\":\"is null\"}");
        
        def.setWhereClause("( vendor = 'null' )");         
        entity = ExclusionRuleConvertUtils.convertExclusionDefintion2ExclusionRuleEntity(def, cols2props);
        Assert.assertEquals(entity.getAsinLike(), "{\"vendor\":\"null\"}");    
         
        def.setWhereClause("( vendor is null or vendor = '' or vendor = 'null' or vendor = 'NULL' )");    
        entity = ExclusionRuleConvertUtils.convertExclusionDefintion2ExclusionRuleEntity(def, cols2props);
        Assert.assertEquals(entity.getAsinLike(), "{\"vendor\":\"is null\"}");
        
        def.setWhereClause("( vendor is null or vendor = '' or vendor = 'null' or vendor = 'NULL' )");    
        entity = ExclusionRuleConvertUtils.convertExclusionDefintion2ExclusionRuleEntity(def, cols2props);
        Assert.assertEquals(entity.getAsinLike(), "{\"vendor\":\"is null\"}");
        
        def.setWhereClause("( vendor is null or vendor = '' or vendor = 'null' or vendor = 'NULL' )");    
        entity = ExclusionRuleConvertUtils.convertExclusionDefintion2ExclusionRuleEntity(def, cols2props);
        Assert.assertEquals(entity.getAsinLike(), "{\"vendor\":\"is null\"}");
       
        def.setWhereClause("( vendor like '%joe%' )");
        entity = ExclusionRuleConvertUtils.convertExclusionDefintion2ExclusionRuleEntity(def, cols2props);
        Assert.assertEquals(entity.getAsinLike(), "{\"vendor\":\"like(joe)\"}");
        
        def.setWhereClause("( cost between 0.1 and 10 )");        
        entity = ExclusionRuleConvertUtils.convertExclusionDefintion2ExclusionRuleEntity(def, cols2props);
        Assert.assertEquals(entity.getAsinLike(), "{\"cost\":\"between 0.1 and 10\"}");
        
        def.setWhereClause("( cost = 0.1 )");        
        entity = ExclusionRuleConvertUtils.convertExclusionDefintion2ExclusionRuleEntity(def, cols2props);
        Assert.assertEquals(entity.getAsinLike(), "{\"cost\":\"0.1\"}");        
    }

    @Test
    public void testConvertExclusionRule2ExclusionDefintion() throws ParseException{
        //is null for string        
        ExclusionRule rule = this.newValidExclusionRuleWithEmptyAsinlike();
        rule.Add2AsinLike("vendor", "is null");
        ExclusionDefinition def = ExclusionRuleConvertUtils.convertExclusionRule2ExclusionDefinition(rule, props2cols);
        Assert.assertEquals(def.getWhereClause(),"( vendor is null or vendor = 'NULL' or vendor = 'null' or vendor = '' )");
        
        //is null for number
        rule = this.newValidExclusionRuleWithEmptyAsinlike();
        rule.Add2AsinLike("cost", "is null");     
        def = ExclusionRuleConvertUtils.convertExclusionRule2ExclusionDefinition(rule, props2cols);
        Assert.assertEquals(def.getWhereClause(),"( cost is null )");    
        
        //is null for date
        rule = this.newValidExclusionRuleWithEmptyAsinlike();
        rule.Add2AsinLike("rundate", "is null");    
        def = ExclusionRuleConvertUtils.convertExclusionRule2ExclusionDefinition(rule, props2cols);
        Assert.assertEquals(def.getWhereClause(),"( rundate is null )");
        
        rule = this.newValidExclusionRuleWithEmptyAsinlike();
        rule.Add2AsinLike("rundate", "null");         
        def = ExclusionRuleConvertUtils.convertExclusionRule2ExclusionDefinition(rule, props2cols);
        Assert.assertEquals(def.getWhereClause(),"( rundate = 'null' )");  
        
        //'' for string
        rule = this.newValidExclusionRuleWithEmptyAsinlike();
        rule.Add2AsinLike("vendor", "''");    
        def = ExclusionRuleConvertUtils.convertExclusionRule2ExclusionDefinition(rule, props2cols);
        Assert.assertEquals(def.getWhereClause(),"( vendor = '' )");
        
        rule = this.newValidExclusionRuleWithEmptyAsinlike();
        rule.Add2AsinLike("vendor", "");    
        def = ExclusionRuleConvertUtils.convertExclusionRule2ExclusionDefinition(rule, props2cols);
        Assert.assertEquals(def.getWhereClause(),"( vendor = '' )");       
   
        //like for string
        rule = this.newValidExclusionRuleWithEmptyAsinlike();
        rule.Add2AsinLike("vendor", "like(joe)");
        def = ExclusionRuleConvertUtils.convertExclusionRule2ExclusionDefinition(rule, props2cols);
        Assert.assertEquals(def.getWhereClause(),"( vendor like '%joe%' )");
        
        //between for number
        rule = this.newValidExclusionRuleWithEmptyAsinlike();
        rule.Add2AsinLike("cost", "between 0.1 and 10");        
        def = ExclusionRuleConvertUtils.convertExclusionRule2ExclusionDefinition(rule, props2cols);
        Assert.assertEquals(def.getWhereClause(),"( cost between 0.1 and 10 )");
        
        //operator for number
        rule = this.newValidExclusionRuleWithEmptyAsinlike();
        rule.Add2AsinLike("cost", "0.1");        
        def = ExclusionRuleConvertUtils.convertExclusionRule2ExclusionDefinition(rule, props2cols);
        Assert.assertEquals(def.getWhereClause(),"( cost = 0.1 )");     
        
        rule = this.newValidExclusionRuleWithEmptyAsinlike();
        rule.Add2AsinLike("cost", ">= 0.1");        
        def = ExclusionRuleConvertUtils.convertExclusionRule2ExclusionDefinition(rule, props2cols);
        Assert.assertEquals(def.getWhereClause(),"( cost >= 0.1 )");   
        
        rule = this.newValidExclusionRuleWithEmptyAsinlike();
        rule.Add2AsinLike("cost", "> 0.1");        
        def = ExclusionRuleConvertUtils.convertExclusionRule2ExclusionDefinition(rule, props2cols);
        Assert.assertEquals(def.getWhereClause(),"( cost > 0.1 )");  
        
        rule = this.newValidExclusionRuleWithEmptyAsinlike();
        rule.Add2AsinLike("cost", "<= 0.1");        
        def = ExclusionRuleConvertUtils.convertExclusionRule2ExclusionDefinition(rule, props2cols);
        Assert.assertEquals(def.getWhereClause(),"( cost <= 0.1 )");
        
        rule = this.newValidExclusionRuleWithEmptyAsinlike();
        rule.Add2AsinLike("cost", "< 0.1");        
        def = ExclusionRuleConvertUtils.convertExclusionRule2ExclusionDefinition(rule, props2cols);
        Assert.assertEquals(def.getWhereClause(),"( cost < 0.1 )"); 
        
        //operator for date
        rule = this.newValidExclusionRuleWithEmptyAsinlike();
        rule.Add2AsinLike("rundate", "2011-01-20");        
        def = ExclusionRuleConvertUtils.convertExclusionRule2ExclusionDefinition(rule, props2cols);
        Assert.assertEquals(def.getWhereClause(),"( rundate = '2011-01-20' )");    
        
        rule = this.newValidExclusionRuleWithEmptyAsinlike();
        rule.Add2AsinLike("rundate", ">= 2011-01-20");        
        def = ExclusionRuleConvertUtils.convertExclusionRule2ExclusionDefinition(rule, props2cols);
        Assert.assertEquals(def.getWhereClause(),"( rundate >= '2011-01-20' )"); 
        
        rule = this.newValidExclusionRuleWithEmptyAsinlike();
        rule.Add2AsinLike("rundate", "> 2011-01-20");        
        def = ExclusionRuleConvertUtils.convertExclusionRule2ExclusionDefinition(rule, props2cols);
        Assert.assertEquals(def.getWhereClause(),"( rundate > '2011-01-20' )"); 
        
        rule = this.newValidExclusionRuleWithEmptyAsinlike();
        rule.Add2AsinLike("rundate", "<= 2011-01-20");        
        def = ExclusionRuleConvertUtils.convertExclusionRule2ExclusionDefinition(rule, props2cols);
        Assert.assertEquals(def.getWhereClause(),"( rundate <= '2011-01-20' )");  
        
        rule = this.newValidExclusionRuleWithEmptyAsinlike();
        rule.Add2AsinLike("rundate", "< 2011-01-20");        
        def = ExclusionRuleConvertUtils.convertExclusionRule2ExclusionDefinition(rule, props2cols);
        Assert.assertEquals(def.getWhereClause(),"( rundate < '2011-01-20' )");     
        
        rule = this.newValidExclusionRuleWithEmptyAsinlike();
        rule.setRulePosition("1");
        def = ExclusionRuleConvertUtils.convertExclusionRule2ExclusionDefinition(rule, props2cols);
        Assert.assertEquals(def.getRulePosition(), new Integer(1));        
        
    }
}
