package oih.business.removals.exclusions.monitor.email;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.junit.BeforeClass;
import org.junit.Test;
import org.mortbay.log.Log;
import com.amazon.hrisworkforce.EmpInfo;

import oih.business.removals.exclusions.monitor.ExclusionMonitorTestUtil;
import oih.business.removals.exclusions.monitor.dependency.HRISServiceUtil;

public class TestHRISServiceUtil {
    @BeforeClass
    public static void theLogThe() {
        // Plz see http://tinyurl.com/a5zcel bullet 3, item 3 for more information on the method name
        Logger.getRootLogger().setLevel(Level.INFO);
    }
    static{ExclusionMonitorTestUtil.configEnv();}
    
    public void testHRISService() {
        try{ 
            EmpInfo empInfo = HRISServiceUtil.getEmpInfoByLogin("zhangxl");
            Log.info(empInfo.getMgruid());
        }catch(Exception e) {
            e.printStackTrace();
        }
    }

    public void testGetJobLevel() {
        try{ 
            EmpInfo empInfo = HRISServiceUtil.getEmpInfoByLogin("zhangxl");
            Log.info(empInfo.getMgruid());
            Integer jobLevel = HRISServiceUtil.getJobLevel(empInfo.getJobLevel());
            Log.info("Job level:" + jobLevel);
        }catch(Exception e) {
            e.printStackTrace();
        }
    }
    

    public void testGetLevel7Manager() {
        try{ 
            String level7Mgr = HRISServiceUtil.getLevel7Manager("weig");
            Log.info("level 7 mgr: " + level7Mgr);
        }catch(Exception e) {
            e.printStackTrace();
        }
    }
}
