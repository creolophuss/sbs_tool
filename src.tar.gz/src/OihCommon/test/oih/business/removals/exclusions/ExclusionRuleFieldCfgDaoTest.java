package oih.business.removals.exclusions;

import java.util.Date;
import java.util.List;
import java.util.Properties;

import junit.framework.Assert;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.junit.Before;
import org.junit.Test;

public class ExclusionRuleFieldCfgDaoTest {
	
	private SessionFactory sessionFactory;
	private ExclusionRuleFieldCfgDao dao;
	private ExclusionRuleFieldCfg cfg;
	
	@Before
	public void setup() {
		// SessionFactory/HSQLDB/schema is built for each test.
        // Not fast, but we have a clean DB each test
        // Setup all config properties by hand.
        Properties props = new Properties();
        props.setProperty("hibernate.connection.driver_class", "org.hsqldb.jdbcDriver");
        // to connect to server running on localhost, use url like: jdbc:hsqldb:hsql://localhost/xdb
        props.setProperty("hibernate.connection.url", "jdbc:hsqldb:file:/var/tmp/testdb");
       
        props.setProperty("hibernate.connection.username", "sa");
        props.setProperty("hibernate.connection.password", "");
        props.setProperty("hibernate.dialect", "org.hibernate.dialect.HSQLDialect");
        props.setProperty("connection.pool_size", "5");
        props.setProperty("hibernate.hbm2ddl.auto", "create");
        props.setProperty("show_sql", "true");;
        
		AnnotationConfiguration config = new AnnotationConfiguration();
		config.addPackage("oih.business.removals.exclusions")
	      .addAnnotatedClass(ExclusionRuleFieldCfg.class);
		config.setProperties(props);
		
		try {
			// need to specify classes to be mapped by hand too
			sessionFactory = config.buildSessionFactory();
		} catch (RuntimeException e) {
			e.printStackTrace();
		}

		dao = new ExclusionRuleFieldCfgDao();
		dao.setSessionFactory(sessionFactory);

		sessionFactory.openSession().createSQLQuery(
				"DELETE FROM " + ExclusionRuleFieldCfg.TABLE).executeUpdate();
		cfg = addCfg();
	}
	
	@Test
	public void testGetAllCfgs(){
		 List<ExclusionRuleFieldCfg> list = dao.getFieldCfg();
		 Assert.assertTrue(list != null && list.size() == 1);
	}
	
	@Test
	public void testGetCfgByFieldAndType(){
		List<ExclusionRuleFieldCfg> list = dao.getFieldCfg(cfg.getField(), cfg.getType());
		Assert.assertTrue(list != null && list.size() == 1);
		Assert.assertTrue("=".equals(list.get(0).getValue()));
	}
	 
	private ExclusionRuleFieldCfg addCfg(){
		ExclusionRuleFieldCfg cfg = new ExclusionRuleFieldCfg();
		cfg.setField("startDate");
		cfg.setType(ExclusionRuleCfgType.FIELD_OPERATOR);
		cfg.setValue("=");
		cfg.setCreatedBy("junit");
		cfg.setCreatedDate(new Date());
		cfg.setLastUpdatedBy("junit");
		cfg.setLastUpdatedDate(new Date());
		dao.addFieldCfg(cfg);
		return cfg;
	}
}
