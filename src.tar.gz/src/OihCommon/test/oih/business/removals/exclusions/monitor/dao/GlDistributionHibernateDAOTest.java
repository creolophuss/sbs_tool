package oih.business.removals.exclusions.monitor.dao;

import java.util.Date;
import java.util.List;

import oih.business.AmazonOrg;
import oih.business.removals.exclusions.monitor.dao.GlDistribution;
import oih.business.removals.exclusions.monitor.dao.GlDistributionHibernateDAO;
import oih.business.removals.exclusions.monitor.util.TestUtil;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.mortbay.log.Log;

public class GlDistributionHibernateDAOTest {
    private GlDistributionHibernateDAO dao;
    
    @BeforeClass
    public static void theLogThe() {
        // Plz see http://tinyurl.com/a5zcel bullet 3, item 3 for more information on the method name
        Logger.getRootLogger().setLevel(Level.INFO);
    }

    @Before
    public void setup() {
        dao = HibernateDAOTestUtil.getDistributionDao();
    }

    private GlDistribution newGlDistribution(
                     Date rundate, String org, int gl, Integer units, 
                     Double percentage, Date createdDate){
        GlDistribution distribution = new GlDistribution();
        distribution.setRundate(rundate);
        distribution.setOrg(org);
        distribution.setGl(gl);
        distribution.setUnits(units);
        distribution.setPercentage(percentage);
        distribution.setCreatedDate(createdDate);
        return distribution;
    }
    
    private void generateTestTable() {
        Date rundate = TestUtil.convertToDate("2014-07-20");
        String org = AmazonOrg.US.getRealm();
        Integer gl = 14;
        Integer units = 10;
        Double percentage = 0.99;
        Date createdDate = TestUtil.convertToDate("2014-07-29");
        GlDistribution distribution = this.newGlDistribution(rundate, org, gl, 
                units, percentage, createdDate);
        dao.save(distribution);
    }
    
    @Test
    public void testFindGlDistributions() {
        this.generateTestTable();
        Date rundate = TestUtil.convertToDate("2014-07-20");     
        try{
            List<GlDistribution> distributions 
            = dao.findGlDistributins(AmazonOrg.US, rundate);
            if(distributions == null || distributions.size() == 0)
                Log.info("No result");
            Log.info("Totally got " + distributions.size() + " results.");
            for(int i = 0; i < distributions.size(); i++){
                Log.info("distribution:" + distributions.get(i));
            }
        }catch(Exception e){
            e.printStackTrace();
            Log.info("Got exception:" + e.getMessage(), e);
        }
    }
}
