package oih.business.removals.exclusions.monitor;

import java.util.Date;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.junit.BeforeClass;
import org.junit.Test;
import org.mortbay.log.Log;

import oih.business.AmazonOrg;
import oih.business.removals.exclusions.monitor.ExclusionMonitorTestUtil;
import oih.business.removals.exclusions.monitor.object.WorkflowLockChecker;
import oih.business.removals.exclusions.monitor.util.TestUtil;

public class TestWorkflowLockedChecker {
    @BeforeClass
    public static void theLogThe() {
        // Plz see http://tinyurl.com/a5zcel bullet 3, item 3 for more information on the method name
        Logger.getRootLogger().setLevel(Level.INFO);
    }
    static{ExclusionMonitorTestUtil.configEnv();}

    public void testGenerateLockName() {
        Date rundate = TestUtil.convertToDate("2013-04-14");
        String lockName = WorkflowLockChecker.generateLockName(AmazonOrg.US, rundate);
        Log.info("Log Name:" + lockName);
    }
    
    public void testCheckWorkflowLocked() {
        Date rundate = TestUtil.convertToDate("2013-04-14");
        Boolean isLocked = WorkflowLockChecker.IsWorkflowLocked(AmazonOrg.CN, rundate);
        Log.info("Is Locked:" + isLocked);   
    }
}
