package oih.config.automationsetup.gl;

import static org.junit.Assert.*;

import java.util.HashMap;
import java.util.Map;

import org.junit.Test;

public class GlToNameMapTest {

    @Test
    public void testGetNameByGl() {
        final Map<String, String> mapGl2Name = new HashMap<String, String>();
        mapGl2Name.put("14", "Books");
        mapGl2Name.put("15", "Music");
        GlToNameMap glToNameMap = new GlToNameMap(null);
        glToNameMap.setGlNameMappings(mapGl2Name);
        
        assertTrue(glToNameMap.getNameByGl(14).equals("Books"));
        assertTrue(glToNameMap.getNameByGl(15).equals("Music"));
        assertTrue(glToNameMap.getNameByGl(21) == null);
    }

}
