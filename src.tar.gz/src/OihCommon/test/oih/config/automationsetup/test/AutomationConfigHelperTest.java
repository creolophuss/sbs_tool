package oih.config.automationsetup.test;

import java.util.List;
import java.util.Properties;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.amazon.oih.dao.DaoModule;
import com.amazon.oihautomationsetup.model.dao.NodeDao;
import com.amazon.oihvendorflex.WarehouseNode;
import com.google.inject.Guice;
import com.google.inject.Inject;
import com.google.inject.Injector;

public class AutomationConfigHelperTest {

    private SessionFactory sessionFactory;

    @Inject
    private NodeDao nodeDao = null;

    @Before
    public void setup() {

        Properties props = new Properties();
        props.setProperty("hibernate.connection.driver_class", "org.hsqldb.jdbcDriver");
        // to connect to server running on localhost, use url like:
        // jdbc:hsqldb:hsql://localhost/xdb
        props.setProperty("hibernate.connection.url", "jdbc:hsqldb:file:/var/tmp/testdb");
        // props.setProperty("hibernate.connection.url",
        // "jdbc:hsqldb:hsql://josiaho.desktop/oih" ); // for testing a local
        // hsql server
        props.setProperty("hibernate.connection.username", "sa");
        props.setProperty("hibernate.connection.password", "");
        props.setProperty("hibernate.dialect", "org.hibernate.dialect.HSQLDialect");
        props.setProperty("connection.pool_size", "5");
        props.setProperty("hibernate.hbm2ddl.auto", "create");
        props.setProperty("show_sql", "true");

        /*
         * String args[] = new String[] { "--root=/tmp/OihConfig/configuration", "--domain=default", "--realm=USAmazon"
         * }; AppConfig.initialize("oih","oih",args); helper = AutomationConfigHelper.instance("USAmazon", "default");
         */

        Configuration config = new Configuration();

        config.setProperties(props);
        try {
            // need to specify classes to be mapped by hand too

            config.addResource("oih/config/automationsetup/model/WarehouseNode.hbm.xml");
            config.addResource("oih/config/automationsetup/model/PhysicalAddress.hbm.xml");
            sessionFactory = config.buildSessionFactory();
        } catch (RuntimeException e) {
            e.printStackTrace();
        }

        Injector injector = Guice.createInjector(new DaoModule());
        injector.injectMembers(this);

        nodeDao.setSessionFactory(sessionFactory);
    }

    @Test
    public void testGetWarehouses() {

        WarehouseNode node = new WarehouseNode();
        node.setWarehouseId("TEST");
        node.setIog(1L);
        node.setMarketplaceId(1L);

        nodeDao.saveWarehouseNode(node);
        List<WarehouseNode> nodes = nodeDao.findAllNodeByIogAndMarketPlaceId(1L, 1L);

        Assert.assertTrue(nodes != null && nodes.size() > 0);
    }

}
