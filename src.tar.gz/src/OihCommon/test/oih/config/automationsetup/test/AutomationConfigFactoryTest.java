package oih.config.automationsetup.test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import junit.framework.Assert;
import oih.config.automationsetup.AutomationConfigFactory;
import oih.config.automationsetup.AutomationConfigFromAppConfigHelper;
import oih.config.automationsetup.AutomationConfigHelperInterface;
import oih.util.MathUtil;
import oih.util.WarehouseCategorizer;

import org.apache.commons.collections15.CollectionUtils;
import org.apache.commons.collections15.Transformer;
import org.apache.commons.lang.StringUtils;
import org.junit.Before;
import org.junit.Test;

import amazon.platform.config.AppConfig;

import com.amazon.oih.dao.DaoModule;
import com.amazon.oihvendorflex.FCGlCost;
import com.amazon.oihvendorflex.WarehouseNode;
import com.google.inject.Guice;
import com.google.inject.Injector;

/**
 * this is a test to compare db automation config data with that of brazil config
 * You can follow following steps to setup the test
 * 0. un-comment //helper = AutomationConfigFactory.getDefaultConfigHelper();
 * 1. change args[], doamin, realm and override( Priority.cfg or OihWocReport.cfg). 
 * 2. if override is Priority.cfg, please comment following test cases:
 * testGetEstimateIsoByFc, testGetEstimateIsoByFcGl, testGetInventoryWarehouses
 *    if override is OihWocReport.cfg, comment test cases except the above three cases
 * 3. The test result is located in files /tmp/automation_config_verification_*
 * 4. After test, please recover all changed code
 * @author jianjbu
 *
 */
public class AutomationConfigFactoryTest {

    private AutomationConfigHelperInterface helper = null;

    @Before
    public void setup() {

        String args[] = new String[] {
                "--root=/tmp/OihConfig/configuration", "--domain=prod", "--realm=GBAmazon", "--override=Priority.cfg"
        };

        if (!AppConfig.isInitialized()) {
            try {
                AppConfig.initialize("OihMetrics", "Oih", args);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        //helper = AutomationConfigFactory.getDefaultConfigHelper();

        Injector injector = Guice.createInjector(new DaoModule());
        injector.injectMembers(this);

    }

    @Test
    public void testGetValidFcs() {

        //List<String> nodes = helper.getValidFcs();
        //List<?> orig = ConfigFactory.getDefaultConfig().findList(AutomationConfigFromAppConfigHelper.VALID_FCS_KEY);
        //Assert.assertTrue(MathUtil.isFcListEqual(orig, nodes, "list for valid fcs is not equal :"));
        Assert.assertTrue(true);
    }

    //@Test
    public void testGetReceiptCostOfFc() {
        List<String> nodes = helper.getValidFcs();
        for (String fc : nodes) {
            for (int i = 1; i < 400; i++) {
                Double oriC = getCostFromAppConfig(fc, Integer.toString(i),
                        AutomationConfigFromAppConfigHelper.RECEIPT_COST);
                Double newC = getCostFromAutomationConfig(fc, Integer.toString(i),
                        AutomationConfigFromAppConfigHelper.RECEIPT_COST);
                MathUtil.isDoubleEqual(oriC, newC, "receipt cost different between fc : " + fc + "--gl : " + i);
            }
        }
    }

    //@Test
    public void testGetRemovalCostOfFc() {
        List<String> nodes = helper.getValidFcs();
        for (String fc : nodes) {
            for (int i = 1; i < 400; i++) {
                Double oriC = getCostFromAppConfig(fc, Integer.toString(i),
                        AutomationConfigFromAppConfigHelper.REMOVAL_COST);
                Double newC = getCostFromAutomationConfig(fc, Integer.toString(i),
                        AutomationConfigFromAppConfigHelper.REMOVAL_COST);
                MathUtil.isDoubleEqual(oriC, newC, "removal cost different between fc : " + fc + "--gl : " + i + " ");
            }
        }
    }

    //@Test
    public void testGetHoldingCostOfFc() {
        List<String> nodes = helper.getValidFcs();
        for (String fc : nodes) {
            for (int i = 1; i < 400; i++) {
                Double oriC = getCostFromAppConfig(fc, Integer.toString(i),
                        AutomationConfigFromAppConfigHelper.QUARTERLY_FC_COST);
                Double newC = getCostFromAutomationConfig(fc, Integer.toString(i),
                        AutomationConfigFromAppConfigHelper.QUARTERLY_FC_COST);
                MathUtil.isDoubleEqual(oriC, newC, "holding cost different between fc : " + fc + "--gl : " + i + " ");
            }
        }
    }

    //@Test
    public void testGetTransportationInCost() {
        List<String> nodes = helper.getValidFcs();
        for (String fc : nodes) {
            for (int i = 1; i < 400; i++) {
                Double oriC = getTransportationCostFromAppConfig(fc, Integer.toString(i),
                        AutomationConfigFromAppConfigHelper.TRANSPORTATION_IN_COST);
                Double newC = getCostFromAutomationConfig(fc, Integer.toString(i),
                        AutomationConfigFromAppConfigHelper.TRANSPORTATION_IN_COST);
                MathUtil.isDoubleEqual(oriC, newC, "trans in cost different between fc : " + fc + "--gl : " + i + " ");
            }
        }

    }

    //@Test
    public void testGetFcSplitRatioMapping() {
        Map origfcSplitRatioMap = AppConfig.findMap("IhrMetrics.FcSplitRatioMapping");
        if (origfcSplitRatioMap == null)
            origfcSplitRatioMap = new HashMap<String, String>();
        Map fcSplitRatioMap = AutomationConfigFactory.getDefaultConfigHelper().findFcSplitRatioMapping();

        MathUtil.isMapEqual(origfcSplitRatioMap, fcSplitRatioMap,
                "new fcSplitRatioMap is different from original in CNuhneahlthyAsinDetail ");

    }

    //@Test
    public void testGetTransportationOutCost() {
        List<String> nodes = helper.getValidFcs();
        for (String fc : nodes) {
            for (int i = 1; i < 400; i++) {
                Double oriC = getCostFromAppConfig(fc, Integer.toString(i),
                        AutomationConfigFromAppConfigHelper.TRANSPORTATION_OUT_COST);
                Double newC = getCostFromAutomationConfig(fc, Integer.toString(i),
                        AutomationConfigFromAppConfigHelper.TRANSPORTATION_OUT_COST);
                MathUtil.isDoubleEqual(oriC, newC, "trans out cost different between fc : " + fc + "--gl : " + i + " ");
            }
        }

    }

    //@Test
    public void testGetEstimateIsoByFc() {

        Map<String, String> origEstimateIsoByFc = new HashMap<String, String>();
        Map<String, String> estimateIsoByFc = new HashMap<String, String>();
        Map<String, WarehouseNode> nodes = helper.getWarehouses();
        Map<String, Object> m = AppConfig.findObjects("IhrMetrics.HoldingCostEstimates.currencyIso.*");

        for (Map.Entry<String, Object> it : m.entrySet()) {
            origEstimateIsoByFc.put(it.getKey(), String.valueOf(it.getValue()));
        }

        for (Map.Entry<String, WarehouseNode> it : nodes.entrySet()) {
            estimateIsoByFc.put("IhrMetrics.HoldingCostEstimates.currencyIso" + "." + it.getKey(), it.getValue()
                    .getHoldingCostEstimateCurrency());
        }

        Assert.assertTrue(MathUtil.isMapEqual(origEstimateIsoByFc, estimateIsoByFc,
                "holding cost estimates currency iso map values different in HoldingCosts "));
    }
    
    //@Test
    public void testGetEstimatesByFcGl() {
        Map<String, String> origEstimateByFcGl = new HashMap<String, String>();
        Map<String, Object> m = AppConfig.findObjects("IhrMetrics.HoldingCostEstimates.*.*");
        Map<String, WarehouseNode> nodes = helper.getWarehouses();
        Map<String, String> estimatesByFcGl = new HashMap<String, String>();
        
        for (Map.Entry<String, Object> it : m.entrySet()) {
            origEstimateByFcGl.put(it.getKey(), String.valueOf(it.getValue()));
        }

        for (Map.Entry<String, WarehouseNode> it : nodes.entrySet()) {           
            List<FCGlCost> costs = helper.getFcGlCostByWarehouseIndex(it.getValue().getId());
            if (costs == null){
                continue;
            }
                
            for (FCGlCost cost : costs) {
                if (cost.getHoldingCostEstimates() != null){
                    estimatesByFcGl.put("IhrMetrics.HoldingCostEstimates." + it.getKey() + "." + cost.getGl(), cost
                            .getHoldingCostEstimates().toString());
                }                
            }
        }

        Assert.assertTrue(MathUtil.isMapEqual(origEstimateByFcGl, estimatesByFcGl,
                "hodling cost estimates by fc and gl map is different in HoldingCosts "));
    }

    //@Test
    public void testGetInventoryWarehouses(){
        List<String> origWarehouses = new ArrayList<String>();
        String w = AppConfig.findString("IhrMetrics.Extract.InventoryCosts.Warehouses");
        w = StringUtils.stripEnd(w, ") ");
        w = StringUtils.stripStart(w, " (");
        origWarehouses.addAll(Arrays.asList(StringUtils.split(w, ",")));
        
        CollectionUtils.transform(
                origWarehouses
                ,
                new Transformer<String, String>() {
                    @Override
                    public String transform(String s) {
                        return StringUtils.stripStart(StringUtils.stripEnd(s.trim(), "' "), " '");
                    }
                }
         );
        
        List<String> warehouses = helper.getInventoryCostsWarehouses();
        
        Assert.assertTrue(
                MathUtil.isFcListEqual(origWarehouses, warehouses, "inventory warehouse list different in IbepLoad "));
    }
    
    //@Test
    public void testGetWarehouseCategory(){
        WarehouseCategorizer w = new WarehouseCategorizer();
    }
    
    /*
     * get receipt cost from app config
     */
    private Double getCostFromAppConfig(String fc, String gl, final String key) {
        final String COST_KEY = key;
        String oriValue = AppConfig.findString(COST_KEY + "." + fc + "." + gl);
        if (oriValue == null) {
            oriValue = AppConfig.findString(COST_KEY + "." + fc);
            if (oriValue == null) {
                oriValue = AppConfig.findString(COST_KEY);
            }
        }

        return Double.parseDouble(oriValue);
    }

    /*
     * get receipt cost from automation config
     */
    private Double getCostFromAutomationConfig(String fc, String gl, final String key) {
        final String COST_KEY = key;

        Double newValue = null;
        if (key.equals(AutomationConfigFromAppConfigHelper.RECEIPT_COST))
            newValue = AutomationConfigFactory.getDefaultConfigHelper().getReceiptCostEstimates(fc, gl);
        else if (key.equals(AutomationConfigFromAppConfigHelper.REMOVAL_COST)) {
            newValue = AutomationConfigFactory.getDefaultConfigHelper().getFcRemovalCostEstimates(fc, gl);
        } else if (key.equals(AutomationConfigFromAppConfigHelper.QUARTERLY_FC_COST)) {
            newValue = AutomationConfigFactory.getDefaultConfigHelper().getHoldingCostEstimates(fc, gl);
        } else if (key.equals(AutomationConfigFromAppConfigHelper.TRANSPORTATION_IN_COST)) {
            newValue = AutomationConfigFactory.getDefaultConfigHelper().getTransportionInCostEstimates(fc, gl);
            if (newValue == null) {
                String str = AppConfig.findString(COST_KEY + "." + gl);
                if (str != null)
                    newValue = Double.parseDouble(str);
            }

        } else if (key.equals(AutomationConfigFromAppConfigHelper.TRANSPORTATION_OUT_COST)) {
            newValue = AutomationConfigFactory.getDefaultConfigHelper().getTransportionOutEstimates(fc, gl);
        }

        if (newValue == null)
            newValue = Double.parseDouble(AppConfig.findString(COST_KEY));
        return newValue;
    }

    /*
     * get transportation in cost from app config
     */
    private Double getTransportationCostFromAppConfig(String fc, String gl, String key) {
        String origTransportationCost = AppConfig.findString(key + "." + gl);
        if (origTransportationCost == null) {
            origTransportationCost = AppConfig.findString(key);
        }

        return Double.parseDouble(origTransportationCost);
    }
}
