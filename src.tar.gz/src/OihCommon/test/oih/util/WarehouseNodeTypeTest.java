package oih.util;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import junit.framework.Assert;
import oih.config.FulfillmentNodeType;
import oih.config.automationsetup.AutomationConfigHelperInterface;
import oih.config.automationsetup.ConfigValueGetter;

import org.junit.Test;

import com.amazon.oihvendorflex.FCGlCost;
import com.amazon.oihvendorflex.WarehouseNode;

public class WarehouseNodeTypeTest {

    @Test
    public void test() {
        FcFulfillmentNodeType warehouseNodeType = new FcFulfillmentNodeType();
        ConfigHelperMock configHelper = new ConfigHelperMock();
        warehouseNodeType.setConfigHelper(configHelper);
        
        Assert.assertTrue(warehouseNodeType.isDropship("LEX2"));
        Assert.assertTrue(warehouseNodeType.isThirdPartyLogistics("PHL2"));
        Assert.assertTrue(warehouseNodeType.isFulfillmentCenter("PHL7"));
        Assert.assertTrue(warehouseNodeType.isVendorFlex("VEX2"));
    }
    
    private class ConfigHelperMock implements AutomationConfigHelperInterface {
        @Override
        public Map<String, String> findFcSplitRatioMapping() {
            return null;
        }

        @Override
        public List<String> getValidFcs() {
            return null;
        }

        @Override
        public Map<String, WarehouseNode> getWarehouses() {
            Map<String, WarehouseNode> results = new HashMap<String, WarehouseNode>();
            WarehouseNode LEX2_Node = new WarehouseNode();
            LEX2_Node.setWarehouseId("LEX2");
            LEX2_Node.setFulfillmentNodeType(FulfillmentNodeType.Dropship.name());
            results.put("LEX2", LEX2_Node);

            WarehouseNode PHL2_Node = new WarehouseNode();
            PHL2_Node.setWarehouseId("PHL2");
            PHL2_Node.setFulfillmentNodeType(FulfillmentNodeType.ThirdPartyLogistics.name());
            results.put("PHL2", PHL2_Node);

            WarehouseNode PHL5_Node = new WarehouseNode();
            PHL5_Node.setWarehouseId("VEX2");
            PHL5_Node.setFulfillmentNodeType(FulfillmentNodeType.VendorFlex.name());
            results.put("VEX2", PHL5_Node);

            WarehouseNode PHL7_Node = new WarehouseNode();
            PHL7_Node.setWarehouseId("PHL7");
            PHL7_Node.setFulfillmentNodeType(FulfillmentNodeType.FulfillmentCenter.name());
            results.put("PHL7", PHL7_Node);

            return results;
        }

        @Override
        public List<FCGlCost> getFcGlCostByWarehouseIndex(String index) {
            return null;
        }

        @Override
        public Double getFcRemovalCostEstimates(String fc, String gl) {
            return null;
        }

        @Override
        public Double getFcRemovalCostEstimates(String fc, String gl, String realm) {
            return null;
        }

        @Override
        public Double getReceiptCostEstimates(String fc, String gl) {
            return null;
        }

        @Override
        public Double getHoldingCostEstimates(String fc, String gl) {
            return null;
        }

        @Override
        public Double getHoldingCostEstimates(String fc, String gl, String realm) {
            return null;
        }

        @Override
        public Double getTransportionInCostEstimates(String fc, String gl) {
            return null;
        }

        @Override
        public Double getTransportionInCostEstimates(String fc, String gl, String realm) {
            return null;
        }

        @Override
        public Double getTransportionOutEstimates(String fc, String gl) {
            return null;
        }

        @Override
        public Double getTransportionOutEstimates(String fc, String gl, String realm) {
            return null;
        }

        @Override
        public String getHoldingCostEstimatesCurrencyIso(String fc) {
            return null;
        }

        @Override
        public List<String> getWarehouseByCategory(String category, String realm) {
            return null;
        }

        @Override
        public List<String> getInventoryCostsWarehouses() {
            return null;
        }

        @Override
        public void destroy() {
        }

        @Override
        public ConfigValueGetter getValueGetter() {
            return null;
        }

        @Override
        public Double getDestroyReturnEstimates(String fc, String gl) {
            return null;
        }

        @Override
        public Double getDestroyReturnEstimates(String fc, String gl, String realm) {
            return null;
        }

    }

}
