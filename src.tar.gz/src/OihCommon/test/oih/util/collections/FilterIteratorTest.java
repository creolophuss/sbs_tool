package oih.util.collections;

import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.NoSuchElementException;

import org.junit.Test;

import static org.junit.Assert.assertTrue;

public class FilterIteratorTest {
    @Test
    public void testFilterIterator1() {
            //
            // ensure it.hasNext() can be called repeatedly
            //
            List<String> list = Arrays.<String>asList("hello", "WORLD", "This", "is", "a", "TEST");
            
            Predicate<String> truePredicate = new Predicate<String>() {
                    public boolean evaluate(String str) {
                            return true;
                    }
            };
            
            FilterIterator<String> it = new FilterIterator<String>(list.iterator(), truePredicate);
            
            for (int i=0; i<20; ++i) {
                    assertTrue("ensure hasNext() can be called repeatedly (1)", (it.hasNext()) );
            }

            Predicate<String> falsePredicate = new Predicate<String>() {
                    public boolean evaluate(String str) {
                            return false;
                    }
            };
            it = new FilterIterator<String>(list.iterator(), falsePredicate);
            
            for (int i=0; i<20; ++i) {
                    assertTrue("ensure hasNext() can be called repeatedly (2)", (! it.hasNext()) );
            }
    }

    @Test
    public void testFilterIterator2() {
            //
            // ensure it.next() can be called repeatedly, until NoSuchElementException
            // get thrown
            //
            List<String> list = Arrays.<String>asList("hello", "WORLD", "This", "is", "a", "TEST");		
            Predicate<String> upperCasePredicate = new Predicate<String>() {
                    public boolean evaluate(String str) {
                            for (int i=0; i<str.length(); ++i) {
                                    if (Character.isLowerCase(str.charAt(i))) {
                                            return false;
                                    }
                            }
                            return true;
                    }
    };

            Iterator<String> it = new FilterIterator<String>(list.iterator(), upperCasePredicate);
            assertTrue("ensure WORLD was returned", "WORLD".equals(it.next()));
            assertTrue("ensure TEST was returned",  "TEST".equals(it.next()));
            try {
                    it.next();
            } catch (Exception e) {
                    assertTrue("ensure Exception was thrown", (e instanceof NoSuchElementException));
            }
    }

    @Test
    public void testFilterIterator3() {
            //
            // ensure it.hasNext() and it.next() work together nicely
            //
            List<String> list = Arrays.<String>asList("hello", "WORLD", "This", "is", "a", "TEST");
            
            Predicate<String> lowerCasePredicate = new Predicate<String>() {
                    public boolean evaluate(String str) {
                            for (int i=0; i<str.length(); ++i) {
                                    if (Character.isUpperCase(str.charAt(i))) {
                                            return false;
                                    }
                            }
                            return true;
                    }
    };

            Iterator<String> it = new FilterIterator<String>(list.iterator(), lowerCasePredicate);
            
            List<String> result = new LinkedList<String>();
            
            while (it.hasNext()) {
                    result.add(it.next());
            }
            
            assertTrue("ensure 3 items returned", (result.size()==3));
            assertTrue("ensure 'hello' was returned", "hello".equals(result.get(0)));
            assertTrue("ensure 'is' was returned",    "is".equals(result.get(1)));
            assertTrue("ensure 'a' was returned",     "a".equals(result.get(2)));
    }

    @Test
    public void testFilterIterator4() {
            //
            // ensure the underlying iterator can be empty
            //
            List<String> list = Collections.<String>emptyList();
            
            Predicate<String> anyPredicate = new Predicate<String>() {
                    public boolean evaluate(String str) {
                            return true;
                    }
    };

            Iterator<String> it = new FilterIterator<String>(list.iterator(), anyPredicate);
            
            assertTrue("ensure underlying iterator can be empty", (! it.hasNext()) );
    }
}
