package oih.util;

import junit.framework.JUnit4TestAdapter;
import org.junit.Test;
import static org.junit.Assert.*;

public class AsinUtilsTest {

	@Test
	public void testIsValidASIN(){
		assertTrue(AsinUtils.isValidASIN("849204030X"));
		assertTrue(AsinUtils.isValidASIN("B94493X84F"));
		assertTrue(AsinUtils.isValidASIN("b032fhe832"));
		assertFalse(AsinUtils.isValidASIN(""));
		assertFalse(AsinUtils.isValidASIN("asin"));
		assertFalse(AsinUtils.isValidASIN("C*$(@NNN8E"));
		assertFalse(AsinUtils.isValidASIN("49fn492nd"));
		assertFalse(AsinUtils.isValidASIN("49fn492nd32"));
	}
	
	@Test
	public void testZeroPadASIN(){
		String asin = "B000333222";
		assertEquals("B000333222", AsinUtils.zeroPadASIN(asin));
		//ASIN too large, should just pass through
		asin = "BDJDSAI92348";
		assertEquals("BDJDSAI92348", AsinUtils.zeroPadASIN(asin));
		//Test ASINs that require zero padding
		asin = "342";
		assertEquals("0000000342", AsinUtils.zeroPadASIN(asin));
		asin = "193284939";
		assertEquals("0193284939", AsinUtils.zeroPadASIN(asin));
		asin = "0";
		assertEquals("0000000000", AsinUtils.zeroPadASIN(asin));
		asin = ""; //Excel at the whole thing!
		assertEquals("0000000000", AsinUtils.zeroPadASIN(asin));
	}
	
	public static junit.framework.Test suite() {
		return new JUnit4TestAdapter(AsinUtilsTest.class);
	}
}
