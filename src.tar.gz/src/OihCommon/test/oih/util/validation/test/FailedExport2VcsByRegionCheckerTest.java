package oih.util.validation.test;

import oih.business.AmazonOrg;
import oih.business.AmazonRegion;
import oih.business.buyer.BuyerUnhealthyDetailHibernateDAO;
import oih.business.damagedcandidates.DamagedCandidateCreationStatusHibernateDAO;
import oih.business.vcs.VCSAsinHibernateDAO;
import oih.business.vcs.VCSStatus;
import oih.business.vcs.VCSSubmissionHibernateDAO;
import oih.util.validation.result.DataCheckRegionLevelResult;
import oih.util.validation.validator.checker.FailedExport2VcsByRegionChecker;

import static org.junit.Assert.assertEquals;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import amazon.platform.config.AppConfig;

/**
 * The unit test class for FailedExport2VcsByRegionChecker
 * @author fengk
 */
@RunWith(JUnit4.class)
public class FailedExport2VcsByRegionCheckerTest extends MemoryDatabaseTestBase {
    
    private VCSAsinHibernateDAO vcsAsinDao;
    private VCSSubmissionHibernateDAO vcsSubmissionDao;
    private DamagedCandidateCreationStatusHibernateDAO damagedCandidatesDao;
    private BuyerUnhealthyDetailHibernateDAO buyerUnhealthyDetailDao;
    
    @Before
    public void setUp() {
        if (AppConfig.isInitialized()) {
            AppConfig.destroy();
        }
        AppConfig.initialize(null, "Oih", new String[] {
                "--domain=test",
                "--realm=USAmazon",
                "--root=/apollo/env/OihWorkflowEngine"
        });
        initialize();
    }
    
    @Override
    public void replaceSessionFactory() {
        vcsAsinDao = (VCSAsinHibernateDAO) VCSAsinHibernateDAO.DEFAULT_INSTANCE;
        vcsSubmissionDao = (VCSSubmissionHibernateDAO) VCSSubmissionHibernateDAO.DEFAULT_INSTANCE;
        damagedCandidatesDao = (DamagedCandidateCreationStatusHibernateDAO) DamagedCandidateCreationStatusHibernateDAO.getInstance();
        buyerUnhealthyDetailDao = (BuyerUnhealthyDetailHibernateDAO) BuyerUnhealthyDetailHibernateDAO.getInstance();
        
        if (sessionFactory != null) {
            logger.info("The SessionFactory for MySQL has been replaced by HSQL sessions");
            vcsAsinDao.setSessionFactory(sessionFactory);
            vcsSubmissionDao.setSessionFactory(sessionFactory);
            damagedCandidatesDao.setSessionFactory(sessionFactory);
            buyerUnhealthyDetailDao.setSessionFactory(sessionFactory);
        }
    }
    
    @Override
    public void constructTestData() {
        String buyerUnhealthyDetailIdPrefix = "test-fengk-";
        String submissionIdPrefix = "oih-submit-";
        String sourceReferenceId = "test-by-fengk";
        String commonDevErrorMessage = "InvalidAddress";
        String commonUserErrorMessage1 = "ShipToAddress is invalid in Input or VM.";
        String commonUserErrorMessage2 = "ShipToAddress is invalid in Input or VM [Return Address CountryCode is Empty. Return Address Line1 is Empty.]";
        
        /* Construct the BUYERS_UNHEALTHY_DETAILS records */
        buyerUnhealthyDetailDao.save(newBuyerUnhealthyDetail(buyerUnhealthyDetailIdPrefix.concat("1"), 1, AmazonOrg.GB, "B123456789", 7, 14, Double.valueOf(100)));
        buyerUnhealthyDetailDao.save(newBuyerUnhealthyDetail(buyerUnhealthyDetailIdPrefix.concat("2"), 1, AmazonOrg.DE, "B123456789", 8, 14, Double.valueOf(100)));
        buyerUnhealthyDetailDao.save(newBuyerUnhealthyDetail(buyerUnhealthyDetailIdPrefix.concat("3"), 1, AmazonOrg.FR, "B123456789", 9, 14, Double.valueOf(100)));
        buyerUnhealthyDetailDao.save(newBuyerUnhealthyDetail(buyerUnhealthyDetailIdPrefix.concat("4"), 1, AmazonOrg.IT, "B123456789", 75, 14, Double.valueOf(100)));
        buyerUnhealthyDetailDao.save(newBuyerUnhealthyDetail(buyerUnhealthyDetailIdPrefix.concat("5"), 1, AmazonOrg.ES, "B123456789", 85, 14, Double.valueOf(100)));
        buyerUnhealthyDetailDao.save(newBuyerUnhealthyDetail(buyerUnhealthyDetailIdPrefix.concat("6"), 1, AmazonOrg.IN, "B123456789", 88, 14, Double.valueOf(100)));
        
        /* Construct the VCS_SUBMISSION records */
        vcsSubmissionDao.save(newVCSSubmission(14, submissionIdPrefix.concat("1"), AmazonOrg.GB, convertStringToDate("2014-03-15"), VCSStatus.ERROR));
        vcsSubmissionDao.save(newVCSSubmission(14, submissionIdPrefix.concat("2"), AmazonOrg.DE, convertStringToDate("2014-03-15"), VCSStatus.ERROR));
        vcsSubmissionDao.save(newVCSSubmission(14, submissionIdPrefix.concat("3"), AmazonOrg.FR, convertStringToDate("2014-03-15"), VCSStatus.ERROR));
        vcsSubmissionDao.save(newVCSSubmission(14, submissionIdPrefix.concat("4"), AmazonOrg.IT, convertStringToDate("2014-03-15"), VCSStatus.ERROR));
        vcsSubmissionDao.save(newVCSSubmission(14, submissionIdPrefix.concat("5"), AmazonOrg.ES, convertStringToDate("2014-03-15"), VCSStatus.ERROR));
        vcsSubmissionDao.save(newVCSSubmission(14, submissionIdPrefix.concat("6"), AmazonOrg.IN, convertStringToDate("2014-03-15"), VCSStatus.ERROR));
        
        /* Construct the VCS_ASINs */
        vcsAsinDao.save(newVCSAsin("B123456789", "TEST1", "123456", VCSStatus.ERROR, convertStringToDate("2014-03-15"), buyerUnhealthyDetailIdPrefix.concat("1"), 
                submissionIdPrefix.concat("1"), 7, 10, 10, 10, "Return", sourceReferenceId, "CWL1", commonDevErrorMessage, commonUserErrorMessage1));
        vcsAsinDao.save(newVCSAsin("B123456789", "TEST2", "123456", VCSStatus.ERROR, convertStringToDate("2014-03-15"), buyerUnhealthyDetailIdPrefix.concat("2"), 
                submissionIdPrefix.concat("2"), 7, 10, 10, 10, "Return", sourceReferenceId, "CWL1", commonDevErrorMessage, commonUserErrorMessage2));
        vcsAsinDao.save(newVCSAsin("B123456789", "TEST3", "123456", VCSStatus.ERROR, convertStringToDate("2014-03-15"), buyerUnhealthyDetailIdPrefix.concat("3"), 
                submissionIdPrefix.concat("3"), 7, 10, 10, 10, "Return", sourceReferenceId, "CWL1", commonDevErrorMessage, commonUserErrorMessage1));
        vcsAsinDao.save(newVCSAsin("B123456789", "TEST4", "123456", VCSStatus.ERROR, convertStringToDate("2014-03-15"), buyerUnhealthyDetailIdPrefix.concat("4"), 
                submissionIdPrefix.concat("4"), 7, 10, 10, 10, "Return", sourceReferenceId, "CWL1", commonDevErrorMessage, commonUserErrorMessage2));
        vcsAsinDao.save(newVCSAsin("B123456789", "TEST5", "123456", VCSStatus.ERROR, convertStringToDate("2014-03-15"), buyerUnhealthyDetailIdPrefix.concat("5"), 
                submissionIdPrefix.concat("5"), 7, 10, 10, 10, "Return", sourceReferenceId, "CWL1", commonDevErrorMessage, commonUserErrorMessage1));
        vcsAsinDao.save(newVCSAsin("B123456789", "FENGK", "123456", VCSStatus.ERROR, convertStringToDate("2014-03-15"), buyerUnhealthyDetailIdPrefix.concat("6"), 
                submissionIdPrefix.concat("6"), 7, 10, 10, 10, "Return", sourceReferenceId, "CWL1", commonDevErrorMessage, commonUserErrorMessage2));
        
        /* Construct the DAMAGE_CANDIDATES */
        damagedCandidatesDao.save(newDamagedCandidateCreationStatusObject(convertStringToDate("2014-03-15"), "B123456789", 1, "CWL1", "0", 14, AmazonOrg.GB, null, null, null, 
                0, "TEST1", 0, Double.valueOf(100), "ERROR", "VRETURNS_BUILD", sourceReferenceId, commonDevErrorMessage, commonUserErrorMessage1, "RI"));
        damagedCandidatesDao.save(newDamagedCandidateCreationStatusObject(convertStringToDate("2014-03-15"), "B123456789", 1, "CWL1", "0", 14, AmazonOrg.DE, null, null, null, 
                0, "TEST2", 0, Double.valueOf(100), "ERROR", "VRETURNS_BUILD", sourceReferenceId, commonDevErrorMessage, commonUserErrorMessage1, "RI"));
        damagedCandidatesDao.save(newDamagedCandidateCreationStatusObject(convertStringToDate("2014-03-15"), "B123456789", 1, "CWL1", "0", 14, AmazonOrg.FR, null, null, null, 
                0, "TEST3", 0, Double.valueOf(100), "ERROR", "VRETURNS_BUILD", sourceReferenceId, commonDevErrorMessage, commonUserErrorMessage1, "RI"));
        damagedCandidatesDao.save(newDamagedCandidateCreationStatusObject(convertStringToDate("2014-03-15"), "B123456789", 1, "CWL1", "0", 14, AmazonOrg.IT, null, null, null, 
                0, "TEST4", 0, Double.valueOf(100), "ERROR", "VRETURNS_BUILD", sourceReferenceId, commonDevErrorMessage, commonUserErrorMessage1, "RI"));
        damagedCandidatesDao.save(newDamagedCandidateCreationStatusObject(convertStringToDate("2014-03-15"), "B123456789", 1, "CWL1", "0", 14, AmazonOrg.ES, null, null, null, 
                0, "TEST5", 0, Double.valueOf(100), "ERROR", "VRETURNS_BUILD", sourceReferenceId, commonDevErrorMessage, commonUserErrorMessage1, "RI"));
        damagedCandidatesDao.save(newDamagedCandidateCreationStatusObject(convertStringToDate("2014-03-15"), "B123456789", 1, "CWL1", "0", 14, AmazonOrg.IN, null, null, null, 
                0, "FENGK", 0, Double.valueOf(100), "ERROR", "VRETURNS_BUILD", sourceReferenceId, commonDevErrorMessage, commonUserErrorMessage1, "RI"));
    }
    
    @Test
    public void testChecker() throws Exception {
        FailedExport2VcsByRegionChecker checker = new FailedExport2VcsByRegionChecker(AmazonRegion.EUFulfillment, convertStringToDate("2014-03-15"));
        DataCheckRegionLevelResult result = checker.check();
        assertEquals(result.getRegion().getRegionName(), AmazonRegion.EUFulfillment.getRegionName());
        assertEquals(result.getIsDataValid(), false);
        logger.info(String.format("The ORG list that needs to send mails: %s", result.getDataCheckOrgLevelResultMap().keySet()));
        for (AmazonOrg org : result.getDataCheckOrgLevelResultMap().keySet()) {
            logger.info(String.format("The mail content to ORG %s:\n %s", org.getRealm(), result.getDataCheckOrgLevelResultMap().get(org).getDetails()));
        }
    }
    
    @After
    public void tearDown() {
        if (AppConfig.isInitialized()) {
            AppConfig.destroy();
        }
    }
}
