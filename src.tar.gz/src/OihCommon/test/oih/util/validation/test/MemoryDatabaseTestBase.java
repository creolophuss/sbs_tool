package oih.util.validation.test;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

import oih.business.AmazonOrg;
import oih.business.buyer.BuyerUnhealthyDetail;
import oih.business.damagedcandidates.DamagedCandidateCreationStatusObject;
import oih.business.vcs.VCSAsin;
import oih.business.vcs.VCSStatus;
import oih.business.vcs.VCSSubmission;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

/**
 * The memory database based tests class:
 * 1) Initialize the Log4J;
 * 2) Initialize the HSQL database in memory;
 * 3) Initialize the tables based on the Hibernate configure.
 * 
 * @author fengk
 */
public abstract class MemoryDatabaseTestBase {
    
    protected static final Logger logger = Logger.getLogger(MemoryDatabaseTestBase.class);
    protected SessionFactory sessionFactory;
    
    static {
        Logger.getRootLogger().setLevel(Level.INFO);
    }
    
    /**
     * Initialize the memory database
     */
    public void initialize() {
        initMemoryDatabase();
        replaceSessionFactory();
        constructTestData();
    }
    
    /**
     * Initialize the HSQL in memory
     * Using Hibernate to construct tables that used in the test
     */
    private void initMemoryDatabase() {
        Properties props = new Properties();
        props.setProperty("hibernate.connection.driver_class", "org.hsqldb.jdbcDriver");
        props.setProperty("hibernate.connection.url", "jdbc:hsqldb:file:/var/tmp/testdb");
        props.setProperty("hibernate.connection.username", "sa");
        props.setProperty("hibernate.connection.password", "");
        props.setProperty("hibernate.dialect", "org.hibernate.dialect.HSQLDialect");
        props.setProperty("connection.pool_size", "5");
        props.setProperty("hibernate.hbm2ddl.auto", "create");
        props.setProperty("show_sql", "false");
        
        Configuration config = new Configuration();
        config.setProperties(props);
        
        try {
            config.addResource("oih/business/vcs/VCSAsin.hbm.xml");
            config.addResource("oih/business/vcs/VCSSubmission.hbm.xml");
            config.addResource("oih/business/buyer/BuyerUnhealthyDetail.hbm.xml");
            config.addResource("oih/business/buyer/BuyerUnhealthyDetailExpand.hbm.xml");
            config.addResource("oih/business/damagedcandidates/DamagedCandidateCreationStatusObject.hbm.xml");
            
            sessionFactory = config.buildSessionFactory();
        } catch (RuntimeException e) {
            logger.error("Unknown exception when tries to initialize Hibernate", e);
        }
    }
    
    /**
     * Using the HSQL session factory to replace the session factory defined in DAO
     */
    public abstract void replaceSessionFactory();
    
    /**
     * Construct the data used in test cases
     */
    public abstract void constructTestData();
    
    protected VCSAsin newVCSAsin(String asin, String vendor, String dsiId, VCSStatus status, Date runDate, 
            String buyerUnhealthyDetailId, String oihSubmissionKey, Integer iog, Integer qtySubmitted, 
            Integer qtySuccess, Integer qtyFailure, String removalType, String sourceRefId, String warehouse, 
            String devErrorMessage, String userErrorMessage) {
        VCSAsin item = new VCSAsin();
        item.setAsin(asin);
        item.setBuyerUnhealthyDetailId(buyerUnhealthyDetailId);
        item.setDsiId(dsiId);
        item.setIog(iog);
        item.setOihSubmissionKey(oihSubmissionKey);
        item.setQtySubmitted(qtySubmitted);
        item.setQtySuccess(qtySuccess);
        item.setQtyFailure(qtyFailure);
        item.setRemovalType(removalType);
        item.setSourceRefId(sourceRefId);
        item.setStatus(status);
        item.setWarehouse(warehouse);
        item.setBuyerUnhealthyDetailId(buyerUnhealthyDetailId);
        item.setDevErrorMessage(devErrorMessage);
        item.setUserErrorMessage(userErrorMessage);
        item.setVendor(vendor);
        return item;
    }
    
    protected VCSSubmission newVCSSubmission(int gl, String oihSubId, AmazonOrg org, Date rundate, VCSStatus status) {
        VCSSubmission item = new VCSSubmission();
        item.setGl(gl);
        item.setOihSubmissionKey(oihSubId);
        item.setOrg(org);
        item.setRundate(rundate);
        item.setSubmissionStatus(status);
        item.setSubmittedBy("system");
        return item;
    }
    
    protected DamagedCandidateCreationStatusObject newDamagedCandidateCreationStatusObject(Date rundate, String asin, int iog, String warehouse, 
            String condition, int gl, AmazonOrg org, String distributorOrderId, String distributorOrderType, String distributorShipmentId, 
            long distributorShipmentItemId, String destVendor, long quantity, double cost, String status, String sourceId, String referenceId,
            String errorMessageType, String errorMessage, String removalType) {
        DamagedCandidateCreationStatusObject item = new DamagedCandidateCreationStatusObject(rundate, asin, iog, warehouse, condition);
        item.setGl(gl);
        item.setFcsku(asin);
        item.setFnsku(asin);
        item.setOrg(org.getRealm());
        item.setDistributorOrderDate(new Date());
        item.setShipmentReceiveDate(new Date());
        item.setDistributorOrderId(distributorOrderId);
        item.setDistributorOrderType(distributorOrderType);
        item.setDistributorShipmentId(distributorShipmentId);
        item.setDistributorShipmentItemId(distributorShipmentItemId);
        item.setReturnByMaxDays(10);
        item.setReturnByMinDays(5);
        item.setIsAuthorizationRequired("Y");
        item.setAuthorizationNumber("123456789");
        item.setVrdsDescription("");
        item.setSourceId(sourceId);
        item.setSourceReferenceId(referenceId);
        item.setStatus(status);
        item.setDestVendor(destVendor);
        item.setQuantity(quantity);
        item.setCost(cost);
        item.setErrorMessageType(errorMessageType);
        item.setErrorMessage(errorMessage);
        item.setRemovalType(removalType);
        return item;
    }
    
    protected BuyerUnhealthyDetail newBuyerUnhealthyDetail(String buyerUnhealthyDetailId, int version, AmazonOrg org, 
            String asin, int iog, int gl, double cost) {
        BuyerUnhealthyDetail item = new BuyerUnhealthyDetail();
        item.setId(buyerUnhealthyDetailId);
        item.setVersion(version);
        item.setOrg(org);
        item.setAsin(asin);
        item.setIog(iog);
        item.setGl(gl);
        item.setCostUsedForCalc(cost);
        item.setCostUsedForReporting(cost);
        return item;
    }
    
    /**
     * Convert the string type of date to Java Date object
     * @param date
     * @return
     */
    protected Date convertStringToDate(String date) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        try {
            return dateFormat.parse(date);
        } catch (ParseException e) {
            logger.error(String.format("The input date %s having problems!", date), e);
        }
        return null;
    }
}
