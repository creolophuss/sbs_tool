package oih.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import oih.business.AmazonOrg;
import oih.business.removals.automations.sla.AutomationSlaUtl;
import oih.config.ConfigFactory;
import oih.util.LockManager.LockDAO;
import oih.util.LockManager.LockException;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class LockManagerTest {

    private SessionFactory sessionFactory;
    private LockDAO dao;
    final static int SLA_DAYS = 7;

    public LockDAO getDao() {
        return dao;
    }

    @BeforeClass
    public static void theLogThe() {
        // Plz see http://tinyurl.com/a5zcel bullet 3, item 3 for more information on the method name
        Logger.getRootLogger().setLevel(Level.ERROR);
    }

    @Before
    public void setup() {
        Map<String, Object> configMap = new HashMap<String, Object>();
        configMap.put("OihAutomation.AutomationSlaDays", SLA_DAYS);
        ConfigFactory.useConfigFrom(configMap);
        // SessionFactory/HSQLDB/schema is built for each test.
        // Not fast, but we have a clean DB each test
        // Setup all config properties by hand.
        Properties props = new Properties();
        props.setProperty("hibernate.connection.driver_class", "org.hsqldb.jdbcDriver");
        // to connect to server running on localhost, use url like: jdbc:hsqldb:hsql://localhost/xdb
        props.setProperty("hibernate.connection.url", "jdbc:hsqldb:file:/var/tmp/testdb_jialei");
        // props.setProperty("hibernate.connection.url", "jdbc:hsqldb:hsql://josiaho.desktop/oih" ); // for testing a
        // local hsql server
        props.setProperty("hibernate.connection.username", "sa");
        props.setProperty("hibernate.connection.password", "");
        props.setProperty("hibernate.dialect", "org.hibernate.dialect.HSQLDialect");
        props.setProperty("connection.pool_size", "5");
        props.setProperty("hibernate.hbm2ddl.auto", "create");
        props.setProperty("show_sql", "true");

        /*
         * props.setProperty( "hibernate.connection.driver_class", "com.mysql.jdbc.Driver" ); props.setProperty(
         * "hibernate.connection.url", "jdbc:mysql://localhost:3306/workflow_db"); props.setProperty(
         * "hibernate.connection.username", "oihadmin" ); props.setProperty( "hibernate.connection.password", "" );
         * props.setProperty( "hibernate.dialect", "org.hibernate.dialect.MySQL5Dialect" ); props.setProperty(
         * "connection.pool_size", "5" );
         */

        Configuration config = new Configuration();

        config.setProperties(props);
        try {
            // need to specify classes to be mapped by hand too

            config.addResource("oih/util/Lock.hbm.xml");

            sessionFactory = config.buildSessionFactory();
        } catch (RuntimeException e) {
            e.printStackTrace();
        }

        LockManager lm = LockManager.getInstance();
        dao = lm.getLockDAO();
        dao.setSessionFactory(sessionFactory);
    }

    @Test
    public void testfindLastKeyPattern() {
        LockManager lm = LockManager.getInstance();
        try {
            lm.lock(AutomationSlaUtl.AUTOMATION_KEY + "USAmazon-2011-03-20", "jialei");
            lm.lock(AutomationSlaUtl.AUTOMATION_KEY + "USAmazon-2011-03-27", "jialei");
        } catch (LockException e) {
            Assert.fail();
        }
        Lock lock1 = dao.findByKey(AutomationSlaUtl.AUTOMATION_KEY + "USAmazon-2011-03-20");
        Lock lock2 = dao.findByKey(AutomationSlaUtl.AUTOMATION_KEY + "USAmazon-2011-03-27");
        Date startDay = new Date(System.currentTimeMillis() - 3 * 24L * 3600L * 1000L + 4 * 3600L * 1000L + 20);
        lock1.setLastUpdated(startDay);
        dao.save(lock1);
        Lock lockFound = dao.findLastKeyPattern(AutomationSlaUtl.AUTOMATION_KEY + "%");
        Assert.assertEquals("AUTOMATION-START-USAmazon-2011-03-27", lockFound.getKey());

        startDay = new Date(System.currentTimeMillis() - 10 * 24L * 3600L * 1000L + 4 * 3600L * 1000L + 20);
        lock2.setLastUpdated(startDay);
        dao.save(lock2);
        lockFound = dao.findLastKeyPattern(AutomationSlaUtl.AUTOMATION_KEY + "%");
        Assert.assertEquals("AUTOMATION-START-USAmazon-2011-03-20", lockFound.getKey());

        try {
            lm.unlock(AutomationSlaUtl.AUTOMATION_KEY + "USAmazon-2011-03-20", "jialei");
            lm.unlock(AutomationSlaUtl.AUTOMATION_KEY + "USAmazon-2011-03-27", "jialei");
        } catch (LockException e) {
            Assert.fail();
        }
    }

    /*@Test
    public void testGetDaysToReachSlaEnd() {
        LockManager lm = LockManager.getInstance();
        try {
            lm.lock(AutomationSlaUtl.AUTOMATION_KEY + "USAmazon", "jialei");
        } catch (LockException e) {
            Assert.fail();
        }
        AutomationSlaUtl.lockDao = new LockDAO();
        AutomationSlaUtl.lockDao.setSessionFactory(sessionFactory);
        Lock lock = dao.findByKey(AutomationSlaUtl.AUTOMATION_KEY + "USAmazon");
        Date startDay = new Date(System.currentTimeMillis() - 3 * 24L * 3600L * 1000L + 4 * 3600L * 1000L + 20);
        lock.setLastUpdated(startDay);
        dao.save(lock);
        int days = AutomationSlaUtl.getTimeSpanToReachSlaEnd(AmazonOrg.US).getDays();
        int hours = AutomationSlaUtl.getTimeSpanToReachSlaEnd(AmazonOrg.US).getHours();
        Assert.assertEquals(4, days);
        Assert.assertEquals(4, hours);

        startDay = new Date(System.currentTimeMillis() - 7 * 24L * 3600L * 1000L + 200000);
        lock.setLastUpdated(startDay);
        dao.save(lock);
        days = AutomationSlaUtl.getTimeSpanToReachSlaEnd(AmazonOrg.US).getDays();
        Assert.assertEquals(0, days);

        Calendar cal = Calendar.getInstance();
        while (cal.get(Calendar.DAY_OF_WEEK) != Calendar.SUNDAY) {
            cal.add(Calendar.DATE, -1);
        }
        System.out.println(cal.getTime());
        int hour = cal.get(Calendar.HOUR_OF_DAY);
        Date newd = new Date(cal.getTime().getTime() - hour * 3600L * 1000L);

        System.out.println(newd);

        lock.setLastUpdated(new Date(System.currentTimeMillis() - 8 * 24L * 3600L * 1000L));
        dao.save(lock);
        days = AutomationSlaUtl.getTimeSpanToReachSlaEnd(AmazonOrg.US).getDays();
        Assert.assertEquals(0, days);

    }*/

    @Test
    public void testListNoLocks() {
        LockManager lm = LockManager.getInstance();
        List<String> locks = lm.listLocks("mrhasnolocks");
        Assert.assertEquals(locks.size(), 0);
    }

    @Test
    public void testCanLock() {
        LockManager lm = LockManager.getInstance();
        Assert.assertTrue(lm.canLock("AReallyTotallyAwesomeKey", "theman"));
    }

    @Test
    public void testSimilarKeyLocking() {
        LockManager lm = LockManager.getInstance();
        try {
            lm.lock("MyKeyLooksLikeYourKey", "billy");
        } catch (LockException e) {
            Assert.fail();
        }
        Assert.assertTrue(lm.canLock("MyKeyLooksLike", "suzie"));

        try {
            lm.unlock("MyKeyLooksLikeYourKey", "billy");
        } catch (LockException e) {
            Assert.fail();
        }

    }

    @Test
    public void testALockAndUnlock() {
        LockManager lm = LockManager.getInstance();
        try {
            lm.lock("SomeSuperKey", "superman");
        } catch (LockException le) {
            Assert.fail();
        }
        try {
            lm.unlock("SomeSuperKey", "superman");
        } catch (LockException le) {
            Assert.fail();
        }

    }

    @Test
    public void testALockAndAttemptToLockByFred() {
        LockManager lm = LockManager.getInstance();
        try {
            lm.lock("masterlockington", "locksown");
        } catch (LockException le) {
            Assert.fail();
        }

        try {
            lm.lock("masterlockington", "fred");
            Assert.fail();
        } catch (LockException le) {
        }

        try {
            lm.unlock("masterlockington", "locksown");
        } catch (LockException le) {
            Assert.fail();
        }
    }

    @Test
    public void testALockAndAttemptToUnlockByFred() {
        LockManager lm = LockManager.getInstance();
        try {
            lm.lock("masterlockington", "locksown");
        } catch (LockException le) {
            Assert.fail();
        }

        try {
            lm.unlock("masterlockington", "fred");
            Assert.fail();
        } catch (LockException le) {

        }

        try {
            lm.unlock("masterlockington", "locksown");
        } catch (LockException le) {
            Assert.fail();
        }
    }

    @Test
    public void testLockListing() {
        LockManager lm = LockManager.getInstance();
        String ashPokemon[] = {
                "bulbasaur", "charmander", "metapod", "pikachu"
        };
        String garyPokemon[] = {
                "squirtle", "weedle"
        };

        try {
            lm.lock("charmander", "ash");
            lm.lock("pikachu", "ash");
            lm.lock("bulbasaur", "ash");
            lm.lock("squirtle", "gary");
            lm.lock("weedle", "gary");
            lm.lock("metapod", "ash");
        } catch (LockException le) {
            Assert.fail();
        }

        String ashList[] = lm.listLocks("ash").toArray(new String[0]);
        String garyList[] = lm.listLocks("gary").toArray(new String[0]);
        Arrays.sort(ashList);
        Arrays.sort(garyList);

        Assert.assertArrayEquals(ashPokemon, ashList);
        Assert.assertArrayEquals(garyPokemon, garyList);

        try {
            lm.unlock("charmander", "ash");
            lm.unlock("pikachu", "ash");
            lm.unlock("bulbasaur", "ash");
            lm.unlock("squirtle", "gary");
            lm.unlock("weedle", "gary");
            lm.unlock("metapod", "ash");
        } catch (LockException le) {
            Assert.fail();
        }
    }

    @Test
    public void testConcurrentLocking() {
        // this test is involved... fire up 8 threads and go nuts

        /* try to kick off all threads in 5 seconds */
        final long startTime = System.currentTimeMillis() + 5000;
        final String names[] = {
                "JohnBoy", "Elizabeth", "Livie", "JimBob", "Ben", "MaryEllen", "Jason", "Erin"
        };

        final Map<String, String> lockStatus = new HashMap<String, String>();

        /* this is a goofy test to see who gets to say goodnight first. ha! */

        List<Runnable> testSet = new ArrayList<Runnable>();
        for (int i = 0; i < 32; i++) {
            final int idx = i;
            final String name = names[idx % names.length] + idx;
            Runnable r = new Runnable() {
                public void run() {
                    LockManager lm = LockManager.getInstance();
                    // log.info("Thread: "+Thread.currentThread().getName()+", name = "+name);
                    long sleepTime = startTime - System.currentTimeMillis();
                    try {
                        Thread.sleep(sleepTime);
                    } catch (Exception exc) {
                        Assert.fail();
                    }
                    try {
                        lm.lock("Goodnight", name);
                        // System.out.println("Thread: "+Thread.currentThread().getName()+", name = "+name+" is a go");
                        synchronized (lockStatus) {
                            lockStatus.put(name, "pass");
                        }

                    } catch (LockException le) {
                        // System.out.println("Thread: "+Thread.currentThread().getName()+", name = "+name+" is a no go");
                        synchronized (lockStatus) {
                            lockStatus.put(name, "fail");
                        }
                    }
                }
            };
            testSet.add(r);
        }

        for (Runnable r : testSet) {
            Thread t = new Thread(r, "LMTestThread" + r.hashCode());
            t.start();
        }

        try {
            Thread.sleep(10000);
        } catch (Exception exc) {
            Assert.fail();
        }

        boolean someoneLocked = false;
        String whoLocked = null;
        LockManager lm = LockManager.getInstance();
        for (String who : lockStatus.keySet()) {
            if (lm.listLocks(who).size() > 0) {
                Assert.assertEquals(lockStatus.get(who), "pass");
                someoneLocked = true;
                whoLocked = who;
            }
        }

        Assert.assertTrue(someoneLocked);
        try {
            lm.unlock("Goodnight", whoLocked);
        } catch (LockException le) {
            Assert.fail();
        }
    }

}
