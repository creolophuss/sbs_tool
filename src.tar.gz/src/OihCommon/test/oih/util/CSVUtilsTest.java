package oih.util;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import junit.framework.JUnit4TestAdapter;

import org.junit.Assert;
import org.junit.Test;

/**
 * Unit tests for CSVUntils
 * 
 * @author svisvan
 */
public class CSVUtilsTest {

	@Test
	public void testToCSVLine() {
		//test normal case
		String arr1[] = new String[] { "s1", "s2", "s3" };
		String result1 = CSVUtils.toCSVLine(arr1);
		Assert.assertEquals("s1,s2,s3", result1);
		
		//test empty array
		String arr2[] = new String[] { };
		String result2 = CSVUtils.toCSVLine(arr2);
		Assert.assertEquals("", result2);
		
		//test one string array, edge-case with no commas
		String arr3[] = new String[] { "boo" };
		String result3 = CSVUtils.toCSVLine(arr3);
		Assert.assertEquals("boo",result3);
		
		//test empty strings
		String arr4[] = new String[] { "", "", "" };
		String result4 = CSVUtils.toCSVLine(arr4);
		Assert.assertEquals(",,", result4);
		
		//test null input case
		try {
			CSVUtils.toCSVLine(null);
			Assert.assertTrue(false);
		} catch (NullPointerException e) {
			Assert.assertTrue(true);
		}
	}
	
    @Test
    public void testListToCSVLine() {
        List<String> list1 = Arrays.asList( "s1", "s2", "s3" );
        String result1 = CSVUtils.listToCSVLine(list1);
        Assert.assertEquals("s1,s2,s3", result1);

        List<String> list2 = Arrays.asList();
        String result2 = CSVUtils.listToCSVLine(list2);
        Assert.assertEquals("", result2);
        
        List<String> list3 = Arrays.asList( "s1" );
        String result3 = CSVUtils.listToCSVLine(list3);
        Assert.assertEquals("s1", result3);

        List<String> list4 = Arrays.asList( "", "", "" );
        String result4 = CSVUtils.listToCSVLine(list4);
        Assert.assertEquals(",,", result4);

        List<String> list5 = Arrays.asList( "", "woo", "" );
        String result5 = CSVUtils.listToCSVLine(list5);
        Assert.assertEquals(",woo,", result5);

        List<String> list6 = Arrays.asList( "woo", "", "" );
        String result6 = CSVUtils.listToCSVLine(list6);
        Assert.assertEquals("woo,,", result6);

        List<String> list7 = Arrays.asList( "", "", "woo" );
        String result7 = CSVUtils.listToCSVLine(list7);
        Assert.assertEquals(",,woo", result7);

        try {
            CSVUtils.listToCSVLine(null);
            Assert.assertTrue(false);
        } catch (NullPointerException e) {
            Assert.assertTrue(true);
        }
    }

	@Test
	public void testJoinEasy() {
	    // test normal case
        List<String> arr1 = Arrays.asList( "s1", "s2", "s3" );
        String result1 = CSVUtils.join(arr1," ");
        assertEquals("s1 s2 s3", result1);
	}

	@Test
	public void testJoinEmpty() {
        // test empty list
        String result2 = CSVUtils.join(new ArrayList<Object>(), " ");
        assertEquals("",result2);
	}
    
	@Test
	public void testJoinIntegers() {
        // test list of integers
        List<Integer> arr3 = Arrays.asList(1,2,3,4);
        String result3 = CSVUtils.join(arr3," ");
        assertEquals("1 2 3 4",result3);
	}
	
	@Test
	public void testJoinTabDelimiter() {
        // test different delimiter - tab
        List<Integer> arr4 = Arrays.asList(2,3,4);
        String result4 = CSVUtils.join(arr4, "\t");
        assertEquals("2\t3\t4",result4);
	}

	@Test
	public void testFailOnNull() {
        //test null input case
        try {
            CSVUtils.toCSVLine(null);
            fail();
        } catch (NullPointerException e) {
            //expected behavior
        }
	}
	
	@Test
	public void testColumnMapFromCSVHeader() {
		//test general case
		String csv = "col1,col2,col3";
		HashMap<String,Integer> result1 = CSVUtils.columnMapFromCSVHeader(csv);
		HashMap<String,Integer> expected = new HashMap<String,Integer>();
		expected.put("col3", 2);
		expected.put("col2", 1);
		expected.put("col1", 0);
		Assert.assertNotNull(result1);
		Assert.assertEquals(expected, result1);
		
		//test empty case
		HashMap<String,Integer> result2 = CSVUtils.columnMapFromCSVHeader("");
		Assert.assertNotNull(result2);
		Assert.assertEquals(new HashMap<String,Integer>(), result2);
		
		//test null case
		try {
			CSVUtils.columnMapFromCSVHeader(null);
			Assert.fail();
		} catch (NullPointerException e) {
			Assert.assertTrue(true);
		}
	}
	
	@Test
	public void testRemapFields() {
		String fields[] = new String[] { "field1", "field2", "field3" };
		HashMap<String,Integer> colMap = new HashMap<String,Integer>();
		colMap.put("col1", 0);
		colMap.put("col2", 1);
		colMap.put("col3", 2);
		
		//test 1
		String result1 = CSVUtils.remapFields(fields, colMap, new String[] { "col2" });
		Assert.assertEquals("field2",result1);
		
		//test 2
		String result2 = CSVUtils.remapFields(fields, colMap, new String[] { "col3", "col1" });
		Assert.assertEquals("field3,field1", result2);
		
		String result3 = CSVUtils.remapFields(fields, colMap, new String[] { "col2", "col3", "col1" });
		Assert.assertEquals("field2,field3,field1", result3);
		
		//null column value
		fields =  new String[] { "field1", "", "field3" };
		String result4 = CSVUtils.remapFields(fields, colMap, new String[] { "col3", "col2", "col1" });
		Assert.assertEquals("field3,,field1", result4);
		
		//test 3: column not in map, will get NPE
		try {
			CSVUtils.remapFields(fields, colMap, new String[] { "invalid-col" });
			Assert.assertTrue(false);
		} catch (NullPointerException e) {
			Assert.assertTrue(true);
		}
	}
	
	public static junit.framework.Test suite(){
		return new JUnit4TestAdapter(CSVUtilsTest.class);
	}
}
