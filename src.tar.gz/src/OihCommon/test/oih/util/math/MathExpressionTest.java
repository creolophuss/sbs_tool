package oih.util.math;

import org.junit.Assert;
import org.junit.Test;

import com.amazon.coral.google.common.collect.ImmutableMap;

public class MathExpressionTest {
    
    @Test
    public void eval(){
        MathExpression  me = new MathExpression("1 * ((a - 10) /10 ) +3");
        Assert.assertEquals(1 * ((10 - 10) /10 ) +3, me.eval(ImmutableMap.<String, Number>of("a", 10)).intValue());
        Assert.assertEquals(1 * ((100.0 - 10) /10 ) +3, me.eval(ImmutableMap.<String, Number>of("a", 100.0)).doubleValue(), 0.0000);
        
        me = new MathExpression("1 * ( (x-10)/10 ) + 3");
        Assert.assertEquals(1 * ((10 - 10) /10 ) +3, me.eval(10).intValue());
    }
    
    @Test
    public void evalWithIllegalVars() {
        MathExpression me;
        try {
            me = new MathExpression("1 * ((a - 10) /10 ) +3");
            Assert.assertEquals(1 * ((10 - 10) / 10) - 3, me.eval(ImmutableMap.<String, Number> of("b", 10)).intValue());
            Assert.fail();
        } catch (Exception e) {
            //e.printStackTrace();
        }

        try {
            me = new MathExpression("1 * ((a - 10) /10 ) +3");
            Assert.assertEquals(1 * ((10 - 10) / 10) - 3, me.eval(10).intValue());
            Assert.fail();
        } catch (Exception e) {
            //e.printStackTrace();
        }
    }
}
