package oih.util.hibernate;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.Map;
import java.util.Properties;

import oih.business.buyer.BuyerUnhealthyDetail;
import oih.util.DateUtils;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import testutils.HSQLDBUtils;

public class HibernateUtilTest {
	private SessionFactory sessionFactory;
	
	@BeforeClass
	public static void theLogThe() {
		// Plz see http://tinyurl.com/a5zcel bullet 3, item 3 for more
		// information on the method name
		Logger.getRootLogger().setLevel(Level.ERROR);
	}
	
	@Before
	public void setUp() throws Exception {
		String tmpdir = System.getProperty("java.io.tmpdir");
		HSQLDBUtils.cleanupHSQLDBFiles(tmpdir, "testdb");

		// SessionFactory/HSQLDB/schema is built for each test.
		// Not fast, but we have a clean DB each test
		// Setup all config properties by hand.
		Properties props = new Properties();
		props.setProperty("hibernate.connection.driver_class",
		"org.hsqldb.jdbcDriver");
		props.setProperty("hibernate.connection.url", "jdbc:hsqldb:file:"+tmpdir+"/testdb");
		props.setProperty("hibernate.connection.username", "sa");
		props.setProperty("hibernate.connection.password", "");
		props.setProperty("hibernate.dialect",
		"org.hibernate.dialect.HSQLDialect");
		props.setProperty("connection.pool_size", "5");
		props.setProperty("hibernate.hbm2ddl.auto", "create");
		props.setProperty("show_sql", "true");
		Configuration config = new Configuration();

		config.setProperties(props);
		
		try {
			// need to specify classes to be mapped by hand too

			config.addResource("oih/business/buyer/BuyerUnhealthyDetail.hbm.xml");
			config.addResource("oih/business/buyer/BuyerUnhealthyDetailExpand.hbm.xml");
			config.addResource("oih/business/raivc/RaivcVendor.hbm.xml");

			sessionFactory = config.buildSessionFactory();

		} catch (Exception e) {
			e.printStackTrace();
			fail();
			System.exit(1);
		}
	}

	@Test
	public void testGetColumn2PropertyMapping() {
		Map<String, String> map = HibernateUtil.getColumn2PropertyMapping(sessionFactory, BuyerUnhealthyDetail.class);
		
		assertTrue(map.size() > 0);
		
		String propertyName = map.get("replenishment_category");
		
		assertEquals(propertyName, "replenishmentCategory");
		
		propertyName = map.get("is_on_markdown");
		
		assertEquals(propertyName, "onMarkdown");
	}

	@Test
	public void testGetPropertyValue() {
		BuyerUnhealthyDetail bu = new BuyerUnhealthyDetail();
		
		try {
			assertTrue("".equals(HibernateUtil.getPropertyValue(bu, "onMarkdown")));
			
			bu.setOnMarkdown(true);
			assertTrue("Y".equals(HibernateUtil.getPropertyValue(bu, "onMarkdown")));
			
			bu.setOnMarkdown(false);
			assertTrue("N".equals(HibernateUtil.getPropertyValue(bu, "onMarkdown")));
			
			bu.setAsin("B012345678");
			assertTrue("B012345678".equals(HibernateUtil.getPropertyValue(bu, "asin")));
			
			bu.setActioningQty(100);
			assertEquals("100", HibernateUtil.getPropertyValue(bu, "actioningQty"));
			
			bu.setRundate(DateUtils.parseDate("2009-03-04"));
			assertEquals("2009-03-04", HibernateUtil.getPropertyValue(bu, "rundate"));
			
			bu.setCartonQuantity(2.1);
			assertEquals("2.1", HibernateUtil.getPropertyValue(bu, "cartonQuantity"));
			
			bu.setOrg("JPAmazon");
			assertEquals("JP", HibernateUtil.getPropertyValue(bu, "org"));
			
//			bu.setCost(null);
//			assertEquals("", HibernateUtil.getPropertyValue(bu, "cost"));
			
		} catch (Exception e) {
			e.printStackTrace();
			fail();
		}
		
	}

	@Test
	public void testSetPropertyValue() {
		BuyerUnhealthyDetail bu = new BuyerUnhealthyDetail();
		
		try {
			HibernateUtil.setPropertyValue(bu, "onMarkdown", "Y");
			assertTrue(bu.getOnMarkdown());

			HibernateUtil.setPropertyValue(bu, "onMarkdown", "N");
			assertTrue(!bu.getOnMarkdown());
			
			HibernateUtil.setPropertyValue(bu, "onMarkdown", null);
			assertTrue(bu.getOnMarkdown() == null);
			
			HibernateUtil.setPropertyValue(bu, "asin", "B012345678");
			assertEquals("B012345678", bu.getAsin());
			
			HibernateUtil.setPropertyValue(bu, "actioningQty", "99");
			assertTrue(99 == bu.getActioningQty());
			
			HibernateUtil.setPropertyValue(bu, "rundate", "2009-07-10");
			assertEquals("2009-07-10", DateUtils.formatDate(bu.getRundate()));

			HibernateUtil.setPropertyValue(bu, "rundate", "9/12/08");
			assertEquals("2008-09-12", DateUtils.formatDate(bu.getRundate()));

			HibernateUtil.setPropertyValue(bu, "cartonQuantity", "5.2");
			assertEquals(Double.valueOf("5.2"), bu.getCartonQuantity());
			
			HibernateUtil.setPropertyValue(bu, "org", "US");
			assertEquals("US", bu.getOrg().getName());
			
		} catch (Exception e) {
			e.printStackTrace();
			fail();
		}
	}

}
