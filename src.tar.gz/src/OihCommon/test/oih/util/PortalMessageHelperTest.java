package oih.util;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import oih.config.ConfigFactory;
import oih.util.PortalMessageHelper.PortalMessageDAO;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;


public class PortalMessageHelperTest {
    private SessionFactory sessionFactory;
    private PortalMessageDAO dao;

    public PortalMessageDAO getDao() {
        return dao;
    }

    @BeforeClass
    public static void theLogThe() {
        // Plz see http://tinyurl.com/a5zcel bullet 3, item 3 for more information on the method name
        Logger.getRootLogger().setLevel(Level.ERROR);
    }

    @SuppressWarnings("deprecation")
    @Before
    public void setup() {
        Map<String, Object> configMap = new HashMap<String, Object>();
        ConfigFactory.useConfigFrom(configMap);
        // SessionFactory/HSQLDB/schema is built for each test.
        // Not fast, but we have a clean DB each test
        // Setup all config properties by hand.
        Properties props = new Properties();
        props.setProperty("hibernate.connection.driver_class", "org.hsqldb.jdbcDriver");
        // to connect to server running on localhost, use url like: jdbc:hsqldb:hsql://localhost/xdb
        props.setProperty("hibernate.connection.url", "jdbc:hsqldb:file:/var/tmp/testdb_jiazhang");
        // props.setProperty("hibernate.connection.url", "jdbc:hsqldb:hsql://josiaho.desktop/oih" ); // for testing a
        // local hsql server
        props.setProperty("hibernate.connection.username", "sa");
        props.setProperty("hibernate.connection.password", "");
        props.setProperty("hibernate.dialect", "org.hibernate.dialect.HSQLDialect");
        props.setProperty("connection.pool_size", "5");
        props.setProperty("hibernate.hbm2ddl.auto", "create");
        props.setProperty("show_sql", "true");

        /*
         * props.setProperty( "hibernate.connection.driver_class", "com.mysql.jdbc.Driver" ); props.setProperty(
         * "hibernate.connection.url", "jdbc:mysql://localhost:3306/workflow_db"); props.setProperty(
         * "hibernate.connection.username", "oihadmin" ); props.setProperty( "hibernate.connection.password", "" );
         * props.setProperty( "hibernate.dialect", "org.hibernate.dialect.MySQL5Dialect" ); props.setProperty(
         * "connection.pool_size", "5" );
         */

        Configuration config = new Configuration();

        config.setProperties(props);
        try {
            // need to specify classes to be mapped by hand too

            config.addResource("oih/util/PortalMessage.hbm.xml");

            sessionFactory = config.buildSessionFactory();
        } catch (RuntimeException e) {
            e.printStackTrace();
        }

        PortalMessageHelper pmh = PortalMessageHelper.getInstance();
        dao = pmh.getPortalMessageDAO();
        dao.setSessionFactory(sessionFactory);
        PortalMessage pm1 = new PortalMessage();
        pm1.setMessageContent("Test1");
        pm1.setOrg("CNAmazon");
        pm1.setGl(14);
        dao.save(pm1);
        PortalMessage pm2 = new PortalMessage();
        pm2.setMessageContent("Test2");
        pm2.setOrg("CNAmazon");
        pm2.setGl(-1);
        dao.save(pm2);
    }
    
    @Test
    public void testGetMessageContent() {
        PortalMessageHelper pmh = PortalMessageHelper.getInstance();
        String str1 = pmh.getMessageContent(14, "CNAmazon");
        Assert.assertEquals(str1, "Test1");
        String str2 = pmh.getMessageContent("CNAmazon");
        Assert.assertEquals(str2, "Test2");
    }

}
