package oih.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import junit.framework.Assert;

import org.junit.Test;

import java.util.Arrays;

public class MathUtilTest {

    @Test
    public void testIsDoubleEqual() {
        Assert.assertTrue(MathUtil.isDoubleEqual(4.5, 4.5, "test double equal "));
        Assert.assertFalse(MathUtil.isDoubleEqual(4.5, 4.6, "test double equal"));
        Assert.assertFalse(MathUtil.isDoubleEqual(null, 4.6, "test double equal"));
        Assert.assertFalse(MathUtil.isDoubleEqual(4.6, null, "test double equal"));
        Assert.assertTrue(MathUtil.isDoubleEqual(null, null, "test double equal"));
    }
    
    @Test
    public void testIsMapEqual(){
        
        Map<String, Double> newM = new HashMap<String, Double>();
        Map<String, Double> oriM = new HashMap<String, Double>();
        
        newM.put("fc1", 3.4);
        newM.put("fc2", 3.5);
        newM.put("fc3", 3.6);
        newM.put("fc4", 3.7);
        
        oriM.put("fc1", 3.4);
        oriM.put("fc2", 3.5);
        oriM.put("fc3", 3.6);
        oriM.put("fc4", 3.7);
        
        Assert.assertTrue(MathUtil.isMapEqual(oriM, newM, "test map equal"));
        
        oriM.put("fc5", 3.8);
        Assert.assertFalse(MathUtil.isMapEqual(oriM, newM, "test map equal"));
        
        newM.put("fc5", null);
        Assert.assertFalse(MathUtil.isMapEqual(oriM, newM, "test map equal"));
        
        newM = null;
        Assert.assertFalse(MathUtil.isMapEqual(oriM, newM, "test map equal"));
        
        newM = oriM;
        oriM = null;
        Assert.assertFalse(MathUtil.isMapEqual(oriM, newM, "test map equal"));
        
        newM = null;
        Assert.assertTrue(MathUtil.isMapEqual(oriM, newM, "test map equal"));
    }
    
    @Test
    public void testIsListEqual(){
        
        List<String> newM = new ArrayList<String>();
        List<String> oriM = new ArrayList<String>();
        
        newM.add("fc1");
        newM.add("fc2");
        newM.add("fc3");
        newM.add("fc4");
        
        oriM.add("fc1");
        oriM.add("fc3");
        oriM.add("fc2");
        oriM.add("fc4");
        
        Assert.assertTrue(MathUtil.isFcListEqual(oriM, newM, "test list equal"));
        
        oriM.add("fc5");
        Assert.assertFalse(MathUtil.isFcListEqual(oriM, newM, "test list equal"));
        
        newM.add(null);
        Assert.assertFalse(MathUtil.isFcListEqual(oriM, newM, "test list equal"));
        
        newM = null;
        Assert.assertFalse(MathUtil.isFcListEqual(oriM, newM, "test list equal"));
        
        newM = oriM;
        oriM = null;
        Assert.assertFalse(MathUtil.isFcListEqual(oriM, newM, "test list equal"));
        
        newM = null;
        Assert.assertTrue(MathUtil.isFcListEqual(oriM, newM, "test list equal"));
    }
    
    
    @Test
    public void testAvgCollection(){
        List<Double> numbers = Arrays.asList(Double.valueOf(1d), Double.valueOf(2), Double.valueOf(4), Double.valueOf(5d));
        Assert.assertEquals(MathUtil.average(numbers), 3d);
        
        numbers = Arrays.asList(Double.valueOf(1d), Double.valueOf(2), Double.valueOf(2), Double.valueOf(1d));
        Assert.assertEquals(MathUtil.average(numbers), 1.5d);        
 
        numbers = Arrays.asList(Double.valueOf(1d));
        Assert.assertEquals(MathUtil.average(numbers), 1d);   
    }
    
    @Test
    public void testGetEqualSpanSeries() {
        Integer[] ret = MathUtil.getEqualSpanSeries(0, 20, 10);
       
        Assert.assertTrue(Arrays.equals(new Integer[]{2, 4, 6, 8, 10, 12, 14, 16, 18, 20}, ret));
        ret = MathUtil.getEqualSpanSeries(0, 20, 6);
        Assert.assertTrue(Arrays.equals(new Integer[]{3, 6, 9, 12, 16, 20}, ret));
        
        ret = MathUtil.getEqualSpanSeries(0, 20, 1);
        Assert.assertTrue(Arrays.equals(new Integer[]{20}, ret));
        
        ret = MathUtil.getEqualSpanSeries(0, 3, 4);
        Assert.assertTrue(Arrays.equals(new Integer[]{1,2,3}, ret));
        
        ret = MathUtil.getEqualSpanSeries(0, 0, 4);
        Assert.assertTrue(Arrays.equals(new Integer[0], ret));
        
    }
    
    @Test
    public void testNormalizationWeight() {
        Map<String, Double> weights = new HashMap<String, Double>();
        weights.put("k1", 2.0);
        weights.put("k2", 4.0);
        weights.put("k3", 6.0);
        weights.put("k4", 8.0);
        
        Map<String, Double> ret = MathUtil.normalizationWeight(weights);
        Assert.assertEquals(ret.get("k3"), 0.3);
        
        weights.put("k1", 0.0);
        weights.put("k2", 0.0);
        weights.put("k3", 0.0);
        weights.put("k4", 0.0);
        ret = MathUtil.normalizationWeight(weights);
        Assert.assertEquals(ret.get("k3"), 0.0);
        
    }
    
    @Test
    public void testLinearInterpolate() {
        double result = MathUtil.linearInterpolate(0.0, 0.0, 10.0, 10.0, 5.0);
        Assert.assertEquals(5.0, result);
        
        result = MathUtil.linearInterpolate(1.0, 12.0, 4.0, 18.0, 2.0);
        Assert.assertEquals(14.0, result);
    }
}
