package oih.util;

import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import oih.config.Config;
import oih.config.ConfigFactory;
import oih.config.automationsetup.AutomationConfigFactory;

import org.jmock.Expectations;
import org.jmock.Mockery;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.amazon.oihautomationsetup.model.mapping.WarehouseNodeModel;

public class WarehouseCategorizerTest {

    private static final Map<String, List<String>> TEST_DATA = new HashMap<String, List<String>>();
    static {
        // add some sortable FCS
        TEST_DATA.put(WarehouseNodeModel.SORTABLE, Arrays.asList(new String[] {
                "IND1", "UPLO", "LEX1", "PHL1", "PHL2", "PHL3", "PHX3", "RNO1", "RNO2", "SDF1", "SDF3", "TUL1", "NRT1",
                "NRT2", "KIX1", "PRTO", "FRA1", "FRA3", "LEJ1", "XDEB", "LTN1", "GLA1", "EDI2", "FRA1", "LEJ1", "CWL1",
                "EUK5", "FRA1", "LEJ1", "ORY1"
        }));

        // add some non-sortable FCS
        TEST_DATA.put(WarehouseNodeModel.NONSORTABLE, Arrays.asList(new String[] {
                "CVG2", "DFW1", "IND2", "PHL4", "PHL5", "PHX5"
        }));

        // add some speciality FCS
        TEST_DATA.put(WarehouseNodeModel.SPECIALITYFC, Arrays.asList(new String[] {
                "CVG1", "IND3", "LEX2", "SDF2"
        }));

        // add some FDFC
        TEST_DATA.put(WarehouseNodeModel.FDFC, Arrays.asList("ABE1", "BOS1", "BWI1", "LAS2", "SEA6"));

        // add some RCS
        TEST_DATA.put(WarehouseNodeModel.RC, Arrays.asList(new String[] {
                "AVP1", "CVG3", "PHX4"
        }));
        
        // add some RCS
        TEST_DATA.put(WarehouseNodeModel.MIXED, Arrays.asList(new String[] {
                "VFP1", "VFP2", "VFP3"
        }));
    }

    private WarehouseCategorizer warehouseCategorizer;

    @Before
    public void initialize() {
        Mockery context = new Mockery();

        final Config c = context.mock(Config.class);
        context.checking(new Expectations() {
            {
                for (Map.Entry<String, List<String>> entry : TEST_DATA.entrySet()) {
                    atLeast(1).of(c).findList("Oih.WarehouseCategorization." + entry.getKey());
                    will(returnValue(entry.getValue()));
                }

                one(c).getDomain();
                will(returnValue("test"));

                one(c).getRealmName();
                will(returnValue("USAmazon"));
            }
        });

        ConfigFactory.useConfig(c);

        // initializeAppConfig();// should initialize appconfig first
        AutomationConfigFactory.getConfigDaoAutomationConfiger();
        // AutomationConfigHelper.instance("USAmazon", "test", daoMaps);
        warehouseCategorizer = new WarehouseCategorizer();
    }

    @Test(expected = UndefinedWarehouseException.class)
    public void testUndefinedFC() throws UndefinedWarehouseException {
        warehouseCategorizer.isFC("BARTSIMPSON");
    }

    @Test(expected = UndefinedWarehouseException.class)
    public void testUndefinedFDFC() throws UndefinedWarehouseException {
        warehouseCategorizer.isFDFC("BARTSIMPSON");
    }

    @Test(expected = UndefinedWarehouseException.class)
    public void testUndefinedRC() throws UndefinedWarehouseException {
        warehouseCategorizer.isRC("BARTSIMPSON");
    }

    @Test(expected = UndefinedWarehouseException.class)
    public void testUndefinedWT() throws UndefinedWarehouseException {
        warehouseCategorizer.getWarehouseType("BARTSIMPSON");
    }

    @Test
    public void testWarehouseType() throws UndefinedWarehouseException {
        Assert.assertEquals(WarehouseType.SFC, warehouseCategorizer.getWarehouseType("LEX1"));
        Assert.assertEquals(WarehouseType.NSFC, warehouseCategorizer.getWarehouseType("DFW1"));
        Assert.assertEquals(WarehouseType.NSFC, warehouseCategorizer.getWarehouseType("VFP1"));
        Assert.assertEquals(WarehouseType.SPFC, warehouseCategorizer.getWarehouseType("IND3"));
        Assert.assertEquals(WarehouseType.FDFC, warehouseCategorizer.getWarehouseType("LAS2"));
        Assert.assertEquals(WarehouseType.RC, warehouseCategorizer.getWarehouseType("PHX4"));
    }

    @Test
    public void testIsFullFilmentCenter() throws UndefinedWarehouseException {
        // sortables
        Assert.assertTrue(warehouseCategorizer.isFC("LEX1"));
        Assert.assertTrue(warehouseCategorizer.isFC("NRT2"));
        Assert.assertTrue(warehouseCategorizer.isFC("PRTO"));
        Assert.assertTrue(warehouseCategorizer.isFC("GLA1"));
        Assert.assertTrue(warehouseCategorizer.isFC("FRA1"));
        Assert.assertTrue(warehouseCategorizer.isFC("VFP1"));
        Assert.assertTrue(warehouseCategorizer.isFC("VFP2"));
        Assert.assertTrue(warehouseCategorizer.isFC("VFP3"));

        // a non sortable
        Assert.assertTrue(warehouseCategorizer.isFC("DFW1"));

        // a speciality
        Assert.assertTrue(warehouseCategorizer.isFC("IND3"));

        // a fdfc
        Assert.assertFalse(warehouseCategorizer.isFC("LAS2"));

        // a rc
        Assert.assertFalse(warehouseCategorizer.isFC("PHX4"));
    }

    @Test
    public void testIsForwardDeployedFullFilmentCenter() throws UndefinedWarehouseException {
        // sortables FC
        Assert.assertFalse(warehouseCategorizer.isFDFC("LEX1"));
        // a non sortable FC
        Assert.assertFalse(warehouseCategorizer.isFDFC("DFW1"));

        // a fdfc
        Assert.assertTrue(warehouseCategorizer.isFDFC("LAS2"));

        // a rc
        Assert.assertFalse(warehouseCategorizer.isFDFC("PHX4"));
    }

    @Test
    public void testIsReplenishmentCenter() throws UndefinedWarehouseException {
        // sortables FC
        Assert.assertFalse(warehouseCategorizer.isRC("LEX1"));
        // a non sortable FC
        Assert.assertFalse(warehouseCategorizer.isRC("DFW1"));

        // a fdfc
        Assert.assertFalse(warehouseCategorizer.isRC("LAS2"));

        // a rc
        Assert.assertTrue(warehouseCategorizer.isRC("PHX4"));
    }

    @Test
    public void testAllFullfilmentCenters() {

        Set<String> fcs = warehouseCategorizer.getFCs();
        Set<String> expected = new HashSet<String>(Arrays.asList(new String[] {
                "IND1", "UPLO", "LEX1", "PHL1", "PHL2", "PHL3", "PHX3", "RNO1", "RNO2", "SDF1", "SDF3", "TUL1", "NRT1",
                "NRT2", "KIX1", "PRTO", "FRA1", "FRA3", "LEJ1", "XDEB", "LTN1", "GLA1", "EDI2", "FRA1", "LEJ1", "CWL1",
                "EUK5", "FRA1", "LEJ1", "ORY1", "CVG2", "DFW1", "IND2", "PHL4", "PHL5", "PHX5", "CVG1", "IND3", "LEX2",
                "SDF2", "VFP1", "VFP2", "VFP3"
        }));
        Assert.assertEquals(expected.size(), fcs.size());
        expected.removeAll(fcs);
        Assert.assertEquals(0, expected.size());
    }

    @Test
    public void testAllForwardDeployedFulFillmentCenter() {
        Set<String> fdfcs = warehouseCategorizer.getFDFCs();
        Set<String> expected = new HashSet<String>(Arrays.asList("ABE1", "BOS1", "BWI1", "LAS2", "SEA6"));
        Assert.assertEquals(expected.size(), fdfcs.size());
        expected.removeAll(fdfcs);
        Assert.assertEquals(0, expected.size());
    }

    @Test
    public void testAllReplenishmentCenter() {
        Set<String> fdfcs = warehouseCategorizer.getRCs();
        Set<String> expected = new HashSet<String>(Arrays.asList(new String[] {
                "AVP1", "CVG3", "PHX4"
        }));
        Assert.assertEquals(expected.size(), fdfcs.size());
        expected.removeAll(fdfcs);
        Assert.assertEquals(0, expected.size());
    }
}
