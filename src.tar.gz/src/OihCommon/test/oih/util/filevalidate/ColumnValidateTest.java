package oih.util.filevalidate;

import java.util.HashMap;
import java.util.Map;

import oih.util.filevalidate.ColumnValidateException;
import oih.util.filevalidate.ColumnValidationExecutor;
import oih.util.filevalidate.ColumnValidator;

import org.junit.Assert;
import org.junit.Test;

public class ColumnValidateTest {

    @Test
    public void testValidateLength() {
        ColumnValidationExecutor validateExecutor = ColumnValidationExecutor.getInstance();
        
        Map<String, String> map = new HashMap<String, String>();
        map.put("asin", "1234567890");
        map.put("somecolumn", "somevalue"); // will not be validated
        try {
            validateExecutor.validate(map);
        } catch (ColumnValidateException e) {
            e.printStackTrace();
        }
        
        map.put("asin", "12345678901");
        try {
            validateExecutor.validate(map);
        } catch (ColumnValidateException e) {
            Assert.assertEquals(e.getMessage(), "Invalid ASIN:12345678901, length:11, expected:10");
        }
        
        validateExecutor.reset();
        validateExecutor.addValidator(new ColumnValidator("org") {

            @Override
            public void validate(String value) throws ColumnValidateException {
                if (value == null) {
                    throw new ColumnValidateException("Null Org value");
                }
                if (value.indexOf("Amazon") < 0) {
                    throw new ColumnValidateException("Org must contain Amazon");
                }
            }
        });
        
        map.put("org", "USAmazon");
        try {
            validateExecutor.validate(map);
        } catch (ColumnValidateException e) {
            e.printStackTrace();
        }
        
        map.put("org", "USA");
        try {
            validateExecutor.validate(map);
        } catch (ColumnValidateException e) {
            Assert.assertEquals(e.getMessage(), "Org must contain Amazon");
        }
    }
}
