package oih.util.aws;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import oih.config.ConfigFactory;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.amazonaws.services.s3.AmazonS3Client;

public class S3FileRetrieverTst {
    
    private S3FileRetriever s3FileRetriever = null;
    
    @Before
    public void setUp(){
        Map config = new HashMap();
        config.put("OihWebsite.Workflow.AWS.S3.MaterialSetName", "com.amazon.access.OIH-oih-cn-1"); 
        config.put("IhrMetrics.eomPlanInput.AWS.S3.CredentialsMaterialSetName", "com.amazon.ipc.eom.oih-input"); 
        config.put("IhrMetrics.eomPlanInput.AWS.S3.EncryptionMaterialSetName", "com.amazon.ipc.eom.oih-input.encryption"); 
        ConfigFactory.useConfigFrom(config);        
    }
    
    @Test
    public void downloadToLocal() throws IOException{
        s3FileRetriever = new S3FileRetriever(OihS3ClientFactory.getInstance().newWorkflowClient());
        s3FileRetriever.downloadToLocal("s3://oih-workflow/Archive/China/201212/automation_upload-China-107-lpcn-lpcn-20121207085958", "/home/yuliang/temp.txt");         
    }
    
    @Test
    public void downloadEomFileToLocal() throws IOException{
        s3FileRetriever = new S3FileRetriever(OihS3ClientFactory.getInstance().newEomFileReadClient());
        s3FileRetriever.downloadToLocal("s3://oih-input-for-eom/upload/NPV_LIMITS-2013-01-06.txt", "/home/yuliang/temp.txt");         
    }
    
    @Test
    public void existEomFile() throws IOException{
        AmazonS3Client s3client = OihS3ClientFactory.getInstance().newEomFileReadClient();
        s3FileRetriever = new S3FileRetriever(OihS3ClientFactory.getInstance().newEomFileReadClient());
        Assert.assertTrue(s3FileRetriever.exist("s3://oih-input-for-eom/upload/NPV_LIMITS-2013-01-08.txt"));
    } 
        
    @Test
    public void listEomFiles() throws IOException{
        AmazonS3Client s3client = OihS3ClientFactory.getInstance().newEomFileReadClient();
        s3FileRetriever = new S3FileRetriever(OihS3ClientFactory.getInstance().newEomFileReadClient());
        List<String> files = s3FileRetriever.listFiles("s3://oih-input-for-eom/");
        for(String f : files){
            System.out.println(f);
        }
    }     
    
    @Test
    public void exist() throws IOException{
        s3FileRetriever = new S3FileRetriever(OihS3ClientFactory.getInstance().newWorkflowClient());
        Assert.assertTrue(s3FileRetriever.exist("s3://oih-workflow/Archive/China/201212/automation_upload-China-107-lpcn-lpcn-20121207085958"));                
        Assert.assertFalse(s3FileRetriever.exist("s3://oih-workflow/Archive/China/201212/automation_upload-China-107-lpcn-lpcn-20121207085958-bad")); 
        Assert.assertFalse(s3FileRetriever.exist("s3://oih-workflow/Archive/China/201212/automation_upload-China-107-lpcn-lpcn-20121207"));
    }

}