package oih.util.pricing;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import oih.business.AmazonOrg;
import oih.business.markdowns.MarkdownAsin;
import oih.business.markdowns.PawsAsin;

import org.junit.Assert;
import org.junit.Test;

public class PricingClientUtilsTest {

    @Test
    public void testAssignBestMarkdownQunatity() {
        Map<String, PawsAsin> dyingPawsAsinMap = new HashMap<String, PawsAsin>();
        Map<String, MarkdownAsin> dyingMarkdownAsinMap = new HashMap<String, MarkdownAsin>();
        
        dyingPawsAsinMap.put("asin1", newPawsAsin("asin1", "Available inventory (99) is already at or below the markdown quantity (100)."));
        dyingPawsAsinMap.put("asin2", newPawsAsin("asin2", "Available inventory (99) is already at or below the markdown quantity (100)."));
        dyingPawsAsinMap.put("asin3", newPawsAsin("asin3", null));
        dyingPawsAsinMap.put("asin5", newPawsAsin("asin5", "foo"));
        dyingPawsAsinMap.put("asin6", newPawsAsin("asin6", null));
        
        dyingMarkdownAsinMap.put("asin1", newMarkdownAsin("asin1", 100, 0));
        dyingMarkdownAsinMap.put("asin2", newMarkdownAsin("asin2", 100, 10));
        dyingMarkdownAsinMap.put("asin3", newMarkdownAsin("asin3", 100, 0));
        dyingMarkdownAsinMap.put("asin4", newMarkdownAsin("asin4", 200, 0));
        
        List<MarkdownAsin> result = PricingClientUtils.getBestQunatityMarkdowns(dyingPawsAsinMap, dyingMarkdownAsinMap);
        Assert.assertEquals(2, result.size());
        
        Map<String, MarkdownAsin> map = new HashMap<String, MarkdownAsin>();
        for (MarkdownAsin ma : result) {
            map.put(ma.getAsinString(), ma);
        }
        
        Assert.assertEquals(new Integer(99), map.get("asin1").getActioningQuantity());
        Assert.assertEquals(new Integer(89), map.get("asin2").getActioningQuantity());
    }
    
    private PawsAsin newPawsAsin(String asin, String devErrorMessage) {
        PawsAsin pa = new PawsAsin();
        pa.setAsin(asin);
        pa.setDevErrorMessage(devErrorMessage);
        return pa;
    }
    
    private MarkdownAsin newMarkdownAsin(String asin, Integer actioningQuantity, Integer totalHealthyQuantity) {
        MarkdownAsin ma = new MarkdownAsin(asin, AmazonOrg.US, 14, "14000000", "14000001");
        ma.setActioningQuantity(actioningQuantity);
        ma.setTotalHealthyQuantity(totalHealthyQuantity);
        return ma;
    }
}
