package oih.util;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.sql.Timestamp;
import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;

import junit.framework.JUnit4TestAdapter;

import org.junit.Assert;
import org.junit.Test;

public class DateUtilsTest {

	@Test
	public void testConvertToPreviousSaturday(){
		
		Calendar cal = Calendar.getInstance();
		cal.set(Calendar.YEAR, 2008);
		cal.set(Calendar.MONTH, Calendar.MARCH);
		cal.set(Calendar.DAY_OF_MONTH, 3);
		
		assertEquals("2008-03-01", DateUtils.formatDate(DateUtils.convertToPreviousSaturday(cal.getTime())));
		
		cal.add(Calendar.DAY_OF_MONTH, -4);
		
		assertEquals("2008-02-23", DateUtils.formatDate(DateUtils.convertToPreviousSaturday(cal.getTime())));
	}
	
	@Test
	public void testGetLastSaturday(){
		Calendar cal = Calendar.getInstance();
		
		while(cal.get(Calendar.DAY_OF_WEEK) != Calendar.SATURDAY){
			cal.add(Calendar.DAY_OF_WEEK, -1);
		}
		
		assertEquals(DateUtils.formatDate(cal.getTime()),
				DateUtils.formatDate(DateUtils.lastSaturday()));
	}
	
	@Test
	public void testFormatDate(){
		Calendar cal = Calendar.getInstance();
		cal.set(Calendar.YEAR, 2008);
		cal.set(Calendar.MONTH, Calendar.MARCH);
		cal.set(Calendar.DAY_OF_MONTH, 3);
		
		assertEquals("2008-03-03", DateUtils.formatDate(cal.getTime()));
		
		cal.add(Calendar.DAY_OF_MONTH, -3);
		
		assertEquals("2008-02-29", DateUtils.formatDate(cal.getTime()));
	}
	
	@Test
	public void testParseDate(){
		String date1 = "2007-06-05";
		String date2 = "2008-02-29";
		String badDate2 = "03/March/2008"; //Wrong date format
		Calendar cal = Calendar.getInstance();
		
		try{
			cal.setTime(DateUtils.parseDate(date1));
			
			assertEquals(2007, cal.get(Calendar.YEAR));
			assertEquals(5, cal.get(Calendar.DAY_OF_MONTH));
			assertEquals(6, cal.get(Calendar.MONTH)+1);
			
			cal.setTime(DateUtils.parseDate(date2));
			
			assertEquals(2008, cal.get(Calendar.YEAR));
			assertEquals(29, cal.get(Calendar.DAY_OF_MONTH));
			assertEquals(2, cal.get(Calendar.MONTH)+1);
		}catch(ParseException p){
			p.printStackTrace();
			fail();
		}
		
		try{
			cal.setTime(DateUtils.parseDate(badDate2));
			fail();
		}catch(ParseException p){
			assertEquals("Unparseable date: \"03/March/2008\"", p.getMessage());
		}
	}
	
	@Test
	public void testGetDateFor() {
		Date d1 = DateUtils.getDateFor(2008, 7, 10);
		Calendar c1 = Calendar.getInstance();
		c1.setTime(d1);
		Assert.assertEquals(c1.get(Calendar.YEAR),2008);
		Assert.assertEquals(c1.get(Calendar.MONTH) + 1, 7);
		Assert.assertEquals(c1.get(Calendar.DATE), 10);
	}
	
	
	@Test
	public void testAdd() {
		Date d = DateUtils.getDateFor(2008, 7, 22);
		
		Date d1 = DateUtils.add(d, 1, 1, 1);
		Date expected1 = DateUtils.getDateFor(2009, 8, 23);
		Assert.assertEquals(expected1, d1);
		
		//NOTE: this also tests that d is unchanged by earlier add
		Date d2 = DateUtils.add(d, -1, -1, -1);
		Date expected2 = DateUtils.getDateFor(2007, 6, 21);
		Assert.assertEquals(expected2, d2);
	}
	
	@Test
	public void testDateInRange() {
		Date rangeStart = DateUtils.getDateFor(2008, 6, 25);
		Date rangeEnd = DateUtils.getDateFor(2008, 7, 5);
		Assert.assertTrue(DateUtils.dateInRange(DateUtils.getDateFor(2008, 7, 1), rangeStart, rangeEnd));
		Assert.assertTrue(DateUtils.dateInRange(DateUtils.getDateFor(2008, 6, 25), rangeStart, rangeEnd));
		Assert.assertFalse(DateUtils.dateInRange(DateUtils.getDateFor(2008, 7, 5), rangeStart, rangeEnd));
		Assert.assertFalse(DateUtils.dateInRange(DateUtils.getDateFor(2008, 6, 20), rangeStart, rangeEnd));
		Assert.assertFalse(DateUtils.dateInRange(DateUtils.getDateFor(2008, 7, 20), rangeStart, rangeEnd));
		
		try {
			DateUtils.dateInRange(rangeEnd, rangeEnd, rangeStart);
			Assert.fail();
		} catch (Exception e) { 
			Assert.assertTrue(true);
		}
	}
	
	@Test
	public void testDateRangesOverlap() {
		Date jun25 = DateUtils.getDateFor(2008, 6, 25);
		Date jul5 = DateUtils.getDateFor(2008, 7, 5);
		Date jul1 = DateUtils.getDateFor(2008, 7, 1);
		Date jul10 = DateUtils.getDateFor(2008, 7, 10);
		
		Assert.assertTrue(DateUtils.dateRangesOverlap(jun25, jul5, jul1, jul10));
		Assert.assertTrue(DateUtils.dateRangesOverlap(jul1, jul10, jun25, jul5));
		Assert.assertTrue(DateUtils.dateRangesOverlap(jun25, jul10, jul1, jul5));
		Assert.assertTrue(DateUtils.dateRangesOverlap(jul1, jul5, jun25, jul10));
		
		//completely disjoint
		Assert.assertFalse(DateUtils.dateRangesOverlap(jul5, jul10, jun25, jul1));
		Assert.assertFalse(DateUtils.dateRangesOverlap(jun25, jul1, jul5, jul10));
		
		//one range ends and second range starts
		Assert.assertFalse(DateUtils.dateRangesOverlap(jun25, jul1, jul1, jul5));
		Assert.assertFalse(DateUtils.dateRangesOverlap(jul1, jul5, jun25, jul1));
	}

    @Test
	public void testGetCalendarDate() {
		Date jun25 = DateUtils.getDateFor(2008, 6, 25);
		Calendar c = DateUtils.getCalendarDate(jun25);
		Assert.assertTrue( c.get(Calendar.HOUR) == 0 );
		Assert.assertTrue( c.get(Calendar.MINUTE) == 0 );
		Assert.assertTrue( c.get(Calendar.SECOND) == 0 );
		Assert.assertTrue( c.get(Calendar.MILLISECOND) == 0 );
		Assert.assertTrue( c.get(Calendar.AM_PM) == Calendar.AM );
		Calendar tmp = Calendar.getInstance();
		tmp.setTimeInMillis(jun25.getTime());
		Assert.assertTrue( c.get(Calendar.YEAR) == tmp.get(Calendar.YEAR) );
		Assert.assertTrue( c.get(Calendar.MONTH) == tmp.get(Calendar.MONTH) );
		Assert.assertTrue( c.get(Calendar.DATE) == tmp.get(Calendar.DATE) );
    }
    
    @Test
    public void testParseDateStrictly(){
        String[] parsePatterns = {"yyyy-MM-dd","M/d/yy","M/d/yyyy"};
        try {
            DateUtils.parseDateStrictly("2/1/11", parsePatterns);
        } catch (ParseException e) {
            Assert.fail();
        }
        try {
            DateUtils.parseDateStrictly("02/01/2011", parsePatterns);
        } catch (ParseException e) {
            Assert.fail();
        }
        try {
            DateUtils.parseDateStrictly("1/20/2011", parsePatterns);
        } catch (ParseException e) {
            Assert.fail();
        }   
        try {
            DateUtils.parseDateStrictly("7/11/2011", parsePatterns);
        } catch (ParseException e) {
            Assert.fail();
        }       
        try {
            DateUtils.parseDateStrictly("02/1/2011", parsePatterns);
        } catch (ParseException e) {
            Assert.fail();
        }         
        try {
            DateUtils.parseDateStrictly("2012-01-30", parsePatterns);
        } catch (ParseException e) {
            Assert.fail();
        }
        try {
            DateUtils.parseDateStrictly("d2/1/11", parsePatterns);
            Assert.fail();
        } catch (ParseException e) {            
        }  
        try {
            DateUtils.parseDateStrictly("2012-01-3d", parsePatterns);
            Assert.fail();
        } catch (ParseException e) {            
        }        
    }
    
    
    
	public static junit.framework.Test suite() {
		return new JUnit4TestAdapter(DateUtilsTest.class);
	}
	
    @Test
    public void testAddDays(){
        Date d = DateUtils.getDateFor(2008, 7, 22);
        Date expected = DateUtils.getDateFor(2008, 8, 2);
        Date actual = org.apache.commons.lang.time.DateUtils.addDays(d, 11);
        Assert.assertEquals(expected, actual);
        
        expected = DateUtils.getDateFor(2009, 7, 22);
        actual = org.apache.commons.lang.time.DateUtils.addDays(d, 365);
        Assert.assertEquals(expected, actual);
    }
	    
    @Test
    public void testDatesInSameWeek() {
        Date basis = DateUtils.getDateFor(2012, 7, 19);
        Date target = DateUtils.getDateFor(2012, 7, 14);
        Assert.assertFalse(DateUtils.isInSameWeek(basis, target));
        
        basis = DateUtils.getDateFor(2012, 7, 19);
        target = DateUtils.getDateFor(2012, 7, 15);
        Assert.assertTrue(DateUtils.isInSameWeek(basis, target));
        
        basis = DateUtils.getDateFor(2012, 7, 19);
        target = DateUtils.getDateFor(2012, 7, 21);
        Assert.assertTrue(DateUtils.isInSameWeek(basis, target));
        
        basis = DateUtils.getDateFor(2012, 7, 19);
        target = DateUtils.getDateFor(2012, 7, 22);
        Assert.assertFalse(DateUtils.isInSameWeek(basis, target));
        
    }
    
    @Test
    public void testSameDay() {
        Date lhs = DateUtils.getDateFor(2012, 12, 20);
        Date rhs = DateUtils.getDateFor(2012, 12, 20);
        Assert.assertTrue(DateUtils.isSameDay(lhs, rhs));
        
        Assert.assertFalse(DateUtils.isSameDay(null, rhs));
        Assert.assertFalse(DateUtils.isSameDay(lhs, null));
        Assert.assertFalse(DateUtils.isSameDay(null, null));
        
        Date date = DateUtils.getDateFor(2012, 12, 20);
        Timestamp timestamp = new Timestamp(DateUtils.getDateFor(2012, 12, 20).getTime());
        Assert.assertTrue(DateUtils.isSameDay(date, timestamp));
        Assert.assertTrue(DateUtils.isSameDay(timestamp, date));
    }
    
    @Test
    public void testNextDayOfWeek() {
        Date pivot = DateUtils.getDateFor(2012, 8, 8);
        Date date = DateUtils.getDateFor(2012, 8, 11);
        Assert.assertEquals(DateUtils.nextDayOfWeek(pivot, 0, Calendar.SATURDAY), date);
        
        date = DateUtils.getDateFor(2012, 8, 12);
        Assert.assertEquals(DateUtils.nextDayOfWeek(pivot, 0, Calendar.SUNDAY), date);
        
        date = DateUtils.getDateFor(2012, 8, 18);
        Assert.assertEquals(DateUtils.nextDayOfWeek(pivot, 1, Calendar.SATURDAY), date);
        
        date = DateUtils.getDateFor(2012, 8, 19);
        Assert.assertEquals(DateUtils.nextDayOfWeek(pivot, 1, Calendar.SUNDAY), date);
        
        date = DateUtils.getDateFor(2012, 8, 25);
        Assert.assertEquals(DateUtils.nextDayOfWeek(pivot, 2, Calendar.SATURDAY), date);
        
        date = DateUtils.getDateFor(2012, 8, 26);
        Assert.assertEquals(DateUtils.nextDayOfWeek(pivot, 2, Calendar.SUNDAY), date);
        
        date = DateUtils.getDateFor(2012, 8, 8);
        Assert.assertEquals(DateUtils.nextDayOfWeek(pivot, 0, Calendar.WEDNESDAY), date);
        
        date = DateUtils.getDateFor(2012, 8, 15);
        Assert.assertEquals(DateUtils.nextDayOfWeek(pivot, 1, Calendar.WEDNESDAY), date);
        
        date = DateUtils.getDateFor(2012, 8, 13);
        Assert.assertEquals(DateUtils.nextDayOfWeek(pivot, 0, Calendar.MONDAY), date);
        
        date = DateUtils.getDateFor(2012, 8, 20);
        Assert.assertEquals(DateUtils.nextDayOfWeek(pivot, 1, Calendar.MONDAY), date);
    }
    
    @Test
    public void testLastDayOfWeek() {
        Date pivot = DateUtils.getDateFor(2012, 8, 8);
        Date date = DateUtils.getDateFor(2012, 8, 4);
        Assert.assertEquals(DateUtils.lastDayOfWeek(pivot, 0, Calendar.SATURDAY), date);
        
        date = DateUtils.getDateFor(2012, 8, 5);
        Assert.assertEquals(DateUtils.lastDayOfWeek(pivot, 0, Calendar.SUNDAY), date);
        
        date = DateUtils.getDateFor(2012, 7, 28);
        Assert.assertEquals(DateUtils.lastDayOfWeek(pivot, 1, Calendar.SATURDAY), date);
        
        date = DateUtils.getDateFor(2012, 7, 29);
        Assert.assertEquals(DateUtils.lastDayOfWeek(pivot, 1, Calendar.SUNDAY), date);
        
        date = DateUtils.getDateFor(2012, 7, 21);
        Assert.assertEquals(DateUtils.lastDayOfWeek(pivot, 2, Calendar.SATURDAY), date);
        
        date = DateUtils.getDateFor(2012, 7, 22);
        Assert.assertEquals(DateUtils.lastDayOfWeek(pivot, 2, Calendar.SUNDAY), date);
        
        date = DateUtils.getDateFor(2012, 8, 8);
        Assert.assertEquals(DateUtils.lastDayOfWeek(pivot, 0, Calendar.WEDNESDAY), date);
        
        date = DateUtils.getDateFor(2012, 8, 1);
        Assert.assertEquals(DateUtils.lastDayOfWeek(pivot, 1, Calendar.WEDNESDAY), date);
        
        date = DateUtils.getDateFor(2012, 8, 6);
        Assert.assertEquals(DateUtils.lastDayOfWeek(pivot, 0, Calendar.MONDAY), date);
        
        date = DateUtils.getDateFor(2012, 7, 30);
        Assert.assertEquals(DateUtils.lastDayOfWeek(pivot, 1, Calendar.MONDAY), date);
    }
}
