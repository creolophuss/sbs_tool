package com.amazon.oih.cbm.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import junit.framework.Assert;

import org.junit.Test;

import com.amazon.oih.cbm.model.CalenderEvaluationInput;
import com.amazon.oih.cbm.util.BaseDateCalculator.BasedDateType;
import com.amazon.oih.cbm.util.ConfiguredDateUtil.DateType;

public class ConfiguredDateUtilTest {
    @Test
    public void testFullPriceEndBaseDay() throws ParseException{
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        CalenderEvaluationInput input = new CalenderEvaluationInput("0301", "0701", "0801");
        input.setSeasonStartYear(2013);
        input.calculateAndSetCBMDates(new MockBaseDateCalculator());
        Date result = ConfiguredDateUtil.getDate(input, DateType.FULL_PRICE_END_BASED_DAYS + ":30");
        Assert.assertEquals("2013-07-31", format.format(result));
        
        input = new CalenderEvaluationInput("1101", "0701", "0801");
        input.setSeasonStartYear(2013);
        input.calculateAndSetCBMDates(new MockBaseDateCalculator());
        result = ConfiguredDateUtil.getDate(input, DateType.FULL_PRICE_END_BASED_DAYS + ":30");
        Assert.assertEquals("2014-07-31", format.format(result));
        result = ConfiguredDateUtil.getDate(input, DateType.SEASON_START_BASED_DAYS + ":30");
        Assert.assertEquals("2013-12-01", format.format(result));
        result = ConfiguredDateUtil.getDate(input, DateType.SEASON_START + ":2");
        Assert.assertEquals("2015-11-01", format.format(result)); 
        result = ConfiguredDateUtil.getDate(input, DateType.FULL_PRICE_END + ":2");
        Assert.assertEquals("2016-07-01", format.format(result));
        result = ConfiguredDateUtil.getDate(input, DateType.LIQUIDATE_DATE + ":2");
        Assert.assertEquals("2016-08-01", format.format(result));
        result = ConfiguredDateUtil.getDate(input, DateType.LIQUIDATE_DATE_REUSE + ":4");
        Assert.assertEquals("2018-08-01", format.format(result));
        result = ConfiguredDateUtil.getDate(input, "0115:4");
        Assert.assertEquals("2018-01-15", format.format(result));
        result = ConfiguredDateUtil.getDate(input, "1201:4");
        Assert.assertEquals("2017-12-01", format.format(result));
        
        input.calculateAndSetCBMDates(new MockBaseDateCalculator(BasedDateType.FULL_PRICE_END_DATE));
        result = ConfiguredDateUtil.getDate(input, DateType.FULL_PRICE_END_BASED_DAYS + ":30");
        Assert.assertEquals("2013-07-31", format.format(result));
        result = ConfiguredDateUtil.getDate(input, DateType.SEASON_START_BASED_DAYS + ":30");
        Assert.assertEquals("2012-12-01", format.format(result));
        result = ConfiguredDateUtil.getDate(input, DateType.SEASON_START + ":2");
        Assert.assertEquals("2014-11-01", format.format(result)); 
        result = ConfiguredDateUtil.getDate(input, DateType.FULL_PRICE_END + ":2");
        Assert.assertEquals("2015-07-01", format.format(result));
        result = ConfiguredDateUtil.getDate(input, DateType.LIQUIDATE_DATE + ":2");
        Assert.assertEquals("2015-08-01", format.format(result));
        result = ConfiguredDateUtil.getDate(input, DateType.LIQUIDATE_DATE_REUSE + ":4");
        Assert.assertEquals("2017-08-01", format.format(result));
        result = ConfiguredDateUtil.getDate(input, "0115:4");
        Assert.assertEquals("2018-01-15", format.format(result));
        result = ConfiguredDateUtil.getDate(input, "1201:4");
        Assert.assertEquals("2017-12-01", format.format(result));
    }
    
    @Test
    public void testNormalDateOrder() throws ParseException{
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        CalenderEvaluationInput input = new CalenderEvaluationInput("0301", "0701", "0801");
        input.setSeasonStartYear(2013);
        input.calculateAndSetCBMDates(new MockBaseDateCalculator());
        Date result = ConfiguredDateUtil.getDate(input, DateType.FULL_PRICE_END_BASED_DAYS + ":30");
        Assert.assertEquals("2013-07-31", format.format(result));
        result = ConfiguredDateUtil.getDate(input, DateType.SEASON_START_BASED_DAYS + ":30");
        Assert.assertEquals("2013-03-31", format.format(result));
        result = ConfiguredDateUtil.getDate(input, DateType.SEASON_START + ":2");
        Assert.assertEquals("2015-03-01", format.format(result)); 
        result = ConfiguredDateUtil.getDate(input, DateType.FULL_PRICE_END + ":2");
        Assert.assertEquals("2015-07-01", format.format(result));
        result = ConfiguredDateUtil.getDate(input, DateType.LIQUIDATE_DATE + ":2");
        Assert.assertEquals("2015-08-01", format.format(result));
        result = ConfiguredDateUtil.getDate(input, DateType.LIQUIDATE_DATE_REUSE + ":4");
        Assert.assertEquals("2017-08-01", format.format(result));
        result = ConfiguredDateUtil.getDate(input, "0115:4");
        Assert.assertEquals("2018-01-15", format.format(result));
        result = ConfiguredDateUtil.getDate(input, "1201:4");
        Assert.assertEquals("2017-12-01", format.format(result));
        result = ConfiguredDateUtil.getDate(input, "0115:0");
        Assert.assertEquals("2014-01-15", format.format(result));
        result = ConfiguredDateUtil.getDate(input, "1201:0");
        Assert.assertEquals("2013-12-01", format.format(result));
        
        input.calculateAndSetCBMDates(new MockBaseDateCalculator(BasedDateType.FULL_PRICE_END_DATE));
        result = ConfiguredDateUtil.getDate(input, DateType.FULL_PRICE_END_BASED_DAYS + ":30");
        Assert.assertEquals("2013-07-31", format.format(result));
        result = ConfiguredDateUtil.getDate(input, DateType.SEASON_START_BASED_DAYS + ":30");
        Assert.assertEquals("2013-03-31", format.format(result));
        result = ConfiguredDateUtil.getDate(input, DateType.SEASON_START + ":2");
        Assert.assertEquals("2015-03-01", format.format(result)); 
        result = ConfiguredDateUtil.getDate(input, DateType.FULL_PRICE_END + ":2");
        Assert.assertEquals("2015-07-01", format.format(result));
        result = ConfiguredDateUtil.getDate(input, DateType.LIQUIDATE_DATE + ":2");
        Assert.assertEquals("2015-08-01", format.format(result));
        result = ConfiguredDateUtil.getDate(input, DateType.LIQUIDATE_DATE_REUSE + ":4");
        Assert.assertEquals("2017-08-01", format.format(result));
        result = ConfiguredDateUtil.getDate(input, "0115:4");
        Assert.assertEquals("2018-01-15", format.format(result));
        result = ConfiguredDateUtil.getDate(input, "1201:4");
        Assert.assertEquals("2017-12-01", format.format(result));
        result = ConfiguredDateUtil.getDate(input, "0115:0");
        Assert.assertEquals("2014-01-15", format.format(result));
        result = ConfiguredDateUtil.getDate(input, "1201:0");
        Assert.assertEquals("2013-12-01", format.format(result));
    }
}
