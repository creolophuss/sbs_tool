package com.amazon.oih.cbm.util;

import java.math.BigDecimal;

import junit.framework.Assert;

import org.junit.Test;

import com.amazon.oih.cbm.model.MarkdownPriceBase;

public class ConfiguredPriceUtilTest {
    @Test
    public void testGetPrice(){
        MarkdownPriceBase base = new MarkdownPriceBase();
        base.setListPrice(new BigDecimal(100));
        BigDecimal price = ConfiguredPriceUtil.getPrice(base, ConfiguredPriceUtil.PriceType.LIST_PRICE_BASED.getFormatString(new BigDecimal(0.5)) + "+10");
        Assert.assertEquals(60, price.intValue());
        price = ConfiguredPriceUtil.getPrice(base, ConfiguredPriceUtil.PriceType.LIST_PRICE_BASED.name() + "*0.50+10");        
        Assert.assertEquals(60, price.intValue());
        price = ConfiguredPriceUtil.getPrice(base, ConfiguredPriceUtil.PriceType.LIST_PRICE_BASED.name() + "*0.50");        
        Assert.assertEquals(50, price.intValue());
    }
    
    @Test
    public void testGetPriceWithAction(){
        MarkdownPriceBase base = new MarkdownPriceBase();
        base.setListPrice(new BigDecimal(100));
        BigDecimal price = ConfiguredPriceUtil.getPrice(base, "action|" + ConfiguredPriceUtil.PriceType.LIST_PRICE_BASED.getFormatString(new BigDecimal(0.5)) + "+10");
        Assert.assertEquals(60, price.intValue());
        price = ConfiguredPriceUtil.getPrice(base, "action|" + ConfiguredPriceUtil.PriceType.LIST_PRICE_BASED.name() + "*0.50+10");        
        Assert.assertEquals(60, price.intValue());
        price = ConfiguredPriceUtil.getPrice(base, "action|" + ConfiguredPriceUtil.PriceType.LIST_PRICE_BASED.name() + "*0.50");        
        Assert.assertEquals(50, price.intValue());
    }
    
    @Test
    public void testPriceFactor() {
    	MarkdownPriceBase base = new MarkdownPriceBase();
        base.setListPrice(new BigDecimal(100));
        base.setCarryoverDiscount(new BigDecimal(25));
        BigDecimal price = ConfiguredPriceUtil.getPrice(base, ConfiguredPriceUtil.PriceType.LIST_PRICE_BASED.name() + "*HUNDRED_MINUS_CARRY_OVER_DISCOUNT");        
        Assert.assertEquals(75, price.intValue());
        price = ConfiguredPriceUtil.getPrice(base, ConfiguredPriceUtil.PriceType.LIST_PRICE_BASED.name() + "*HUNDRED_MINUS_CARRY_OVER_DISCOUNT+2");      
        Assert.assertEquals(77, price.intValue());
        price = ConfiguredPriceUtil.getPrice(base, ConfiguredPriceUtil.PriceType.LIST_PRICE_BASED.name() + "*HUNDRED_MINUS_CARRY_OVER_DISCOUNT+HUNDRED_MINUS_CARRY_OVER_DISCOUNT");        
        Assert.assertEquals(75.75, price.doubleValue());
    }
}
