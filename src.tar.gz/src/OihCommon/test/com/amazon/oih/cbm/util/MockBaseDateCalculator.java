package com.amazon.oih.cbm.util;

import com.amazon.oih.cbm.model.CalenderEvaluationInput;


public class MockBaseDateCalculator extends BaseDateCalculator {
	BasedDateType baseType = BasedDateType.SEASON_START_DATE;
	
	public MockBaseDateCalculator(){};
	public MockBaseDateCalculator(BasedDateType baseType){
		this.baseType = baseType;
	}
	@Override
    protected BasedDateType getBaseDateType(CalenderEvaluationInput input) {
    	return baseType;
    }
}
