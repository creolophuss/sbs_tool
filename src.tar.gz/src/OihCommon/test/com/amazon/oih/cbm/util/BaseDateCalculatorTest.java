package com.amazon.oih.cbm.util;

import junit.framework.Assert;

import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.junit.Test;

import com.amazon.oih.cbm.model.CalenderEvaluationInput;

import static com.amazon.oih.cbm.util.BaseDateCalculator.BasedDateType.*;

public class BaseDateCalculatorTest {
    private static final DateTimeFormatter dateFormatter = DateTimeFormat.forPattern("yyyyMMdd");
    @Test
    public void testCalculateBaseDate(){
        BaseDateCalculator calculator = new MockBaseDateCalculator(SEASON_START_DATE);
        CalenderEvaluationInput input = new CalenderEvaluationInput(null, null, null);
        input.setSeasonStartYear(2013);
        
        input.setSeasonStartDateCode("0601");
        input.setFullPriceEndDateCode("0701");
        input.setLiquidationEligibilityDateCode("0901");       
        DateTime date = calculator.calculateBaseDate(SEASON_START_DATE, input);
        Assert.assertEquals(dateFormatter.parseDateTime("20130601"), date);
        date = calculator.calculateBaseDate(FULL_PRICE_END_DATE, input);
        Assert.assertEquals(dateFormatter.parseDateTime("20130701"), date);
        date = calculator.calculateBaseDate(LIQUIDATE_ELIGIBLE_DATE, input);
        Assert.assertEquals(dateFormatter.parseDateTime("20130901"), date);
        
        input.setSeasonStartDateCode("1101");
        input.setFullPriceEndDateCode("0301");
        input.setLiquidationEligibilityDateCode("0601");
        date = calculator.calculateBaseDate(SEASON_START_DATE, input);
        Assert.assertEquals(dateFormatter.parseDateTime("20131101"), date);
        date = calculator.calculateBaseDate(FULL_PRICE_END_DATE, input);
        Assert.assertEquals(dateFormatter.parseDateTime("20140301"), date);
        date = calculator.calculateBaseDate(LIQUIDATE_ELIGIBLE_DATE, input);
        Assert.assertEquals(dateFormatter.parseDateTime("20140601"), date);
        
        calculator = new MockBaseDateCalculator(FULL_PRICE_END_DATE);
        input.setSeasonStartDateCode("0601");
        input.setFullPriceEndDateCode("0701");
        input.setLiquidationEligibilityDateCode("0901");       
        date = calculator.calculateBaseDate(SEASON_START_DATE, input);
        Assert.assertEquals(dateFormatter.parseDateTime("20130601"), date);
        date = calculator.calculateBaseDate(FULL_PRICE_END_DATE, input);
        Assert.assertEquals(dateFormatter.parseDateTime("20130701"), date);
        date = calculator.calculateBaseDate(LIQUIDATE_ELIGIBLE_DATE, input);
        Assert.assertEquals(dateFormatter.parseDateTime("20130901"), date);
        
        input.setSeasonStartDateCode("1101");
        input.setFullPriceEndDateCode("0701");
        input.setLiquidationEligibilityDateCode("0801");
        date = calculator.calculateBaseDate(SEASON_START_DATE, input);
        Assert.assertEquals(dateFormatter.parseDateTime("20121101"), date);
        date = calculator.calculateBaseDate(FULL_PRICE_END_DATE, input);
        Assert.assertEquals(dateFormatter.parseDateTime("20130701"), date);
        date = calculator.calculateBaseDate(LIQUIDATE_ELIGIBLE_DATE, input);
        Assert.assertEquals(dateFormatter.parseDateTime("20130801"), date);
        input.setLiquidationEligibilityDateCode("0501");
        date = calculator.calculateBaseDate(LIQUIDATE_ELIGIBLE_DATE, input);
        Assert.assertEquals(dateFormatter.parseDateTime("20140501"), date);
        
        calculator = new MockBaseDateCalculator(LIQUIDATE_ELIGIBLE_DATE);
        input.setLiquidationEligibilityDateCode("0801");
        date = calculator.calculateBaseDate(SEASON_START_DATE, input);
        Assert.assertEquals(dateFormatter.parseDateTime("20121101"), date);
        date = calculator.calculateBaseDate(FULL_PRICE_END_DATE, input);
        Assert.assertEquals(dateFormatter.parseDateTime("20130701"), date);
        date = calculator.calculateBaseDate(LIQUIDATE_ELIGIBLE_DATE, input);
        Assert.assertEquals(dateFormatter.parseDateTime("20130801"), date);
        input.setLiquidationEligibilityDateCode("0501");
        date = calculator.calculateBaseDate(LIQUIDATE_ELIGIBLE_DATE, input);
        Assert.assertEquals(dateFormatter.parseDateTime("20130501"), date);
        date = calculator.calculateBaseDate(SEASON_START_DATE, input);
        Assert.assertEquals(dateFormatter.parseDateTime("20121101"), date);
        date = calculator.calculateBaseDate(FULL_PRICE_END_DATE, input);
        Assert.assertEquals(dateFormatter.parseDateTime("20120701"), date);
    }
}
