package com.amazon.oih.cbm;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.joda.time.DateTime;
import org.junit.Assert;
import org.junit.Test;

import com.amazon.oih.cbm.model.CalenderEvaluationOutput;
import com.amazon.oih.cbm.model.MarkdownType;
import com.amazon.oih.cbm.model.MultipleFloorMarkdownAction;
import com.amazon.oih.cbm.model.PromotionOutputDetail;
import com.amazon.oih.cbm.model.Stage;
import com.amazon.oih.cbm.model.StatusCode;
import com.amazon.oih.dao.exception.OihPersistenceException;
import com.amazon.oih.utils.DaoUtil;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;


public class CalendarEvaluationOutputDaoTest{      
    @SuppressWarnings("rawtypes")
    CalendarEvaluationOutputDao dao = new CalendarEvaluationOutputDao(DaoUtil.getAnnotationSessionFactory(
            Arrays.asList((Class) CalenderEvaluationOutput.class, (Class) PromotionOutputDetail.class)), true);
    
    @Test
    public void testFindActiveMarkdownHistoryByParent() throws OihPersistenceException{
        CalenderEvaluationOutput data1 = new CalenderEvaluationOutput();
        data1.setAsin("ASIN1");
        data1.setParentAsin("ASIN1");
        data1.setPriceDiscount("70");
        data1.setMarketplaceId(1l);
        data1.setMerchantId(1l);
        data1.setEndDate(new DateTime().minusDays(2).toDate());
        data1.setMarkdownType(MarkdownType.PROMOTION);
        data1.setStatusCode(StatusCode.SUCCESS);
        data1.setMessage("initMsg");
        data1.addMessage("appendMsg");
           
        CalenderEvaluationOutput data2 = new CalenderEvaluationOutput();
        data2.setAsin("ASIN2");
        data2.setParentAsin("ASIN2");
        data2.setPriceDiscount("80");
        data2.setMarketplaceId(1l);
        data2.setMerchantId(1l);
        data2.setEndDate(new DateTime().plusDays(2).toDate());
        data2.setMarkdownType(MarkdownType.PROMOTION);
        data2.setStatusCode(StatusCode.SUCCESS);
           
        CalenderEvaluationOutput data3 = new CalenderEvaluationOutput();
        data3.setAsin("ASIN3");
        data3.setParentAsin("ASIN3");
        data3.setPriceDiscount("90");
        data3.setMarketplaceId(1l);
        data3.setMerchantId(1l);
        data3.setEndDate(new DateTime().plusDays(2).toDate());
        data3.setMarkdownType(MarkdownType.PROMOTION);
        data3.setStatusCode(StatusCode.CBM_ATTRIBUTES_ERROR);
         
        CalenderEvaluationOutput data4 = new CalenderEvaluationOutput();
        data4.setAsin("ASIN4");
        data4.setParentAsin("ASIN4");
        data4.setPriceDiscount("90");
        data4.setMarketplaceId(1l);
        data4.setMerchantId(1l);
        data4.setEndDate(new DateTime().plusDays(2).toDate());
        data4.setMarkdownType(MarkdownType.PROMOTION);
        data4.setStatusCode(StatusCode.ACTION_REMOVED);
         
        CalenderEvaluationOutput data5 = new CalenderEvaluationOutput();
        data5.setAsin("ASIN7");
        data5.setParentAsin("ASIN6");
        data5.setColor("red");
        data5.setPriceDiscount("70");
        data5.setMarketplaceId(1l);
        data5.setMerchantId(1l);
        data5.setEndDate(new DateTime().plusDays(10).toDate());
        data5.setMarkdownType(MarkdownType.CADENCE);
        data5.setStatusCode(StatusCode.SUCCESS);
        data5.setFloorDiscount(MultipleFloorMarkdownAction.MULTI_FLOOR);
        data5.setMessage("initMsg");
        data5.addMessage("appendMsg");
        data5.setStage("a");
        data5.setActionId(1l);
        
        dao.save(data1);
        dao.save(data2);
        dao.save(data3);
        dao.save(data4);
        dao.save(data5);
        
        List<CalenderEvaluationOutput>  resultSet = dao.findActiveActionHistoryByParent(1l, 1l, Sets.newHashSet(new AsinColor("ASIN4", "")), Sets.newHashSet(new AsinColor("ASIN4", "")), new DateTime());
        Assert.assertTrue(1 == resultSet.size());
        Assert.assertEquals("ASIN4", resultSet.iterator().next().getParentAsin());   
        
        
        resultSet = dao.findActiveActionHistoryByParent(1l, 1l, Sets.newHashSet(new AsinColor("ASIN1", "")), Sets.newHashSet(new AsinColor("ASIN1", ""), new AsinColor("ASIN2", ""), new AsinColor("ASIN3", "")), new DateTime());
        Assert.assertTrue(resultSet.size() == 1);
        Assert.assertTrue("ASIN2".equals(resultSet.iterator().next().getParentAsin()));
        Assert.assertTrue(resultSet.get(0) instanceof PromotionOutputDetail);
        Long id = resultSet.iterator().next().getId();
        CalenderEvaluationOutput output1 = dao.findById(id);
        Assert.assertTrue(output1.getParentAsin().equals("ASIN2"));
        Assert.assertTrue(output1 instanceof PromotionOutputDetail);
        Assert.assertTrue(((PromotionOutputDetail) output1).getPromotionInfos().size() == 0);
        data2.setParentAsin("Parent1");
        dao.save(data2);
        
        resultSet = dao.findActiveActionHistoryByParent(1l, 1l, Sets.newHashSet(new AsinColor("ASIN2", "")), Sets.newHashSet(new AsinColor("ASIN1", "")), new DateTime());
        Assert.assertTrue(1 == resultSet.size());
        Assert.assertEquals("Parent1", resultSet.iterator().next().getParentAsin());   
        
        resultSet = dao.findActiveActionHistoryByParent(1l, 1l, Sets.newHashSet(new AsinColor("ASIN7", "")), Sets.newHashSet(new AsinColor("ASIN6", "")), new DateTime());
        Assert.assertTrue(0 == resultSet.size());
        
        resultSet = dao.findActiveActionHistoryByParent(1l, 1l, Sets.newHashSet(new AsinColor("ASIN7", "red")), Sets.newHashSet(new AsinColor("ASIN6", "red")), new DateTime());
        Assert.assertTrue(1 == resultSet.size());
        Assert.assertEquals("ASIN6", resultSet.iterator().next().getParentAsin());   
  
   }
    
    
    @Test
    public void testFindMultiFloorActiveMarkdown() throws OihPersistenceException{
        CalenderEvaluationOutput data1 = new CalenderEvaluationOutput();
        data1.setAsin("ASIN1");
        data1.setParentAsin("ASIN1");
        data1.setPriceDiscount("70");
        data1.setMarketplaceId(1l);
        data1.setMerchantId(1l);
        data1.setEndDate(new DateTime().plusDays(100).toDate());
        data1.setMarkdownType(MarkdownType.CADENCE);
        data1.setStatusCode(StatusCode.SUCCESS);
        data1.setFloorDiscount(MultipleFloorMarkdownAction.MULTI_FLOOR);
        data1.setMessage("initMsg");
        data1.addMessage("appendMsg");
        data1.setStage("a");
        data1.setActionId(1l);
           
        CalenderEvaluationOutput data2 = new CalenderEvaluationOutput();
        data2.setAsin("ASIN2");
        data2.setParentAsin("ASIN2");
        data2.setPriceDiscount("80");
        data2.setMarketplaceId(1l);
        data2.setMerchantId(1l);
        data2.setEndDate(new DateTime().plusDays(200).toDate());
        data2.setMarkdownType(MarkdownType.CADENCE);
        data2.setStatusCode(StatusCode.SUCCESS);
        data2.setFloorDiscount("VENDOR_COST*0.7");
        data2.setStage("b");
           
        CalenderEvaluationOutput data3 = new CalenderEvaluationOutput();
        data3.setAsin("ASIN3");
        data3.setParentAsin("ASIN3");
        data3.setPriceDiscount("90");
        data3.setMarketplaceId(1l);
        data3.setMerchantId(1l);
        data3.setEndDate(new DateTime().plusDays(200).toDate());
        data3.setMarkdownType(MarkdownType.CADENCE);
        data3.setFloorDiscount(null);
        data3.setStatusCode(StatusCode.CBM_ATTRIBUTES_ERROR);
        data3.setStage("c");
        
        CalenderEvaluationOutput data4 = new CalenderEvaluationOutput();
        data4.setAsin("ASIN4");
        data4.setParentAsin("ASIN4");
        data4.setPriceDiscount("90");
        data4.setMarketplaceId(1l);
        data4.setMerchantId(1l);
        data4.setEndDate(new DateTime().plusDays(200).toDate());
        data4.setMarkdownType(MarkdownType.CADENCE);
        data4.setStatusCode(StatusCode.CBM_ATTRIBUTES_ERROR);
        data4.setStage(Stage.UNKNOW_MISSING_INPUT);
        data4.setFloorDiscount(null);
         
        CalenderEvaluationOutput data5 = new CalenderEvaluationOutput();
        data5.setAsin("ASIN5");
        data5.setParentAsin("ASIN5");
        data5.setPriceDiscount("70");
        data5.setMarketplaceId(1l);
        data5.setMerchantId(1l);
        data5.setEndDate(new DateTime().minusDays(10).toDate());
        data5.setMarkdownType(MarkdownType.CADENCE);
        data5.setStatusCode(StatusCode.SUCCESS);
        data5.setFloorDiscount(MultipleFloorMarkdownAction.MULTI_FLOOR);
        data5.setMessage("initMsg");
        data5.addMessage("appendMsg");
        data5.setStage("a");
        data5.setActionId(1l);
       
        
        CalenderEvaluationOutput data6 = new CalenderEvaluationOutput();
        data6.setAsin("ASIN6");
        data6.setParentAsin("ASIN6");
        data6.setPriceDiscount("70");
        data6.setMarketplaceId(1l);
        data6.setMerchantId(1l);
        data6.setEndDate(new DateTime().plusDays(100).toDate());
        data6.setMarkdownType(MarkdownType.CADENCE);
        data6.setStatusCode(StatusCode.SUBMITTING);
        data6.setFloorDiscount(MultipleFloorMarkdownAction.MULTI_FLOOR);
        data6.setMessage("initMsg");
        data6.addMessage("appendMsg");
        data6.setStage("a");
        data6.setActionId(144l);
        
        dao.save(data1);
        dao.save(data2);
        dao.save(data3);
        dao.save(data4);
        dao.save(data5);
        dao.save(data6);
        
        CalenderEvaluationOutput result = dao.findMultiFloorActiveMarkdown(1l, "ASIN1");
        Assert.assertTrue(result.getActionId() == 1);
        result = dao.findMultiFloorActiveMarkdown(1l, "ASIN2");
        Assert.assertEquals(result, null); 
        result = dao.findMultiFloorActiveMarkdown(1l, "ASIN3");
        Assert.assertEquals(result, null); 
        result = dao.findMultiFloorActiveMarkdown(1l, "ASIN4");
        Assert.assertEquals(result, null);    
        result = dao.findMultiFloorActiveMarkdown(1l, "ASIN5");
        Assert.assertEquals(result, null);  
        result = dao.findMultiFloorActiveMarkdown(1l, "ASIN6");
        Assert.assertTrue(144l == result.getActionId()); 
   }
 
    @Test
    public void testFindOverrideAction() throws OihPersistenceException{
        CalenderEvaluationOutput data1 = new CalenderEvaluationOutput();
        data1.setAsin("ASIN1a");
        data1.setParentAsin("ASIN1");
        data1.setPriceDiscount("70");
        data1.setMarketplaceId(1l);
        data1.setMerchantId(1l);
        data1.setEndDate(new DateTime().plusDays(100).toDate());
        data1.setMarkdownType(MarkdownType.CADENCE);
        data1.setStatusCode(StatusCode.SUCCESS);
        data1.setFloorDiscount(MultipleFloorMarkdownAction.MULTI_FLOOR);
        data1.setMessage("initMsg");
        data1.addMessage("appendMsg");
        data1.setActionId(1l);
        data1.setStage(Stage.LIQUIDATE_STAGE);

        CalenderEvaluationOutput data2 = new CalenderEvaluationOutput();
        data2.setAsin("ASIN1b");
        data2.setParentAsin("ASIN1");
        data2.setPriceDiscount("80");
        data2.setMarketplaceId(1l);
        data2.setMerchantId(1l);
        data2.setEndDate(new DateTime().plusDays(200).toDate());
        data2.setMarkdownType(MarkdownType.CADENCE);
        data2.setStatusCode(StatusCode.SUCCESS);
        data2.setFloorDiscount("VENDOR_COST*0.7");
        data2.setStage(Stage.OVERRIDE_ACTION);

        CalenderEvaluationOutput data3 = new CalenderEvaluationOutput();
        data3.setAsin("ASIN1c");
        data3.setParentAsin("ASIN1");
        data3.setPriceDiscount("90");
        data3.setMarketplaceId(1l);
        data3.setMerchantId(1l);
        data3.setEndDate(new DateTime().plusDays(200).toDate());
        data3.setMarkdownType(MarkdownType.CADENCE);
        data3.setFloorDiscount(null);
        data3.setStatusCode(StatusCode.CBM_ATTRIBUTES_ERROR);
        data3.setStage(Stage.OVERRIDE_ACTION);
        

        dao.save(data1);
        dao.save(data2);
        dao.save(data3);

        CalenderEvaluationOutput result = dao.findOverrideAction(1l, "ASIN1", "");
        Assert.assertEquals(result.getAsin(), "ASIN1b");
    }
    
    @Test
    public void testFindCBMAsins() throws OihPersistenceException{
        CalenderEvaluationOutput data1 = new CalenderEvaluationOutput();
        data1.setAsin("ASIN1a");
        data1.setParentAsin("ASIN1");
        data1.setPriceDiscount("70");
        data1.setMarketplaceId(1l);
        data1.setMerchantId(1l);
        data1.setEndDate(new DateTime().plusDays(100).toDate());
        data1.setMarkdownType(MarkdownType.CADENCE);
        data1.setStatusCode(StatusCode.NON_CBM);
        data1.setFloorDiscount(MultipleFloorMarkdownAction.MULTI_FLOOR);
        data1.setMessage("initMsg");
        data1.addMessage("appendMsg");
        data1.setActionId(1l);
        data1.setCreateDate(new Date());
        data1.setStage(Stage.LIQUIDATE_STAGE);

        CalenderEvaluationOutput data2 = new CalenderEvaluationOutput();
        data2.setAsin("ASIN1b");
        data2.setParentAsin("ASIN2");
        data2.setPriceDiscount("80");
        data2.setMarketplaceId(1l);
        data2.setMerchantId(1l);
        data2.setEndDate(new DateTime().plusDays(200).toDate());
        data2.setMarkdownType(MarkdownType.CADENCE);
        data2.setStatusCode(StatusCode.SUCCESS);
        data2.setFloorDiscount("VENDOR_COST*0.7");
        data2.setCreateDate(new Date());
        data2.setStage(Stage.OVERRIDE_ACTION);

        CalenderEvaluationOutput data3 = new CalenderEvaluationOutput();
        data3.setAsin("ASIN1c");
        data3.setParentAsin("ASIN3");
        data3.setPriceDiscount("90");
        data3.setMarketplaceId(1l);
        data3.setMerchantId(1l);
        data3.setEndDate(new DateTime().plusDays(200).toDate());
        data3.setMarkdownType(MarkdownType.CADENCE);
        data3.setFloorDiscount(null);
        data3.setStatusCode(StatusCode.NON_CBM);
        data3.setCreateDate(new Date());
        data3.setStage(Stage.OVERRIDE_ACTION);
        
        CalenderEvaluationOutput data4 = new CalenderEvaluationOutput();
        data4.setAsin("ASIN1d");
        data4.setParentAsin("ASIN4");
        data4.setPriceDiscount("90");
        data4.setMarketplaceId(1l);
        data4.setMerchantId(1l);
        data4.setEndDate(new DateTime().plusDays(200).toDate());
        data4.setMarkdownType(MarkdownType.CADENCE);
        data4.setFloorDiscount(null);
        data4.setStatusCode(StatusCode.SUCCESS);
        data4.setCreateDate(new Date());
        data4.setStage(Stage.UNKNOW_MISSING_INPUT);
        
        dao.save(data1);
        dao.save(data2);
        dao.save(data3);
        dao.save(data4);

        Map<String, String> resultSet  = dao.findCBMAsinStages(1l, Sets.newHashSet("ASIN1", "ASIN2", "ASIN3","ASIN4"));
        Assert.assertEquals(resultSet.size(), 1);
        Assert.assertTrue(resultSet.containsKey("ASIN2"));
        Assert.assertTrue(resultSet.get("ASIN2").equals(Stage.OVERRIDE_ACTION));
    }
 
    @Test
    public void testGetCBMASINSet() throws OihPersistenceException{
        CalenderEvaluationOutput data1 = new CalenderEvaluationOutput();
        data1.setAsin("ASIN1a");
        data1.setParentAsin("ASIN1");
        data1.setPriceDiscount("70");
        data1.setMarketplaceId(1l);
        data1.setMerchantId(1l);
        data1.setEndDate(new DateTime().plusDays(100).toDate());
        data1.setMarkdownType(MarkdownType.CADENCE);
        data1.setStatusCode(StatusCode.NON_CBM);
        data1.setFloorDiscount(MultipleFloorMarkdownAction.MULTI_FLOOR);
        data1.setMessage("initMsg");
        data1.addMessage("appendMsg");
        data1.setActionId(1l);
        data1.setStage(Stage.LIQUIDATE_STAGE);

        CalenderEvaluationOutput data2 = new CalenderEvaluationOutput();
        data2.setAsin("ASIN1b");
        data2.setParentAsin("ASIN2");
        data2.setPriceDiscount("80");
        data2.setMarketplaceId(1l);
        data2.setMerchantId(1l);
        data2.setEndDate(new DateTime().plusDays(200).toDate());
        data2.setMarkdownType(MarkdownType.CADENCE);
        data2.setStatusCode(StatusCode.SUCCESS);
        data2.setFloorDiscount("VENDOR_COST*0.7");
        data2.setCreateDate(new DateTime().minusDays(20).toDate());
        data2.setStage(Stage.OVERRIDE_ACTION);
        
        CalenderEvaluationOutput data4 = new CalenderEvaluationOutput();
        data4.setAsin("ASIN1b");
        data4.setParentAsin("ASIN2");
        data4.setPriceDiscount("80");
        data4.setMarketplaceId(1l);
        data4.setMerchantId(1l);
        data4.setEndDate(new DateTime().plusDays(200).toDate());
        data4.setMarkdownType(MarkdownType.CADENCE);
        data4.setStatusCode(StatusCode.NON_CBM);
        data4.setFloorDiscount("VENDOR_COST*0.7");
        data4.setCreateDate(new DateTime().minusDays(40).toDate());
        data4.setStage(Stage.OVERRIDE_ACTION);

        CalenderEvaluationOutput data3 = new CalenderEvaluationOutput();
        data3.setAsin("ASIN1c");
        data3.setParentAsin("ASIN3");
        data3.setPriceDiscount("90");
        data3.setMarketplaceId(1l);
        data3.setMerchantId(1l);
        data3.setEndDate(new DateTime().plusDays(200).toDate());
        data3.setMarkdownType(MarkdownType.CADENCE);
        data3.setFloorDiscount(null);
        data3.setStatusCode(StatusCode.NON_CBM);
        data3.setStage(Stage.OVERRIDE_ACTION);

        Map<String, String> resultSet  = dao.getCBMASINSet(Lists.newArrayList(data1, data2, data3, data4));
        Assert.assertEquals(resultSet.size(), 3);

        Assert.assertTrue(resultSet.containsKey("ASIN1"));
        Assert.assertTrue(resultSet.get("ASIN1").equals(Stage.LIQUIDATE_STAGE));
        
        Assert.assertTrue(resultSet.containsKey("ASIN2"));
        Assert.assertTrue(resultSet.get("ASIN2").equals(Stage.OVERRIDE_ACTION));
        
        Assert.assertTrue(resultSet.containsKey("ASIN3"));
        Assert.assertTrue(resultSet.get("ASIN3").equals(Stage.OVERRIDE_ACTION));
        
        
        data4.setCreateDate(new DateTime().minusDays(10).toDate());
        resultSet  = dao.getCBMASINSet(Lists.newArrayList(data1, data2, data3, data4));
        Assert.assertEquals(resultSet.size(), 3);
    }
}
