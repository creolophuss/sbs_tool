package com.amazon.oih.cbm;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Map;

import org.junit.Assert;
import org.junit.Test;

import com.amazon.oih.cbm.model.NonReissueAsin;
import com.amazon.oih.dao.exception.OihPersistenceException;
import com.amazon.oih.utils.DaoUtil;
import com.google.common.collect.Lists;

public class ReissueAsinWhiteListDaoTest {
    @SuppressWarnings("rawtypes")
    ReissueAsinWhiteListDao dao = new ReissueAsinWhiteListDao(DaoUtil.getAnnotationSessionFactory(
            Arrays.asList((Class) NonReissueAsin.class)));
    
    @Test
    public void testGetReissueAsinWhiteListStatus() throws OihPersistenceException {
        ArrayList<NonReissueAsin> reissueAsins = Lists.newArrayList(new NonReissueAsin("A1"), new NonReissueAsin("A3"), new NonReissueAsin("A5"));
        dao.save(reissueAsins);
        Map<String, Boolean> result = dao.getReissueAsinWhiteListStatus(new HashSet<String>(Arrays.asList(new String [] {"A1", "A2", "A3", "A4", "A5", "A6"})));
        Assert.assertTrue(result.get("A1"));
        Assert.assertTrue(result.get("A3"));
        Assert.assertTrue(result.get("A5"));
        Assert.assertFalse(result.get("A2"));
        Assert.assertFalse(result.get("A4"));
        Assert.assertFalse(result.get("A6"));
    }
}
