package com.amazon.oih.cbm;

import org.junit.Assert;
import org.junit.Test;

import com.amazon.oih.cbm.model.MarkdownFloor;

public class MarkdownFloorTest {
    @Test
    public void testIsActive(){
        MarkdownFloor floor = new MarkdownFloor(MarkdownFloor.END, "VENDOR_COST:4");
        Assert.assertTrue(floor.isActive(2000));
        Assert.assertTrue(floor.isActive(4400));
        floor = new MarkdownFloor("0410:1", "VENDOR_COST:4");
        Assert.assertTrue(!floor.isActive(2012));
        Assert.assertTrue(floor.isActive(4000));
    }
    
    @Test 
    public void testActiveAfter(){
        MarkdownFloor floor1 = new MarkdownFloor(MarkdownFloor.END, "VENDOR_COST:4");
        MarkdownFloor floor2 = new MarkdownFloor("0410:1", "VENDOR_COST:4");
        MarkdownFloor floor3 = new MarkdownFloor("0110:2", "VENDOR_COST:4");
        MarkdownFloor floor4 = new MarkdownFloor("0110:1", "VENDOR_COST:4");
        Assert.assertTrue(floor1.activeAfter(floor2));
        Assert.assertTrue(floor1.activeAfter(floor3));
        Assert.assertTrue(floor1.activeAfter(floor4));
        Assert.assertTrue(!floor2.activeAfter(floor3));
        Assert.assertTrue(floor2.activeAfter(floor4));
        Assert.assertTrue(floor3.activeAfter(floor4));       
    }
}
