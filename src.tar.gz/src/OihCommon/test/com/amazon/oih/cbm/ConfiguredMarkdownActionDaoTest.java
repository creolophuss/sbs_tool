package com.amazon.oih.cbm;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.junit.Assert;
import org.junit.Test;

import com.amazon.oih.cbm.ConfiguredMarkdownActionDao;
import com.amazon.oih.cbm.model.ActionMultiKey;
import com.amazon.oih.cbm.model.CalenderEvaluationInput;
import com.amazon.oih.cbm.model.CalenderEvaluationOutput;
import com.amazon.oih.cbm.model.ConfiguredMarkdownAction;
import com.amazon.oih.cbm.model.LifecycleDemandType;
import com.amazon.oih.cbm.model.MarkdownFloor;
import com.amazon.oih.cbm.model.MarkdownType;
import com.amazon.oih.cbm.model.MarketplaceMerchant;
import com.amazon.oih.cbm.model.MultipleFloorMarkdownAction;
import com.amazon.oih.cbm.model.ActionMultiKey.ActionKeyName;
import com.amazon.oih.cbm.util.MockBaseDateCalculator;
import com.amazon.oih.dao.exception.OihPersistenceException;

import static com.amazon.oih.cbm.util.ConfiguredPriceUtil.PriceType.*;

import com.amazon.oih.utils.DaoUtil;


public class ConfiguredMarkdownActionDaoTest {
    @SuppressWarnings("rawtypes")
    private ConfiguredMarkdownActionDao dao = new ConfiguredMarkdownActionDao(DaoUtil.getAnnotationSessionFactory(
            Arrays.asList((Class) CalenderEvaluationOutput.class, (Class) ConfiguredMarkdownAction.class, (Class) MultipleFloorMarkdownAction.class)), null);
    private final DateTimeFormatter DATE_FORMATTER = DateTimeFormat.forPattern("yyyyMMdd");
    private final SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
    
    @Test
    public void testSaveLoadAll() throws OihPersistenceException{
        ConfiguredMarkdownAction action1 = new ConfiguredMarkdownAction();
        action1.setActionType(MarkdownType.CADENCE);
        action1.setCategory(309000l);
        action1.setSubcategory(309444444l);
        action1.setStartDate("SEASON_START:4");
        action1.setEndDate("0404:10");
        action1.setMarketplaceId(1l);
        action1.setGl(309);
        
        ConfiguredMarkdownAction action2 = new ConfiguredMarkdownAction();
        action2.setActionType(MarkdownType.CADENCE);
        action2.setCategory(197000l);
        action2.setSubcategory(197444444l);
        action2.setStartDate("FULL_PRICE_END:1");
        action2.setEndDate("LIQUIDATE_DATE:0");
        action2.setMarketplaceId(1l);
        action2.setGl(309);
       
        dao.save(Arrays.asList(action1, action2));
        
        List<ConfiguredMarkdownAction> actions = dao.loadAll();
        Assert.assertTrue(actions.size() == 2);
        
        CalenderEvaluationInput input = new CalenderEvaluationInput(null, null, null);
        input.setSeasonStartYear(null);
        Date date = action1.getActionEndDate(input);
        //due to model year is null.
        Assert.assertNull(date);
        
        
        input.setSeasonStartYear(2008);
        action1 = new ConfiguredMarkdownAction();
        action1.setActionType(MarkdownType.CADENCE);
        action1.setCategory(309000l);
        action1.setSubcategory(309444444l);
        action1.setStartDate("SEASON_START:4");
        action1.setEndDate("0404:10");
        action1.setMarketplaceId(1l);
        action1.setGl(309);
        date = action1.getActionStartDate(input);
        //due to SEASON_START is null in input
        Assert.assertNull(date);
        
        input.setSeasonStartDate(DATE_FORMATTER.parseDateTime("20080104"));
        input.setCoordinateDate(input.getSeasonStartDate());
        action1 = new ConfiguredMarkdownAction();
        action1.setActionType(MarkdownType.CADENCE);
        action1.setCategory(309000l);
        action1.setSubcategory(309444444l);
        action1.setStartDate("SEASON_START:4");
        action1.setEndDate("0404:10");
        action1.setMarketplaceId(1l);
        action1.setGl(309);
        //2008 + 10 : 04-04    
        date = action1.getActionEndDate(input);
        Assert.assertEquals("2018-04-04", format.format(date));
        input.setSeasonStartDate(DATE_FORMATTER.parseDateTime("20080504"));
        input.setCoordinateDate(input.getSeasonStartDate());
        //2009 + 10 +1 :04-04
        date = action1.getActionEndDate(input);
        Assert.assertEquals("2019-04-04", format.format(date));
        
        // seasonStart, 
        input = new CalenderEvaluationInput("0430", "1030", "0130");
        input.setSeasonStartYear(2000);
        input.calculateAndSetCBMDates(new MockBaseDateCalculator());
        action1 = new ConfiguredMarkdownAction();
        action1.setActionType(MarkdownType.CADENCE);
        action1.setCategory(309000l);
        action1.setSubcategory(309444444l);
        action1.setStartDate("SEASON_START:4");
        action1.setEndDate("0404:10");
        action1.setMarketplaceId(1l);
        action1.setGl(309);
        date = action1.getActionStartDate(input);

        //1000 + 4 : 04-30
        Assert.assertEquals("2004-04-30", format.format(date));
        date = action1.getActionEndDate(input);
        //1000 + 11 : 04-04
        Assert.assertEquals("2011-04-04", format.format(date));
        date = action2.getActionStartDate(input);
        //1000+1 : 10-30
        Assert.assertEquals("2001-10-30", format.format(date));
        date = action2.getActionEndDate(input);
        //1000 + 1 : 01-30
        Assert.assertEquals("2001-01-30", format.format(date));
    }
    
    @Test
    public void testGetValidConfiguredMarkdownAction() throws OihPersistenceException{
        ConfiguredMarkdownAction action1 = new ConfiguredMarkdownAction();
        action1.setActionType(MarkdownType.CADENCE);
        action1.setCategory(309000l);
        action1.setSubcategory(309444444l);
        action1.setStartDate("0101:3000");
        action1.setEndDate("0101:4000");
        action1.setMarketplaceId(1l);
        action1.setPriceDiscount("LIST_PRICE_BASED*0.3");       
        action1.setGl(309);
        
        ConfiguredMarkdownAction action2 = new ConfiguredMarkdownAction();
        action2.setActionType(MarkdownType.PROMOTION);
        action2.setCategory(197000l);
        action2.setSubcategory(197444444l);
        action2.setStartDate("0101:0");
        action2.setEndDate("0101:6000");
        action2.setMarketplaceId(1l);
        action2.setPriceDiscount("VENDOR_COST_BASED*0.2");
        action2.setGl(309);
        
        ConfiguredMarkdownAction action3 = new ConfiguredMarkdownAction();
        action3.setActionType(MarkdownType.PROMOTION);
        action3.setCategory(309000l);
        action3.setSubcategory(309444444l);
        action3.setStartDate("0101:0");
        action3.setEndDate("0101:5000");
        action3.setMarketplaceId(1l);
        action3.setGl(309);
        action3.setPriceDiscount("LIST_PRICE_BASED*0.1");
       
        dao = new ConfiguredMarkdownActionDao(DaoUtil.getAnnotationSessionFactory(
                Arrays.asList((Class) CalenderEvaluationOutput.class, (Class) ConfiguredMarkdownAction.class)), 
                Arrays.asList(action1, action2, action3));
        CalenderEvaluationInput input = new CalenderEvaluationInput(null, null, null);
        input.setSeasonStartDate(DATE_FORMATTER.parseDateTime("20000504"));
        input.setSeasonStartYear(2000);
        input.setCoordinateDate(input.getSeasonStartDate());
        input.setListPrice(new BigDecimal(100));
        input.setVendorCost(new BigDecimal(200));
        input.setMarketplaceMerchant(new MarketplaceMerchant(1l, 1l));
        input.setGl(309);
        input.setCategory(309000l);
        input.setSubCategory(309444444l);

        ConfiguredMarkdownAction action = dao.getValidConfiguredMarkdownAction(input);
        Assert.assertTrue(action.getSubcategory() == 309444444l);

        input.setSubCategory(null);
        action = dao.getValidConfiguredMarkdownAction(input);
        Assert.assertTrue(action == null);
        input.setSubCategory(197444444l);
        action = dao.getValidConfiguredMarkdownAction(input);
        Assert.assertTrue(action == null);
        
        //testing getPrice and getPriceFloor
        BigDecimal price = action3.getPrice(input.getPriceBases());
        Assert.assertEquals(Math.round(price.doubleValue()), 10);
        price = action2.getPrice(input.getPriceBases());
        Assert.assertEquals(Math.round(price.doubleValue()), 40);
        price = action1.getPrice(input.getPriceBases());
        Assert.assertEquals(Math.round(price.doubleValue()), 30);
        price = action1.getFloorPrice(input.getPriceBases());
        Assert.assertEquals(price, null);
    }
    
    @Test
    public void testSeasonStartBasedDaySetting(){
        ConfiguredMarkdownAction action1 = new ConfiguredMarkdownAction();
        action1.setStartDate("SEASON_START_BASED_DAYS:1");
        action1.setEndDate("SEASON_START_BASED_DAYS:10");    

        CalenderEvaluationInput input = new CalenderEvaluationInput(null, null, null);
        input.setSeasonStartYear(2000);
        input.setSeasonStartDate(DATE_FORMATTER.parseDateTime("20000101"));

        Assert.assertEquals("2000-01-02", format.format(action1.getActionStartDate(input)));
        Assert.assertEquals("2000-01-11", format.format(action1.getActionEndDate(input)));
    }
    
    @Test
    public void testSaveLoadAllWithMultiFloor() throws OihPersistenceException{
        MultipleFloorMarkdownAction action1 = new MultipleFloorMarkdownAction();
        action1.setActionType(MarkdownType.CADENCE);
        action1.setCategory(209000l);
        action1.setSubcategory(209444444l);
        action1.setStartDate("SEASON_START:4");
        action1.setEndDate("04-04:10");
        action1.setMarketplaceId(1l);
        action1.setGl(209);
        
        ConfiguredMarkdownAction action2 = new ConfiguredMarkdownAction();
        action2.setActionType(MarkdownType.CADENCE);
        action2.setCategory(197000l);
        action2.setSubcategory(197444444l);
        action2.setStartDate("FULL_PRICE_END:1");
        action2.setPriceFloorDiscount(VENDOR_COST_BASED.getFormatString(new BigDecimal(100)));
        action2.setEndDate("LIQUIDATE_DATE:0");
        action2.setMarketplaceId(1l);
        action2.setGl(309);
        
        MultipleFloorMarkdownAction action3 = new MultipleFloorMarkdownAction();
        action3.setActionType(MarkdownType.CADENCE);
        action3.setCategory(309000l);
        action3.setSubcategory(309444444l);
        action3.setStartDate("SEASON_START:4");
        action3.setEndDate("04-04:10");
        action3.setMarketplaceId(1l);
        action3.setGl(309);
        Set<MarkdownFloor> markdownFloors = new HashSet<MarkdownFloor>();
        MarkdownFloor floor1 = new MarkdownFloor("date1", "price1");
        MarkdownFloor floor2 = new MarkdownFloor("date2", "price2");
        MarkdownFloor floor3 = new MarkdownFloor("date3", "price3");
        markdownFloors.add(floor1);
        markdownFloors.add(floor2);
        markdownFloors.add(floor3);
        action3.setMarkdownFloors(markdownFloors);
        
        dao.save(Arrays.asList(action1, action2, action3));
        List<String> dates = Arrays.asList("date1", "date2", "date3");
        List<String> prices = Arrays.asList("price1", "price2", "price3");
        List<ConfiguredMarkdownAction> actions = dao.loadAll();
        Assert.assertTrue(actions.size() == 3);
        for (ConfiguredMarkdownAction action : actions){
            if (action instanceof MultipleFloorMarkdownAction){
                MultipleFloorMarkdownAction multiFloorAction = (MultipleFloorMarkdownAction) action;
                if (action.getGl() == 209){
                    Assert.assertTrue(multiFloorAction.getMarkdownFloors().size() == 0);
                } else {
                    Assert.assertEquals(multiFloorAction.getMarkdownFloors().size(), 3); 
                    for (MarkdownFloor floorP : multiFloorAction.getMarkdownFloors()){
                        Assert.assertTrue(dates.contains(floorP.getEndDate()));
                        Assert.assertTrue(prices.contains(floorP.getPriceFloor()));
                    }
                }
            }
        }
    }
    
    @Test
    public void testSaveLoadAllWithAdditionalKey() throws OihPersistenceException{
        MultipleFloorMarkdownAction action1 = new MultipleFloorMarkdownAction();
        action1.setActionType(MarkdownType.CADENCE);
        action1.setCategory(209000l);
        action1.setSubcategory(209444444l);
        action1.setStartDate("SEASON_START:4");
        action1.setEndDate("04-04:10");
        action1.setMarketplaceId(1l);
        action1.setGl(209);
        
        ConfiguredMarkdownAction action2 = new ConfiguredMarkdownAction();
        action2.setActionType(MarkdownType.CADENCE);
        action2.setCategory(197000l);
        action2.setSubcategory(197444444l);
        action2.setStartDate("FULL_PRICE_END:1");
        action2.setPriceFloorDiscount(VENDOR_COST_BASED.getFormatString(new BigDecimal(100)));
        action2.setEndDate("LIQUIDATE_DATE:0");
        action2.setMarketplaceId(1l);
        action2.setGl(309);
        Map<String, String> keyMap = new HashMap<String, String>();
        keyMap.put("keyName1", "keyValue1");
        keyMap.put("keyName2", "keyValue2");
        action2.setAdditionalKey(keyMap);
        
        MultipleFloorMarkdownAction action3 = new MultipleFloorMarkdownAction();
        action3.setActionType(MarkdownType.CADENCE);
        action3.setCategory(309000l);
        action3.setSubcategory(309444444l);
        action3.setStartDate("SEASON_START:4");
        action3.setEndDate("04-04:10");
        action3.setMarketplaceId(1l);
        action3.setGl(309);
        Set<MarkdownFloor> markdownFloors = new HashSet<MarkdownFloor>();
        MarkdownFloor floor1 = new MarkdownFloor("date1", "price1");
        MarkdownFloor floor2 = new MarkdownFloor("date2", "price2");
        MarkdownFloor floor3 = new MarkdownFloor("date3", "price3");
        markdownFloors.add(floor1);
        markdownFloors.add(floor2);
        markdownFloors.add(floor3);
        action3.setMarkdownFloors(markdownFloors);
        keyMap = new HashMap<String, String>();
        keyMap.put("keyName3", "keyValue3");
        keyMap.put("keyName4", "keyValue4");
        action3.setAdditionalKey(keyMap);
        
        dao.save(Arrays.asList(action1, action2, action3));
        List<String> dates = Arrays.asList("date1", "date2", "date3");
        List<String> prices = Arrays.asList("price1", "price2", "price3");
        List<String> keyName12 = Arrays.asList("keyName1", "keyName2");
        List<String> keyValue12 = Arrays.asList("keyValue1", "keyValue2");
        List<String> keyName34 = Arrays.asList("keyName3", "keyName4");
        List<String> keyValue34 = Arrays.asList("keyValue3", "keyValue4");
        List<ConfiguredMarkdownAction> actions = dao.loadAll();
        Assert.assertTrue(actions.size() == 3);
        for (ConfiguredMarkdownAction action : actions){
            if (action instanceof MultipleFloorMarkdownAction){
                MultipleFloorMarkdownAction multiFloorAction = (MultipleFloorMarkdownAction) action;
                if (action.getGl() == 209){
                    Assert.assertTrue(multiFloorAction.getMarkdownFloors().size() == 0);
                    Assert.assertEquals(multiFloorAction.getAdditionalKey().size(), 0);       
                } else {
                    Assert.assertEquals(multiFloorAction.getMarkdownFloors().size(), 3);                    
                    for (MarkdownFloor floorP : multiFloorAction.getMarkdownFloors()){
                        Assert.assertTrue(dates.contains(floorP.getEndDate()));
                        Assert.assertTrue(prices.contains(floorP.getPriceFloor()));
                    }
                    Assert.assertEquals(multiFloorAction.getAdditionalKey().size(), 2);
                    Assert.assertTrue(multiFloorAction.getAdditionalKey().keySet().containsAll(keyName34));
                    Assert.assertTrue(keyName34.containsAll(multiFloorAction.getAdditionalKey().keySet()));
                    Assert.assertTrue(multiFloorAction.getAdditionalKey().values().containsAll(keyValue34));
                    Assert.assertTrue(keyValue34.containsAll(multiFloorAction.getAdditionalKey().values()));
                }
            } else {
                Assert.assertEquals(action.getAdditionalKey().size(), 2);
                Assert.assertTrue(action.getAdditionalKey().keySet().containsAll(keyName12));
                Assert.assertTrue(keyName12.containsAll(action.getAdditionalKey().keySet()));
                Assert.assertTrue(action.getAdditionalKey().values().containsAll(keyValue12));
                Assert.assertTrue(keyValue12.containsAll(action.getAdditionalKey().values()));
            }         
        }
    }
    
    @Test
    public void testGetConfiguredMarkdownActions() throws OihPersistenceException{
        ConfiguredMarkdownAction action1 = new ConfiguredMarkdownAction();
        action1.setActionType(MarkdownType.CADENCE);
        action1.setCategory(309000l);
        action1.setSubcategory(309444444l);
        action1.setStartDate("01-01:3000");
        action1.setEndDate("01-01:4000");
        action1.setMarketplaceId(1l);
        action1.setPriceDiscount("LIST_PRICE_BASED*0.3");       
        action1.setGl(309);
        
        ConfiguredMarkdownAction action2 = new ConfiguredMarkdownAction();
        action2.setActionType(MarkdownType.PROMOTION);
        action2.setCategory(197000l);
        action2.setSubcategory(197444444l);
        action2.setStartDate("01-01:0");
        action2.setEndDate("01-01:6000");
        action2.setMarketplaceId(1l);
        action2.setPriceDiscount("VENDOR_COST_BASED*0.2");
        action2.setGl(309);
        
        ConfiguredMarkdownAction action3 = new ConfiguredMarkdownAction();
        action3.setActionType(MarkdownType.PROMOTION);
        action3.setCategory(309000l);
        action3.setSubcategory(309444444l);
        action3.setStartDate("01-01:0");
        action3.setEndDate("01-01:5000");
        action3.setMarketplaceId(1l);
        action3.setGl(309);
        Map<String, String> additionalKey = new HashMap<String, String>();
        additionalKey.put(ActionKeyName.DEMAND_TYPE.name(), LifecycleDemandType.LIMITED_SEASONAL.name());
        additionalKey.put(ActionKeyName.BRAND_CODE.name(), "Jialei");
        action3.setAdditionalKey(additionalKey);
        action3.setPriceDiscount("LIST_PRICE_BASED*0.1");
        
        ConfiguredMarkdownAction action4 = new ConfiguredMarkdownAction();
        action4.setActionType(MarkdownType.PROMOTION);
        action4.setCategory(309000l);
        action4.setSubcategory(309444444l);
        action4.setStartDate("01-01:0");
        action4.setEndDate("01-01:5555");
        action4.setMarketplaceId(2l);       //dismatch
        action4.setGl(309);
        additionalKey = new HashMap<String, String>();
        additionalKey.put(ActionKeyName.DEMAND_TYPE.name(), LifecycleDemandType.LIMITED_SEASONAL.name());
        additionalKey.put(ActionKeyName.BRAND_CODE.name(), "Jialei");
        action4.setAdditionalKey(additionalKey);
        action4.setPriceDiscount("LIST_PRICE_BASED*0.1");
       
        ActionMultiKey key1 = new ActionMultiKey(action1);
        ActionMultiKey key2 = new ActionMultiKey(action2);
        ActionMultiKey key3 = new ActionMultiKey(action3);
        ActionMultiKey key4 = new ActionMultiKey(action4);
        
        dao = new ConfiguredMarkdownActionDao(DaoUtil.getAnnotationSessionFactory(
                Arrays.asList((Class) CalenderEvaluationOutput.class, (Class) ConfiguredMarkdownAction.class)), 
                Arrays.asList(action1, action2, action3, action4));
        CalenderEvaluationInput input = new CalenderEvaluationInput(null, null, null);
        input.setSeasonStartDate(DATE_FORMATTER.parseDateTime(new DateTime().getYear() + "0504"));
        input.setSeasonStartYear(2000);
        input.setListPrice(new BigDecimal(100));
        input.setVendorCost(new BigDecimal(200));
        input.setMarketplaceMerchant(new MarketplaceMerchant(1l, 1l));
        input.setGl(309);
        input.setCategory(309000l);
        input.setSubCategory(309444444l);
        List<ConfiguredMarkdownAction> actions = dao.getConfiguredMarkdownActions(input);
        Assert.assertTrue(actions.size() == 1);
        Assert.assertEquals("01-01:4000", actions.get(0).getEndDate());
 
        input.setSubCategory(null);
        actions = dao.getConfiguredMarkdownActions(input);
        Assert.assertTrue(actions.size() == 0);

        input.setSubCategory(197444444l);
        actions = dao.getConfiguredMarkdownActions(input);
        Assert.assertTrue(actions.size() == 0);

        input.setSubCategory(309444444l);
        input.setBrandCode("Jialei");
        input.setLifecycleDemandType(LifecycleDemandType.LIMITED_SEASONAL);
        actions = dao.getConfiguredMarkdownActions(input);
        Assert.assertTrue(actions.size() == 2);
        Assert.assertEquals("01-01:5000", actions.get(0).getEndDate());
        Assert.assertEquals("01-01:4000", actions.get(1).getEndDate());
        Assert.assertEquals(key1.getPriority(), new BigDecimal(11110));
        Assert.assertEquals(key2.getPriority(), new BigDecimal(11110));
        Assert.assertEquals(key3.getPriority(), new BigDecimal(1111110));
        Assert.assertEquals(key3.getPriority(), new BigDecimal(1111110));
    }
    
    @Test
    public void testFindById() throws OihPersistenceException{
        MultipleFloorMarkdownAction action1 = new MultipleFloorMarkdownAction();
        action1.setActionType(MarkdownType.CADENCE);
        action1.setCategory(209000l);
        action1.setSubcategory(209444444l);
        action1.setStartDate("SEASON_START:4");
        action1.setEndDate("04-04:10");
        action1.setMarketplaceId(1l);
        action1.setGl(209);
        
        ConfiguredMarkdownAction action2 = new ConfiguredMarkdownAction();
        action2.setActionType(MarkdownType.CADENCE);
        action2.setCategory(197000l);
        action2.setSubcategory(197444444l);
        action2.setStartDate("FULL_PRICE_END:1");
        action2.setPriceFloorDiscount(VENDOR_COST_BASED.getFormatString(new BigDecimal(100)));
        action2.setEndDate("LIQUIDATE_DATE:0");
        action2.setMarketplaceId(1l);
        action2.setGl(309);
        Map<String, String> keyMap = new HashMap<String, String>();
        keyMap.put("keyName1", "keyValue1");
        keyMap.put("keyName2", "keyValue2");
        action2.setAdditionalKey(keyMap);
        
        MultipleFloorMarkdownAction action3 = new MultipleFloorMarkdownAction();
        action3.setActionType(MarkdownType.CADENCE);
        action3.setCategory(309000l);
        action3.setSubcategory(309444444l);
        action3.setStartDate("SEASON_START:4");
        action3.setEndDate("04-04:10");
        action3.setMarketplaceId(1l);
        action3.setGl(309);
        Set<MarkdownFloor> markdownFloors = new HashSet<MarkdownFloor>();
        MarkdownFloor floor1 = new MarkdownFloor("date1", "price1");
        MarkdownFloor floor2 = new MarkdownFloor("date2", "price2");
        MarkdownFloor floor3 = new MarkdownFloor("date3", "price3");
        markdownFloors.add(floor1);
        markdownFloors.add(floor2);
        markdownFloors.add(floor3);
        action3.setMarkdownFloors(markdownFloors);
        keyMap = new HashMap<String, String>();
        keyMap.put("keyName3", "keyValue3");
        keyMap.put("keyName4", "keyValue4");
        action3.setAdditionalKey(keyMap);
        
        dao.save(Arrays.asList(action1, action2, action3));

        List<ConfiguredMarkdownAction> actions = dao.loadAll();
        for (ConfiguredMarkdownAction currentAction : actions){
            System.out.println(currentAction.getId());
            ConfiguredMarkdownAction action = dao.findById(currentAction.getId());
            if (action instanceof MultipleFloorMarkdownAction){
                Assert.assertEquals(((MultipleFloorMarkdownAction) action).getMarkdownFloors(), 
                        ((MultipleFloorMarkdownAction) currentAction).getMarkdownFloors());
            }
            Assert.assertEquals(action.getGl(), currentAction.getGl());
            Assert.assertEquals(action.getMarketplaceId(), currentAction.getMarketplaceId());
            Assert.assertEquals(action.getPriceDiscount(), currentAction.getPriceDiscount());
            Assert.assertEquals(action.getPriceFloorDiscount(), currentAction.getPriceFloorDiscount());
            Assert.assertEquals(action.getStartDate(), currentAction.getStartDate());
            Assert.assertEquals(action.getAdditionalKey(), currentAction.getAdditionalKey());
        }
    }
}
