package com.amazon.oih.cbm;

import java.math.BigDecimal;
import java.util.HashSet;
import java.util.Set;

import org.joda.time.DateTime;
import org.junit.Assert;
import org.junit.Test;

import com.amazon.oih.cbm.model.MarkdownFloor;
import com.amazon.oih.cbm.model.MarkdownPriceBase;
import com.amazon.oih.cbm.model.MultipleFloorMarkdownAction;

public class MultipleFloorMarkdownActionTest {
    MultipleFloorMarkdownAction action = new MultipleFloorMarkdownAction();
    Set<MarkdownFloor> floors = new HashSet<MarkdownFloor>();
    DateTime today = new DateTime();
    MarkdownFloor floor1 = new MarkdownFloor(MarkdownFloor.END, "VENDOR_COST_BASED:0.5");
    MarkdownFloor floor2 = new MarkdownFloor("1220:0", "VENDOR_COST_BASED:0.2");
    MarkdownFloor floor3 = new MarkdownFloor("1231:0", "VENDOR_COST_BASED:0.3");
    MarkdownFloor floor4 = new MarkdownFloor("0115:1", "VENDOR_COST_BASED:0.4");
    MarkdownPriceBase input = new MarkdownPriceBase();
    
    public  void initData(){
        action.setMarkdownFloors(floors);
        floors.add(floor1);
        floors.add(floor2);
        floors.add(floor3);
        floors.add(floor4);
        input.setVendorCost(new BigDecimal(100));
    }
    
    public MultipleFloorMarkdownActionTest(){
        initData();
    }
    @Test
    public void testGetCurrentFloorPrice1(){
        BigDecimal floor = action.getCurrentFloorPrice(input, today.getYear()+1);
        Assert.assertTrue(20==floor.intValue());
    }
    
    @Test
    public void testGetCurrentFloorPrice2(){
        BigDecimal floor = action.getCurrentFloorPrice(input, today.getYear() - 2); 
        Assert.assertTrue(50==floor.intValue());
    }
    
    @Test
    public void testGetCurrentFloorPriceNull(){
        action.setMarkdownFloors(null);
        BigDecimal floor = action.getCurrentFloorPrice(input, today.getYear() - 2); 
        Assert.assertTrue(floor == null);
    }
}
