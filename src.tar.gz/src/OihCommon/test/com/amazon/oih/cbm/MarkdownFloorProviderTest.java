package com.amazon.oih.cbm;

import static org.easymock.EasyMock.createMock;
import static org.easymock.EasyMock.expect;
import static org.easymock.EasyMock.replay;
import static org.junit.Assert.fail;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import junit.framework.Assert;

import oih.business.removals.config.ConfigType;
import oih.business.removals.config.OihConfig;
import oih.business.removals.config.OihConfigHibernateDAO;
import oih.config.ConfigFactory;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import testutils.BaseTestDaoSetup;
import testutils.HSQLDBUtils;

import amazon.platform.config.AppConfig;
import amazon.platform.logging.AppConfigLog4jConfigurator;

import com.amazon.oih.cbm.CalendarEvaluationOutputDao;
import com.amazon.oih.cbm.ConfiguredMarkdownActionDao;
import com.amazon.oih.cbm.MarkdownFloorProvider;
import com.amazon.oih.cbm.model.CalenderEvaluationOutput;
import com.amazon.oih.cbm.model.MarkdownPriceBase;
import com.amazon.oih.cbm.model.MultipleFloorMarkdownAction;
import com.amazon.oih.cbm.model.exception.MarkdowFloorProviderException;
import com.amazon.oih.dao.exception.OihPersistenceException;

public class MarkdownFloorProviderTest extends BaseTestDaoSetup{
    private ConfiguredMarkdownActionDao configuredActionDao;
    private CalendarEvaluationOutputDao evaluateOutputDao;
    private MultipleFloorMarkdownAction fakeAction;
    private MarkdownFloorProvider provider;
    @Rule
    public ExpectedException expectEx = ExpectedException.none();
    
    @BeforeClass
    public static void beforeClass(){
        Map<String, Object> map = new HashMap<String, Object>();
        Map<String, List<Map<String, String>>> cbmMap = new HashMap<String, List<Map<String, String>>>();
        List<Map<String, String>> detailMap = new ArrayList<Map<String, String>>();
        Map<String, String> glMap = new HashMap<String, String>();
        glMap.put("gl", "1");
        Map<String, String> categoryMap = new HashMap<String, String>();
        categoryMap.put("category", "1");
        Map<String, String> subcatMap = new HashMap<String, String>();
        subcatMap.put("subcategory", "1");
        detailMap.add(glMap); 
        detailMap.add(categoryMap); 
        detailMap.add(subcatMap); 
        cbmMap.put("1", detailMap);
        map.put("CBM.ActionScope", cbmMap);
        ConfigFactory.useConfigFrom("test", "USAmazon", map);
    }
    
    @Before
    public void setUp(){
    	if (!AppConfig.isInitialized()) {
			String[] args = new String[] { "--root", "/tmp", "--domain",
					"--test", "--realm", "USAmazon" };
			AppConfigLog4jConfigurator.configureForBootstrap();
			AppConfig.initialize("OihMetrics", "Oih", args);
			AppConfigLog4jConfigurator.configureFromAppConfig();
		}
		
    	baseSetup();
    	
    	config.addResource( "oih/business/removals/config/OihConfig.hbm.xml" );
        sessionFactory = config.buildSessionFactory();
        
        
		OihConfigHibernateDAO dao = new OihConfigHibernateDAO();
		dao.setSessionFactory(sessionFactory);
		OihConfig oihconfig = new OihConfig();
		oihconfig.setGl(1);
		oihconfig.setOrg("USAmazon");
		oihconfig.setTag(ConfigType.CBM_ACTION_SCOPE);
		oihconfig.setValue("YES");
		dao.save(oihconfig);
		ConfigType.CBM_ACTION_SCOPE.setDao(dao);
    	
        configuredActionDao = createMock(ConfiguredMarkdownActionDao.class);
        evaluateOutputDao = createMock(CalendarEvaluationOutputDao.class);
        fakeAction = createMock(MultipleFloorMarkdownAction.class);

		
        provider = new MarkdownFloorProvider(configuredActionDao, evaluateOutputDao);
		
    }
    
    @Test
    public void testNoConfig() throws OihPersistenceException, MarkdowFloorProviderException{
        CalenderEvaluationOutput output = new CalenderEvaluationOutput();
        output.setActionId(1l);
        output.setSeasonStartYear(200);
        expect(evaluateOutputDao.findMultiFloorActiveMarkdown(1l, "ASIN1")).andReturn(output);
        expect(configuredActionDao.findById(1l)).andReturn(null);

        replay(evaluateOutputDao, configuredActionDao);
        expectEx.expect(MarkdowFloorProviderException.class);
        expectEx.expectMessage(MarkdowFloorProviderException.NO_CONFIG);
        provider.getCurrentlyFloor(1l, 1, "1", "1", "ASIN1", null);
    }
    
    @Test
    public void testInvalidHistory() throws OihPersistenceException, MarkdowFloorProviderException{
        CalenderEvaluationOutput output = new CalenderEvaluationOutput();
        expect(evaluateOutputDao.findMultiFloorActiveMarkdown(1l, "ASIN1")).andReturn(output);

        replay(evaluateOutputDao);
        expectEx.expect(MarkdowFloorProviderException.class);
        expectEx.expectMessage(MarkdowFloorProviderException.INVALID_HISTORY);
        provider.getCurrentlyFloor(1l, 1, "1", "1", "ASIN1", null);
    }
    
    @Test
    public void testExceptionWhenQueryMarkdownhistory() throws OihPersistenceException, MarkdowFloorProviderException{
        CalenderEvaluationOutput output = new CalenderEvaluationOutput();
        output.setActionId(1l);
        expect(evaluateOutputDao.findMultiFloorActiveMarkdown(1l, "ASIN1")).andThrow(new OihPersistenceException("test"));

        replay(evaluateOutputDao, configuredActionDao);
        expectEx.expect(MarkdowFloorProviderException.class);
        expectEx.expectMessage(MarkdowFloorProviderException.UNKNOW_HISTORY);
        provider.getCurrentlyFloor(1l, 1, "1", "1", "ASIN1", null);
    }
    
    @Test
    public void testNoHistory() throws OihPersistenceException, MarkdowFloorProviderException{
        expect(evaluateOutputDao.findMultiFloorActiveMarkdown(1l, "ASIN1")).andReturn(null);

        replay(evaluateOutputDao);
        MarkdownPriceBase priceBase = new MarkdownPriceBase();
        BigDecimal floor = provider.getCurrentlyFloor(1l, 1, "1", "1", "ASIN1", priceBase);
        Assert.assertEquals(floor, null);
    }
    
    @Test
    public void testInvalidFloor() throws OihPersistenceException, MarkdowFloorProviderException{
        CalenderEvaluationOutput output = new CalenderEvaluationOutput();
        output.setActionId(1l);
        output.setSeasonStartYear(2013);
        expect(evaluateOutputDao.findMultiFloorActiveMarkdown(1l, "ASIN1")).andReturn(output);
        expect(configuredActionDao.findById(1l)).andReturn(fakeAction);
        MarkdownPriceBase priceBase = new MarkdownPriceBase();
        expect(fakeAction.getCurrentFloorPrice(priceBase, 2013)).andReturn(null);
        
        replay(evaluateOutputDao, configuredActionDao, fakeAction);
        expectEx.expect(MarkdowFloorProviderException.class);
        expectEx.expectMessage(MarkdowFloorProviderException.INVALID_FLOOR);
        provider.getCurrentlyFloor(1l, 1, "1", "1", "ASIN1", priceBase);
    }
    
    @Test
    public void testFound() throws OihPersistenceException, MarkdowFloorProviderException{
        CalenderEvaluationOutput output = new CalenderEvaluationOutput();
        output.setActionId(1l);
        output.setSeasonStartYear(2013);
        expect(evaluateOutputDao.findMultiFloorActiveMarkdown(1l, "ASIN1")).andReturn(output);
        expect(configuredActionDao.findById(1l)).andReturn(fakeAction);
        MarkdownPriceBase priceBase = new MarkdownPriceBase();
        BigDecimal mockResult = new BigDecimal(100);
        expect(fakeAction.getCurrentFloorPrice(priceBase, 2013)).andReturn(mockResult);
        
        replay(evaluateOutputDao, configuredActionDao, fakeAction);

        BigDecimal floor = provider.getCurrentlyFloor(1l, 1, "1", "1", "ASIN1", priceBase);
        Assert.assertEquals(floor, mockResult);
    }
    
    @Test
    public void testNotEligibleForCBM() throws OihPersistenceException, MarkdowFloorProviderException{
        BigDecimal floor = provider.getCurrentlyFloor(1l, 1, "2", "1", "ASIN1", null);
        Assert.assertEquals(floor, null);
    }
}
