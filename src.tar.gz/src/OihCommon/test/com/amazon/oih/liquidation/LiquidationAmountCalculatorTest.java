package com.amazon.oih.liquidation;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.amazon.oih.configuration.model.LiquidationPolicy;
import com.amazon.oih.dao.averageliquidationinfo.AverageLiquidationInfo;

public class LiquidationAmountCalculatorTest {

    private static long RUN_ID = 1;
    private static int IOG = 1;
    private static String COUNTRY = "US";
    private static String GL = "14";
    private static String CATEGORY = "TEST_CATEGORY";
    private static String SUB_CATEGORY = "TEST_SUB_CATEGORY";
    
    private static double COST = 10.0;
    private static double PRICE = 15.0;
    private static double LIST_PRICE = 20.0;
    
    private static LiquidationAmountCalculator liAmountCalculator = null;
    private static LiquidationInfoKey liInfoKey = null;
    
    private static AverageLiquidationInfo avgLiInfo = null;
    private static LiquidationPolicy liPolicy = null;
    
    @BeforeClass
    public static void init() throws IOException {
        Logger.getRootLogger().setLevel(Level.OFF);
        
        avgLiInfo = new AverageLiquidationInfo();
        avgLiInfo.setCategory(CATEGORY);
        avgLiInfo.setCountry(COUNTRY);
        avgLiInfo.setGl(GL);
        avgLiInfo.setIog(IOG);
        avgLiInfo.setLayer("GL");
        avgLiInfo.setRate(50.0d);
        avgLiInfo.setRateFound("Y");
        avgLiInfo.setRunID(RUN_ID);
        avgLiInfo.setSubCategory(SUB_CATEGORY);
        avgLiInfo.setType("PERCENTAGE_OF_COST");
        List<AverageLiquidationInfo> avgLiInfos = new ArrayList<AverageLiquidationInfo>();
        avgLiInfos.add(avgLiInfo);
        
        liPolicy = new LiquidationPolicy();
        liPolicy.setIog(IOG);
        liPolicy.setGl(Integer.parseInt(GL));
        liPolicy.setOrg(COUNTRY);
        liPolicy.setValue(50.0d);
        liPolicy.setVendor("GENC1");
        liPolicy.setPerOrderCap(9999);
        liPolicy.setPriceType("PRCNTCOST");
        
        List<LiquidationPolicy> liPolicies = new ArrayList<LiquidationPolicy>();
        liPolicies.add(liPolicy);
        
        liInfoKey = new LiquidationInfoKey();
        liInfoKey.setIog(IOG);
        liInfoKey.setGl(GL);
        liInfoKey.setCountry(COUNTRY);
        liInfoKey.setCategory(CATEGORY);
        liInfoKey.setSubCategory(SUB_CATEGORY);
    }

    @Test
    public void calcLiquidationValue() {        
        double value1 = LiquidationAmountCalculator.calcLiquidationValue(avgLiInfo, COST, PRICE, LIST_PRICE);        
        double value2 = LiquidationAmountCalculator.calcLiquidationValue(liPolicy, COST, PRICE, LIST_PRICE);      
        Assert.assertTrue(value1 == COST * 50/100);
        Assert.assertTrue(value2 == COST * 50/100);
    }

}
