package com.amazon.oih.policy;

import java.util.Calendar;
import java.util.Date;

import org.junit.Assert;
import org.junit.Test;

import com.amazon.oih.policy.Util;


public class UtilTest {

    @Test
    public void testLastSaturday() {
        Date d = Util.lastSaturday();
        Calendar c = Calendar.getInstance();
        c.setTime( d );
        Assert.assertEquals( Calendar.SATURDAY, c.get( Calendar.DAY_OF_WEEK ) );
    }

    @Test
    public void testIsValidAsin() {
        String asins[] = { "foo", "8675309000", "AA00BB11CC", "11ABC213", null };
        boolean valid[] = { false, true, true, false, false };
        for ( int i = 0; i < asins.length; i++ ) {
            Assert.assertEquals( valid[ i ], Util.isValidASIN( asins[ i ] ) );
        }
    }

    @Test
    public void testFormatDate() {
        Calendar c = Calendar.getInstance();
        c.set( Calendar.YEAR, 2009 );
        c.set( Calendar.MONTH, Calendar.AUGUST );
        c.set( Calendar.DAY_OF_MONTH, 29 );

        Assert.assertEquals( "2009-08-29", Util.formatDate( c.getTime() ) );
    }

    @Test
    public void testConvertToPreviousSaturday() {
        Calendar c = Calendar.getInstance();
        c.set( Calendar.YEAR, 2009 );
        c.set( Calendar.MONTH, Calendar.AUGUST );
        c.set( Calendar.DAY_OF_MONTH, 29 );

        Date lastSat = Util.convertToPreviousSaturday( c.getTime() );

        Assert.assertEquals( "2009-08-29", Util.formatDate( lastSat ) );

        c.set( Calendar.DAY_OF_MONTH, 28 );

        Date nLastSat = Util.convertToPreviousSaturday( c.getTime() );

        Assert.assertEquals( "2009-08-22", Util.formatDate( nLastSat ) );

        c.set( Calendar.DAY_OF_MONTH, 30 );

        Date mLastSat = Util.convertToPreviousSaturday( c.getTime() );

        Assert.assertEquals( "2009-08-29", Util.formatDate( mLastSat ) );
    }

}
