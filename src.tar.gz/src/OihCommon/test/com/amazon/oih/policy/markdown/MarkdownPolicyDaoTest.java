package com.amazon.oih.policy.markdown;

import java.util.Date;
import java.util.List;
import java.util.Properties;

import junit.framework.Assert;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.junit.Before;
import org.junit.Test;

import amazon.platform.config.AppConfig;
import amazon.platform.logging.AppConfigLog4jConfigurator;

import com.amazon.oih.policy.MarkdownPolicyEntity;
import com.amazon.oih.policy.PriceType;
import com.amazon.oih.policy.markdown.dao.MarkdownPolicyHibernateDao;

public class MarkdownPolicyDaoTest {
	
	 private SessionFactory sessionFactory;
	 private MarkdownPolicyHibernateDao dao;
	    
	@Before
	public void setup(){
		// SessionFactory/HSQLDB/schema is built for each test.
        // Not fast, but we have a clean DB each test
        // Setup all config properties by hand.
        Properties props = new Properties();
        props.setProperty("hibernate.connection.driver_class", "org.hsqldb.jdbcDriver");
        // to connect to server running on localhost, use url like: jdbc:hsqldb:hsql://localhost/xdb
        props.setProperty("hibernate.connection.url", "jdbc:hsqldb:file:/var/tmp/testdb");
       
        props.setProperty("hibernate.connection.username", "sa");
        props.setProperty("hibernate.connection.password", "");
        props.setProperty("hibernate.dialect", "org.hibernate.dialect.HSQLDialect");
        props.setProperty("connection.pool_size", "5");
        props.setProperty("hibernate.hbm2ddl.auto", "create");
        props.setProperty("show_sql", "true");

        Configuration config = new Configuration();

        config.setProperties(props);
        try {
            // need to specify classes to be mapped by hand too
            config.addResource("com/amazon/oih/policy/MarkdownPolicyEntity.hbm.xml");

            sessionFactory = config.buildSessionFactory();
        } catch (RuntimeException e) {
            e.printStackTrace();
        }

        MarkdownPolicyHibernateDao hibernateDao = new MarkdownPolicyHibernateDao();
        hibernateDao.setSessionFactory(sessionFactory);
        dao = hibernateDao;
        
        prepareData();
	}
	
	@Test
	public void testGetType(){
		Assert.assertEquals(
				"com.amazon.oih.policy.MarkdownPolicyEntity", 
				dao.getType());
	}
	
	@Test
	public void testFindAllMarkdownPolicies(){
		List<MarkdownPolicyEntity> list = dao.findAllMarkdownPolicies();
		Assert.assertEquals(list.size(), 1);
		Assert.assertTrue(PriceType.PRCNTCOST == list.get(0).getPriceType());
		list = dao.findMarkdownPoliciesByMarketplaceAndIog(1, 1);
		Assert.assertEquals(list.size(), 1);
		list = dao.findMarkdownPoliciesByMarketplaceAndIog(1, 2);
		Assert.assertEquals(list.size(), 0);
	}
	
	private void prepareData(){
		MarkdownPolicyEntity entity = new MarkdownPolicyEntity();
		entity.setMarketPlaceId(1);
		entity.setIog(1);
		entity.setGl(14);
		entity.setAdditionalAttributes("");
		entity.setCreatedBy("nobody");
		entity.setCreatedDate(new Date());
		entity.setUpdatedBy("nobody");
		entity.setUpdatedDate(new Date());
		entity.setPriority(0);
		entity.setPriceType(PriceType.PRCNTCOST);
		dao.save(entity);
	}
}
