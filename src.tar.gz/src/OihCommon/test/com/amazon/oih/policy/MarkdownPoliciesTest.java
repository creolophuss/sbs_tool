package com.amazon.oih.policy;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.Arrays;
import java.util.List;

import junit.framework.Assert;

import org.junit.Before;
import org.junit.Test;

import com.amazon.oih.policy.MarkdownPolicies;
import com.amazon.oih.policy.Util;

public class MarkdownPoliciesTest {

    private MarkdownPolicies mp;
    private static List<String> _REALMS = Arrays.asList("USAmazon", "GBAmazon", "CNAmazon");
    private static String _FILES_ROOT = "/tmp/";
    private static String _FILE_TEMPLATE = "${REALM}/MarkdownPolicies-extracted.${DATE_START}_to_${DATE_END}.txt";
    private MarketplaceIog mAndIog = new MarketplaceIog(1, 1);
    
    @Before
    public void setup() throws IOException {

        List<String> fileNames = Util.getFileNames(_REALMS, _FILES_ROOT,
                _FILE_TEMPLATE);
        String title = "marketPlaceId,iog,gl,category,sub_category,price_type,price_or_percent,duration_days";
        String row;

        File file1 = createFile(fileNames.get(0));
        BufferedWriter bf1 = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file1, true)));
        bf1.write(title + "\n");
        // All values
        row = "1,1,14,1400,1401,PRCNTCOST,10,1\n";
        bf1.write(row);

        // part of values blank, different type
        row = "1,1,14,1400,,PRCNTPRICE,20,2\n";
        bf1.write(row);
        row = "1,1,14,,,PERUNIT,15,2\n";
        bf1.write(row);
        row = "1,1,14,,1411,PRCNTCOST,20,4\n";
        bf1.write(row);

        // dublicate keys
        row = "1,1,16,1600,1601,PRCNTCOST,40,5\n";
        bf1.write(row);
        row = "1,1,16,1600,1601,PRCNTCOST,50,6\n";
        bf1.write(row);
        
        // ALL Price keys
        row = "1,1,17,1710,1711,,40,7\n";
        bf1.write(row);
        row = "1,1,17,1720,1721,,,8\n";
        bf1.write(row);
        row = "1,1,17,1730,,,ALL,9\n";
        bf1.write(row);
        row = "1,1,17,1740,,ALL,ALL,10\n";
        bf1.write(row);
        row = "1,1,18,ALL,ALL,ALL,ALL,20\n";
        bf1.write(row);
        
        bf1.flush();
        bf1.close();

        File file2 = createFile(fileNames.get(1));
        BufferedWriter bf2 = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file2, true)));
        bf2.write(title + ",0\n");

        // part of values, different IOG
        row = "1,2,14,ALL,all,PRCNTCOST,10,11\n";
        bf2.write(row);
        row = "1,2,14,1400,all,PRCNTPRICE,10,12\n";
        bf2.write(row);
        row = "1,2,15,,Anything,PRCNTCOST,10,13\n";
        bf2.write(row);

        bf2.flush();
        bf2.close();
        
        // Empty file
        File file3 = createFile(fileNames.get(2));
        BufferedWriter bf3 = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file3, true)));
        bf3.write(title + "\n");
        bf3.flush();
        bf3.close();

        mp = new MarkdownPolicies(_FILES_ROOT, _FILE_TEMPLATE, _REALMS);
        mp.init();
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }
    
    public File createFile(String fileName) throws IOException{
        File file = new File(fileName);
        if (!file.exists()) {
            File parent = file.getParentFile();
            parent.mkdirs();
            file.createNewFile();
        } else {
            file.delete();
        }
        return file;
    }

    @Test
    public void testPriceNormalCase() {
        // All values
        Assert.assertEquals(1.0, mp.getMarkdownPrice(mAndIog,
                new Integer(14), "1400", "1401",
                new Double(10), new Double(11)));

        // part of values blank, different type
        Assert.assertEquals(2.2, mp.getMarkdownPrice(mAndIog,
                new Integer(14), "1400", "1402",
                new Double(10), new Double(11)));
        Assert.assertEquals(15.0, mp.getMarkdownPrice(mAndIog,
                new Integer(14), "1500", "1502",
                new Double(30), new Double(20)));


        // dublicate keys
        Assert.assertEquals(4.0, mp.getMarkdownPrice(mAndIog,
                new Integer(16), "1600", "1601",
                new Double(10), new Double(20)));

        // part of values, different IOG
        Assert.assertEquals(1.0, mp.getMarkdownPrice(mAndIog.cloneAndSet(1, 2),
                new Integer(14), "1450", "1451",
                new Double(10), new Double(11)));
        Assert.assertEquals(2.0, mp.getMarkdownPrice(mAndIog.cloneAndSet(1, 2),
                new Integer(14), "1400", "1411",
                new Double(10), new Double(20)));
        Assert.assertEquals(15,0, mp.getMarkdownPrice(mAndIog.cloneAndSet(1, 1),
                new Integer(14), "1410", "1411",
                new Double(10), new Double(20)));

    }
    
    @Test
    public void testNoPriceValuesFoundCase() {
        Assert.assertNull(mp.getMarkdownPrice(mAndIog,
                new Integer(17), "1700", "1701",
                new Double(10), new Double(11)));
        
        MarketplaceIog mIogCopy = mAndIog.cloneAndSet(1, 2);
        
        Assert.assertNull(mp.getMarkdownPrice(mAndIog,
                new Integer(15), "1500", "1501",
                new Double(10), new Double(20)));
        
        Assert.assertNull(mp.getMarkdownPrice(mIogCopy,
                new Integer(17), "1710", "1711",
                new Double(10), new Double(20)));
        
        Assert.assertNull(mp.getMarkdownPrice(mIogCopy,
                new Integer(17), "1720", "1721",
                new Double(10), new Double(20)));
        
        Assert.assertNull(mp.getMarkdownPrice(mIogCopy,
                new Integer(17), "1730", "1731",
                new Double(10), new Double(20)));
        
        Assert.assertNull(mp.getMarkdownPrice(mIogCopy,
                new Integer(17), "1740", "1741",
                new Double(10), new Double(20)));
    }
    
    @Test
    public void testDurationDaysNormalCase() {
        // All values
        
        Assert.assertEquals(new Integer(1), mp.getMarkdownDurationDays(mAndIog, new Integer(14), "1400", "1401"));

        // part of values blank, different type
        Assert.assertEquals(new Integer(2), mp.getMarkdownDurationDays(mAndIog,
                new Integer(14), "1400", "1402"));
        Assert.assertEquals(new Integer(2), mp.getMarkdownDurationDays(mAndIog,
                new Integer(14), "1500", "1502"));


        // dublicate keys
        Assert.assertEquals(new Integer(5), mp.getMarkdownDurationDays(mAndIog,
                new Integer(16), "1600", "1601"));

        // part of values, different IOG
        Assert.assertEquals(new Integer(11), mp.getMarkdownDurationDays(mAndIog.cloneAndSet(1, 2),
                new Integer(14), "1450", "1451"));
        Assert.assertEquals(new Integer(12), mp.getMarkdownDurationDays(mAndIog.cloneAndSet(1, 2),
                new Integer(14), "1400", "1411"));
        Assert.assertEquals(new Integer(2), mp.getMarkdownDurationDays(mAndIog,
                new Integer(14), "1410", "1411"));
        Assert.assertEquals(new Integer(20), mp.getMarkdownDurationDays(mAndIog,
                new Integer(18), "1810", "1811"));

    }

}
