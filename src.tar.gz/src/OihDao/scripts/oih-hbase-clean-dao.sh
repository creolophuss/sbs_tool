#! /bin/sh

tablelist=""
endDate=""

echo 'status' > ${ROOT}/var/output/data/${DOMAIN}/${REALM}/hbaserun

outputDeleteCommand() {
    echo "disable '$1_${REALM}_$2'" >> ${ROOT}/var/output/data/${DOMAIN}/${REALM}/hbaserun
    echo "drop '$1_${REALM}_$2'" >>  ${ROOT}/var/output/data/${DOMAIN}/${REALM}/hbaserun
}

for parameter in $*; do
    name=`echo "$parameter"|awk -F "=" '{print($1)}'`;
    value=`echo "$parameter"|awk -F "=" '{print($2)}'`;
    if [ "$name" = "--tableList" ]
    then
        tablelist=`echo "$value" | awk -F',' '{print $0}' | sed "s/,/ /g"`
        echo "tablelist="$tablelist
    fi
    if [ "$name" = "--endDate" ]
    then
        endDate=`echo "$value" | sed "s/-//g"`
        echo "endDate=$endDate"
    fi
done

for table in $tablelist; do
    outputDeleteCommand $table $endDate
done

echo "major_compact '.META.'" >>  ${ROOT}/var/output/data/${DOMAIN}/${REALM}/hbaserun
echo "exit" >>  ${ROOT}/var/output/data/${DOMAIN}/${REALM}/hbaserun

/apollo/env/OIHHBase/bin/apollo-hbase shell "${ROOT}/var/output/data/${DOMAIN}/${REALM}/hbaserun"
