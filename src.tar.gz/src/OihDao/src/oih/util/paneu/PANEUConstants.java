package oih.util.paneu;

public class PANEUConstants {
    public final static int VIRTUAL_MARKETPLACEID = 10000;
    
    public final static int VIRTUAL_MERCHANTID = 10000;   
    
    public final static int VIRTUAL_IOG = 10001;

    public final static String EUREALM = "EUAmazon";
    
    public final static int[] GB_IOG_LIST = {7, 13, 24};
    
    public final static String GB_CURRENCY = "GBP";   
    
    public final static String GB_COUNTRY_CODE = "GB";
    
    public final static int GB_IOG = 7;
}
