package oih.business;

import java.util.TimeZone;

import amazon.platform.config.Realm;

public enum AmazonOrg {

	US("US", "USAmazon", "America/Los_Angeles"),
	JP("Japan", "JPAmazon", "Asia/Tokyo"),
	GB("UK", "GBAmazon", "Europe/London"),
	CA("Canada", "CAAmazon", "America/Los_Angeles"),
	FR("France", "FRAmazon", "Europe/Paris"),
	DE("Germany", "DEAmazon", "Europe/Berlin"),
	IT("Italy", "ITAmazon", "Europe/Rome"),
	CN("China", "CNAmazon", "Asia/Shanghai"),
	ES("Spain", "ESAmazon", "Europe/Madrid"),
	IN("India", "INAmazon", "Asia/New_Delhi"),
	EU("PanEU", "EUAmazon", "Europe/London"),
	VG("VirtualGroup", "VGAmazon", "Europe/London");
	
	private String name;
	private String realm;
	private TimeZone timeZone;
	
	private AmazonOrg(String name, String realm, String timeZone) {
		this.name = name;
		this.realm = realm;
		this.timeZone = TimeZone.getTimeZone(timeZone);
	}
	
	public String getName() {
		return name;
	}
	
	public String getRealm() {
		return realm;
	}
	
	public TimeZone getTimeZone() {
		return timeZone;
	}

	/**
	 * used by hibernate to reconstruct an AmazonOrg from the db
	 * @param inRealm
	 * @return
	 */
	public static AmazonOrg fromString( String inRealm ) {
	    for ( AmazonOrg o : AmazonOrg.values() ) {
	        if ( o.getRealm().equals( inRealm ) ) 
	            return o;
	    }
	    return null;
	}
	
	public static AmazonOrg fromRealm( Realm appConfigRealm ) {
	    for ( AmazonOrg o : AmazonOrg.values() ) {
	        if ( o.getRealm().equals( appConfigRealm.name() ) )
	            return o;
	    }
	    return null;
	}
	
}
