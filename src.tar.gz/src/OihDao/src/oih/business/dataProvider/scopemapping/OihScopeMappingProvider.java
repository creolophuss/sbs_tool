package oih.business.dataProvider.scopemapping;

import static com.google.common.base.Preconditions.checkArgument;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import oih.business.AmazonOrg;
import oih.config.ConfigFactory;

import com.amazon.oih.dao.scopemapping.MarketplaceMerchantIdPair;
import com.amazon.oih.dao.scopemapping.OihG2S2Constants;
import com.amazon.oih.dao.scopemapping.OihScopeMapping;
import com.google.common.base.Function;
import com.google.common.base.Preconditions;
import com.google.common.collect.Lists;

public class OihScopeMappingProvider {

    private static List<OihScopeMapping> scopeMappings = (List<OihScopeMapping>) ConfigFactory.getDefaultConfig()
            .findList(OihG2S2Constants.SCOPEMAPPING_TABLE, OihScopeMapping.class);
    private static Map<String, OihScopeMapping> scopeNameToScopeMapping;
    private static Map<Long, OihScopeMapping> iogToScopeMapping = new HashMap<Long, OihScopeMapping>();
    private static Map<Long, OihScopeMapping> marketplaceToScopeMapping = new HashMap<Long, OihScopeMapping>();
    
    @SuppressWarnings("unchecked")
    private static Map<String, List<String>> realmToScopeMapForCalc = (Map<String, List<String>>)ConfigFactory.getDefaultConfig().findMap(OihG2S2Constants.REALM_TO_SCOPE_MAP_FOR_CALC);

    /**
     * a map whose key is ScopeName and value is a CountryCode, PANEU Scope should not be included in scopeToContryMap
     */
    @SuppressWarnings("unchecked")
    private static Map<String, String> scopeToCountryMap = (Map<String, String>)ConfigFactory.getDefaultConfig().findMap(OihG2S2Constants.SCOPE_TO_COUNTRY);    
    
  
    static {
        makeOihScopeMappingsImmutable();
        init();
    }
    /**
     * 
     */
    private static void makeOihScopeMappingsImmutable(){
        scopeMappings = Collections.unmodifiableList(Lists.transform(scopeMappings, new Function<OihScopeMapping, OihScopeMapping>( ) {
            @Override
            public ImmutableOihScopeMapping apply(OihScopeMapping scopeMapping) {
                return new ImmutableOihScopeMapping(scopeMapping);
            }
        }));
    }
    
    private static void init(){
        Map<String,OihScopeMapping> scopeNameToScopeMapping = new HashMap<String, OihScopeMapping>();
        for (OihScopeMapping scope : scopeMappings) {         
            scopeNameToScopeMapping.put(scope.getScope(), scope);
        }        
        OihScopeMappingProvider.scopeNameToScopeMapping = Collections.unmodifiableMap(scopeNameToScopeMapping); 
        
        //use country level scope as default mapping
        for (OihScopeMapping scope : scopeMappings) {
            if( scopeToCountryMap.get(scope.getScope()) != null){
                addInverseMapping(scope);
            }            
        }
        //override mapping for some special scopes (i.e. PANEU)
        List<OihScopeMapping> usedScopes = getScopeMappingsByRealmForCalc(ConfigFactory.getDefaultConfig().getRealmName());
        for (OihScopeMapping scope : usedScopes) {
            addInverseMapping(scope);
        }
        
        Preconditions.checkNotNull(realmToScopeMapForCalc , "Config ["+ OihG2S2Constants.REALM_TO_SCOPE_MAP_FOR_CALC +"] can not be null");
        Preconditions.checkNotNull(scopeToCountryMap, "Config ["+ OihG2S2Constants.SCOPE_TO_COUNTRY +"] can not be null");
    } 
    
    private static void addInverseMapping(OihScopeMapping scope){
        for (Long iog : scope.getIogs()) {
            iogToScopeMapping.put(iog, scope);
            iogToScopeMapping.put(scope.getPrimaryIogId(), scope); //for paneu
        }                
        for (Long marketplaceId : scope.getMarketplaces()) {
            marketplaceToScopeMapping.put(marketplaceId, scope);            
            marketplaceToScopeMapping.put(scope.getPrimaryMarketplaceId(), scope); //for paneu
        }        
    }

    public static List<OihScopeMapping> getAllScopeMapping() {
        return scopeMappings;
    }

    public static OihScopeMapping getScopeMappingByIog(Long iog) {
        return iogToScopeMapping.get(iog);
    }
    
    public static OihScopeMapping getScopeMappingByIog(Long iog, String realm) {
        if(ConfigFactory.getDefaultConfig().getRealmName().equals(realm) ){
            return iogToScopeMapping.get(iog);
        }else{
            List<OihScopeMapping> usedScopes = getScopeMappingsByRealmForCalc(realm);
            for (OihScopeMapping scope : usedScopes) {
                if(scope.getIogs().contains(iog)){
                    return scope;
                }
            }            
            return null;
        }
    }    

    public static OihScopeMapping getScopeMappingByMarketplaceId(Long marketplaceId) {
        return marketplaceToScopeMapping.get(marketplaceId);
    }
    
    public static OihScopeMapping getScopeMappingByMarketplaceId(Long marketplaceId, String realm) {
        if(ConfigFactory.getDefaultConfig().getRealmName().equals(realm) ){
            return marketplaceToScopeMapping.get(marketplaceId);
        }else{
            List<OihScopeMapping> usedScopes = getScopeMappingsByRealmForCalc(realm);
            for (OihScopeMapping scope : usedScopes) {
                if(scope.getMarketplaces().contains(marketplaceId)){
                    return scope;
                }
            }            
            return null;
        }
    }

    public static OihScopeMapping getScopeMappingByScopeName(String scopeName) {
        return scopeNameToScopeMapping.get(scopeName);
    }
    
    public static OihScopeMapping get(String scopeName){
        return scopeNameToScopeMapping.get(scopeName);
    }

    public static String getScopeNameByIog(Long iog) {
        return getScopeMappingByIog(iog).getScope();
    }
    
	public static String getScopeNameByIog(String iog) {
		return getScopeMappingByIog(Long.parseLong(iog)).getScope();
	}

    public static Long getPrimaryIogByIog(Long iog) {
        return getScopeMappingByIog(iog).getPrimaryIogId();
    }

    public static Long getPrimaryMarketplaceIdByIog(Long iog) {
        return getScopeMappingByIog(iog).getPrimaryMarketplaceId();
    }

    public static List<Long> getIOGsByIog(Long iog) {
        return getScopeMappingByIog(iog).getIogs();
    }

    public static List<Long> getMarketplaceIdsByIog(Long iog) {
        return getScopeMappingByIog(iog).getMarketplaces();
    }
    
    /**
     * get Primary MerchantId list for the given scope
     */
    public static Long getPrimaryMerchantIdOfScope(OihScopeMapping scope){
        if(scope.getMarketplaceMerchantIdPairs() != null){
            for( MarketplaceMerchantIdPair  p :  scope.getMarketplaceMerchantIdPairs()){
                if(p.getMarketplaceId() == scope.getPrimaryMarketplaceId() ){
                    return p.getMerchantId();
                }
            }
        }
        return null;
    }
    
    
    /**
     * get MerchantId list for the given scope
     */
    public static List<Long> getMerchantIdsOfScope(OihScopeMapping scope){
        List<Long> merchantIds = new ArrayList<Long>(scope.getMarketplaceMerchantIdPairs().size());
        for( MarketplaceMerchantIdPair  p :scope.getMarketplaceMerchantIdPairs()){
            merchantIds.add(p.getMerchantId());
        }
        return merchantIds;
    }
    
    
    public static boolean isScopeBelongOneCountry(String scopeId){
        return scopeToCountryMap.containsKey(scopeId);
    }
    
    /**
     * get Scope for the given iog considering the iog's country.
     * So PANEU scope will never be return
     */
    public static OihScopeMapping getScopeMappingByIogConsideringCountry(Long iog){
        for(OihScopeMapping scope : getAllScopeMapping()){
            if( isScopeBelongOneCountry(scope.getScope()) && scope.getIogs().contains(iog)){
                return scope;
            }
        }
        return null;
    }
    
    /**
     * for india case, a first scope with marketplaceId will be returned
     * @param marketplaceId
     * @return
     */
    public static OihScopeMapping getScopeMappingByMarketplaceIdConsideringCountry(Long marketplaceId){
        for(OihScopeMapping scope : getAllScopeMapping()){
            if( isScopeBelongOneCountry(scope.getScope()) && scope.getMarketplaces().contains(marketplaceId)){
                return scope;
            }
        }
        return null;
    }    
    
        
    /**
     * 
     * get Marketplace Id for the given iog considering the iog's country.
     * For India case, iog.rc1 > merchant.rc1, iog.rc2 > merchant.rc2
     */
    public static Long getMerchantIdByIog(Long iog){
        OihScopeMapping scope = getScopeMappingByIogConsideringCountry(iog);
        return scope == null? null : getPrimaryMerchantIdOfScope(scope);          
    }
    
    
    /**
     * get Marketplace Id for the given iog considering the iog's country. 
     * even in PANEU case, GB iog will return GB marketplace, de iog will return de marketplace
     * @return
     */
    public static Long getMarketplaceIdByIog(Long iog){
        OihScopeMapping scope = getScopeMappingByIogConsideringCountry(iog); 
        return scope.getPrimaryMarketplaceId();
    }

    public static String getForecastGroupByIog(Long iog) {
        return getScopeMappingByIog(iog).getForecastGroup();
    }

    public static List<Long> getIOGsByRealmForCalc(String realm) {
        List<Long> ret = new ArrayList<Long>();
        List<String> scopes = realmToScopeMapForCalc.get(realm);
        for (String scope : scopes){
            ret.addAll(getScopeMappingByScopeName(scope).getIogs());
        }
        return ret;
    }

    public static List<Long> getMarketplaceIdsByRealmForCalc(String realm) {
        List<Long> ret = new ArrayList<Long>();
        List<String> scopes = realmToScopeMapForCalc.get(realm);
        for (String scope : scopes){
            ret.addAll(getScopeMappingByScopeName(scope).getMarketplaces());
        }
        return ret;
    }

    public static List<OihScopeMapping> getScopeMappingsByRealmForCalc(String realm) {
        List<OihScopeMapping> ret = new ArrayList<OihScopeMapping>();
        List<String> scopes = realmToScopeMapForCalc.get(realm);
        for (String scope : scopes){
            ret.add(getScopeMappingByScopeName(scope));
        }
        return ret;
    }
    
    /**
     * 
     * get Scope for the given country.
     * For India case, the first scope will be returned. 
     */
    public static OihScopeMapping getScopeMappingByCountry(String countryCode){
        for( Entry<String, String> entry : scopeToCountryMap.entrySet() ){
            if(entry.getValue().equals(countryCode)){
                return getScopeMappingByScopeName(entry.getKey());
            }
        }
        return null;        
    }
    
    /**
     * 
     * get list of Scopes for the given country.
     * For India case, more than one scopes will be returned. 
     */    
    public static List<OihScopeMapping> getScopeMappingsByCountry(String countryCode){
        List<OihScopeMapping> scopes = new ArrayList<OihScopeMapping>();
        for( Entry<String, String> entry : scopeToCountryMap.entrySet() ){
            if(entry.getValue().equals(countryCode)){
                scopes.add(getScopeMappingByScopeName(entry.getKey()));
            }
        }
        return scopes;
    }
    
    public static OihScopeMapping getScopeMappingByRealm(String realm){
        if(AmazonOrg.EU.getRealm().equals(realm)){
            String paneuScopeName = realmToScopeMapForCalc.get(realm).get(0);
            return getScopeMappingByScopeName(paneuScopeName);
        }else{
            String countryCode = realm.substring(0,2);
            return getScopeMappingByCountry(countryCode);
        }
    }    
    
    /**
     * 
     * get list of Scopes for the given realm, including PANEU.
     * For India case, more than one scopes will be returned. 
     * For PANEU, PANEU scope will be returned.
     */      
    public static List<OihScopeMapping> getScopeMappingsByRealm(String realm){
        if(AmazonOrg.EU.getRealm().equals(realm)){
            String paneuScopeName = realmToScopeMapForCalc.get(realm).get(0);
            return Collections.singletonList(getScopeMappingByScopeName(paneuScopeName));
        }else{
            String countryCode = realm.substring(0,2);
            return getScopeMappingsByCountry(countryCode);
        }
    }

    public static List<Long> getMarketplaceIdsByRealm(String realm) {
        return getScopeMappingByRealm(realm).getMarketplaces();
    }
    
    public static Long getPrimaryMarketplaceIdByRealm(String realm) {
        return getScopeMappingByRealm(realm).getPrimaryMarketplaceId();
    }
    
    public static String getCalRealmByScope(String scope){
        for( Entry<String, List<String>> entry: realmToScopeMapForCalc.entrySet()){
            if(entry.getValue().contains(scope)){
                return entry.getKey();
            }
        }
        return null;
    }
    
    public static String getCountryOfScope(String scope){
        return scopeToCountryMap.get(scope);
    }

    public static String getRealmByScope(String scope){
        String countryCode = scopeToCountryMap.get(scope);
        if( countryCode != null){
            return countryCode + "Amazon"; 
        }else{            
            return OihScopeMappingProvider.getCalRealmByScope(scope);
        }
    }    
    
    static class ImmutableMarketplaceMerchantIdPair extends MarketplaceMerchantIdPair{
        private MarketplaceMerchantIdPair inner;
        public ImmutableMarketplaceMerchantIdPair(MarketplaceMerchantIdPair marketplaceMerchantIdPair){
            checkArgument(marketplaceMerchantIdPair != null, "Parameter marketplaceMerchantIdPair of ImmutableMarketplaceMerchantIdPair constructor can not be null");
            this.inner = marketplaceMerchantIdPair;
        }
        public long getMarketplaceId() {
            return inner.getMarketplaceId();
        }
        public void setMarketplaceId(long marketplaceId) {
            throw new UnsupportedOperationException("Unsupported method setMarketplaceId");
        }
        public long getMerchantId() {
            return inner.getMerchantId();
        }
        public void setMerchantId(long merchantId) {
            throw new UnsupportedOperationException("Unsupported method setMerchantId");
        }
    }
    
    static class ImmutableOihScopeMapping extends OihScopeMapping{
        private OihScopeMapping scopeMapping;
        private List<Long> immutableIogs;
        private List<Long> immutableMarketplaces;
        private List<Long> immutableDisabledIogs;
        private List<Long> immutableDisabledMarketplaces;
        private List<MarketplaceMerchantIdPair> immutableMarketplaceMerchantIdPairs;

        public ImmutableOihScopeMapping(OihScopeMapping scopeMapping) {
            checkArgument(scopeMapping != null, "Parameter scopeMapping of ImmutableOihScopeMapping's constructor can not be null");
            this.scopeMapping = scopeMapping;
            this.immutableIogs = Collections.unmodifiableList(scopeMapping.getIogs());
            this.immutableMarketplaces = Collections.unmodifiableList(scopeMapping.getMarketplaces());
            this.immutableDisabledIogs = Collections.unmodifiableList(scopeMapping.getDisabledIogs());
            this.immutableDisabledMarketplaces = Collections.unmodifiableList(scopeMapping.getDisabledMarketplaces());
            this.immutableMarketplaceMerchantIdPairs =  Collections.unmodifiableList(getEnabledMarketplaceMerchantIdPairs(scopeMapping));

        }
        
        private static List<MarketplaceMerchantIdPair> getEnabledMarketplaceMerchantIdPairs(OihScopeMapping scopeMapping){
            List<MarketplaceMerchantIdPair> marketplaceMerchantIdPairs = new ArrayList<MarketplaceMerchantIdPair>();
            for(MarketplaceMerchantIdPair pair : scopeMapping.getMarketplaceMerchantIdPairs()){
                if(scopeMapping.getMarketplaces().contains( pair.getMarketplaceId())){
                    marketplaceMerchantIdPairs.add(new ImmutableMarketplaceMerchantIdPair(pair));
                }
            }
            return marketplaceMerchantIdPairs;
        }
        
        public String getScope() {
            return scopeMapping.getScope();
        }
        public void setScope(String scope) {
            throw new UnsupportedOperationException("Unsupported method setScope");
        }
        public List<Long> getIogs() {
            return immutableIogs;
        }
        public void setIogs(List<Long> iogs) {
            throw new UnsupportedOperationException("Unsupported method setIogs");
        }
        public List<Long> getMarketplaces() {
            return immutableMarketplaces;
        }
        public void setMarketplaces(List<Long> marketplaces) {
            throw new UnsupportedOperationException("Unsupported method setMarketplaces");
        }
        public Long getPrimaryIogId() {
            return scopeMapping.getPrimaryIogId();
        }
        public void setPrimaryIogId(Long primaryIogId) {
            throw new UnsupportedOperationException("Unsupported method setPrimaryIogId");
        }
        public Long getPrimaryMarketplaceId() {
            return scopeMapping.getPrimaryMarketplaceId();
        }
        public void setPrimaryMarketplaceId(Long primaryMarketplaceId) {
            throw new UnsupportedOperationException("Unsupported method setPrimaryMarketplaceId");
        }
        public List<Long> getDisabledIogs() {
            return immutableDisabledIogs;
        }
        public void setDisabledIogs(List<Long> disabledIogs) {
            throw new UnsupportedOperationException("Unsupported method setDisabledIogs");
        }
        public List<Long> getDisabledMarketplaces() {
            return immutableDisabledMarketplaces;
        }
        public void setDisabledMarketplaces(List<Long> disabledMarketplaces) {
            throw new UnsupportedOperationException("Unsupported method setDisabledMarketplaces");
        }
        public String getForecastGroup() {
            return scopeMapping.getForecastGroup();
        }
        public void setForecastGroup(String forecastGroup) {
            throw new UnsupportedOperationException("Unsupported method setForecastGroup");
        }        
        public List<MarketplaceMerchantIdPair> getMarketplaceMerchantIdPairs() {
            return this.immutableMarketplaceMerchantIdPairs;
        }
        public void setMarketplaceMerchantIdPairs(List<MarketplaceMerchantIdPair> marketplaceMerchantIdPairs) {
            throw new UnsupportedOperationException("Unsupported method setMarketplaceMerchantIdPairs");
        }
        
        public String toString() {
            return scopeMapping.toString();
        }
        @Override
        public int hashCode() {
            final int prime = 31;
            int result = 1;
            result = prime * result + ((scopeMapping == null) ? 0 : scopeMapping.hashCode());
            return result;
        }
        @Override
        public boolean equals(Object obj) {
            if (this == obj)
                return true;
            if (obj == null)
                return false;
            if (getClass() != obj.getClass())
                return false;
            ImmutableOihScopeMapping other = (ImmutableOihScopeMapping) obj;
            if (scopeMapping == null) {
                if (other.scopeMapping != null)
                    return false;
            } else if (!scopeMapping.equals(other.scopeMapping))
                return false;
            return true;
        }
    }
}
