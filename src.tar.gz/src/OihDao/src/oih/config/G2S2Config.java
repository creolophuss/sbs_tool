package oih.config;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.amazon.oih.dao.g2s2.G2S2AppConfigsReadonlyDao;
import com.amazon.oih.dao.g2s2.G2S2AppConfigsReadonlyDaoImpl;

import amazon.platform.config.AppConfig;
import amazon.platform.config.Conversions;

public class G2S2Config extends ConfigBase {

    private static Map<String, ValueReference<Object>> cacheObject = new ConcurrentHashMap<String, ValueReference<Object>>();
    private static Map<String, ValueReference<List<?>>> cacheObjectList = new ConcurrentHashMap<String, ValueReference<List<?>>>();
    private static G2S2AppConfigsReadonlyDao G2S2RODao;

    G2S2Config() {
        if (!AppConfig.isInitialized())
            throw new ConfigException("AppConfig is not yet initialized !!");
        if (G2S2RODao == null) {
            G2S2RODao = new G2S2AppConfigsReadonlyDaoImpl();
        }
    }

    /**
     * Only for UT
     * 
     * @param G2S2RODao
     */
    static void setG2S2Dao(G2S2AppConfigsReadonlyDao G2S2RODao) {
        G2S2Config.G2S2RODao = G2S2RODao;
    }

    /**
     * See {@link oih.config.Config}
     */
    @Override
    public String findString(String key) {
        Object o = findObject(key, String.class);
        if ((o != null) && (o instanceof String))
            return (String) o;
        else
            return null;
    }

    /**
     * See {@link oih.config.Config}
     */
    @Override
    public Integer findInteger(String key) {
        Object o = findObject(key, Integer.class);
        return Conversions.getInteger(o);
    }

    /**
     * See {@link oih.config.Config}
     */
    @Override
    public Double findDouble(String key) {
        Object o = findObject(key, Double.class);
        return Conversions.getDouble(o);
    }

    /**
     * See {@link oih.config.Config}
     */
    @Override
    public Boolean findBoolean(String key) {
        Object o = findObject(key, Boolean.class);
        return Conversions.getBoolean(o);
    }

    /**
     * 
     * @deprecated findObject use findObject(String key, Class<T> clazz) to replace this one
     */
    @Override
    public Object findObject(String key) {
        throw new UnsupportedOperationException("can't support this method");
    }

    /**
     * Retrieve the value for the specified key.
     * 
     * @param key
     *            the key of the value to lookup.
     * @return the configured value, or null otherwise.
     */
    @SuppressWarnings("unchecked")
    public <T> T findObject(String key, Class<T> clazz) {
        ValueReference<Object> vr = null;
        if (!cacheObject.containsKey(key)) {
            T o;
            o = G2S2RODao.getAppConfig(key, clazz);
            vr = new ValueReference<Object>(o);
            cacheObject.put(key, vr);
        } else {
            vr = cacheObject.get(key);
        }
        return (vr.value == null) ? null : (T) vr.value;
    }

    /**
     * See {@link oih.config.Config}
     */
    @SuppressWarnings("rawtypes")
    @Override
    public List<?> findList(String key) {
        Object o = findObject(key, List.class);
        if ((o != null) && (o instanceof List))
            return (List) o;
        else
            return null;
    }

    /**
     * See {@link oih.config.Config}
     */
    @SuppressWarnings("rawtypes")
    @Override
    public Map<?, ?> findMap(String key) {
        Object o = findObject(key, Map.class);
        if ((o != null) && (o instanceof Map))
            return (Map) o;
        else
            return null;
    }

    /**
     * See {@link oih.config.Config}
     * 
     * @deprecated use findMap(String key) to replace this one
     */
    @Override
    public Map<String, Object> findObjects(String key) {
        throw new UnsupportedOperationException("can't support this method");
    }

    /**
     * See {@link oih.config.Config}
     * 
     * @deprecated don't support this method because of the limitation of G2S2
     */
    @Override
    public Map<String, Object> findObjectsByPrefix(String keyPrefix) {
        throw new UnsupportedOperationException("can't support this method");
    }

    /**
     * See {@link oih.config.Config}
     */
    @Override
    public String getDomain() {
        return AppConfig.getDomain();
    }

    /**
     * See {@link oih.config.Config}
     */
    @Override
    public String getMachine() {
        return AppConfig.getMachine();
    }

    /**
     * See {@link oih.config.Config}
     */
    @Override
    public String getRealmName() {
        return AppConfig.getRealm().name();
    }

    /**
     * See {@link oih.config.Config}
     */
    @Override
    public String[] getArguments() {
        return AppConfig.getArguments();
    }

    /**
     * See {@link oih.config.Config}
     */
    @Override
    public synchronized void reloadConfig() {
        G2S2RODao.flushCache();

        cacheObject.clear();
        cacheObjectList.clear();
    }

    /**
     * See {@link oih.config.Config}
     */
    @SuppressWarnings("unchecked")
    @Override
    public <T> List<T> findList(String key, Class<T> clazz) {
        ValueReference<List<?>> vr = null;
        if (!cacheObjectList.containsKey(key)) {
            vr = new ValueReference<List<?>>(G2S2RODao.getAppConfigList(key, clazz));
            cacheObjectList.put(key, vr);
        } else {
            vr = (ValueReference<List<?>>) cacheObjectList.get(key);
        }
        return vr.value == null ? null : (List<T>) vr.value;
    }

    static class ValueReference<T> {
        T value;

        ValueReference(T value) {
            this.value = value;
        }
    }
}
