package oih.config;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import amazon.platform.config.AppConfig;
import amazon.platform.config.AppConfigException;

/**
 * Implementation of Config that wraps {@link amazon.platform.config.AppConfig}
 * from JavaCore. It assumes that AppConfig has already been initialized at 
 * app startup.
 * 
 * NOTE: After unit-testing, I find that AppConfig doesn't exactly behave
 * as documented. See the TestBrazilConfig unit test for details. (e.g.
 * findInteger, findString... don't throw exception for lists & maps. They
 * just return null). 
 * 
 * @author svisvan
 *
 */
public class BrazilConfig extends ConfigBase {

	/**
	 * Construct a new wrapper for AppConfig.
	 * 
	 * @throws ConfigException if AppConfig is not initialized
	 */
	BrazilConfig() {
		if (!AppConfig.isInitialized())
			throw new ConfigException("AppConfig is not yet initialized !!");
	}
	
	/**
	 * See {@link oih.config.Config}
	 */
	public String findString(String key) {
		String result = null;
		try {
			result = AppConfig.findString(key);
		} catch (AppConfigException e) {
			throw new ConfigException(e);
		}
		return result;
	}
	
	/**
	 * See {@link oih.config.Config}
	 */
	public Boolean findBoolean(String key) {
		Boolean result = null;
		try {
			result = AppConfig.findBoolean(key);
		} catch (AppConfigException e) {
			throw new ConfigException(e);
		}
		return result;
	}

	/**
	 * See {@link oih.config.Config}
	 */
	public Double findDouble(String key) {
		Double result = null;
		try {
			result = AppConfig.findDouble(key);
		} catch (AppConfigException e) {
			throw new ConfigException(e);
		}
		return result;
	}

	/**
	 * See {@link oih.config.Config}
	 */
	public Integer findInteger(String key) {
		Integer result = null;
		try {
			result = AppConfig.findInteger(key);
		} catch (AppConfigException e) {
			throw new ConfigException(e);
		}
		return result;
	}

	/**
	 * See {@link oih.config.Config}
	 */
	public List<?> findList(String key) {
		return AppConfig.findVector(key);
	}

	/**
	 * See {@link oih.config.Config}
	 */
	public Map<?,?> findMap(String key) {
		return AppConfig.findMap(key);
	}

	/**
	 * See {@link oih.config.Config}
	 */
	public Object findObject(String key) {
		return AppConfig.findObject(key);
	}

	/**
	 * See {@link oih.config.Config}
	 */
	public Map<String, Object> findObjectsByPrefix(String keyPrefix) {
		return customCast(AppConfig.findObjectsByPrefix(keyPrefix));
	}

	
	/**
	 * See {@link oih.config.Config}
	 */
	public Map<String, Object> findObjects(String key) {
		return customCast(AppConfig.findObjects(key));
	}
	
	
	/**
	 * Does a shallow copy of the input map to a Map<String,Object>.
	 * Checks that keys are String's.
	 * @param map some map
	 * @return map of String -> Object
	 */
	private Map<String,Object> customCast(Map<?,?> map) {
		Map<String,Object> result = new HashMap<String,Object>();
		for (Map.Entry<?, ?> entry : map.entrySet()) {
			Object key = entry.getKey();
			Object value = entry.getValue();
			if (key instanceof String)
				result.put((String)key, value);
			else
				throw new ConfigException("Found non-String key in AppConfig: " + key);
		}
		return result;
	}

    @Override
    public String getDomain() {
        return AppConfig.getDomain();
    }

    @Override
    public String getMachine() {
        return AppConfig.getMachine();
    }

    @Override
    public String getRealmName() {
        return AppConfig.getRealm().name();
    }

    @Override
    public String[] getArguments() {
        return AppConfig.getArguments();
    }

    /**
     * 
     * @deprecated findObject
     *  this method only support in G2S2Config
     */
    @Override
    public <T> T findObject(String key, Class<T> clazz) {
        throw new UnsupportedOperationException("can't support this method");
    }

    /**
     * 
     * @deprecated findObject
     *  this method only support in G2S2Config
     */
    @Override
    public void reloadConfig() {
        throw new UnsupportedOperationException("can't support this method");
    }

    /**
     * 
     * @deprecated findObject
     *  this method only support in G2S2Config
     */
    @Override
    public <T> List<T> findList(String key, Class<T> clazz){
        throw new UnsupportedOperationException("can't support this method");
    }
}
