package oih.config;

import java.util.List;
import java.util.Map;

import oih.config.ConfigException;

/**
 * The Config interface provides methods for looking up configuration
 * values via keys. Implementors will have different ways for storing
 * the key-value configuration.
 * 
 * This interface provides a subset of AppConfig's accessors and is 
 * meant to decouple our code from AppConfig
 * 
 * @author svisvan
 *
 */
public interface Config {

	/**
	 * Retrieve the string value for the specified key.
	 * 
	 * @param key the key of the value to lookup.
	 * @return the configured value, or null otherwise.
	 * @throws ConfigException if the value found is not a string.
	 */
	public String findString(String key);

	
	/**
	 * Retrieve the integer value for the specified key.
	 * 
	 * @param key the key of the value to lookup.
	 * @return the configured value, or null otherwise.
	 * @throws ConfigException if the value found is not an integer.
	 */
	public Integer findInteger(String key);

	
	/**
	 * Retrieve the integer value/default value for the specified key.
	 * 
	 * @param key the key of the value to lookup.
	 * @param defaultValue default value if no key found
	 * @return the configured value or the default
	 * @throws ConfigException if the value found is not an integer
	 */
	public Integer findInteger(String key, int defaultValue);

	
	/**
	 * Retrieve the double value for the specified key.
	 * 
	 * @param key the key of the value to lookup.
	 * @return the configured value, or null otherwise.
	 * @throws ConfigException if the value found is not a double
	 */
	public Double findDouble(String key);

	
	/**
	 * Retrieve the double value/default value for the specified key.
	 * 
	 * @param key the key of the value to lookup.
	 * @param defaultValue default value if no key found
	 * @return the configured value or the default
	 * @throws ConfigException if the value found is not an double
	 */
	public Double findDouble(String key, double defaultValue);

	
	/**
	 * Retrieve the boolean value for the specified key.
	 * 
	 * @param key the key of the value to lookup.
	 * @return the configured value, or null otherwise.
	 * @throws ConfigException if the value found is not a boolean
	 */
	public Boolean findBoolean(String key);

	
	/**
	 * Retrieve the boolean value/default value for the specified key.
	 * 
	 * @param key the key of the value to lookup.
	 * @param defaultValue default value if no key found
	 * @return the configured value or the default
	 * @throws ConfigException if the value found is not an boolean
	 */
	public Boolean findBoolean(String key, boolean defaultValue);

	
	/**
	 * Retrieve the value for the specified key. Possible types for the Object
	 * returned are String, List and Map.
	 * 
	 * @param key the key of the value to lookup.
	 * @return the configured value, or null otherwise.
	 */
	public Object findObject(String key);

	
	/**
	 * Retrieve the List value for the specified key.
	 * 
	 * @param key the key of the value to lookup.
	 * @return the configured value, or null otherwise.
	 * @throws ConfigException if the value found is not a List
	 */
	public List<?> findList(String key);

	
	/**
	 * Retrieve the Map value for the specified key.
	 * 
	 * @param key the key of the value to lookup.
	 * @return the configured value, or null otherwise.
	 * @throws ConfigException if the value found is not a Map.
	 */
	public Map<?, ?> findMap(String key);

	/**
	 * Retrieve the object for the specified key by specified class.
	 * 
	 * @param key
	 * @param clazz
	 * @return the configured value, or null otherwise
	 */
    public <T> T findObject(String key, Class<T> clazz);
    
    /**
     * Retrieve the object for the specified key by specified class.
     * 
     * @param key
     * @param clazz
     * @return the list of configured value, or null otherwise
     */
    public <T> List<T> findList(String key, Class<T> clazz);
    
    /**
     * reload all config into app cache
     */
    public void reloadConfig();
        
	/**
	 * Construct Map of configuration values from multiple values that match a
	 * key. Key can contain asterisk segments that match any entry, segments are
	 * separated by periods. Single "*" matches single segment but not multiple
	 * ones.
	 * 
	 * For the following example config:
	 * 
	 * <pre>
	 * q
	 * *.*.foo.a = &quot;a&quot;;
	 * *.*.foo.b = &quot;b&quot;;
	 * *.*.foo.c.d = &quot;c.d&quot;;
	 * *.*.foo.c.e = &quot;c.e&quot;;
	 * </pre>
	 * 
	 * call findObjects("foo.*") returns the following map: {foo.a="a",
	 * foo.b="b"}
	 * 
	 * call findObjects("foo.*.*") returns the following map: {foo.c.d="c.d",
	 * foo.c.e="c.e"}
	 * 
	 * @param key
	 *            the key of the value to lookup. Can include "*" segments.
	 * @return Map with configuration values as map values and config keys as
	 *         map keys.
	 */
	public Map<String, Object> findObjects(String key);

	/**
     * Construct Map of configuration values from multiple values that match a key prefix.
     * Prefix should consist of entire segments, segments are separated by periods. 
     *  
     * For the following example config:
     * <pre>
     * *.*.foo.a = "a";
     * *.*.foo.b = "b";
     * *.*.foo.c.d = "c.d";
     * *.*.foo.c.e = "c.e";
     * </pre>
     * call <code> findObjectsByPrefix("foo") </code> returns the following map:
     * <code> {foo.a="a", foo.b="b", foo.c.d="c.d", foo.c.e="c.e"} </code>
     * 
     * call <code>findObjectByPrefix("fo")</code> returns empty map as "fo" doesn't match entire segment
     * 
     * @param keyPrefix the prefix of the key values to lookup. Should consist of entire segments.
     * @return Map with configuration values as map values and config keys as map keys.
     */
	public Map<String, Object> findObjectsByPrefix(String keyPrefix);
	
	/**
	 * Get the application's domain
	 * @return the application's domain
	 */
	public String getDomain();
	
	/**
	 * Get the application's realm name.
	 * 
	 * This method returns realm name, rather than a realm object, because
	 * the Realm class doesn't have a public constructor.
	 * @return the application's realm name
	 */
	public String getRealmName();

	/**
	 * Get the name of the host.
	 * @return the name of the host this is running on
	 */
	public String getMachine();

	/**
	 * Get the configuration arguments
	 * @return the configuration arguments
	 */
	public String[] getArguments();

}