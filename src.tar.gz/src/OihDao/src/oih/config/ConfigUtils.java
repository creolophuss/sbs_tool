package oih.config;

import java.util.List;

import java.util.Arrays;

import com.google.common.collect.Lists;

public class ConfigUtils {
    
    private final static List<String> ALL_MATCHER = Arrays.asList("*", "-1", "ALL", "all");
    private final static String NOT = "!=";
    
    public static boolean contains(List<String> glList, String gl){        
        if(glList == null || glList.isEmpty()){
            return false;
        }        
        for(String all : ALL_MATCHER ){
            if(glList.contains(all)){
                return true;
            }
        }
        List<String> excludedGls = Lists.newArrayList();
        for(String glExpression : glList){
            if(glExpression.startsWith(NOT)){
                String excludedGl = glExpression.substring(NOT.length());
                excludedGls.add(excludedGl);
            }
        }
        if(excludedGls.isEmpty()){
            return glList.contains(gl);
        }else{
            if(excludedGls.size()!= glList.size()){
                throw new RuntimeException("all elements should start with '"+ NOT + "' for excluded config");
            }
            return !excludedGls.contains(gl);
        }        
    }
        
    public static boolean configContainsGl(String configKey, String gl){
        @SuppressWarnings("unchecked")
        List<String> glList = (List<String>)(ConfigFactory.getDefaultConfig().findList(configKey));
        return contains(glList, gl);
    }

}
