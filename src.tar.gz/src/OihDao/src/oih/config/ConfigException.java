package oih.config;


/**
 * Special exception type thrown by Config API. Its
 * extends {@link java.lang.RuntimeException}
 * 
 * @author svisvan
 *
 */
public class ConfigException extends RuntimeException {
	private static final long serialVersionUID = 1L;

	public ConfigException() {
	}

	public ConfigException(String msg) {
		super(msg);
	}

	public ConfigException(Throwable throwable) {
		super(throwable);
	}

	public ConfigException(String msg, Throwable throwable) {
		super(msg, throwable);
	}
}
