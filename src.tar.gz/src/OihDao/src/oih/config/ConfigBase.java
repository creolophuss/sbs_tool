package oih.config;



/**
 * Super-class for Config implementors that provides
 * some common methods
 *  
 * @author svisvan
 *
 */
abstract class ConfigBase implements Config {

	/**
	 * See {@link oih.config.Config}
	 */
	public Integer findInteger(String key, int defaultValue) {
		Integer value = findInteger(key);
		return (value != null) ? value : defaultValue;
	}

	/**
	 * See {@link oih.config.Config}
	 */
	public Double findDouble(String key, double defaultValue) {
		Double value = findDouble(key);
		return (value != null) ? value : defaultValue;
	}

	/**
	 * See {@link oih.config.Config}
	 */
	public Boolean findBoolean(String key, boolean defaultValue) {
		Boolean value = findBoolean(key);
		return (value != null) ? value : defaultValue;
	}
}
