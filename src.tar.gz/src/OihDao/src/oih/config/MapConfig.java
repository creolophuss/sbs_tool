package oih.config;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import oih.config.ConfigBase;
import oih.config.ConfigException;

/**
 * Implementation of Config that looks up a map for its values
 * 
 * @author svisvan
 * 
 */
class MapConfig extends ConfigBase {
    private final Map<String, Object> map;
    private static Pattern validKeyPattern = null;

    private String domain = null;
    private String realmName = null;
    private String machine = null;
    private String[] arguments;

    /**
     * Construct a new instance backed by the given map. The values of the map must be instances of String's, Integer's,
     * Double's, List's or Map's. The keys must be strings of the form A[.A]* where A = [a-zA-Z_0-9]+
     * 
     * @param map
     *            Map that will be used for this Config
     * @throws ConfigException
     *             Thrown if a key is not of correct format or if the value is not one of the acceptable types
     */
    MapConfig(Map<String, Object> map) {
        if (validKeyPattern == null)
            validKeyPattern = Pattern.compile("\\w+(\\.\\w+)*");
        for (Map.Entry<String, Object> entry : map.entrySet()) {
            if (!validKeyPattern.matcher(entry.getKey()).matches())
                throw new ConfigException("Format of key is incorrect: " + entry.getKey());

            Object value = entry.getValue();
            if (value instanceof String || value instanceof Integer || value instanceof Double
                    || value instanceof Boolean || value instanceof List<?> || value instanceof Map<?, ?>)
                continue;
            else
                throw new ConfigException("Value for key '" + entry.getKey()
                        + "' is not a String/Integer/Double/Boolean/List/Map");
        }
        this.map = map;
    }

    /**
     * Returns value for 'key' from map. Also ensures that the value found is of type 'type'
     * 
     * @param key
     *            Key to look up
     * @param type
     *            Type we expect
     * @return value found or null if key is not present
     * @throws ConfigException
     *             if the value found is not of required type
     */
    private Object getAndCheckType(String key, Class<?> type) {
        if (!map.containsKey(key))
            return null;

        Object value = map.get(key);
        if (type.isInstance(value))
            return value;
        else
            throw new ConfigException("Value for '" + key + "' is not a " + type);
    }

    /**
     * See {@link oih.config.Config}
     */
    @Override
    public String findString(String key) {
        return (String) getAndCheckType(key, String.class);
    }

    /**
     * See {@link oih.config.Config}
     */
    @Override
    public Integer findInteger(String key) {
        return (Integer) getAndCheckType(key, Integer.class);
    }

    /**
     * See {@link oih.config.Config}
     */
    @Override
    public Double findDouble(String key) {
        return (Double) getAndCheckType(key, Double.class);
    }

    /**
     * See {@link oih.config.Config}
     */
    @Override
    public Boolean findBoolean(String key) {
        return (Boolean) getAndCheckType(key, Boolean.class);
    }

    /**
     * See {@link oih.config.Config}
     */
    @Override
    public Object findObject(String key) {
        return map.get(key);
    }

    /**
     * See {@link oih.config.Config}
     */
    @Override
    public List<?> findList(String key) {
        if (!map.containsKey(key))
            return null;

        Object value = map.get(key);
        if (value instanceof List<?>)
            return (List<?>) value;
        else
            throw new ConfigException("Value for '" + key + "' is not a list");
    }

    /**
     * See {@link oih.config.Config}
     */
    @Override
    public Map<?, ?> findMap(String key) {
        if (!map.containsKey(key))
            return null;

        Object value = map.get(key);
        if (value instanceof Map<?, ?>)
            return (Map<?, ?>) value;
        else
            throw new ConfigException("Value for '" + key + "' is not a map");
    }

    /**
     * See {@link oih.config.Config}
     */
    @Override
    public Map<String, Object> findObjects(String key) {
        // assuming key follows valid syntax here
        String searchRegex = key.replace("*", "\\w+").replace(".", "\\.");
        Pattern searchPattern = Pattern.compile(searchRegex);

        Map<String, Object> result = new HashMap<String, Object>();
        for (Map.Entry<String, Object> entry : map.entrySet())
            if (searchPattern.matcher(entry.getKey()).matches())
                result.put(entry.getKey(), entry.getValue());
        return result;
    }

    /**
     * See {@link oih.config.Config}
     */
    @Override
    public Map<String, Object> findObjectsByPrefix(String keyPrefix) {
        Map<String, Object> result = new HashMap<String, Object>();
        String keyPrefixDot = keyPrefix + ".";
        for (Map.Entry<String, Object> entry : map.entrySet()) {
            String keyDot = entry.getKey() + ".";
            if (keyDot.startsWith(keyPrefixDot))
                result.put(entry.getKey(), entry.getValue());
        }
        return result;
    }

    @Override
    public void reloadConfig() {
    }
    
    @Override
    public String getDomain() {
        return this.domain;
    }

    @Override
    public String getRealmName() {
        return this.realmName;
    }

    public void setDomain(String domain) {
        this.domain = domain;
    }

    public void setRealmName(String realmName) {
        this.realmName = realmName;
    }

    @Override
    public String getMachine() {
        return machine;
    }

    public void setMachine(String machine) {
        this.machine = machine;
    }

    @Override
    public String[] getArguments() {
        return arguments;
    }

    public void setArguments(String[] arguments) {
        this.arguments = arguments;
    }

    @SuppressWarnings("unchecked")
    @Override
    public <T> T findObject(String key, Class<T> clazz) {
        if (!map.containsKey(key))
            return null;

        Object value = map.get(key);
        if (clazz.isAssignableFrom(value.getClass()))
            return (T) value;
        else
            throw new ConfigException("Value for '" + key + "' is not a object");
    }

    @SuppressWarnings("unchecked")
    @Override
    public <T> List<T> findList(String key, Class<T> clazz){
        if (!map.containsKey(key))
            return null;

        @SuppressWarnings("rawtypes")
        List value = (List)map.get(key);
        if (value.size() == 0){
            return value;
        }
        if (clazz.isAssignableFrom(value.get(0).getClass()))
            return value;
        else
            throw new ConfigException("Value for '" + key + "' is not a object");
    }
}
