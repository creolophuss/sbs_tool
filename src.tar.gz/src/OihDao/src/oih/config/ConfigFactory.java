package oih.config;

import java.util.Map;

import oih.config.ConfigProxy;

import org.apache.log4j.Logger;

import amazon.platform.config.AppConfig;

/**
 * Factory for instantiating Config objects.
 * 
 * @author svisvan
 * 
 */
public class ConfigFactory {
    private static Logger log = Logger.getLogger(ConfigFactory.class);
    private static Config mapConfig = null;
    private static String realm = null;
    private static String domain = null;
    private static volatile ConfigProxy configProxy = null;

    /**
     * Get current default configuration. By default values from AppConfig will be used. For testing or other purposes,
     * configuration from a map can be used be calling useConfigFrom()
     * 
     * @return Config representing current application configuration
     */
    public static Config getDefaultConfig() {
        if (mapConfig == null) {
            log.debug("brazil-config will be used for configuration");
            if (configProxy == null) {
                synchronized (ConfigFactory.class) {
                    if(configProxy == null){
                        configProxy = new ConfigProxy();
                    }
                }
            }
            return configProxy;
        } else {
            //log.debug("Custom map being used for configuration");
            return mapConfig;
        }
    }

    public static String getRealm() {
        if (realm == null)
            return AppConfig.getRealm().name();
        return realm;
    }

    public static void setRealmForTest(String testRealm) {
        realm = testRealm;
    }
    
    public static String getDomain() {
        if (domain == null)
            return AppConfig.getDomain();
        return domain;
    }

    /**
     * @deprecated Use Force use of configuration from the given map.
     * @param map
     *            Configuration key-value pairs
     */
    public static void useConfigFrom(Map<String, Object> map) {
        log.debug("Updating map used for configuration");
        mapConfig = new MapConfig(map);
    }

    public static void useConfigFrom(final String domain, String realmName, Map<String, Object> map) {
        log.debug("Updating map used for configuration");
        MapConfig tmp = new MapConfig(map);
        tmp.setDomain(domain);
        tmp.setRealmName(realmName);
        mapConfig = tmp;
    }

    public static void useConfig(Config c) {
        mapConfig = c;
    }

    /**
     * Force use of settings from brazil-config
     */
    public static void useBrazilConfig() {
        mapConfig = null;
    }
}
