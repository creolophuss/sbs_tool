package oih.config;

import java.util.List;
import java.util.Map;

public class ConfigProxy extends ConfigBase {

    private BrazilConfig brazilConfig;
    private G2S2Config g2s2Config;
    
    ConfigProxy(){
        brazilConfig = new BrazilConfig();
        g2s2Config = new G2S2Config();
    }

    /**
     * See {@link oih.config.Config}
     */
    @Override
    public String findString(String key) {
        String ret = brazilConfig.findString(key);
        if (ret == null || ret.isEmpty()){
            return g2s2Config.findString(key);
        }
        return ret;
    }

    /**
     * See {@link oih.config.Config}
     */
    @Override
    public Integer findInteger(String key) {
        Integer ret = brazilConfig.findInteger(key);
        if (ret == null){
            return g2s2Config.findInteger(key);
        }
        return ret;
    }

    /**
     * See {@link oih.config.Config}
     */
    @Override
    public Double findDouble(String key) {
        Double ret = brazilConfig.findDouble(key);
        if (ret == null){
            return g2s2Config.findDouble(key);
        }
        return ret;
    }

    /**
     * See {@link oih.config.Config}
     */
    @Override
    public Boolean findBoolean(String key) {
        Boolean ret = brazilConfig.findBoolean(key);
        if (ret == null){
            return g2s2Config.findBoolean(key);
        }
        return ret;
    }

    /**
     * This method ONLY support BrazilConfig
     * See {@link oih.config.Config}
     */
    @Override
    public Object findObject(String key) {
        return brazilConfig.findObject(key);
    }

    /**
     * See {@link oih.config.Config}
     */
    @Override
    public List<?> findList(String key) {
        List<?> ret = brazilConfig.findList(key);
        if (ret == null){
            return g2s2Config.findList(key);
        }
        return ret;
    }

    /**
     * See {@link oih.config.Config}
     */
    @Override
    public Map<?, ?> findMap(String key) {
        Map<?, ?> ret = brazilConfig.findMap(key);
        if (ret == null){
            return g2s2Config.findMap(key);
        }
        return ret;
    }

    /**
     * This method ONLY support BrazilConfig
     * See {@link oih.config.Config}
     */
    @Override
    public Map<String, Object> findObjects(String key) {
        return brazilConfig.findObjects(key);
    }

    /**
     * This method ONLY support BrazilConfig
     * See {@link oih.config.Config}
     */
    @Override
    public Map<String, Object> findObjectsByPrefix(String keyPrefix) {
        return brazilConfig.findObjectsByPrefix(keyPrefix);
    }

    /**
     * See {@link oih.config.Config}
     */
    @Override
    public String getDomain() {
        String ret = brazilConfig.getDomain();
        if (ret == null){
            return g2s2Config.getDomain();
        }
        return ret;
    }

    /**
     * See {@link oih.config.Config}
     */
    @Override
    public String getRealmName() {
        String ret = brazilConfig.getRealmName();
        if (ret == null){
            return g2s2Config.getRealmName();
        }
        return ret;
    }

    /**
     * See {@link oih.config.Config}
     */
    @Override
    public String getMachine() {
        String ret = brazilConfig.getMachine();
        if (ret == null){
            return g2s2Config.getMachine();
        }
        return ret;
    }

    /**
     * See {@link oih.config.Config}
     */
    @Override
    public String[] getArguments() {
        String[] ret = brazilConfig.getArguments();
        if (ret == null){
            return g2s2Config.getArguments();
        }
        return ret;
    }

    /**
     * Retrieve the value for the specified key. This method ONLY support G2S2Config
     * 
     * @param key the key of the value to lookup.
     * @return the configured value, or null otherwise.
     */
    @Override
    public <T> T findObject(String key, Class<T> clazz){
        return g2s2Config.findObject(key, clazz);
    }

    /**
     * See {@link oih.config.Config}
     */
    @Override
    public void reloadConfig() {
        g2s2Config.reloadConfig();
    }

    /**
     * See {@link oih.config.Config}
     */
    @Override
    public <T> List<T> findList(String key, Class<T> clazz) {
        return g2s2Config.findList(key, clazz);
    }

    /**
     * @param brazilConfig the brazilConfig to set
     */
    public void setBrazilConfig(BrazilConfig brazilConfig) {
        this.brazilConfig = brazilConfig;
    }

    /**
     * @param g2s2Config the g2s2Config to set
     */
    public void setG2s2Config(G2S2Config g2s2Config) {
        this.g2s2Config = g2s2Config;
    }
    
}
