package com.amazon.oih.common;

import java.io.IOException;
import java.util.List;

public interface KeyValueDao<K, V> {
    public V getValue4Key(K key) throws IOException;
    
    public List<V> batchGet(List<K> keys) throws IOException;
    
    public void batchSave(List<V> values) throws IOException;
}
