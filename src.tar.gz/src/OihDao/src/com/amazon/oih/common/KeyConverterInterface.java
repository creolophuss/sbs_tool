package com.amazon.oih.common;

import java.util.List;


public interface KeyConverterInterface<T> {
    public List<String> convertToAsinIogRowkey(T orgKey);
    public List<String> convertToAsinScopeRowkey(T orgKey);
    public List<String> convertToAsinMarketplaceIdRowkey(T orgKey);
    public List<String> convertToAsinCountryIdRowkey(T orgKey);
}
