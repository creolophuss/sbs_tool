package com.amazon.oih.common;

import java.util.Map;

public interface KVObjectFactoryInterface<T>{
    public T create(Map<String, String> fieldValueMap);
}
