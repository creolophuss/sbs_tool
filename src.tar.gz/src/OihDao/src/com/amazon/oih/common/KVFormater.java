package com.amazon.oih.common;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;



public class KVFormater<T> {
    private final Class<T> classObj;
    
    public KVFormater(Class<T> classObj){
        this.classObj = classObj;
    }
    
    public String formatForReview(List<PairBase<TrackableKVObj<T>, Boolean>> pairList){
        String content = format(pairList, "<td>", "<td style=\"color:red\">", "</td>", "<tr>", "<tr style=\"color:red\">", "</tr>\n");
        return "<table border = 1>" + content + "</table>";
    }
    
    public String formatForEdit(List<T> formatableList){
        List<PairBase<TrackableKVObj<T>, Boolean>> pairList = new ArrayList<PairBase<TrackableKVObj<T>, Boolean>>();
        for (T t : formatableList){
            pairList.add(PairBase.pair(new TrackableKVObj<T>(t), false));
        }
        String formatedContent = format(pairList, ",", ",", "", "", "", "\n");
        formatedContent = formatedContent.replaceFirst(",", "");
        return formatedContent.replaceAll("\n,", "\n");
    }
    
    String format(List<PairBase<TrackableKVObj<T>, Boolean>> pairList, String preElement, String preElement4change, String postElement, String preLine,
                         String preLineForInsert, String postLine){
        StringBuilder lineBuilder = new StringBuilder();
        lineBuilder.append(getHeader(preElement, preElement4change, postElement, preLine, preLineForInsert, postLine));      
        for (PairBase<TrackableKVObj<T>, Boolean> formatable : pairList){
            Map<String, PairBase<Object, Object>> changes = formatable.getFirst().getChanges();
            TrackableKVObj<T> value = formatable.getFirst();
            Boolean isInsert = formatable.getSecond();
            
            lineBuilder.append(toFormatStr(getHeaderColumns(classObj), value.getKeyValues(), changes, preElement, preElement4change, postElement,
                    preLine, preLineForInsert, postLine, isInsert));
        }
        return lineBuilder.toString();
    }
    
    private String getHeader(String preElement, String preElement4change, String postElement, String preLine, String preLineForInsert, String postLine){
        List<String> keys = getHeaderColumns(classObj);
        Map<String, Object> key2keyMap = new HashMap<String, Object>();
        for (String key : keys){
            key2keyMap.put(key, key);
        }
        return toFormatStr(keys, key2keyMap, null, preElement, preElement4change, postElement, preLine, preLineForInsert, postLine, false);
    }
    
    private String toFormatStr(List<String> keys,  Map<String, Object> elementsMap, Map<String, PairBase<Object, Object>> changes, String preElement, String preElement4change, 
                           String postElement, String preLine, String preLineForInsert, String postLine, boolean insert){
        StringBuilder lineBuilder = new StringBuilder();
        if (insert){
            lineBuilder.append(preLineForInsert);
        } else {
            lineBuilder.append(preLine);
        }
        
        for (String key : keys){
            if (!insert && changes!= null && changes.containsKey(key)){
                PairBase<Object, Object> change = changes.get(key);
                lineBuilder.append(preElement4change).append("" + change.getSecond() + "=>" + change.getFirst()).append(postElement);
            } else {
                lineBuilder.append(preElement).append("" + elementsMap.get(key)).append(postElement);
            }
        }
        lineBuilder.append(postLine);
        return lineBuilder.toString();
    }
    
    public static <T> List<String> getHeaderColumns(Class<T> classObj){
        FileColumnNames columnNames = classObj.getAnnotation(FileColumnNames.class);
        if (columnNames == null){
        	throw new RuntimeException("Class:" + classObj.getName() + " do not have Annotation of FileColumnNames");
        }
        return Arrays.asList(columnNames.value());
    }
    
    @Retention(RetentionPolicy.RUNTIME)
    @Target(ElementType.TYPE)
    public static @interface FileColumnNames {
        String[] value();    
    }
}
