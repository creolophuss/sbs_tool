package com.amazon.oih.common;

import java.util.Map;

import com.amazon.oih.common.KeyValueBase;


public class KVObjectFactory<T> implements KVObjectFactoryInterface<T>{ 
    private Class<T> classObj;
    public KVObjectFactory(Class<T> classObj){
        this.classObj = classObj;
    }
    
    public T create(Map<String, String> fieldValueMap) {
        KeyValueBase<T> kv = KeyValueBase.createBlankObject(classObj);
        for (Map.Entry<String, String> entry: fieldValueMap.entrySet()){
            String fieldName = entry.getKey();
            String value = entry.getValue();
            kv.update(fieldName, value);
        }
        return kv.getStored();
    }
}
