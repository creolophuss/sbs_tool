package com.amazon.oih.common;

import java.util.List;

public enum RowKeyType {
    ASIN_SCOPE {
        @Override
        public <T> List<String> getKey(KeyConverterInterface<T> converter, T t) {
            return converter.convertToAsinScopeRowkey(t);
        }
    }, ASIN_IOG {
        @Override
        public <T> List<String> getKey(KeyConverterInterface<T> converter, T t) {
            return converter.convertToAsinIogRowkey(t);
        }
    }, ASIN_MARKETPLACE {
        @Override
        public <T> List<String> getKey(KeyConverterInterface<T> converter, T t) {
            return converter.convertToAsinMarketplaceIdRowkey(t);
        }
    }, ASIN_COUNTRY {
        @Override
        public <T> List<String> getKey(KeyConverterInterface<T> converter, T t) {
            return converter.convertToAsinCountryIdRowkey(t);
        }
    };
    
    public abstract <T> List<String> getKey(KeyConverterInterface<T> converter, T t);
}
