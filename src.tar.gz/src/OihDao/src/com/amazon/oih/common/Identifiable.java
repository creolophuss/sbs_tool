package com.amazon.oih.common;

public interface Identifiable {
    public String getIdentity(); 
}
