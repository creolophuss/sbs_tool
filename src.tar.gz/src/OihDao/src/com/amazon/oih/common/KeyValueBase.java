package com.amazon.oih.common;

import java.lang.annotation.ElementType;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.lang.StringUtils;

import com.google.common.base.Objects;


/**
 * If you want to update the Obj by String, and your <T> has Date field, then your String format must be:"yyyy-MM-dd"
 * @author jialei
 *
 * @param <T>
 * TODO: make date type as a parameter.
 */
public class KeyValueBase<T> {
    private final static String DEFAULT_DATE_FORMAT = "yyyy-MM-dd";
    private final T stored;
    private final Map<String, String> keyFieldMapping;
    private final static Map<Class<?>, Map<String, String>> keyFieldMappings = new ConcurrentHashMap<Class<?>, Map<String, String>>();
    
    public KeyValueBase(T t){
        stored = t;
        keyFieldMapping = Collections.unmodifiableMap(getKeyFieldMaps(t.getClass()));
    }
    
    private KeyValueBase(Class<T> classObj){
        try {
            stored = classObj.newInstance();
        } catch (Exception e) {
            throw new RuntimeException("Exception happened during instance creation:" + classObj.getName());
        } 
        keyFieldMapping = Collections.unmodifiableMap(getKeyFieldMaps(classObj));
    }
    
    static <T> KeyValueBase<T> createBlankObject(Class<T> classObj){
        return new KeyValueBase<T>(classObj);
    }
    
    public T getStored(){
        return stored;
    }
    
    public void updateBy(T newValues){
        for (Map.Entry<String, String> entry : keyFieldMapping.entrySet()){
            String fieldName = entry.getValue();
            String key = entry.getKey();
            try {
                Object oldV = PropertyUtils.getSimpleProperty(stored, fieldName);
                Object newV = PropertyUtils.getSimpleProperty(newValues, fieldName);
                if (!Objects.equal(oldV, newV)){
                    update(key, newV);
                }
            }catch(Exception e){
                throw new RuntimeException("Error occourred during update. ", e);
            }
        }
    }
    
    public void setKV4Column(T newValues, String key){
        String fieldName = keyFieldMapping.get(key);
        try {
            Object newV = PropertyUtils.getSimpleProperty(newValues, fieldName);
            update(key, newV);            
        }catch(Exception e){
            throw new RuntimeException("Error occourred during copyKV4Column. For column: " + fieldName 
                    + " for Class:" + stored.getClass().getCanonicalName(), e);
        }
    }
    
    public Map<String, Object> getKeyValues(){
        Map<String, Object> kvMap = new HashMap<String, Object>();
        for (Map.Entry<String, String> entry : keyFieldMapping.entrySet()){
            Object value = getValue(entry.getKey());
            kvMap.put(entry.getKey(), value);
        }
        return kvMap;
    }
    
    protected void update(String key, Object newV) {
        String fieldName = keyFieldMapping.get(key);
        try {
            if (newV != null){
                BeanUtilsFactory.getBeanUtils(DEFAULT_DATE_FORMAT).setProperty(stored, fieldName, newV);
            } else {
                PropertyUtils.setSimpleProperty(stored, fieldName, null);
            }
        } catch (Exception e) {
            throw new RuntimeException("Error occourred during update: " + fieldName , e);
        } 
    }
    
    protected Object getValue(String key){
        String fieldName = keyFieldMapping.get(key);
        Object value = null;
        try {
            value = PropertyUtils.getSimpleProperty(stored, fieldName);
        } catch(Exception e){
            throw new RuntimeException("Error occourred during get. ", e);
        }
        return value;
    }
    
    private static <T> Map<String, String> getKeyFieldMaps(Class<T> classObj){
        Map<String, String> keyFieldMapping = keyFieldMappings.get(classObj);
        if (keyFieldMapping == null){
            keyFieldMapping = findKeyValueFields(classObj);
            keyFieldMappings.put(classObj, keyFieldMapping);
        }
        
        return keyFieldMapping;
    }
    private static <T> Map<String, String> findKeyValueFields(Class<T> classObj){
        Map<String, String> keyFieldMap = new HashMap<String, String>();
        for (Field field : classObj.getDeclaredFields()){
            NamedValue nameAno = field.getAnnotation(NamedValue.class);
            if (nameAno == null){
                continue;
            }
            String key = getKey(field, nameAno);
            if (keyFieldMap.containsKey(key)){
                throw new RuntimeException("Duplicated NameValue:" + key + " for Class:" + classObj.getName());
            }
            keyFieldMap.put(key, field.getName());
        }
        return keyFieldMap;
    }
    
    private static String getKey(Field field, NamedValue nameAno){
        if (StringUtils.isBlank(nameAno.value())){
            return field.getName();
        }
        return nameAno.value();
    }
    
    public static <T> List<T> convertToStoredList(List<? extends KeyValueBase<T>> kVObjList){
        List<T> result = new ArrayList<T>();
        for (KeyValueBase<T> kVObj : kVObjList){
            result.add(kVObj.getStored());
        }
        return result;
    }
    
    @Retention(RetentionPolicy.RUNTIME)
    @Target(ElementType.FIELD)
    @Inherited
    public static @interface NamedValue {
        String value() default "";
    }
}
