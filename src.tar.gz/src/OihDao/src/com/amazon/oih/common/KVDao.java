package com.amazon.oih.common;

import java.util.Collection;
import java.util.List;

import com.amazon.oih.dao.exception.OihPersistenceException;

public interface KVDao<T extends Identifiable> {
    public List<T> loadAll(String realm) throws OihPersistenceException;
    public String getPhysicalId(T t);
    public void saveAll(Collection<T> all, Collection<T> changed) throws OihPersistenceException;
}
