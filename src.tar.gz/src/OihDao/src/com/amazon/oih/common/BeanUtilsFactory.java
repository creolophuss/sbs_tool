package com.amazon.oih.common;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.beanutils.BeanUtilsBean;
import org.apache.commons.beanutils.ConvertUtilsBean2;
import org.apache.commons.beanutils.PropertyUtilsBean;
import org.apache.commons.beanutils.converters.DateConverter;
import org.apache.commons.beanutils.converters.DateTimeConverter;

/**
 * BeanUtilsBean is not threadSafe, put it into ThreadLocal.
 * 
 * @author jialei
 * 
 */
public class BeanUtilsFactory {
    private static final String DEFAULT_FORMAT = "yyyyMMddHHmmssZ";
    private static final ThreadLocal<Map<String, BeanUtilsBean>> local = new ThreadLocal<Map<String, BeanUtilsBean>>();

    public static BeanUtilsBean getBeanUtils(String dateFormatStr) {
        Map<String, BeanUtilsBean> beanMap = local.get();
        if (beanMap == null) {
            beanMap = new HashMap<String, BeanUtilsBean>();
            local.set(beanMap);
        }
        BeanUtilsBean bean = beanMap.get(dateFormatStr);
        if (bean == null) {
            ConvertUtilsBean2 convertUtils = new ConvertUtilsBean2();
            DateTimeConverter dateConverter = new DateConverter(null);
            SimpleDateFormat format = new SimpleDateFormat(dateFormatStr);
            dateConverter.setPattern(format.toPattern());
            convertUtils.register(dateConverter, Date.class);
            beanMap.put(dateFormatStr, new BeanUtilsBean(convertUtils, new PropertyUtilsBean()));
        }

        return local.get().get(dateFormatStr);
    }
    
    public static BeanUtilsBean getBeanUtils() {
        return getBeanUtils(DEFAULT_FORMAT);
    }
}
