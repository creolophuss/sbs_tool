package com.amazon.oih.common;

import java.util.HashMap;
import java.util.Map;
import java.util.Stack;

import com.google.common.base.Objects;


public class TrackableKVObj<T> extends KeyValueBase<T>{
    private Map<String, ChangeHistory> changeMap = new HashMap<String, ChangeHistory>();
    
    public TrackableKVObj(T t) {
        super(t);
    }
    
    @Override
    public void update(String key, Object newV){
        Object oldV = getValue(key);
        if (!Objects.equal(oldV, newV)){
            recordChange(key, newV, oldV);
            super.update(key, newV);
        }
    }
    
    public void rollBackOneStep(String key) throws Exception{
        ChangeHistory changeRecord = changeMap.get(key);
        if (changeRecord != null){
            changeRecord.rollBack();
            Object preV = changeRecord.getLatestValue();
            super.update(key, preV);
        }
    }
    
    public void rollBackAllStep(String key){
        ChangeHistory changeRecord = changeMap.get(key);
        rollBackAllStep(key, changeRecord);
    }
    
    private void rollBackAllStep(String key, ChangeHistory changeRecord){
        if (changeRecord != null){
            changeRecord.rollBackAll();
            Object preV = changeRecord.getInitValue();
            super.update(key, preV);
        }
    }
    
    public void rollBackAll(){
        for (Map.Entry<String, ChangeHistory> entry : changeMap.entrySet()){
            rollBackAllStep(entry.getKey(), entry.getValue());
        }
    }
    
    private void recordChange(String key, Object newV, Object oldV){
        ChangeHistory change = changeMap.get(key);
        if (change == null){
            change = new ChangeHistory(oldV);
            changeMap.put(key, change);
        }
        change.addChange(newV);
    }
    
    public Map<String, PairBase<Object, Object>> getChanges(){
        Map<String, PairBase<Object, Object>> result = new HashMap<String, PairBase<Object, Object>>();
        for (Map.Entry<String, ChangeHistory> entry : changeMap.entrySet()){
            String key = entry.getKey();
            ChangeHistory changeRecord = entry.getValue();
            if (changeRecord.hasChange()){
                result.put(key, PairBase.pair(changeRecord.getLatestValue(), changeRecord.getInitValue()));
            }
        }
        return result;
    }
    
    public boolean isChanged(){
        for(ChangeHistory changeRecord : changeMap.values()){
            if (changeRecord.hasChange()){
                return true;
            }
        }
        return false;
    }

    private static class ChangeHistory{
        private Object initValue;
        private Stack<Object> changes = new Stack<Object>(); 
        ChangeHistory(Object initValue){
            this.initValue = initValue;
        }

        public Object getInitValue(){
            return initValue;
        }
        
        public void addChange(Object newV){
            changes.push(newV);
        }
        
        public Object getLatestValue(){
            if (changes.size() > 0){
                return changes.peek();
            } else {
                return initValue;
            }           
        }
        
        public void rollBack(){
            changes.pop();
        }
        
        public void rollBackAll(){
            changes.clear();
        }
        
        public boolean hasChange(){
            return changes.size() != 0;
        }
    }
}
