package com.amazon.oih.cbm.model;

import java.util.Map;

import com.amazon.oih.common.KVObjectFactory;

public class CalendarMarkdownHistoricDemandKVObjectFactory extends
		KVObjectFactory<CalendarMarkdownHistoricDemand> {

	public CalendarMarkdownHistoricDemandKVObjectFactory() {
		super(null);
	}
	
	@Override
    public CalendarMarkdownHistoricDemand create(Map<String, String> fieldValueMap) {
        CalendarMarkdownHistoricDemand demand = new CalendarMarkdownHistoricDemand(
        		fieldValueMap.get(CalendarMarkdownHistoricDemand.ASIN_FIELD)
        		, Long.valueOf(fieldValueMap.get(CalendarMarkdownHistoricDemand.MARKETPLACEID_FIELD))
        		, CalendarMarkdownHistoricDemand.parseDemands(fieldValueMap.get(CalendarMarkdownHistoricDemand.DEMAND_FIELD)));
        return demand;
    }
}
