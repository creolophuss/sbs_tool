package com.amazon.oih.cbm.model;

public interface AsinMarketplace {
	public String getAsin();
	public long getMarketplace();
}
