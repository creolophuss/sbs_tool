package com.amazon.oih.cbm.model;

import java.util.List;

import com.amazon.oih.common.KVFormater.FileColumnNames;
import com.amazon.oih.common.KeyValueBase.NamedValue;
import com.google.common.base.Function;
import com.google.common.collect.Lists;
import static com.amazon.oih.cbm.model.CalendarMarkdownHistoricDemand.*;

@FileColumnNames(value = {ASIN_FIELD, MARKETPLACEID_FIELD, DEMAND_FIELD})
public class CalendarMarkdownHistoricDemand{
	public static final String ASIN_FIELD = "ASIN";
	public static final String MARKETPLACEID_FIELD = "marketplaceid";
	public static final String DEMAND_FIELD = "demand";
	@NamedValue(ASIN_FIELD)
	private final String asin;
	@NamedValue(MARKETPLACEID_FIELD)
	private final Long marketplaceId;
	@NamedValue(DEMAND_FIELD)
	private List<Integer> demands;
	public static final String DEMAND_SEPARATOR = ",";
	
	public CalendarMarkdownHistoricDemand(String a, Long m, List<Integer> d) {
		asin = a;
		marketplaceId = m;
		demands = d;
	}
	
	public static List<Integer> parseDemands(String s) {
		List<Integer> demands = Lists.transform(Lists.newArrayList(s.split(",")), new Function<String, Integer>(){
            @Override
            public Integer apply(String input) {
                return Integer.parseInt(input.trim());
            }
        });
		return demands;
	}

	public String getAsin() {
		return asin;
	}

	public Long getMarketplaceId() {
		return marketplaceId;
	}

	public List<Integer> getDemands() {
		return demands;
	}

	public void setDemands(List<Integer> demands) {
		this.demands = demands;
	}

	@Override
	public String toString() {
		return "CalendarMarkdownHistoricDemand [asin=" + asin
				+ ", marketplaceId=" + marketplaceId + ", demands=" + demands
				+ "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((asin == null) ? 0 : asin.hashCode());
		result = prime * result + ((demands == null) ? 0 : demands.hashCode());
		result = prime * result
				+ ((marketplaceId == null) ? 0 : marketplaceId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CalendarMarkdownHistoricDemand other = (CalendarMarkdownHistoricDemand) obj;
		if (asin == null) {
			if (other.asin != null)
				return false;
		} else if (!asin.equals(other.asin))
			return false;
		if (demands == null) {
			if (other.demands != null)
				return false;
		} else if (!demands.equals(other.demands))
			return false;
		if (marketplaceId == null) {
			if (other.marketplaceId != null)
				return false;
		} else if (!marketplaceId.equals(other.marketplaceId))
			return false;
		return true;
	}
}
