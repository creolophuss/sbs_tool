 /**
  * Copyright (c) 2014 Amazon.com, Inc.  All rights reserved.
  * 
  * Owner: oih-cn@
  */
package com.amazon.oih.cbm.model;

import java.util.Date;

import com.amazon.oih.common.RowKeyBuildType;
import com.amazon.oih.common.RowKeyType;
import com.amazon.oih.dao.hbase.base.CommonKVHBaseDao.HTable;
import com.amazon.oih.dao.hbase.converter.Column;
import com.amazon.oih.dao.hbase.converter.RowKey;
import com.amazon.oih.dao.remotecat.RemoteCatValueObject;

/**
 * @author gaoxing
 *
 */
@RowKey({"asin", "marketplaceId"})
@RowKeyBuildType(RowKeyType.ASIN_MARKETPLACE)
@HTable(value = "Calender_Markdown_RemoteCat", columFamilyName = "CBMRC")
public class CalendarMarkdownRemoteCat {
    
    @Column(name = "asin", index = 0)
    private String asin;
    @Column(name = "color", index = 0)
    private String color = "";

    @Column(name = "parent_asin", index = 0)
    private String parentAsin; // store same with asin if no parent

    @Column(name = "marketplace_id", index = 0)
    private Long marketplaceId;
    
    @Column(name = "merchant_id", index = 0)
    private Long merchantId;

    @Column(name = "gl", index = 0)
    private Integer gl;
    @Column(name = "category", index = 0)
    private int category;
    @Column(name = "sub_category", index = 0)
    private int subcategory;

    @Column(name = "season_start_year", index = 0)
    private int seasonStartYear;
    @Column(name = "season_start_date", index = 0)
    private String seasonStartDate;
    @Column(name = "full_price_end_date", index = 0)
    private String fullPriceEndDate;
    @Column(name = "liquidate_eligible_date", index = 0)
    private String liquidateEligibleDate;

    @Column(name = "life_cycle_demand_type", index = 0)
    private String lifecycleDemandType;
    @Column(name = "life_cycle_supply_type", index = 0)
    private String lifecycleSupplyType;
    
    @Column(name = "seasons", index = 0)
    private String seasons;
    @Column(name = "brand_code", index = 0)
    private String brandCode;
    @Column(name = "title", index = 0)
    private String title;
    @Column(name = "site_launch_date", index = 0)
    private Date siteLaunchDate;
    
    @Column(name = "list_price", index = 0)
    private double listPrice;
    @Column(name = "list_price_with_tax", index = 0)
    private double listPriceWithTax;
    @Column(name = "base_price", index = 0)
    private double basePrice;
    
    public CalendarMarkdownRemoteCat(RemoteCatValueObject remoteCatValueObj) {
        this.asin = remoteCatValueObj.getAsin();
        this.marketplaceId = remoteCatValueObj.getMarketplace();
        this.merchantId = remoteCatValueObj.getMerchant();
        this.gl = remoteCatValueObj.getGl();
        this.category = remoteCatValueObj.getCategory();
        this.subcategory = remoteCatValueObj.getSubCategory();

        this.parentAsin = remoteCatValueObj.getParentAsin();
        this.color = remoteCatValueObj.getColor();

        this.seasonStartYear = remoteCatValueObj.getSeasonStartYear() == null ? 0 : Integer.valueOf(remoteCatValueObj
                .getSeasonStartYear());
        this.seasonStartDate = remoteCatValueObj.getSeasonStart();

        this.fullPriceEndDate = remoteCatValueObj.getFullPriceEnd();
        this.liquidateEligibleDate = remoteCatValueObj.getLiquidateDate();
        this.lifecycleDemandType = remoteCatValueObj.getDemandType();
        this.lifecycleSupplyType = remoteCatValueObj.getSupplyType();
        
        this.seasons = remoteCatValueObj.getSeasons();
        this.brandCode = remoteCatValueObj.getBrandCode();
        this.title = remoteCatValueObj.getTitle();
        this.siteLaunchDate = remoteCatValueObj.getSiteLaunchDate();
        this.listPrice = remoteCatValueObj.getListPrice();
        this.listPriceWithTax = remoteCatValueObj.getListPriceWithTax();
        this.basePrice = remoteCatValueObj.getBasePrice();
    }

    public String getAsin() {
        return asin;
    }
    public void setAsin(String asin) {
        this.asin = asin;
    }
    public String getColor() {
        return color;
    }
    public void setColor(String color) {
        this.color = color;
    }
    public String getParentAsin() {
        return parentAsin;
    }
    public void setParentAsin(String parentAsin) {
        this.parentAsin = parentAsin;
    }
    public Long getMarketplaceId() {
        return marketplaceId;
    }
    public void setMarketplaceId(Long marketplaceId) {
        this.marketplaceId = marketplaceId;
    }
    public Long getMerchantId() {
        return merchantId;
    }
    public void setMerchantId(Long merchantId) {
        this.merchantId = merchantId;
    }
    public Integer getGl() {
        return gl;
    }
    public void setGl(Integer gl) {
        this.gl = gl;
    }
    public int getCategory() {
        return category;
    }
    public void setCategory(int category) {
        this.category = category;
    }
    public int getSubcategory() {
        return subcategory;
    }
    public void setSubcategory(int subcategory) {
        this.subcategory = subcategory;
    }
    public Integer getSeasonStartYear() {
        return seasonStartYear;
    }
    public void setSeasonStartYear(Integer seasonStartYear) {
        this.seasonStartYear = seasonStartYear;
    }
    public String getSeasonStartDate() {
        return seasonStartDate;
    }
    public void setSeasonStartDate(String seasonStartDate) {
        this.seasonStartDate = seasonStartDate;
    }
    public String getFullPriceEndDate() {
        return fullPriceEndDate;
    }
    public void setFullPriceEndDate(String fullPriceEndDate) {
        this.fullPriceEndDate = fullPriceEndDate;
    }
    public String getLiquidateEligibleDate() {
        return liquidateEligibleDate;
    }
    public void setLiquidateEligibleDate(String liquidateEligibleDate) {
        this.liquidateEligibleDate = liquidateEligibleDate;
    }
    public String getLifecycleDemandType() {
        return lifecycleDemandType;
    }
    public void setLifecycleDemandType(String lifecycleDemandType) {
        this.lifecycleDemandType = lifecycleDemandType;
    }
    public String getLifecycleSupplyType() {
        return lifecycleSupplyType;
    }
    public void setLifecycleSupplyType(String lifecycleSupplyType) {
        this.lifecycleSupplyType = lifecycleSupplyType;
    }

    public String getSeasons() {
        return seasons;
    }

    public void setSeasons(String seasons) {
        this.seasons = seasons;
    }

    public String getBrandCode() {
        return brandCode;
    }

    public void setBrandCode(String brandCode) {
        this.brandCode = brandCode;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Date getSiteLaunchDate() {
        return siteLaunchDate;
    }

    public void setSiteLaunchDate(Date siteLaunchDate) {
        this.siteLaunchDate = siteLaunchDate;
    }

    public double getListPrice() {
        return listPrice;
    }

    public void setListPrice(double listPrice) {
        this.listPrice = listPrice;
    }

    public double getListPriceWithTax() {
        return listPriceWithTax;
    }

    public void setListPriceWithTax(double listPriceWithTax) {
        this.listPriceWithTax = listPriceWithTax;
    }

    public double getBasePrice() {
        return basePrice;
    }

    public void setBasePrice(double basePrice) {
        this.basePrice = basePrice;
    }

}
