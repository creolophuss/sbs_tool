package com.amazon.oih.utils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Utils {
    public static Map<Integer, List<String>> splitAsinIogList2AsinsMap(List<AsinIogPair> asinIogPairs) {
        Map<Integer, List<String>> iog2AsinsMap = new HashMap<Integer, List<String>>();
        for (AsinIogPair asinIog : asinIogPairs) {
            Integer key = Integer.valueOf(asinIog.getIog());
            List<String> asins = null;
            if (iog2AsinsMap.containsKey(key) == true) {
                asins = iog2AsinsMap.get(key);
            } else {
                asins = new ArrayList<String>();
            }
            if (asins.contains(asinIog.getAsin()) == false) {
                asins.add(asinIog.getAsin());
                iog2AsinsMap.put(key, asins);
            }
        }
        return iog2AsinsMap;
    }
    
    public static <T> List<T> collapseNestedList(List<List<T>> nestedList){
        List<T> result = new ArrayList<T>();
        for (List<T> subList : nestedList){
            if (subList != null){
                result.addAll(subList);
            }
        }
        return result;
    }   
    
    @SuppressWarnings("unchecked")
    public static <T> List<List<T>> toNestedList(List<T> list){
        List<List<T>> result = new ArrayList<List<T>>();
        for (T obj : list){
            result.add(Arrays.asList(obj));
        }
        return result;
    }
}
