 /**
  * Copyright (c) 2014 Amazon.com, Inc.  All rights reserved.
  * 
  * Owner: oih-cn@
  */
package com.amazon.oih.utils;

import java.util.List;

import com.google.common.base.Joiner;

/**
 * @author gaoxing
 *
 */
public class GenericLineProcessor implements ILineProcessor<String> {
    protected String delimiter = "\t";
    private static final String CARRIAGE_RETURN = "\r";
    private static final String NEW_LINE = "\n";
    private static final String QUOTE = "\"";
    private static final String REGULAR_OR = "|";
    private String specialChars = null;
    private String regularExpression = null;

    public GenericLineProcessor(String delimiter) {
        this.delimiter = delimiter;
        specialChars = Joiner.on(REGULAR_OR).join(delimiter, CARRIAGE_RETURN, NEW_LINE, QUOTE);
        regularExpression = ".*(" + specialChars + ").*";
    }

    @Override
    public String buildLine(List<String> rawDataList) {
        StringBuilder strBuilder = new StringBuilder();
        for (int i = 0; i < rawDataList.size(); i++) {
            String eachField = rawDataList.get(i);
            strBuilder.append(escapeSpecialChar(eachField));
            if (i < rawDataList.size() - 1) {
                strBuilder.append(delimiter);
            }
        }
        return strBuilder.toString();
    }

    private String escapeSpecialChar(String eachField) {
        if (eachField.matches(regularExpression)) {
            // Surround with quote if there is any special char
            return QUOTE + eachField.replace(QUOTE, QUOTE + QUOTE) + QUOTE; 
        } else {
            return eachField;
        }
    }

    /* Not implemented right now, it's useful when we do the import tool
     * @see com.amazon.oih.utils.ILineProcessor#parseLine(java.lang.String)
     */
    @Override
    public List<String> parseLine(String inputLine) {
        return null;
    }

}
