package com.amazon.oih.utils;

public class HBaseConstants {
    public static final String USE_HBASE = "IhrMetrics.Use.Hbase";
}