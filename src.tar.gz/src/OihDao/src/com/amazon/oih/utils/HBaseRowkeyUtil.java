package com.amazon.oih.utils;

import java.util.Arrays;

import com.amazon.oih.dao.hbase.forecast.ForecastHBaseObject;
import com.amazon.oih.dao.hbase.ourprice.OurpriceHbaseObject;
import com.amazon.oih.dao.hbase.revenue.AsinRevenueData;
import com.amazon.oih.dao.markdowninfo.MarkdownInfo;
import com.amazon.oih.dao.quantitymarkdowninfo.QuantityBasedMarkdownInfo;
import com.google.common.base.Joiner;

public class HBaseRowkeyUtil {
    private static final String ROWKEY_SPLIT = ":";
    private static final int ASIN_INDEX = 0;
    private static final int MARKETPLACE_INDEX = 1;

    private static final int ASIN_REVENUE_DATA_INDEX = 0;
    private static final int ASIN_REVENUE_DATA_SCOPE_INDEX = 1;

    static public OurpriceHbaseObject parseOurpriceHbaseObject(String rowkey) {
        String[] asinIog = rowkey.split(ROWKEY_SPLIT);
        String asin = asinIog[0];
        String iog = asinIog[1];
        
        OurpriceHbaseObject result = new OurpriceHbaseObject();
        result.setAsin(asin); result.setIog(Integer.valueOf(iog));
        return result;
    }
    
    static public String getRowKeyForAsinIog(String asin, String iog) {
        return asin + ROWKEY_SPLIT + iog;
    }
    
    static public String getRowKeyForAsinScope(String asin, String scopeId) {
        return asin + ROWKEY_SPLIT + scopeId;
    }
    
    @SuppressWarnings("unchecked")
    static public String getRowKeyBasedAsinMarketplace(String asin, long marketplace) {
        return Joiner.on(ROWKEY_SPLIT).join(Arrays.asList(asin, marketplace));
    }

    public static MarkdownInfo parseMarkdownInfoRowKey(String rowKey) {
        String[] markdownInfoRowKey = rowKey.split(ROWKEY_SPLIT);
        String asin = markdownInfoRowKey[0];
        int marketplaceId = Integer.valueOf(markdownInfoRowKey[1]);
        MarkdownInfo markdownInfoObject = new MarkdownInfo();
        markdownInfoObject.setAsin(asin);
        markdownInfoObject.setMarketplaceId(marketplaceId);
        return markdownInfoObject;
    }

    public static QuantityBasedMarkdownInfo parseQuantityBasedMarkdownInfoRowKey(String rowKey) {
        String[] quantityBasedMarkdownInfoRowKey = rowKey.split(ROWKEY_SPLIT);
        String asin = quantityBasedMarkdownInfoRowKey[0];
        int marketplaceId = Integer.valueOf(quantityBasedMarkdownInfoRowKey[1]);
        QuantityBasedMarkdownInfo quantityBasedMarkdownInfoObject = new QuantityBasedMarkdownInfo();
        quantityBasedMarkdownInfoObject.setAsin(asin);
        quantityBasedMarkdownInfoObject.setMarketplaceId(marketplaceId);
        return quantityBasedMarkdownInfoObject;
    }
    
    static public ForecastHBaseObject parseForecastRowkey(String rowkey) {
        String[] forecastRowKey = rowkey.split(ROWKEY_SPLIT);
        String asin = forecastRowKey[ASIN_INDEX];
        long marketplace = Long.valueOf(forecastRowKey[MARKETPLACE_INDEX]);
        return new ForecastHBaseObject(asin, marketplace);
    }

    static public AsinRevenueData parseAsinRevenueDatakey(String rowkey) {
        String[] asinRevenueDataRowKey = rowkey.split(ROWKEY_SPLIT);
        String asin = asinRevenueDataRowKey[ASIN_REVENUE_DATA_INDEX];
        String scopeId = asinRevenueDataRowKey[ASIN_REVENUE_DATA_SCOPE_INDEX];
        return new AsinRevenueData(asin, scopeId);
    }

    static public String getRowKeyForAsinRevenueData(AsinRevenueData asinRevenueData) {
        return getRowKeyForAsinRevenueData(asinRevenueData.getAsin(), asinRevenueData.getScopeId());
    }

    static public String getRowKeyForAsinRevenueData(String asin, String scopeId) {
        return getRowKeyForAsinScope(asin, scopeId);
    }
    
    static public String getRowKeyForAsinCountry(String asin, String countryCode) {
        return asin + ROWKEY_SPLIT + countryCode;
    }
}
