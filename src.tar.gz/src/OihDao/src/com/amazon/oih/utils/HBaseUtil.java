package com.amazon.oih.utils;
import amazon.platform.config.AppConfig;

public class HBaseUtil {
    public static boolean isUseHBase(String name) {
        return AppConfig.findVector(HBaseConstants.USE_HBASE) != null
                && AppConfig.findVector(HBaseConstants.USE_HBASE).contains(name);
    }
}
