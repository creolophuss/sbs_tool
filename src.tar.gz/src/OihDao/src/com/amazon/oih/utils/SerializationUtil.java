package com.amazon.oih.utils;

import java.io.IOException;

import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;

public class SerializationUtil {

    private static ObjectMapper jacksonMapper = new ObjectMapper();
    
    public static String toJsonString(Object o) throws JsonGenerationException, JsonMappingException, IOException {
        return jacksonMapper.writeValueAsString(o);
    }
    
    public static <T> T readJsonObject(String json, Class<T> clazz) throws JsonParseException, JsonMappingException, IOException {
        return jacksonMapper.readValue(json, clazz);
    }
}
