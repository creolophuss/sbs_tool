 /**
  * Copyright (c) 2014 Amazon.com, Inc.  All rights reserved.
  * 
  * Owner: oih-cn@
  */
package com.amazon.oih.utils;

import java.util.List;

/**
 * @author gaoxing
 *
 */
public interface ILineProcessor<T> {

    /**
     * Build output String based on the raw input data
     * 
     * @param rawDataList
     * @return
     */
    public String buildLine(List<T> rawDataList);

    /**
     * Parse input data String to String list based on the Column definition
     * 
     * @param inputLine
     * @return
     */
    public List<T> parseLine(String inputLine);
}
