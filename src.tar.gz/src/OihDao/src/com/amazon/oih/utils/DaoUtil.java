package com.amazon.oih.utils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;

import com.amazon.oih.dao.HibernateUtil;
import com.amazon.oih.dao.MySQLSessionFactoryUtil;
import com.amazon.oih.dao.apub.ApubAsin;
import com.amazon.oih.dao.apub.ApubAsinDao;
import com.amazon.oih.dao.apub.ApubAsinDaoImpl;
import com.amazon.oih.dao.averageliquidationinfo.AverageLiquidationInfo;
import com.amazon.oih.dao.averageliquidationinfo.AverageLiquidationInfoDao;
import com.amazon.oih.dao.averageliquidationinfo.AverageLiquidationInfoDaoImpl;
import com.amazon.oih.dao.forecast.ForecastDao;
import com.amazon.oih.dao.forecast.ForecastObject;
import com.amazon.oih.dao.forecastnew.ForecastNewDao;
import com.amazon.oih.dao.forecastnew.ForecastNewDaoOracleImp;
import com.amazon.oih.dao.forecastnew.ForecastNewDataBaseObject;
import com.amazon.oih.dao.ilbo.IlboDao;
import com.amazon.oih.dao.ilbo.IlboObject;
import com.amazon.oih.dao.inventorysourcingcost.InventorySourcingCost;
import com.amazon.oih.dao.inventorysourcingcost.InventorySourcingCostDao;
import com.amazon.oih.dao.inventorysourcingcost.InventorySourcingCostDaoImpl;
import com.amazon.oih.dao.markdowninfo.MarkdownForecast;
import com.amazon.oih.dao.markdowninfo.MarkdownForecastDao;
import com.amazon.oih.dao.markdowninfo.MarkdownForecastDaoImpl;
import com.amazon.oih.dao.miscAsin.MiscAsin;
import com.amazon.oih.dao.miscAsin.MiscAsinDao;
import com.amazon.oih.dao.miscAsin.MiscAsinDaoImpl;
import com.amazon.oih.dao.ourprice.OurPriceDao;
import com.amazon.oih.dao.ourprice.OurPriceObject;
import com.amazon.oih.dao.removalleadtime.RemoveLeadTime;
import com.amazon.oih.dao.removalleadtime.RemoveLeadTimeDao;
import com.amazon.oih.dao.removalleadtime.RemoveLeadTimeDaoImpl;
import com.amazon.oih.dao.targetInvLevel.TargetInventoryLevel;
import com.amazon.oih.dao.targetInvLevel.TargetInventoryLevelDao;
import com.amazon.oih.dao.targetInvLevel.TargetInventoryLevelDaoImpl;
import com.amazon.oih.dao.targetInvLevel.TargetInventoryLevelMaxOverPeriod;
import com.amazon.oih.dao.targetInvLevel.TargetInventoryLevelMaxOverPeriodDao;
import com.amazon.oih.dao.targetInvLevel.TargetInventoryLevelMaxOverPeriodDaoImpl;
import com.amazon.oih.dao.targetInvLevel.TargetInventoryLevelScope;
import com.amazon.oih.dao.targetInvLevel.TargetInventoryLevelScopeDao;
import com.amazon.oih.dao.targetInvLevel.TargetInventoryLevelScopeDaoImpl;
import com.amazon.oih.dao.vendorleadtime.VendorLeadTime;
import com.amazon.oih.dao.vendorleadtime.VendorLeadTimeDao;
import com.amazon.oih.dao.vendorleadtime.VendorLeadTimeDaoImpl;

/**
 * Dao Utils for unit test
 * 
 * @author zhongwei
 * 
 */
public class DaoUtil {
    private static final String UNIT_TEST = "UNIT_TEST";
    private static SessionFactory targetInventoryLevelDaoSessionFactory = null;
    private static SessionFactory legacyTargetInventoryLevelDaoSessionFactory = null;
    private static SessionFactory forecastDaoSessionFactory = null;
    private static SessionFactory ourPriceDaoSessionFactory = null;
    private static SessionFactory ilboDaoSessionFactory = null;
    private static SessionFactory markdownDaoSessionFactory = null;
    private static SessionFactory vendorLeadTimeDaoSessionFactory = null;
    private static SessionFactory removalLeadTimeDaoSessionFactory = null;
    private static SessionFactory targetInventoryLevelScopeDaoSessionFactory = null;
    private static SessionFactory forecastNewDaoSessionFactory = null;
    private static SessionFactory averageLiquidationInfoDaoSessionFactory = null;
    private static SessionFactory apubAsinDaoSessionFactory = null;
    private static SessionFactory miscAsinDaoSessionFactory = null;
    public static boolean showSql = false;
    private static SessionFactory inventorySourcingCostDaoSessionFactory = null;
    private static SessionFactory taxDaoSessionFactory = null;

    @SuppressWarnings("unchecked")
    private static Map<Class, String> class2HibernateConfigMap = new HashMap<Class, String>();
    static {
        class2HibernateConfigMap.put(TargetInventoryLevel.class,
                "com/amazon/oih/dao/targetInvLevel/targetinventorylevel.hbm.xml");
        class2HibernateConfigMap.put(TargetInventoryLevelMaxOverPeriod.class,
                "com/amazon/oih/dao/targetInvLevel/legacytargetinventorylevel.hbm.xml");
        class2HibernateConfigMap.put(ForecastObject.class, "com/amazon/oih/dao/forecast/forecast.hbm.xml");
        class2HibernateConfigMap.put(OurPriceObject.class, "com/amazon/oih/dao/ourprice/ourprice.hbm.xml");
        class2HibernateConfigMap.put(IlboObject.class, "com/amazon/oih/dao/ilbo/IlboObject.hbm.xml");
        class2HibernateConfigMap.put(TargetInventoryLevelScope.class,
        "com/amazon/oih/dao/targetInvLevel/targetinventorylevelscope.hbm.xml");
        class2HibernateConfigMap.put(MarkdownForecast.class,
                "com/amazon/oih/dao/markdowninfo/markdownForecast.hbm.xml");
        class2HibernateConfigMap.put(VendorLeadTime.class,
                "com/amazon/oih/dao/vendorleadtime/vendorLeadTime.hbm.xml");
        class2HibernateConfigMap.put(RemoveLeadTime.class,
                "com/amazon/oih/dao/removalleadtime/removeLeadTime.hbm.xml");
        class2HibernateConfigMap.put(ForecastNewDataBaseObject.class,
                "com/amazon/oih/dao/forecastnew/forecastNew.hbm.xml");
        class2HibernateConfigMap.put(AverageLiquidationInfo.class,
                "com/amazon/oih/dao/averageliquidationinfo/averageLiquidationInfo.hbm.xml");
        class2HibernateConfigMap.put(InventorySourcingCostDao.class,
                "com/amazon/oih/dao/inventorysourcingcost/inventorysourcingcost.hbm.xml");
        class2HibernateConfigMap.put(ApubAsin.class, "com/amazon/oih/dao/apub/apubAsin.hbm.xml");
        class2HibernateConfigMap.put(MiscAsin.class, 
        		"com/amazon/oih/dao/miscAsin/miscAsin.hbm.xml");
    }

    /**
     * Init the Session Factory according to the Class
     * 
     * @param clazz
     * @return
     */
    @SuppressWarnings("unchecked")
    private static SessionFactory getSessionFactory(Class clazz) {
        Properties props = getProperties();

        Configuration config = new Configuration();
        config.setProperties(props);

        for (String configValue : class2HibernateConfigMap.values()){
            config.addResource(configValue);
        }
        return config.buildSessionFactory();
    }
   
    public static SessionFactory getSessionFactory(List<Class> clazzs, List<String> resources) {
        Properties props = getProperties();

        AnnotationConfiguration config = new AnnotationConfiguration();
        config.setProperties(props);

        if (clazzs != null){
            for (Class persistentClass : clazzs){
                config.addAnnotatedClass(persistentClass);
            }
        }
        
        if (resources != null){
        	for (String resource : resources){
                config.addResource(resource);
            }
        }
        return config.buildSessionFactory();
    }
    
    public static SessionFactory getAnnotationSessionFactory(List<Class> clazzs) {
    	return getSessionFactory(clazzs, null);
    }
    
    public static SessionFactory getResourceSessionFactory(List<String> resources) {
    	return getSessionFactory(null, resources);
    }

    
    private static Properties getProperties() {
        Properties props = new Properties();

        props.setProperty("hibernate.connection.driver_class", "org.hsqldb.jdbcDriver");
        props.setProperty("hibernate.connection.url", "jdbc:hsqldb:mem:testdb");

        props.setProperty("hibernate.connection.username", "sa");
        props.setProperty("hibernate.connection.password", "");
        props.setProperty("hibernate.dialect", "org.hibernate.dialect.HSQLDialect");
        props.setProperty("connection.pool_size", "5");
        props.setProperty("hibernate.hbm2ddl.auto", "create");
        if (showSql) {
            props.setProperty("hibernate.show_sql", "true");
            props.setProperty("hibernate.format_sql", "true");
            props.setProperty("hibernate.use_sql_comments", "true");
        }
        return props;
    }

    public synchronized static TargetInventoryLevelScopeDao getTargetInventoryLevelScopeDao4UnitTest() {
        if (targetInventoryLevelScopeDaoSessionFactory == null) {
            targetInventoryLevelScopeDaoSessionFactory = getSessionFactory(TargetInventoryLevelScope.class);
            MySQLSessionFactoryUtil.setSessionFactory(targetInventoryLevelScopeDaoSessionFactory);
        }

        return new TargetInventoryLevelScopeDaoImpl(UNIT_TEST);
    }

    /**
     * get target inventory level DAO for unit test
     * 
     * @param domain
     * @return
     */
    public synchronized static TargetInventoryLevelDao getTargetInventoryLevelDao4UnitTest() {
        if (targetInventoryLevelDaoSessionFactory == null) {
            targetInventoryLevelDaoSessionFactory = getSessionFactory(TargetInventoryLevel.class);
            MySQLSessionFactoryUtil.setSessionFactory(targetInventoryLevelDaoSessionFactory);
        }

        return new TargetInventoryLevelDaoImpl(UNIT_TEST);
    }

    /**
     * get legacy target inventory level DAO for unit test
     * 
     * @param domain
     * @return
     */
    public synchronized static TargetInventoryLevelMaxOverPeriodDao getLegacyTargetInventoryLevelDao4UnitTest() {
        if (legacyTargetInventoryLevelDaoSessionFactory == null) {
            legacyTargetInventoryLevelDaoSessionFactory = getSessionFactory(TargetInventoryLevelMaxOverPeriod.class);
            MySQLSessionFactoryUtil.setSessionFactory(legacyTargetInventoryLevelDaoSessionFactory);
        }

        return new TargetInventoryLevelMaxOverPeriodDaoImpl(UNIT_TEST);
    }


    /**
     * Get forecast in-memory DAO
     * 
     * @return
     */
    public synchronized static ForecastDao getForecatDao4UnitTest() {
        if (forecastDaoSessionFactory == null) {
            forecastDaoSessionFactory = getSessionFactory(ForecastObject.class);
            HibernateUtil.setSessionFactory(forecastDaoSessionFactory);
        }

        return new ForecastDao(UNIT_TEST);
    }
    
    /**
     * Get forecast in-memory DAO
     * 
     * @return
     */
    public synchronized static ForecastNewDao getForecastNewDao4UnitTest() {
        if (forecastNewDaoSessionFactory == null) {
        	forecastNewDaoSessionFactory = getSessionFactory(ForecastNewDataBaseObject.class);
            HibernateUtil.setSessionFactory(forecastNewDaoSessionFactory);
        }

        return new ForecastNewDaoOracleImp(UNIT_TEST);
    }  

    /**
     * get our price DAO for unit test
     * 
     * @param domain
     * @return
     */
    public static OurPriceDao getOurPriceDao4UnitTest() {
        if (ourPriceDaoSessionFactory == null) {
            ourPriceDaoSessionFactory = getSessionFactory(OurPriceObject.class);
            HibernateUtil.setSessionFactory(ourPriceDaoSessionFactory);
        }

        return new OurPriceDao(UNIT_TEST);
    }

    /**
     * get our price DAO for unit test
     * 
     * @param domain
     * @return
     */
    public static IlboDao getILBODao4UnitTest() {
        if (ilboDaoSessionFactory == null) {
            ilboDaoSessionFactory = getSessionFactory(IlboObject.class);
            HibernateUtil.setSessionFactory(ilboDaoSessionFactory);
        }

        return new IlboDao(UNIT_TEST);
    }
    
    public static AverageLiquidationInfoDao getAverageLiquidationInfoDao4UnitTest(){
        if ( averageLiquidationInfoDaoSessionFactory == null) {
            averageLiquidationInfoDaoSessionFactory = getSessionFactory(AverageLiquidationInfo.class);
            MySQLSessionFactoryUtil.setSessionFactory(averageLiquidationInfoDaoSessionFactory);
        }

        return new AverageLiquidationInfoDaoImpl(UNIT_TEST);
    }
    
    public static ApubAsinDao getApubAsinDao4UnitTest(){
        if ( apubAsinDaoSessionFactory == null) {
            apubAsinDaoSessionFactory = getSessionFactory(ApubAsin.class);
            MySQLSessionFactoryUtil.setSessionFactory(apubAsinDaoSessionFactory);
        }

        return new ApubAsinDaoImpl();
    }

    public static MiscAsinDao getMiscAsinDao4UnitTest(){
        if ( miscAsinDaoSessionFactory == null) {
        	miscAsinDaoSessionFactory = getSessionFactory(MiscAsin.class);
            MySQLSessionFactoryUtil.setSessionFactory(miscAsinDaoSessionFactory);
        }

        return new MiscAsinDaoImpl(UNIT_TEST);
    }
    
    /**
     * get MarkdownForecast DAO for unit test
     * 
     * @param domain
     * @return
     */
    public static MarkdownForecastDao getMarkdownForecast4UnitTest() {
        if (markdownDaoSessionFactory == null) {
        	markdownDaoSessionFactory = getSessionFactory(MarkdownForecast.class);
        	MySQLSessionFactoryUtil.setSessionFactory(markdownDaoSessionFactory);
        }

        return new MarkdownForecastDaoImpl(UNIT_TEST);
    }
    
    /**
     * get MarkdownForecast DAO for unit test
     * 
     * @param domain
     * @return
     */
    public static VendorLeadTimeDao getVendorLeadTime4UnitTest() {
        if (vendorLeadTimeDaoSessionFactory == null) {
        	vendorLeadTimeDaoSessionFactory = getSessionFactory(VendorLeadTime.class);
        	MySQLSessionFactoryUtil.setSessionFactoryForInspector(vendorLeadTimeDaoSessionFactory);
        }

        return new VendorLeadTimeDaoImpl(UNIT_TEST);
    }
    
    /**
     * get MarkdownForecast DAO for unit test
     * 
     * @param domain
     * @return
     */
    public static RemoveLeadTimeDao getRemovalLeadTime4UnitTest() {
        if (removalLeadTimeDaoSessionFactory == null) {
        	removalLeadTimeDaoSessionFactory = getSessionFactory(RemoveLeadTime.class);
        	MySQLSessionFactoryUtil.setSessionFactoryForInspector(removalLeadTimeDaoSessionFactory);
        }

        return new RemoveLeadTimeDaoImpl(UNIT_TEST);
    }
    
    public static InventorySourcingCostDao getInventorySourcingCostDao4UnitTest() {
        if (inventorySourcingCostDaoSessionFactory == null) {
            inventorySourcingCostDaoSessionFactory = getSessionFactory(InventorySourcingCost.class);
            MySQLSessionFactoryUtil.setSessionFactory(inventorySourcingCostDaoSessionFactory);
        }

        return new InventorySourcingCostDaoImpl(UNIT_TEST);
    }
}    
