package com.amazon.oih.utils;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

/**
 * Time help for calculate the accumulated time for any phase
 * 
 * copied from OihCommon
 * 
 * @author xlpeng
 * 
 */
public class TimerHelper {
    Logger logger = Logger.getLogger(TimerHelper.class);
    private Map<String, Phase> phases = new ConcurrentHashMap<String, Phase>();
    private static TimerHelper instance = new TimerHelper(); 
    
    static{
        //add shut down hook to print time message while the jvm instance is shutting down.
        Runtime.getRuntime().addShutdownHook(new Thread(){
            @Override
            public void run(){
                TimerHelper.getInstance().printTimeMessage();
            }
        });
    }
    
    private TimerHelper() {
    }

    public static TimerHelper getInstance() {
        return instance;
    }
    
    private void addPhaseElapsedTime(String phaseName, long additionalTime, boolean useNanoTime) {
        Phase existingPhase = (Phase) phases.get(phaseName);
        if (existingPhase == null) {
            existingPhase = new Phase(phaseName, additionalTime,useNanoTime);
            phases.put(phaseName, existingPhase);
        } else {
            existingPhase.addTime(additionalTime);
        }
    }

    public void addPhase(String phaseName, long startMillisTime) {
        long additionalTime = System.currentTimeMillis() - startMillisTime;
        this.addPhaseElapsedTime(phaseName, additionalTime, false);
    }
    
    public void addNanoPhase(String phaseName, long startNanoTime) {        
        long additionalTime = System.nanoTime() - startNanoTime;
        this.addPhaseElapsedTime(phaseName, additionalTime, true);
    }    

    public long getExecuteCount(String phaseName) {
        Phase existingPhase = (Phase) phases.get(phaseName);
        if (existingPhase == null) {
            return 0;
        }
        return existingPhase.getExecuteCount();
    }

    public long getExecuteTime(String phaseName) {
        Phase existingPhase = (Phase) phases.get(phaseName);
        if (existingPhase == null) {
            return 0;
        }

        return existingPhase.getExecuteTime();
    }

    protected String getTimeMessage() {
        StringBuilder msg = new StringBuilder();
        for(Map.Entry<String, Phase> phaseEntry : phases.entrySet()){
        	msg.append(phaseEntry.getValue().toString());
        	msg.append("\n");
        }
        return msg.toString();
    }
    
    public void printTimeMessage() {
        String msg = getTimeMessage();
        if(StringUtils.isNotBlank(msg)){
            System.out.println(msg) ;
            logger.info(msg);
        }
    }
}

class Phase {
    String phaseName = null;
    private AtomicLong executeTime = new AtomicLong(0);
    private AtomicLong executeCount = new AtomicLong(0);
    private boolean useNanoTime = false;
    
    public Phase(String phaseName, long time, boolean useNanoTime) {
        this.phaseName = phaseName;
        this.setExecuteCount(1);
        this.setExecuteTime(time);
        this.useNanoTime = useNanoTime;
    } 
    
    public Phase(String phaseName, long time) {
        this(phaseName, time, false);
    }

    public void addTime(long extraTime) {
    	this.executeTime.addAndGet(extraTime);
    	this.executeCount.incrementAndGet();
    }

    public void setExecuteCount(long executeCount) {
        this.executeCount.set(executeCount);
    }

    public long getExecuteCount() {
        return executeCount.get();
    }

    public void setExecuteTime(long executeTime) {
        this.executeTime.set(executeTime);
    }

    public long getExecuteTime() {
        return executeTime.get();
    }
    
    public double getExecuteMillseconds(){
        double t = executeTime.get();
        return useNanoTime ? (t/1000000) :t;
    }
    
    public double getAverageExecuteMillseconds(){
        long executeCount = this.getExecuteCount();
        if(executeCount > 0){
            return (double)this.getExecuteMillseconds()/executeCount;
        }else{
            return 0;
        }
    }
    
    @Override
    public String toString(){
    	StringBuilder sb = new StringBuilder();
    	sb.append(String.format("%s: %ds", phaseName, (int)(getExecuteMillseconds()/1000)));
    	sb.append(String.format(", execute count: %d", getExecuteCount()));
    	sb.append(String.format(", average time: %f ms", getAverageExecuteMillseconds()));
    	return sb.toString();
    }
}
