package com.amazon.oih.utils;

public class AsinIogPair {
    private String asin;
    private String iog;

    public String getAsin() {
        return asin;
    }

    public void setAsin(String asin) {
        this.asin = asin;
    }

    public String getIog() {
        return iog;
    }

    public void setIog(String iog) {
        this.iog = iog;
    }
    
    public AsinIogPair(String asin, String iog) {
        this.asin = asin;
        this.iog = iog;
    }
    
    @Override
    public int hashCode() {
        final int prime = 127; //changed from default - 31 is a lame prime #
        int result = 1;
        result = prime * result + ((asin == null) ? 0 : asin.hashCode());
        result = prime * result + ((iog == null) ? 0 : iog.hashCode());
        return result;
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        
        if (getClass() != obj.getClass())
            return false;
        
        final AsinIogPair other = (AsinIogPair) obj;
        
        if (asin == null) {
            if (other.asin != null)
                return false;
        } else if (!asin.equals(other.asin))
            return false;
        
        if (iog == null) {
            if (other.iog != null)
                return false;
        } else if (!iog.equals(other.iog))
            return false;
        
        return true;
    }
    
    @Override
    public String toString() {
        StringBuilder b = new StringBuilder("{ ");
        b.append("asin = ");
        b.append(asin);
        b.append("; iog = ");
        b.append(iog);
        b.append(" }");
        return b.toString();
    }
}
