package com.amazon.oih.utils;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import com.amazon.oih.dao.exception.OihPersistenceException;
import com.amazon.oih.dao.repository.DaoFactory;
import com.amazon.oih.dao.run.Run;
import com.amazon.oih.dao.run.RunDao;

public class RunID2RunDateMapper {
	private RunDao runDao;
	private Map<Long, Date> runId2RunDateMap = new HashMap<Long, Date>();
	public RunID2RunDateMapper(String domain) {
        runDao = DaoFactory.getRunDao(domain);
	}
	
	public Date getRunDate(long runId){
        
        Date runDate = runId2RunDateMap.get(runId);
        
        if (runDate != null){
        	return runDate;
        }
        
        Run run = null;
        try {
            run = runDao.find(runId);
        } catch (OihPersistenceException e) {
            throw new RuntimeException(e);
        }
        
        if (run != null){
        	runId2RunDateMap.put(runId, run.getRunDate().toDate());
            return run.getRunDate().toDate();
        }
        
        return null;
	}
	
	public void setRunDao(RunDao dao){
		this.runDao = dao;
	}
}
