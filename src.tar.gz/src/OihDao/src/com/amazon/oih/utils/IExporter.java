 /**
  * Copyright (c) 2014 Amazon.com, Inc.  All rights reserved.
  * 
  * Owner: oih-cn@
  */
package com.amazon.oih.utils;

import java.io.IOException;

/**
 * @author gaoxing
 *
 */
public interface IExporter<T> {
    public void export(String entityName, String outputFilePath, ILineProcessor<T> lineBuilder) throws IOException;
}
