package com.amazon.oih.utils;

import java.io.IOException;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.util.CollectionUtils;

import amazon.platform.config.AppConfig;

import com.amazon.oih.dao.DaoConstants;
import com.amazon.oih.dao.hbase.revenue.RevenueHBaseDao;
import com.amazon.oih.dao.hbase.revenue.RevenueHBaseTableMetaDataDao;
import com.amazon.oih.dao.hbase.revenue.RevenueHBaseTableMetaDataObject;
import com.amazon.oih.dao.hbase.revenue.RevenueTableStatus;
import com.amazon.oih.dao.hbase.schema.HBaseSchemaDaoImpl;
import com.google.common.base.Splitter;

public final class RevenueHBaseTableUtil {

    private static Logger log = Logger.getLogger(RevenueHBaseTableUtil.class);

    private static final String TABLENAME_SPLIT = "_";

    private static final String DATE_FORMAT = "yyyyMMdd";

    private static String RevenueTableName = AppConfig.findString("IhrMetrics.AsinRevenueDataHBase.TableName");
    
    public static String RevenueMetadataTableName = AppConfig.findString("IhrMetrics.RevenueMetadataHBase.TableName", "AsinRevenueTableMetadata");

    public static final String RevenueTableSourceIdentity = AppConfig
            .findString("IhrMetrics.AsinRevenueDataHBase.SourceIdentity");

    public static final int REVENUE_MAX_HISTORY = 10 * 7;
    public static final int REVENUE_MAX_HISTORY_NUMBER = 2;

    @SuppressWarnings("unchecked")
    public static final Map<Integer, List<Double>> EMPTY_REVENUE_MAP = Collections.EMPTY_MAP;

    private static ThreadLocal<DecimalFormat> formatThreadLocal = new ThreadLocal<DecimalFormat>();

    public static List<String> findAllDateOfAsinRevenueDataInAscOrder(String realm, Date beforeDate) throws IOException {
        List<String> tableRundates = new LinkedList<String>();
        Calendar cal = Calendar.getInstance();
        cal.setTime(beforeDate);
        RevenueHBaseTableMetaDataDao metadataDao = new RevenueHBaseTableMetaDataDao(realm);
        for (int i = 0; i < REVENUE_MAX_HISTORY; i++, cal.add(Calendar.DATE, -1)) {
            Date currDate = cal.getTime();
            String tableRunDate = getDateOfAsinRevenueData(metadataDao, realm, currDate);
            if (tableRunDate != null) {
                if (cal.get(Calendar.DAY_OF_WEEK) != Calendar.SUNDAY) {
                    log.warn("Find table that not belong to Sunday:" + tableRunDate);
                }
                tableRundates.add(tableRunDate);
                if (tableRundates.size() >= REVENUE_MAX_HISTORY_NUMBER) {
                    break;
                }
            }
        }
        metadataDao.close();
        Collections.reverse(tableRundates);
        log("All AsinRevenueTable dates:" + tableRundates);
        return tableRundates;
    }

    public static String findDateOfAsinRevenueData(String realm, String dateStr) throws IOException, ParseException {
        DateFormat df = new SimpleDateFormat(DATE_FORMAT);
        Date date = df.parse(dateStr);
        return findDateOfAsinRevenueData(realm, date);
    }

    public static String findDateOfAsinRevenueData(String realm, Date date) throws IOException {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        String tableRunDate = null;
        RevenueHBaseTableMetaDataDao metadataDao = new RevenueHBaseTableMetaDataDao(realm);
        for (int i = 0; i < REVENUE_MAX_HISTORY; i++) {
            Date currDate = cal.getTime();
            tableRunDate = getDateOfAsinRevenueData(metadataDao, realm, currDate);
            if (tableRunDate != null) {
                break;
            }
            cal.add(Calendar.DATE, -1);
        }
        metadataDao.close();
        log("Table date mark for date " + date + " is " + tableRunDate);
        return tableRunDate;
    }

    public static boolean isAsinRevenueDataReady(String realm, String dateStr) throws IOException, ParseException {
        DateFormat df = new SimpleDateFormat(DATE_FORMAT);
        Date date = df.parse(dateStr);
        return isAsinRevenueDataReady(realm, date);
    }

    public static boolean isAsinRevenueDataReady(String realm, Date date) throws IOException {
        RevenueHBaseTableMetaDataDao metadataDao = new RevenueHBaseTableMetaDataDao(realm);
        String tableRunDate = getDateOfAsinRevenueData(metadataDao, realm, date);
        metadataDao.close();
        return tableRunDate != null;
    }

    public static String getDateOfAsinRevenueData(RevenueHBaseTableMetaDataDao metadataDao, String realm, Date date)
            throws IOException {
        DateFormat df = new SimpleDateFormat(DATE_FORMAT);
        String tableRunDate = df.format(date);
        String tableName = getAsinRevenueTableNameForDate(realm, tableRunDate);
        RevenueHBaseTableMetaDataObject revenueTableMetadata = metadataDao.get(tableName);
        if (revenueTableMetadata.getStatus() == RevenueTableStatus.Ready) {
            return tableRunDate;
        }
        return null;
    }

    public static String getAsinRevenueTableNameForDate(String realm, Date date) {
        DateFormat df = new SimpleDateFormat(DATE_FORMAT);
        String tableRunDate = df.format(date);
        return getAsinRevenueTableNameForDate(realm, tableRunDate);
    }

    public static String getAsinRevenueTableNameForDate(String realm, String date) {
        return RevenueTableName + TABLENAME_SPLIT + realm + TABLENAME_SPLIT + date;
    }

    public static String recreateAsinRevenueDataTable(String realm, Date rundate) throws IOException {
        DateFormat df = new SimpleDateFormat(DATE_FORMAT);
        String tableRunDate = df.format(rundate);
        String tableName = getAsinRevenueTableNameForDate(realm, tableRunDate);
        log("Recreating Table for date:" + tableRunDate + ". TableName is " + tableName);

        HBaseSchemaDaoImpl.getInstance(realm, RevenueTableSourceIdentity).recreateHTable(tableName, new String[] {
            RevenueHBaseDao.columnFamily
        });
        return tableName;
    }

    public static Double getDoubleValueFromString(String value) {
        if (StringUtils.isEmpty(value) || StringUtils.equalsIgnoreCase("null", value)) {
            return null;
        }
        return Double.valueOf(value);
    }

    public static boolean compareInventory2RevenueMap(Map<Integer, List<Double>> m1, Map<Integer, List<Double>> m2) {
        if (m1 == null && m2 == null) {
            return true;
        }
        if (m1 == null || m2 == null) {
            return false;
        }

        if (m1.size() != m2.size()) {
            return false;
        }

        for (Integer key : m1.keySet()) {
            List<Double> v1 = m1.get(key);
            List<Double> v2 = m2.get(key);
            if (v1 == null && v2 == null) {
                return true;
            }
            if (v1 == null && v2 == null) {
                return false;
            }
            if (v1.size() != v1.size()) {
                return false;
            }
            for (int i = 0; i < v1.size(); i++) {
                if (Math.abs(v1.get(i) - v2.get(i)) > 0.01) {
                    return false;
                }
            }
        }
        return true;
    }

    public static String convertInventoryRevenueMap2String(Map<Integer, List<Double>> inventory2RevenueMap) {
        if (inventory2RevenueMap == null) {
            return "";
        }
        Set<Entry<Integer, List<Double>>> inventoriesRevenueData = inventory2RevenueMap.entrySet();

        if (CollectionUtils.isEmpty(inventoriesRevenueData)) {
            return "";
        }

        StringBuilder ret = new StringBuilder();

        DecimalFormat format = formatThreadLocal.get();
        if (format == null) {
            DecimalFormatSymbols symbols = DecimalFormatSymbols.getInstance();
            symbols.setDecimalSeparator('.');

            format = new DecimalFormat(".##", symbols);
            formatThreadLocal.set(format);
        }

        for (Entry<Integer, List<Double>> inventoryRevenueData : inventoriesRevenueData) {
            ret.append(inventoryRevenueData.getKey());
            ret.append(DaoConstants.INVENTORY_REVENUE_SPLIT);
            appendReveneString(inventoryRevenueData.getValue(), ret, format);
        }
        if (ret.charAt(ret.length() - 1) == DaoConstants.INVENTORIES_SPLIT) {
            ret.deleteCharAt(ret.length() - 1);
        }
        return ret.toString();
    }

    private static void appendReveneString(List<Double> revenues, StringBuilder ret, DecimalFormat format) {
        if (CollectionUtils.isEmpty(revenues)) {
            return;
        }
        for (Double revenue : revenues) {
            ret.append(format.format(revenue));
            ret.append(DaoConstants.REVENUE_SPLIT);
        }
        ret.setCharAt(ret.length() - 1, DaoConstants.INVENTORIES_SPLIT);
    }

    public static Map<Integer, List<Double>> convertString2InventoryRevenueMap(String value) {
        if (StringUtils.isEmpty(value) == true) {
            return EMPTY_REVENUE_MAP;
        }
        Map<Integer, List<Double>> inventory2RevenueMap = new LinkedHashMap<Integer, List<Double>>();

        Iterable<String> inventoriesRevenue = Splitter.on(DaoConstants.INVENTORIES_SPLIT).split(value);

        for (String inventoryRevenue : inventoriesRevenue) {
            int inventorySepPosition = inventoryRevenue.indexOf(DaoConstants.INVENTORY_REVENUE_SPLIT);
            int inventory = Integer.parseInt(inventoryRevenue.substring(0, inventorySepPosition));
            String revenuesStr = inventoryRevenue.substring(inventorySepPosition + 1);
            Iterator<String> revenues = Splitter.on(DaoConstants.REVENUE_SPLIT).split(revenuesStr).iterator();

            List<Double> revenueValue = new LinkedList<Double>();
            inventory2RevenueMap.put(inventory, revenueValue);
            while (revenues.hasNext()) {
                revenueValue.add(Double.valueOf(revenues.next()));
            }
        }

        return inventory2RevenueMap;
    }

    private static void log(Object msg) {
        log.info(msg);
        System.out.println(msg);
    }
}
