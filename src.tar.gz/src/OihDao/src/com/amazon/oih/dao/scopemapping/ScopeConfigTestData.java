package com.amazon.oih.dao.scopemapping;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import amazon.security.AmzUid;

import com.amazon.oih.dao.scopemapping.InventoryOwnerGroup;
import com.amazon.oih.dao.scopemapping.Marketplace;
import com.amazon.oih.dao.scopemapping.MarketplaceMerchantIdPair;
import com.amazon.oih.dao.scopemapping.Merchant;
import com.amazon.oih.dao.scopemapping.OihG2S2Constants;
import com.amazon.oih.dao.scopemapping.OihScopeMapping;

/**
 * This class is used only for test. 
 * It exists in OihDao src directory instead of test directory because other brazil packages OihCommon, OihMetrics will use the same data for test, 
 * but Brazil build system does not support dependency of test directory in its Config
 * @author yuliang
 *
 */
public class ScopeConfigTestData {
    
    public static OihScopeMapping US_SCOPE, CA_SCOPE, GB_SCOPE, FR_SCOPE, DE_SCOPE, ES_SCOPE, IT_SCOPE, 
        JP_SCOPE, CN_SCOPE, PANEU_SCOPE, IN_RC1_SCOPE, IN_RC2_SCOPE, IN_RC3_SCOPE, IN_RC4_SCOPE, IN_RC5_SCOPE;
    public static List<OihScopeMapping> scopes;
    
    public static final InventoryOwnerGroup 
            US_AMAZON_IOG = newIog( 1, "Amazon", "US"),
            US_ADVANTAGE_IOG = newIog( 2, "Advantage", "US"),       
            GB_AMAZON_IOG = newIog( 7, "Amazon.UK", "GB"),     
            DE_AMAZON_IOG = newIog( 8, "Amazon.DE", "DE"),
            FR_AMAZON_IOG = newIog( 9, "Amazon.FR", "FR"),
            JP_AMAZON_IOG = newIog( 10, "Amazon.JP", "JP"),
            CA_AMAZON_IOG = newIog( 11, "Amazon.CA", "CA"),
            GB_ADVANTAGE_IOG = newIog( 13, "Advantage.UK", "GB"),
            DE_ADVANTAGE_IOG = newIog( 31, "Advantage.DE", "DE"),
            FR_ADVANTAGE_IOG = newIog( 32, "Advantage.FR", "FR"),
            JP_ADVANTAGE_IOG = newIog( 33, "Advantage.JP", "JP"),
            CN_JOYO_IOG = newIog( 70, "Amazon.cn Joyo", "CN"),
            CN_AMAZON_IOG = newIog( 71, "Amazon.CN", "CN"),
            IT_AMAZON_IOG = newIog( 75, "Amazon.IT", "IT"),
            IT_ADVANTAGE_IOG = newIog( 76, "Advantage.IT", "IT"),
            CA_ADVANTAGE_IOG = newIog( 77, "Advantage.CA", "CA"),
            ES_AMAZON_IOG = newIog( 85, "Amazon.ES", "ES"),
            IN_RC1_IOG = newIog( 88, "Amazon.IN.RC1", "IN"),
            IN_RC2_IOG = newIog( 89, "Amazon.IN.RC2", "IN"),            
            IN_RC3_IOG = newIog( 86, "Amazon.IN.RC3", "IN"),
            IN_RC4_IOG = newIog( 87, "Amazon.IN.RC4", "IN"),
            IN_RC5_IOG = newIog( 91, "Amazon.IN.RC5", "IN"),            
            ES_ADVANTAGE_IOG = newIog( 96, "Advantage.ES", "ES"),
            US_101_IOG = newIog( 101, "Amazon", "US"),
            PANEU_VIRTUAL_IOG = newIog( 10001, "PANEU.VIRTUAL", "EU");
  
    public static List<InventoryOwnerGroup> iogs = Arrays.asList(
            US_AMAZON_IOG, US_ADVANTAGE_IOG, GB_AMAZON_IOG, DE_AMAZON_IOG, FR_AMAZON_IOG,
            JP_AMAZON_IOG, CA_AMAZON_IOG, GB_ADVANTAGE_IOG, DE_ADVANTAGE_IOG, FR_ADVANTAGE_IOG, JP_ADVANTAGE_IOG, 
            CN_JOYO_IOG, CN_AMAZON_IOG, IT_AMAZON_IOG, CA_ADVANTAGE_IOG, ES_AMAZON_IOG, IT_ADVANTAGE_IOG, 
            IN_RC1_IOG, IN_RC2_IOG, IN_RC3_IOG, IN_RC4_IOG, IN_RC5_IOG, ES_ADVANTAGE_IOG,US_101_IOG,PANEU_VIRTUAL_IOG
            );
    
    public static final Marketplace         
            US_AMAZON_COM = newMarketplace(1, "www.amazon.com"),
            GB_AMAZON_COM = newMarketplace(3, "www.amazon.co.uk"),
            DE_AMAZON_COM = newMarketplace(4, "www.amazon.de"),
            FR_AMAZON_COM = newMarketplace(5, "www.amazon.fr"),
            JP_AMAZON_COM = newMarketplace(6,"www.amazon.co.jp"),
            CA_AMAZON_COM = newMarketplace(7,"www.amazon.ca"),
            CN_AMAZON_COM = newMarketplace(3240,"www.amazon.cn"),
            ENDLESS_COM = newMarketplace(4861l, "www.endless.com"),            
            IT_AMAZON_COM = newMarketplace(35691,"www.amazon.it"),
            ES_AMAZON_COM = newMarketplace(44551,"www.amazon.es"),
            IN_AMAZON_COM = newMarketplace(44571,"www.amazon.in"),
            PANEU_VIRTUAL_COM = newMarketplace(10000,"virtual.amazon.paneu");
    public static List<Marketplace> marketplaces = Arrays.asList(
            US_AMAZON_COM, ENDLESS_COM, CA_AMAZON_COM, GB_AMAZON_COM, DE_AMAZON_COM, 
            FR_AMAZON_COM ,ES_AMAZON_COM, IT_AMAZON_COM, IN_AMAZON_COM , JP_AMAZON_COM, CN_AMAZON_COM);
    
    public static Merchant
            US_AMAZON_MCT = newMerchant(1, "amazon.com"),
            US_ENDLESS_MCT = newMerchant(1146949031, "endless.com"),
            GB_AMAZON_MCT = newMerchant(9, "amazon.co.uk"),
            DE_AMAZON_MCT = newMerchant(10, "amazon.de"),
            FR_AMAZON_MCT = newMerchant(11, "amazon.fr"),
            JP_AMAZON_MCT = newMerchant(12, "amazon.co.jp"),
            CA_AMAZON_MCT = newMerchant(13, "amazon.ca"),
            CN_AMAZON_MCT = newMerchant(623133424, "amazon.cn"),
            IT_AMAZON_MCT = newMerchant(755690533, "amazon.it"),
            ES_AMAZON_MCT = newMerchant(695831032, "amazon.es"),        
            IN_AMAZON_MCT = newMerchant(716841912, "amazon.in"),
            IN_RC1_MCT = newMerchant(830277313, "amazon.in.rc1"),        
            IN_RC2_MCT = newMerchant(159155813, "amazon.in.rc2"),
            IN_RC3_MCT = newMerchant(110571617, "amazon.in.rc3"), 
            IN_RC4_MCT = newMerchant(1104436463,"amazon.in.rc4"),
            IN_RC5_MCT = newMerchant(237197033, "amazon.in.rc5"),             
            PANEU_VIRTUAL_MCT = newMerchant(10000l,"virtual.amazon.paneu");
    public static List<Merchant> merchants = Arrays.asList(
            US_AMAZON_MCT, US_ENDLESS_MCT, GB_AMAZON_MCT, DE_AMAZON_MCT, FR_AMAZON_MCT, JP_AMAZON_MCT, CA_AMAZON_MCT, CN_AMAZON_MCT,
            IT_AMAZON_MCT, ES_AMAZON_MCT, IN_AMAZON_MCT, IN_RC1_MCT, IN_RC2_MCT, IN_RC3_MCT, IN_RC4_MCT, IN_RC5_MCT );
    
    static Map<String,Object> configMap = new HashMap<String,Object>();
    
    static {
        init();
    }
    
    
    private static void init(){        
        configMap.put(OihG2S2Constants.IOG_TABLE, iogs);
        configMap.put(OihG2S2Constants.MARKETPLACEATTR_TABLE, marketplaces);
        configMap.put(OihG2S2Constants.MERCHANT_TABLE, merchants);
        generateScopeConfig();
    }
    
    public static Map<String,Object> getConfigMap(){
        return configMap;
    }
    
    
    public static Marketplace newMarketplace(Number id, String name){
        Marketplace m = new Marketplace();
        m.setMarketplaceId(id.longValue());
        m.setMarketplaceName(name);
        m.setEncryptedMarketplaceId(AmzUid.encryptCustomerID(m.getMarketplaceId()));
        return m;       
    }
    
    
    public static Merchant newMerchant(Number id , String name){
        Merchant m = new Merchant();
        m.setMerchantId(id.longValue());
        m.setEncryptedMerchantId(AmzUid.encryptCustomerID(m.getMerchantId()));
        m.setMerchantName(name);
        return m;
    }

    public static InventoryOwnerGroup newIog(Number id, String name, boolean isAdvantage, boolean considerSellable, boolean considerUnsellable, String countryCode){
        InventoryOwnerGroup i = new InventoryOwnerGroup();
        i.setIogId(id.longValue());
        i.setIogName(name);
        i.setIogType(isAdvantage? "Advantage":"Amazon");
        i.setConsiderSellable(considerSellable);
        i.setConsiderUnsellable(considerUnsellable);
        i.setCountryCode(countryCode);
        return i;  
    }
    
    public static InventoryOwnerGroup newIog(Number id, String name, String countryCode){
        boolean isAdvantage = name.toLowerCase().contains("advantage");
        return newIog(id, name, isAdvantage, true, true, countryCode);
    }
 
    private static void addMarketplaceMerchantIdPair(OihScopeMapping scope, Number marketplaceId, Number merchantId){
        if(scope.getMarketplaceMerchantIdPairs() == null){
            scope.setMarketplaceMerchantIdPairs(new ArrayList<MarketplaceMerchantIdPair>());
        }
        MarketplaceMerchantIdPair mm = new MarketplaceMerchantIdPair();
        mm.setMarketplaceId(marketplaceId.longValue());
        mm.setMerchantId(merchantId.longValue());
        scope.getMarketplaceMerchantIdPairs().add(mm);
    } 

    private static void generateScopeConfig(){
        
        scopes = new ArrayList<OihScopeMapping>();
        Map<String, List<String>> realm2scopesForCal = new HashMap<String, List<String>>();
        Map<String, String> realm2scope = new HashMap<String, String>();
        Map<String, String> scope2country = new HashMap<String, String>();
                
        OihScopeMapping sm; 
        
        US_SCOPE = new OihScopeMapping();
        sm = US_SCOPE;
        sm.setScope("AMAZON_US");
        sm.setForecastGroup("US");
        sm.setMarketplaces(Arrays.asList(US_AMAZON_COM.getMarketplaceId(), 4861l));
        sm.setPrimaryMarketplaceId(US_AMAZON_COM.getMarketplaceId());    
        sm.setDisabledMarketplaces(Collections.<Long>emptyList());        
        addMarketplaceMerchantIdPair(sm, US_AMAZON_COM.getMarketplaceId(), US_AMAZON_MCT.getMerchantId());
        addMarketplaceMerchantIdPair(sm, 4861l, 1146949031l);
        sm.setPrimaryIogId(US_AMAZON_IOG.getIogId());        
        sm.setIogs(Arrays.asList(US_AMAZON_IOG.getIogId(), US_ADVANTAGE_IOG.getIogId(), US_101_IOG.getIogId()));    
        sm.setDisabledIogs(Collections.<Long>emptyList());
        realm2scopesForCal.put("USAmazon", Arrays.asList(sm.getScope()));        
        scope2country.put(sm.getScope(), "US");
        
        CA_SCOPE = new OihScopeMapping();
        sm = CA_SCOPE;
        sm.setScope("AMAZON_CA");
        sm.setForecastGroup("CA");
        sm.setMarketplaces(Arrays.asList(CA_AMAZON_COM.getMarketplaceId()));
        sm.setPrimaryMarketplaceId(CA_AMAZON_COM.getMarketplaceId());    
        sm.setDisabledMarketplaces(Collections.<Long>emptyList());        
        addMarketplaceMerchantIdPair(sm, CA_AMAZON_COM.getMarketplaceId(), CA_AMAZON_MCT.getMerchantId());
        sm.setPrimaryIogId(CA_AMAZON_IOG.getIogId());        
        sm.setIogs(Arrays.asList(CA_AMAZON_IOG.getIogId(), CA_ADVANTAGE_IOG.getIogId()));    
        sm.setDisabledIogs(Collections.<Long>emptyList());
        realm2scopesForCal.put("CAAmazon", Arrays.asList(sm.getScope()));        
        scope2country.put(sm.getScope(), "CA");
 
        GB_SCOPE = new OihScopeMapping();
        sm = GB_SCOPE;
        sm.setScope("AMAZON_GB");
        sm.setForecastGroup("GB");
        sm.setMarketplaces(Arrays.asList(GB_AMAZON_COM.getMarketplaceId()/*, 35291l*/));
        sm.setPrimaryMarketplaceId(GB_AMAZON_COM.getMarketplaceId());    
        sm.setDisabledMarketplaces(Collections.<Long>emptyList());        
        addMarketplaceMerchantIdPair(sm, GB_AMAZON_COM.getMarketplaceId(), GB_AMAZON_MCT.getMerchantId());
        //addMarketplaceMerchantIdPair(sm, 35291l, 1057962543);
        sm.setPrimaryIogId(GB_AMAZON_IOG.getIogId());        
        sm.setIogs(Arrays.asList(GB_AMAZON_IOG.getIogId(), GB_ADVANTAGE_IOG.getIogId()));    
        sm.setDisabledIogs(Collections.<Long>emptyList());
        realm2scopesForCal.put("GBAmazon", Arrays.asList(sm.getScope()));        
        scope2country.put(sm.getScope(), "GB");
          
        DE_SCOPE = new OihScopeMapping();
        sm = DE_SCOPE;
        sm.setScope("AMAZON_DE");
        sm.setForecastGroup("DE");
        sm.setMarketplaces(Arrays.asList(DE_AMAZON_COM.getMarketplaceId()));
        sm.setPrimaryMarketplaceId(DE_AMAZON_COM.getMarketplaceId());    
        sm.setDisabledMarketplaces(Collections.<Long>emptyList());        
        addMarketplaceMerchantIdPair(sm, DE_AMAZON_COM.getMarketplaceId(), DE_AMAZON_MCT.getMerchantId());
        sm.setPrimaryIogId(DE_AMAZON_IOG.getIogId());        
        sm.setIogs(Arrays.asList(DE_AMAZON_IOG.getIogId(), DE_ADVANTAGE_IOG.getIogId()));    
        sm.setDisabledIogs(Collections.<Long>emptyList());
        realm2scopesForCal.put("DEAmazon", Arrays.asList(sm.getScope()));        
        scope2country.put(sm.getScope(), "DE");
        
        FR_SCOPE = new OihScopeMapping();
        sm = FR_SCOPE;
        sm.setScope("AMAZON_FR");
        sm.setForecastGroup("FR");
        sm.setDisabledMarketplaces(Collections.<Long>emptyList());
        sm.setDisabledIogs(Collections.<Long>emptyList());        
        sm.setMarketplaces(Arrays.asList(FR_AMAZON_COM.getMarketplaceId()/*, 35341L*/));
        addMarketplaceMerchantIdPair(sm, FR_AMAZON_COM.getMarketplaceId(), FR_AMAZON_MCT.getMerchantId());
        //addMarketplaceMerchantIdPair(sm, 35341L, 374150422L);
        sm.setIogs(Arrays.asList(FR_AMAZON_IOG.getIogId(), FR_ADVANTAGE_IOG.getIogId()));
        sm.setPrimaryIogId(FR_AMAZON_IOG.getIogId());
        sm.setPrimaryMarketplaceId(FR_AMAZON_COM.getMarketplaceId());
        scope2country.put(sm.getScope(), "FR");

        ES_SCOPE = new OihScopeMapping();
        sm = ES_SCOPE;
        sm.setScope("AMAZON_ES");
        sm.setForecastGroup("ES");
        sm.setMarketplaces(Arrays.asList(ES_AMAZON_COM.getMarketplaceId()));
        sm.setPrimaryMarketplaceId(ES_AMAZON_COM.getMarketplaceId());    
        sm.setDisabledMarketplaces(Collections.<Long>emptyList());        
        addMarketplaceMerchantIdPair(sm, ES_AMAZON_COM.getMarketplaceId(), ES_AMAZON_MCT.getMerchantId());
        sm.setPrimaryIogId(ES_AMAZON_IOG.getIogId());        
        sm.setIogs(Arrays.asList(ES_AMAZON_IOG.getIogId(), ES_ADVANTAGE_IOG.getIogId()));    
        sm.setDisabledIogs(Collections.<Long>emptyList());
        realm2scopesForCal.put("ESAmazon", Arrays.asList(sm.getScope()));        
        scope2country.put(sm.getScope(), "ES");
        scopes.add(sm);
       
        IT_SCOPE = new OihScopeMapping();
        sm = IT_SCOPE;
        sm.setScope("AMAZON_IT");
        sm.setForecastGroup("IT");
        sm.setMarketplaces(Arrays.asList(IT_AMAZON_COM.getMarketplaceId()));
        sm.setPrimaryMarketplaceId(IT_AMAZON_COM.getMarketplaceId());    
        sm.setDisabledMarketplaces(Collections.<Long>emptyList());        
        addMarketplaceMerchantIdPair(sm, IT_AMAZON_COM.getMarketplaceId(), IT_AMAZON_MCT.getMerchantId());
        sm.setPrimaryIogId(IT_AMAZON_IOG.getIogId());        
        sm.setIogs(Arrays.asList(IT_AMAZON_IOG.getIogId(), IT_ADVANTAGE_IOG.getIogId()));    
        sm.setDisabledIogs(Collections.<Long>emptyList());
        realm2scopesForCal.put("ITAmazon", Arrays.asList(sm.getScope()));        
        scope2country.put(sm.getScope(), "IT");
        scopes.add(sm);
        
        PANEU_SCOPE = new OihScopeMapping();
        sm = PANEU_SCOPE;
        sm.setScope("AMAZON_PAN_EU");
        sm.setForecastGroup("PAN-EU");
        sm.setDisabledMarketplaces(Collections.<Long>emptyList());
        sm.setDisabledIogs(Collections.<Long>emptyList());        
        sm.setMarketplaces(Arrays.asList(GB_AMAZON_COM.getMarketplaceId(), DE_AMAZON_COM.getMarketplaceId(),FR_AMAZON_COM.getMarketplaceId(), ES_AMAZON_COM.getMarketplaceId(), IT_AMAZON_COM.getMarketplaceId()));
        addMarketplaceMerchantIdPair(sm, GB_AMAZON_COM.getMarketplaceId(), GB_AMAZON_MCT.getMerchantId());
        addMarketplaceMerchantIdPair(sm, DE_AMAZON_COM.getMarketplaceId(), DE_AMAZON_MCT.getMerchantId());
        addMarketplaceMerchantIdPair(sm, FR_AMAZON_COM.getMarketplaceId(), FR_AMAZON_MCT.getMerchantId());
        addMarketplaceMerchantIdPair(sm, ES_AMAZON_COM.getMarketplaceId(), ES_AMAZON_MCT.getMerchantId());
        addMarketplaceMerchantIdPair(sm, IT_AMAZON_COM.getMarketplaceId(), IT_AMAZON_MCT.getMerchantId());        
        sm.setIogs(Arrays.asList(GB_AMAZON_IOG.getIogId(),DE_AMAZON_IOG.getIogId(),FR_AMAZON_IOG.getIogId(),ES_AMAZON_IOG.getIogId(),IT_AMAZON_IOG.getIogId()));
        sm.setPrimaryIogId(PANEU_VIRTUAL_IOG.getIogId());
        sm.setPrimaryMarketplaceId(PANEU_VIRTUAL_COM.getMarketplaceId());
        realm2scopesForCal.put("EUAmazon", Arrays.asList(sm.getScope()));
        
        JP_SCOPE = new OihScopeMapping();
        sm = JP_SCOPE;
        sm.setScope("AMAZON_JP");
        sm.setForecastGroup("JP");
        sm.setMarketplaces(Arrays.asList(JP_AMAZON_COM.getMarketplaceId()));
        sm.setPrimaryMarketplaceId(JP_AMAZON_COM.getMarketplaceId());    
        sm.setDisabledMarketplaces(Collections.<Long>emptyList());        
        addMarketplaceMerchantIdPair(sm, JP_AMAZON_COM.getMarketplaceId(), JP_AMAZON_MCT.getMerchantId());
        sm.setPrimaryIogId(JP_AMAZON_IOG.getIogId());        
        sm.setIogs(Arrays.asList(JP_AMAZON_IOG.getIogId(), JP_ADVANTAGE_IOG.getIogId()));    
        sm.setDisabledIogs(Collections.<Long>emptyList());
        realm2scopesForCal.put("JPAmazon", Arrays.asList(sm.getScope()));        
        scope2country.put(sm.getScope(), "JP");
        
        CN_SCOPE = new OihScopeMapping();
        sm = CN_SCOPE;
        sm.setScope("AMAZON_CN");
        sm.setForecastGroup("CN");
        sm.setMarketplaces(Arrays.asList(CN_AMAZON_COM.getMarketplaceId()));
        sm.setPrimaryMarketplaceId(CN_AMAZON_COM.getMarketplaceId());    
        sm.setDisabledMarketplaces(Collections.<Long>emptyList());        
        addMarketplaceMerchantIdPair(sm, CN_AMAZON_COM.getMarketplaceId(), CN_AMAZON_MCT.getMerchantId());
        sm.setPrimaryIogId(CN_AMAZON_IOG.getIogId());        
        sm.setIogs(Arrays.asList( CN_JOYO_IOG.getIogId(), CN_AMAZON_IOG.getIogId()));    
        sm.setDisabledIogs(Collections.<Long>emptyList());
        realm2scopesForCal.put("CNAmazon", Arrays.asList(sm.getScope()));        
        scope2country.put(sm.getScope(), "CN");
         
        IN_RC1_SCOPE = new OihScopeMapping();
        sm = IN_RC1_SCOPE;
        sm.setScope("AMAZON_IN_RC1");
        sm.setForecastGroup("IN");        
        sm.setMarketplaces(Arrays.asList(IN_AMAZON_COM.getMarketplaceId()));
        sm.setPrimaryMarketplaceId(IN_AMAZON_COM.getMarketplaceId());
        addMarketplaceMerchantIdPair(sm, IN_AMAZON_COM.getMarketplaceId(), IN_RC1_MCT.getMerchantId());
        sm.setIogs(Arrays.asList(IN_RC1_IOG.getIogId()));
        sm.setPrimaryIogId(IN_RC1_IOG.getIogId());
        sm.setDisabledMarketplaces(Collections.<Long>emptyList());
        sm.setDisabledIogs(Collections.<Long>emptyList());        
        scope2country.put(sm.getScope(), "IN");        
                
        IN_RC2_SCOPE = new OihScopeMapping();
        sm = IN_RC2_SCOPE;
        sm.setScope("AMAZON_IN_RC2");
        sm.setForecastGroup("IN");        
        sm.setMarketplaces(Arrays.asList(IN_AMAZON_COM.getMarketplaceId()));
        sm.setPrimaryMarketplaceId(IN_AMAZON_COM.getMarketplaceId());
        addMarketplaceMerchantIdPair(sm, IN_AMAZON_COM.getMarketplaceId(), IN_RC2_MCT.getMerchantId());
        sm.setIogs(Arrays.asList(IN_RC2_IOG.getIogId()));
        sm.setPrimaryIogId(IN_RC2_IOG.getIogId());
        sm.setDisabledMarketplaces(Collections.<Long>emptyList());
        sm.setDisabledIogs(Collections.<Long>emptyList());        
        scope2country.put(sm.getScope(), "IN");
        
        IN_RC3_SCOPE = new OihScopeMapping();
        sm = IN_RC3_SCOPE;
        sm.setScope("AMAZON_IN_RC3");
        sm.setForecastGroup("IN");        
        sm.setMarketplaces(Arrays.asList(IN_AMAZON_COM.getMarketplaceId()));
        sm.setPrimaryMarketplaceId(IN_AMAZON_COM.getMarketplaceId());
        addMarketplaceMerchantIdPair(sm, IN_AMAZON_COM.getMarketplaceId(), IN_RC3_MCT.getMerchantId());
        sm.setIogs(Arrays.asList(IN_RC3_IOG.getIogId()));
        sm.setPrimaryIogId(IN_RC3_IOG.getIogId());
        sm.setDisabledMarketplaces(Collections.<Long>emptyList());
        sm.setDisabledIogs(Collections.<Long>emptyList());        
        scope2country.put(sm.getScope(), "IN");        
        
        IN_RC4_SCOPE = new OihScopeMapping();
        sm = IN_RC4_SCOPE;
        sm.setScope("AMAZON_IN_RC4");
        sm.setForecastGroup("IN");        
        sm.setMarketplaces(Arrays.asList(IN_AMAZON_COM.getMarketplaceId()));
        sm.setPrimaryMarketplaceId(IN_AMAZON_COM.getMarketplaceId());
        addMarketplaceMerchantIdPair(sm, IN_AMAZON_COM.getMarketplaceId(), IN_RC4_MCT.getMerchantId());
        sm.setIogs(Arrays.asList(IN_RC4_IOG.getIogId()));
        sm.setPrimaryIogId(IN_RC4_IOG.getIogId());
        sm.setDisabledMarketplaces(Collections.<Long>emptyList());
        sm.setDisabledIogs(Collections.<Long>emptyList());        
        scope2country.put(sm.getScope(), "IN"); 
        
        IN_RC5_SCOPE = new OihScopeMapping();
        sm = IN_RC5_SCOPE;
        sm.setScope("AMAZON_IN_RC5");
        sm.setForecastGroup("IN");        
        sm.setMarketplaces(Arrays.asList(IN_AMAZON_COM.getMarketplaceId()));
        sm.setPrimaryMarketplaceId(IN_AMAZON_COM.getMarketplaceId());
        addMarketplaceMerchantIdPair(sm, IN_AMAZON_COM.getMarketplaceId(), IN_RC5_MCT.getMerchantId());
        sm.setIogs(Arrays.asList(IN_RC5_IOG.getIogId()));
        sm.setPrimaryIogId(IN_RC5_IOG.getIogId());
        sm.setDisabledMarketplaces(Collections.<Long>emptyList());
        sm.setDisabledIogs(Collections.<Long>emptyList());        
        scope2country.put(sm.getScope(), "IN");         
        
        realm2scopesForCal.put("FRAmazon", Arrays.asList(FR_SCOPE.getScope(),ES_SCOPE.getScope(), IT_SCOPE.getScope(), 
                IN_RC1_SCOPE.getScope(),IN_RC2_SCOPE.getScope(),IN_RC3_SCOPE.getScope(), IN_RC4_SCOPE.getScope(),IN_RC5_SCOPE.getScope()));
        
        scopes = Arrays.asList(US_SCOPE, CA_SCOPE, GB_SCOPE, FR_SCOPE, DE_SCOPE, ES_SCOPE, IT_SCOPE, 
                JP_SCOPE, CN_SCOPE, PANEU_SCOPE, IN_RC1_SCOPE, IN_RC2_SCOPE, IN_RC3_SCOPE, IN_RC4_SCOPE, IN_RC5_SCOPE);
        
        configMap.put(OihG2S2Constants.SCOPEMAPPING_TABLE, scopes);        
        configMap.put(OihG2S2Constants.REALM_TO_SCOPE_MAP_FOR_CALC, realm2scopesForCal);
        configMap.put(OihG2S2Constants.SCOPE_TO_COUNTRY, scope2country);     
    }
}
