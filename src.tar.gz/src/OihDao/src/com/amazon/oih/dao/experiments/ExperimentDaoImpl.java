package com.amazon.oih.dao.experiments;

import java.util.List;

import org.joda.time.DateTime;

import com.amazon.carbonado.ConfigurationException;
import com.amazon.carbonado.PersistException;
import com.amazon.carbonado.Repository;
import com.amazon.carbonado.RepositoryException;
import com.amazon.carbonado.Storage;
import com.amazon.oih.dao.exception.DaoRuntimeException;
import com.amazon.oih.dao.exception.OihPersistenceException;

public class ExperimentDaoImpl implements ExperimentDao {

    protected String _domain = null;
    protected Repository repository = null;

    public ExperimentDaoImpl(String domain) {
        _domain = domain;
    }

    public void setRepository(Repository repository) {
        if (null == repository) {
            throw new IllegalArgumentException("repository is null");
        }
        this.repository = repository;
    }

    @Override
    public List<Experiment> find(boolean active) throws OihPersistenceException {
        try {
            Storage<Experiment> sf = repository.storageFor(Experiment.class);
            return sf.query("active = ?").with(active).fetch().toList();
        } catch (ConfigurationException e) {
            throw new DaoRuntimeException(e);
        } catch (RepositoryException e) {
            throw new OihPersistenceException(e);
        }
    }

    @Override
    public List<Experiment> find(String name, boolean active) throws OihPersistenceException {
        try {
            Storage<Experiment> sf = repository.storageFor(Experiment.class);
            return sf.query("name = ? & active = ?").with(name).with(active).fetch().toList();
        } catch (ConfigurationException e) {
            throw new DaoRuntimeException(e);
        } catch (RepositoryException e) {
            throw new OihPersistenceException(e);
        }
    }

    @Override
    public List<Experiment> find() throws OihPersistenceException {
        try {
            Storage<Experiment> sf = repository.storageFor(Experiment.class);
            return sf.query().fetch().toList();
        } catch (ConfigurationException e) {
            throw new DaoRuntimeException(e);
        } catch (RepositoryException e) {
            throw new OihPersistenceException(e);
        }
    }

    @Override
    public List<Experiment> find(String name) throws OihPersistenceException {
        try {
            Storage<Experiment> sf = repository.storageFor(Experiment.class);
            return sf.query("name = ?").with(name).fetch().toList();
        } catch (ConfigurationException e) {
            throw new DaoRuntimeException(e);
        } catch (RepositoryException e) {
            throw new OihPersistenceException(e);
        }
    }

    @Override
    public Experiment createExperiment(String name, DateTime startDate, DateTime endDate, boolean active, int iog,
            int gl, boolean usePopulationFile) throws OihPersistenceException {
        try {
            Storage<Experiment> sf = repository.storageFor(Experiment.class);
            Experiment e = sf.prepare();
            e.setStartDate(startDate);
            e.setEndDate(endDate);
            e.setActive(active);
            e.setName(name);
            e.setIog(iog);
            e.setGl(gl);
            e.setUsePopulationFile(usePopulationFile);
            return e;

        } catch (ConfigurationException e) {
            throw new DaoRuntimeException(e);
        } catch (RepositoryException e) {
            throw new OihPersistenceException(e);
        }
    }

    @Override
    public void save(Experiment o) throws OihPersistenceException {
        try {
            o.insert();
        } catch (PersistException e) {
            throw new OihPersistenceException(e);
        }
    }

    @Override
    public List<Experiment> find(String name, DateTime dt, boolean active) throws OihPersistenceException {
        try {
            dt = dt.withTime(0, 0, 0, 0);
            Storage<Experiment> sf = repository.storageFor(Experiment.class);
            return sf.query("name = ? & startDate <= ? & endDate >= ? & active = ?").with(name).with(dt).with(dt)
                    .with(active).fetch().toList();
        } catch (ConfigurationException e) {
            throw new DaoRuntimeException(e);
        } catch (RepositoryException e) {
            throw new OihPersistenceException(e);
        }

    }

    @Override
    public List<Experiment> find(DateTime dt, boolean active) throws OihPersistenceException {
        try {
            dt = dt.withTime(0, 0, 0, 0);
            Storage<Experiment> sf = repository.storageFor(Experiment.class);
            return sf.query("startDate <= ? & endDate >= ? & active = ?").with(dt).with(dt).with(active).fetch()
                    .toList();
        } catch (ConfigurationException e) {
            throw new DaoRuntimeException(e);
        } catch (RepositoryException e) {
            throw new OihPersistenceException(e);
        }
    }

}
