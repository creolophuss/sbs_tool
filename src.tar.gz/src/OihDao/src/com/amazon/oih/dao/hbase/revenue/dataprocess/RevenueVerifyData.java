package com.amazon.oih.dao.hbase.revenue.dataprocess;

public class RevenueVerifyData {

    public String asin;
    public String gl;

    public String exceptionDetails = "";

    public String getAsin() {
        return asin;
    }

    public void setAsin(String asin) {
        this.asin = asin;
    }

    public String getGl() {
        return gl;
    }

    public void setGl(String gl) {
        this.gl = gl;
    }

    public String getExceptionDetails() {
        return exceptionDetails;
    }

    public void setExceptionDetails(String exceptionDetails) {
        this.exceptionDetails = exceptionDetails;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((asin == null) ? 0 : asin.hashCode());
        result = prime * result + ((exceptionDetails == null) ? 0 : exceptionDetails.hashCode());
        result = prime * result + ((gl == null) ? 0 : gl.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        RevenueVerifyData other = (RevenueVerifyData) obj;
        if (asin == null) {
            if (other.asin != null)
                return false;
        } else if (!asin.equals(other.asin))
            return false;
        if (exceptionDetails == null) {
            if (other.exceptionDetails != null)
                return false;
        } else if (!exceptionDetails.equals(other.exceptionDetails))
            return false;
        if (gl == null) {
            if (other.gl != null)
                return false;
        } else if (!gl.equals(other.gl))
            return false;
        return true;
    }

}
