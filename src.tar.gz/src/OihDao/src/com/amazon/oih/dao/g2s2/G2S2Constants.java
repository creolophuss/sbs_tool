package com.amazon.oih.dao.g2s2;

public interface G2S2Constants {
    public static final String TABLE_NAME = "table_name";
    public static final String APP_CONFIG_OVERRIDE_HIERARCHY = "app_config_override_hierarchy";
    public static final String APP_CONFIG_NAME = "app_config_name";
    public static final String APP_CONFIG_DOMAIN = "app_config_domain";
    public static final String APP_CONFIG_REALM = "app_config_realm";
    public static final String APP_CONFIG_KEY = "app_config_key";
    public static final String STAGE_VERSION = "stage_version";
    public static final String APP_CONFIG = "app_config";
    public static final String STAGE_VERSION_LABEL = "stage_version_label";

    public static final String STAGE_VERSION_TABLE = "stage_version_labels";
    public static final String APP_CONFIG_KEYS_TABLE = "app_config_keys";
    public static final String APP_CONFIG_REALMS_TABLE = "app_config_realms";
    public static final String APP_CONFIG_DOMAINS_TABLE = "app_config_domains";
    public static final String APP_CONFIGS_TABLE = "app_configs";

    public final static String APP_CONFIG_OVERRIDE_HIERARCHY_VALUE = "global";
    public final static String APP_CONFIG_NAME_VALUE = "OIH";
    public final static String DEFAULT = "default";
}