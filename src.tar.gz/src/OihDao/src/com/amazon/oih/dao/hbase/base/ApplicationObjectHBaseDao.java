package com.amazon.oih.dao.hbase.base;

import java.io.IOException;
import java.util.Date;
import java.util.List;

import org.apache.hadoop.hbase.client.Result;

import com.google.common.collect.Lists;
import com.google.common.base.Function;

/**
 * Dao that saves Application objects directly to hbase by firstly converting application object to  hbase object
 *
 * @param <APP_TYPE> the application object type
 * @param <HBASE_TYPE> the hbase object type
 */
public class ApplicationObjectHBaseDao<APP_TYPE extends HBaseSaveableObject<HBASE_TYPE>, HBASE_TYPE extends AsinScopeValueHBaseObject<APP_TYPE>> {

    private CommonKVHBaseDao<HBASE_TYPE> kvDao;
    
    public ApplicationObjectHBaseDao(Class<HBASE_TYPE> classObj) {
        kvDao = new CommonKVHBaseDao<HBASE_TYPE>(classObj);
    }
    
    public ApplicationObjectHBaseDao(Class<HBASE_TYPE> classObj, String additionalId, String realm,
            Date rundate) {
        kvDao = new  CommonKVHBaseDao<HBASE_TYPE>(classObj, additionalId, realm, rundate);   
    }

    public APP_TYPE get(String rowKey) throws IOException {
        HBASE_TYPE ret = kvDao.get(rowKey);
        
        return ret.toApplicationObject();
    }
    
    public void save(APP_TYPE object) throws IOException {
        kvDao.putSingleElement(object.toHBaseObject());
    }
    
    public APP_TYPE convert(Result res) throws IOException {
        HBASE_TYPE ret = kvDao.convert(new String(res.getRow()), res);
        
        return ret.toApplicationObject();
    }
    
    public List<APP_TYPE> batchGet(List<String> rowkeys) throws IOException {
        List<HBASE_TYPE> rows = kvDao.batchGet(rowkeys);
        
        return Lists.transform(rows, new Function<HBASE_TYPE, APP_TYPE>(){

            @Override
            public APP_TYPE apply(HBASE_TYPE input) {
                return input.toApplicationObject();
            }
            
        });
    }
    
    public void batchSave(List<APP_TYPE> obejcts) throws IOException {
        kvDao.batchSave(Lists.transform(obejcts, new Function<APP_TYPE, HBASE_TYPE>(){

            @Override
            public HBASE_TYPE apply(APP_TYPE input) {
                return input.toHBaseObject();
            }
        }));
    }
    
    public String generateRowKey(APP_TYPE bObject) {
        return kvDao.generateRowKey(bObject.toHBaseObject());
    }
}
