package com.amazon.oih.dao.forecastnew;

import com.amazon.carbonado.*;
import com.amazon.carbonado.constraint.*;
import com.amazon.oih.dao.forecast.ForecastType;

/**
 * Forecast bean with annotations for Carbonado ORM. Simple constraints added
 * for data verification.
 */
@Alias("data_forecast_new")
@PrimaryKey({"runID", "asin", "iog", "type", "probability"})
public abstract class ForecastNewBDBObject implements Storable<ForecastNewBDBObject>, ForecastNew {

    @Alias("run_id")
    public abstract long getRunID();
    public abstract void setRunID(long runid);

    public abstract String getAsin();
    @LengthConstraint(min = 10, max = 10)
    public abstract void setAsin(String asin);

    public abstract int getIog();
    public abstract void setIog(int iog);

    public abstract String getType();
    @TextConstraint(allowed = {"PNT", "OV", "P50", "MEAN", "OIH", "pnt", "ov", "p50", "mean", "oih"})
    public abstract void setType(String type);

    /**
     * Return the type as a ForecastType enum instead of as a string.
     * 
     * @return ForecastType enum
     */
    @Derived
    public ForecastType getForecastType() {
        return ForecastType.valueOf(getType());
    }

    /**
     * Set type type using the ForecastType enum instead of a String.
     * 
     * @param t type as a ForecastType enum
     */
    public void setForecastType(ForecastType t) {
        setType(t.name());
    }

    public abstract double getProbability();
    @FloatConstraint(min = 0, max = 1)
    public abstract void setProbability(double probability);

    @Alias("week1")
    public abstract double getWeek1();
    @FloatConstraint(min = 0.0, max = Float.MAX_VALUE)
    public abstract void setWeek1(double week);
    
    @Alias("week2")
    public abstract double getWeek2();
    @FloatConstraint(min = 0.0, max = Float.MAX_VALUE)
    public abstract void setWeek2(double week);
    
    @Alias("week3")
    public abstract double getWeek3();
    @FloatConstraint(min = 0.0, max = Float.MAX_VALUE)
    public abstract void setWeek3(double week);
    
    @Alias("week4")
    public abstract double getWeek4();
    @FloatConstraint(min = 0.0, max = Float.MAX_VALUE)
    public abstract void setWeek4(double week);
    
    @Alias("week5")
    public abstract double getWeek5();
    @FloatConstraint(min = 0.0, max = Float.MAX_VALUE)
    public abstract void setWeek5(double week);
    
    @Alias("week6")
    public abstract double getWeek6();
    @FloatConstraint(min = 0.0, max = Float.MAX_VALUE)
    public abstract void setWeek6(double week);
    
    @Alias("week7")
    public abstract double getWeek7();
    @FloatConstraint(min = 0.0, max = Float.MAX_VALUE)
    public abstract void setWeek7(double week);
    
    @Alias("week8")
    public abstract double getWeek8();
    @FloatConstraint(min = 0.0, max = Float.MAX_VALUE)
    public abstract void setWeek8(double week);
    
    @Alias("week9")
    public abstract double getWeek9();
    @FloatConstraint(min = 0.0, max = Float.MAX_VALUE)
    public abstract void setWeek9(double week);
    
    @Alias("week10")
    public abstract double getWeek10();
    @FloatConstraint(min = 0.0, max = Float.MAX_VALUE)
    public abstract void setWeek10(double week);
    
    @Alias("week11")
    public abstract double getWeek11();
    @FloatConstraint(min = 0.0, max = Float.MAX_VALUE)
    public abstract void setWeek11(double week);
    
    @Alias("week12")
    public abstract double getWeek12();
    @FloatConstraint(min = 0.0, max = Float.MAX_VALUE)
    public abstract void setWeek12(double week);
    
    @Alias("week13")
    public abstract double getWeek13();
    @FloatConstraint(min = 0.0, max = Float.MAX_VALUE)
    public abstract void setWeek13(double week);
    
    @Alias("week14")
    public abstract double getWeek14();
    @FloatConstraint(min = 0.0, max = Float.MAX_VALUE)
    public abstract void setWeek14(double week);
    
    @Alias("week15")
    public abstract double getWeek15();
    @FloatConstraint(min = 0.0, max = Float.MAX_VALUE)
    public abstract void setWeek15(double week);
    
    @Alias("week16")
    public abstract double getWeek16();
    @FloatConstraint(min = 0.0, max = Float.MAX_VALUE)
    public abstract void setWeek16(double week);
      
    @Alias("week17")
    public abstract double getWeek17();
    @FloatConstraint(min = 0.0, max = Float.MAX_VALUE)
    public abstract void setWeek17(double week);
    
    @Alias("week18")
    public abstract double getWeek18();
    @FloatConstraint(min = 0.0, max = Float.MAX_VALUE)
    public abstract void setWeek18(double week);
    
    @Alias("week19")
    public abstract double getWeek19();
    @FloatConstraint(min = 0.0, max = Float.MAX_VALUE)
    public abstract void setWeek19(double week);
    
    @Alias("week20")
    public abstract double getWeek20();
    @FloatConstraint(min = 0.0, max = Float.MAX_VALUE)
    public abstract void setWeek20(double week);
    
    @Alias("week21")
    public abstract double getWeek21();
    @FloatConstraint(min = 0.0, max = Float.MAX_VALUE)
    public abstract void setWeek21(double week);
    
    @Alias("week22")
    public abstract double getWeek22();
    @FloatConstraint(min = 0.0, max = Float.MAX_VALUE)
    public abstract void setWeek22(double week);
    
    @Alias("week23")
    public abstract double getWeek23();
    @FloatConstraint(min = 0.0, max = Float.MAX_VALUE)
    public abstract void setWeek23(double week);
    
    @Alias("week24")
    public abstract double getWeek24();
    @FloatConstraint(min = 0.0, max = Float.MAX_VALUE)
    public abstract void setWeek24(double week);
    
    @Alias("week25")
    public abstract double getWeek25();
    @FloatConstraint(min = 0.0, max = Float.MAX_VALUE)
    public abstract void setWeek25(double week);
    
    @Alias("week26")
    public abstract double getWeek26();
    @FloatConstraint(min = 0.0, max = Float.MAX_VALUE)
    public abstract void setWeek26(double week);
    
    @Alias("week27")
    public abstract double getWeek27();
    @FloatConstraint(min = 0.0, max = Float.MAX_VALUE)
    public abstract void setWeek27(double week);
    
    @Alias("week28")
    public abstract double getWeek28();
    @FloatConstraint(min = 0.0, max = Float.MAX_VALUE)
    public abstract void setWeek28(double week);
    
    @Alias("week29")
    public abstract double getWeek29();
    @FloatConstraint(min = 0.0, max = Float.MAX_VALUE)
    public abstract void setWeek29(double week);
    
    @Alias("week30")
    public abstract double getWeek30();
    @FloatConstraint(min = 0.0, max = Float.MAX_VALUE)
    public abstract void setWeek30(double week);
    
    @Alias("week31")
    public abstract double getWeek31();
    @FloatConstraint(min = 0.0, max = Float.MAX_VALUE)
    public abstract void setWeek31(double week);
    
    @Alias("week32")
    public abstract double getWeek32();
    @FloatConstraint(min = 0.0, max = Float.MAX_VALUE)
    public abstract void setWeek32(double week);
    
    @Alias("week33")
    public abstract double getWeek33();
    @FloatConstraint(min = 0.0, max = Float.MAX_VALUE)
    public abstract void setWeek33(double week);   
    
}
