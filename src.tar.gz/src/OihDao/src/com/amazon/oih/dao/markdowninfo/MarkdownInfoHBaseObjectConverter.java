package com.amazon.oih.dao.markdowninfo;

import com.amazon.oih.dao.hbase.base.CommonKVHBaseDao;

public class MarkdownInfoHBaseObjectConverter extends CommonKVHBaseDao<MarkdownInfo> {

	public MarkdownInfoHBaseObjectConverter() {
		super(MarkdownInfo.class);
	}
}
