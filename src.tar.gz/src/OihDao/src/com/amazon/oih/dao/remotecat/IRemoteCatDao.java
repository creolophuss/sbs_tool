package com.amazon.oih.dao.remotecat;

import java.util.List;

import com.amazon.carbonado.Repository;
import com.amazon.oih.dao.exception.OihPersistenceException;

public interface IRemoteCatDao {
    public void setRepository(Repository repository);

    public RemoteCat createRemoteCat(long runId, RemoteCatValueObject valueObject) throws OihPersistenceException;

    public void save(RemoteCat remoteCat) throws OihPersistenceException;

    public void save(List<RemoteCat> remoteCats) throws OihPersistenceException;

    public RemoteCat find(Long runId, String asin, long marketplaceId, long merchantId) throws OihPersistenceException ;
    
    public List<RemoteCat> find(Long runId, List<String> asins, long marketplaceId, long merchantId) throws OihPersistenceException ;

    public boolean exists(Long runId, String asin, long marketplaceId,long merchantId) throws OihPersistenceException;

}
