package com.amazon.oih.dao.scopemapping;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import org.codehaus.jackson.annotate.JsonIgnore;

import com.amazon.oih.dao.g2s2.ConfigKey;

/**
 * An abstract class whose children will represent a config entity in g2s2. 
 *
 */
public abstract class ConfigEntity {

    @JsonIgnore
    public Object getId() {
        try {
            return getIdMethod(this.getClass()).invoke(this);
        } catch (IllegalArgumentException e) {
            throw new RuntimeException(e);
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        } catch (InvocationTargetException e) {
            throw new RuntimeException(e);
        }
    }
    
    @JsonIgnore
    public String getConfigKey() {
        return getConfigKey(this.getClass());
    }

    public boolean equalsById(ConfigEntity o) {
        return this.getId().equals(o.getId());
    }

    public static String getConfigKey(Class<? extends ConfigEntity> clazz) {
        ConfigKey configKey = clazz.getAnnotation(ConfigKey.class);
        if (configKey == null) {
            throw new RuntimeException("Can not find ConfigKey annotation for " + clazz.getName());
        }
        return configKey.value();
    }
    
    public static Method getIdMethod(Class<? extends ConfigEntity> clazz) {
        for (Method m : clazz.getMethods()) {
            if (m.isAnnotationPresent(ID.class)) {
                return m;
            }
        } 
        throw new RuntimeException("Can not find a method with annotation " + ID.class.getSimpleName());
    }

    


}
