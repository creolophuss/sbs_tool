package com.amazon.oih.dao.experiments;

import com.amazon.carbonado.Alias;
import com.amazon.carbonado.PrimaryKey;
import com.amazon.carbonado.Storable;
import com.amazon.carbonado.constraint.IntegerConstraint;
import com.amazon.carbonado.constraint.LengthConstraint;

@Alias("data_ipc_experiments_treatment")
@PrimaryKey({
        "runID", "experimentId", "iog", "asin"
})
public abstract class Treatment implements Storable<Treatment> {
    @Alias("run_id")
    public abstract long getRunID();

    public abstract void setRunID(long runid);

    @Alias("experiment_id")
    public abstract int getExperimentId();

    public abstract void setExperimentId(int experimentId);

    public abstract String getAsin();

    @LengthConstraint(min = 10, max = 10)
    public abstract void setAsin(String asin);

    public abstract int getIog();

    @IntegerConstraint(min = 1, max = Integer.MAX_VALUE)
    public abstract void setIog(int iog);
}
