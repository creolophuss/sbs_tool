package com.amazon.oih.dao.recall;

public class RecallInfo {
    private String asin;
    private String iog;
    private boolean isRecalled;
    public RecallInfo(String asin, String iog, boolean isRecalled) {
        super();
        this.asin = asin;
        this.iog = iog;
        this.isRecalled = isRecalled;
    }
    public String getAsin() {
        return asin;
    }
    public void setAsin(String asin) {
        this.asin = asin;
    }
    public String getIog() {
        return iog;
    }
    public void setIog(String iog) {
        this.iog = iog;
    }
    public boolean isRecalled() {
        return isRecalled;
    }
    public void setRecalled(boolean isRecalled) {
        this.isRecalled = isRecalled;
    }
    
    @Override
    public String toString() {
        StringBuilder b = new StringBuilder("{ ");
        b.append("asin = ");
        b.append(asin);
        b.append("; iog = ");
        b.append(iog);
        b.append("; isRecalled = ");
        b.append(isRecalled);
        b.append(" }");
        return b.toString();
    }

}
