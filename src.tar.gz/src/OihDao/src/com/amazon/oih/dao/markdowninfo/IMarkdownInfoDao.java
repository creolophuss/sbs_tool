package com.amazon.oih.dao.markdowninfo;

import java.util.List;

import com.amazon.carbonado.Repository;
import com.amazon.oih.dao.exception.OihPersistenceException;

/**
 * The Dao Interface definition for MarkdownInfo
 * @author zhongwei
 *
 */
public interface IMarkdownInfoDao {

    /**
     * Save mark down Info list to the database
     * @param infos
     * @throws OihPersistenceException
     */
    public abstract void save(List<MarkdownInfo> infos) throws OihPersistenceException;

    /**
     *  Save mark down Info to the database
     * @param info
     * @throws OihPersistenceException
     */
    public abstract void save(MarkdownInfo info) throws OihPersistenceException;

    /**
     * Check whether the data exist in the database.
     * @param runId
     * @param asin
     * @param marketplaceId
     * @return
     * @throws OihPersistenceException
     */
    public abstract boolean exists(Long runId, String asin, long marketplaceId) throws OihPersistenceException;

    /**
     * find the mark down info by run id, ASIN, marketplace id
     * @param runId
     * @param asin
     * @param marketplaceId
     * @return
     * @throws OihPersistenceException
     */
    public abstract MarkdownInfo find(Long runId, String asin, long marketplaceId) throws OihPersistenceException;

    /**
     * Create the mark down info object for the by the BDB
     * @param runid
     * @param asin
     * @param marketplaceId
     * @param recoveryRate
     * @param increaseDemand
     * @param increaseDemandRate
     * @param dataLevel
     * @param dataVersion
     * @return
     * @throws OihPersistenceException
     */
    public abstract MarkdownInfo createMarkdownInfo(Long runId, String asin, long marketplaceId, double recoveryRate,
            double demandIncrease, double demandIncreaseRate, String dataLevel, String dataVersion)
            throws OihPersistenceException;

    public void setRepository(Repository repository);
}
