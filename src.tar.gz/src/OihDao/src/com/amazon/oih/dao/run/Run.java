package com.amazon.oih.dao.run;

import org.joda.time.DateTime;

import com.amazon.carbonado.Alias;
import com.amazon.carbonado.Automatic;
import com.amazon.carbonado.PrimaryKey;
import com.amazon.carbonado.Storable;
import com.amazon.carbonado.constraint.LengthConstraint;

/** Run object. Describe specific run parameters. Might be extended without impact on other entities */
@Alias("dic_run")
@PrimaryKey({"runID"})
public abstract class Run implements Storable<Run> {
	@Alias("run_id")
	@Automatic
	public abstract long getRunID();
	public abstract void setRunID(long asin);

	@Alias("rundate")
	public abstract DateTime getRunDate();
	public abstract void setRunDate(DateTime time);
	
	public abstract String getDomain();
    @LengthConstraint(min=1, max=20)
	public abstract void setDomain(String domain);
	
	public abstract String getRealm();	
	public abstract void setRealm(String realm);
	
	public abstract String getTag();
    @LengthConstraint(min=0, max=20)
	public abstract void setTag(String tag);
    
    public String toString() {
        return String.format("runId: %l, runDate: %s, domain: %s, realm: %s, tag: %s", 
                getRunID(), getRunDate(), getDomain(), getRealm(), getTag());
    }
}
