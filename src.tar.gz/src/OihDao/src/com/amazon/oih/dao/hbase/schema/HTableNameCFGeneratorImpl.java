package com.amazon.oih.dao.hbase.schema;

import java.util.Calendar;
import java.util.Date;

public class HTableNameCFGeneratorImpl implements HTableNameCFGenerator {
    private static final int MARK_OF_TUESDAY = 3;
    private static final int MARK_OF_SATURDAY = 7;

    private Date rundate;
    private String realm;
    private String inputName;
    private String tableName = null;
    private String columnFamily = null;
    private boolean shouldSkipChecking = false;

    public HTableNameCFGeneratorImpl(String inputName, String columnFamily, String realm, Date rundate) {
    	this(inputName, columnFamily, realm, rundate, false);
    }
    
    public HTableNameCFGeneratorImpl(String inputName, String columnFamily, String realm, Date rundate, boolean shouldSkipChecking) {
        this.inputName = inputName;
        this.columnFamily = columnFamily;

        this.realm = realm;
        this.rundate = rundate;
        this.shouldSkipChecking = shouldSkipChecking;
    }

    @Override
    public String getTableName() {
        tableName = generateTableName(inputName, realm, rundate);
        return tableName;
    }

    @Override
    public String getColumnFamily() {
        return columnFamily;
    }
    
    /*
     * check the rundate, currently it only allows Tue & Sat generate the tablename based on input name, realm, rundate
     * Example: ForecastDistribution_USAmazon_20130101 This is a default rule, if you want to change this rule, please
     * override this method in your Dao
     */
    private String generateTableName(String inputName, String realm, Date rundate) {
    	if (! shouldSkipChecking) {
    		check(inputName, realm, rundate);
    	}
        return new HTableNamer().generateName(inputName, realm, rundate);
    }

    private void check(String inputName, String realm, Date rundate) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(rundate);
        int dayOfWeek = cal.get(Calendar.DAY_OF_WEEK);
        if (dayOfWeek != MARK_OF_TUESDAY && dayOfWeek != MARK_OF_SATURDAY) {
            throw new RuntimeException("Invalid rundate.");
        }
    }
    

}
