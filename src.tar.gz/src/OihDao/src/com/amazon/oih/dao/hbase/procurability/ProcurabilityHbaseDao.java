package com.amazon.oih.dao.hbase.procurability;

import java.util.Date;

import com.amazon.oih.dao.hbase.base.CommonKVHBaseDao;
import com.amazon.oih.dao.procurability.Procurability;


public class ProcurabilityHbaseDao extends CommonKVHBaseDao<Procurability> {

    public ProcurabilityHbaseDao() {
        super(Procurability.class);
    }

    public ProcurabilityHbaseDao(String additionalId, String realm, Date rundate) {
        super(Procurability.class, additionalId, realm, rundate);
    }
}