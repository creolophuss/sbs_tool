package com.amazon.oih.dao.hbase.vrds;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.client.ResultScanner;
import org.apache.hadoop.hbase.client.Scan;
import org.apache.hadoop.hbase.util.Bytes;

import amazon.platform.config.AppConfig;

import com.amazon.oih.dao.DaoConstants;
import com.amazon.oih.dao.hbase.base.AbstractHBaseDaoImpl;
import com.amazon.oih.dao.hbase.converter.HBaseConverterFactory;
import com.amazon.oih.dao.hbase.converter.IHBaseObjectConverter;
import com.amazon.oih.dao.hbase.schema.HTableNameCFGeneratorImpl;

@Deprecated
public class VRDSHBaseReturnTermDao extends AbstractHBaseDaoImpl<VRDSHBaseReturnTerm>{
    final static String RETURN_TERM_INPUTNAME = AppConfig.findString(DaoConstants.VRDS_RETURN_TERM_INPUTNAME);
    final static String RETURN_TERM_COLUMNFAMILY = AppConfig.findString(DaoConstants.VRDS_RETURN_TERM_COLUMNFAMILY);

    VRDSHBaseReturnTermConverter vrdsHBaseReturnTermConverter = new VRDSHBaseReturnTermConverter();
    public VRDSHBaseReturnTermDao(Date rundate, String realm) {
        super(new HTableNameCFGeneratorImpl(RETURN_TERM_INPUTNAME, RETURN_TERM_COLUMNFAMILY, realm, rundate), realm);
    }

    @Override
    protected VRDSHBaseReturnTerm convert(String rowKey, Result rs) throws IOException {
        return vrdsHBaseReturnTermConverter.convert(rowKey, rs);
    }

    @Override
    protected List<Put> convert(VRDSHBaseReturnTerm bObject) throws IOException {
        return vrdsHBaseReturnTermConverter.convert(bObject);
    }
    
}
