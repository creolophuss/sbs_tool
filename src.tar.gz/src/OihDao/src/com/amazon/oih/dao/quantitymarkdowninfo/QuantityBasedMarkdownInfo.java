package com.amazon.oih.dao.quantitymarkdowninfo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.builder.ToStringBuilder;

import com.amazon.oih.dao.markdowninfo.MarkdownInfo;
import com.google.common.annotations.VisibleForTesting;
import com.google.common.base.Preconditions;
import com.google.common.base.Splitter;
import com.google.common.collect.Lists;




/**
 * @author gaoxing
 *
 */
public class QuantityBasedMarkdownInfo implements Serializable, Cloneable {
    private static final long serialVersionUID = -3623212325131702374L;
    public static final String DATA_LEVEL_SEPARATOR = "|";
    private Map<Integer, MarkdownInfo> markdownInfos = new LinkedHashMap<Integer, MarkdownInfo>();
    public static final int NON_QUANTITY_BASED_MARKDOWN_INFO_KEY = -1;
    private ArrayList<String> dataLevels = new ArrayList<String>();
    private String asin;
    private int marketplaceId;
    private String dataVersion;
    private long runID;
    
    public final static  QuantityBasedMarkdownInfo NO_MARKDOWN = new QuantityBasedMarkdownInfo(MarkdownInfo.NO_MARKDOWN);
    
    public QuantityBasedMarkdownInfo() {
        
    }
    
    public QuantityBasedMarkdownInfo(MarkdownInfo markdownInfo) {
        setLegacyMarkdownInfo(markdownInfo);
        addDataLevel(markdownInfo.getDataLevel());
        setDataVersion(markdownInfo.getDataVersion());
        setRunID(markdownInfo.getRunID());
        setMarketplaceId(markdownInfo.getMarketplaceId());
        setAsin(markdownInfo.getAsin());
    }
  

    public QuantityBasedMarkdownInfo(long runID, String asin, int marketplaceId,
            Map<Integer, MarkdownInfo> markdownInfos, ArrayList<String> dataLevels, String dataVersion) {
        this.runID = runID;
        this.asin = asin;
        this.marketplaceId = marketplaceId;
        this.markdownInfos = markdownInfos;
        this.dataVersion = dataVersion;
        this.dataLevels = dataLevels;
    }

    public String getDataVersion() {
        return dataVersion;
    }

    public void setDataVersion(String dataVersion) {
        this.dataVersion = dataVersion;
    }

    public Map<Integer, MarkdownInfo> getMarkdownInfos() {
        return markdownInfos;
    }
    
    public void setLegacyMarkdownInfo(MarkdownInfo info) {
        markdownInfos.put(NON_QUANTITY_BASED_MARKDOWN_INFO_KEY, info);
    }

    public void setMarkdownInfos(Map<Integer, MarkdownInfo> markdownInfos) {
        this.markdownInfos = markdownInfos;
    }

    public ArrayList<String> getDataLevels() {
        return dataLevels;
    }

    public void setDataLevels(List<String> dataLevels) {
        this.dataLevels.addAll(dataLevels);
    }

    public void setAsin(String asin) {
        this.asin = asin;
    }

    public String getAsin() {
        return asin;
    }

    public int getMarketplaceId() {
        return marketplaceId;
    }

    public void setMarketplaceId(int marketplaceId) {
        this.marketplaceId = marketplaceId;
    }

    public long getRunID() {
        return runID;
    }

    public void setRunID(long runID) {
        this.runID = runID;
    }
    
    public boolean hasData() {
        return markdownInfos.size() > 0;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("asin").append(asin)
                .append("marketplaceId").append(marketplaceId)
                .append("dataLevels").append(dataLevels)
                .append("dataVersion").append(dataVersion)
                .append("markdownInfos").append(markdownInfos)
                .toString();
    }
    
    @Override
    public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }

    public MarkdownInfo getMarkdownInfoByQuantity(int quantity) {
        MarkdownInfo info = markdownInfos.get(NON_QUANTITY_BASED_MARKDOWN_INFO_KEY);
        if (quantity == 0) {
            info = MarkdownInfo.NO_MARKDOWN;
        }
        if (info == null) {
            info = markdownInfos.get(quantity);
        }
        return info;
    }

    public boolean isValid(){
        if( markdownInfos == null || markdownInfos.isEmpty()){
            return false;
        }
        
        boolean isAllInvalid = true;
        for (MarkdownInfo info : markdownInfos.values()) {
            if (info.isValid() && MarkdownInfo.NO_MARKDOWN != info) {
                isAllInvalid = false;
                break;
            }
        }
        return !isAllInvalid;    
    }
    
    
    public double getMaxMarkdownPrice(double d) {
        double maxPrice = 0.0;
        for (MarkdownInfo info : markdownInfos.values()) {
            maxPrice = Math.max(maxPrice, info.getPrice(d));
        }
        return maxPrice;
    }

    public void addDataLevel(String dataLevel) {
        if (dataLevel != null) {
            setDataLevels(Lists.newArrayList(Splitter.on(DATA_LEVEL_SEPARATOR).split(dataLevel)));
        }
        
    }

    public void setMarkdownInfoByQuantity(int quantity, MarkdownInfo markdownInfo) {
        markdownInfos.put(quantity, markdownInfo);

    }
}
