package com.amazon.oih.dao.hbase.tip;

import com.amazon.oih.dao.hbase.base.CommonKVHBaseDao;
import com.amazon.oih.dao.targetInvLevel.TargetInventoryLevelScope;

public class TargetInventoryLevelInfoHBaseDao extends CommonKVHBaseDao<TargetInventoryLevelScope>{
    public TargetInventoryLevelInfoHBaseDao() {
        super(TargetInventoryLevelScope.class);
    }
}
