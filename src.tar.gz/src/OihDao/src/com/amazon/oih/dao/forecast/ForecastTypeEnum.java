package com.amazon.oih.dao.forecast;

import com.amazon.oih.utils.EnumUserType;

/**
 * @author jianguoq
 * UserType for persisting an ForecastType Enum with a VARCHAR column
 */
public class ForecastTypeEnum extends EnumUserType<ForecastType> { 
    public ForecastTypeEnum() { 
        super(ForecastType.class); 
    } 
}
