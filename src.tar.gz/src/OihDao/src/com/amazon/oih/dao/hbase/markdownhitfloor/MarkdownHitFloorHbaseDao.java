package com.amazon.oih.dao.hbase.markdownhitfloor;

import com.amazon.oih.dao.hbase.base.CommonKVHBaseDao;

public class MarkdownHitFloorHbaseDao extends CommonKVHBaseDao<MarkdownHitFloorInfo>{

    public MarkdownHitFloorHbaseDao() {
        super(MarkdownHitFloorInfo.class);
    }

}
