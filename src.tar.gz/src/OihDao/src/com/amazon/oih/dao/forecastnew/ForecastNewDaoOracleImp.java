package com.amazon.oih.dao.forecastnew;

import java.util.Collection;
import java.util.List;

import javax.naming.NamingException;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import com.amazon.carbonado.PersistException;
import com.amazon.carbonado.RepositoryException;
import com.amazon.oih.dao.HibernateUtil;
import com.amazon.oih.dao.MySQLSessionFactoryUtil;
import com.amazon.oih.dao.forecast.ForecastType;
import com.amazon.oih.dao.run.RunDao;
import com.amazon.oih.utils.RunID2RunDateMapper;


public class ForecastNewDaoOracleImp implements ForecastNewDao{
    private final static Logger logger = Logger.getLogger(ForecastNewDaoOracleImp.class);
    protected Session session = null;
    private RunID2RunDateMapper runID2RunDateMapper;

    public ForecastNewDaoOracleImp(String domain) {
    	runID2RunDateMapper = new RunID2RunDateMapper(domain);
    }
    
    void setRunDaoForRunDateMapper(RunDao runDao){
    	runID2RunDateMapper.setRunDao(runDao);
    }
	
	@Override
	public void save(ForecastNew o) throws PersistException {
        Transaction tx = null;
        try {
            openSession();
            tx = session.beginTransaction();
            session.save(o);
            tx.commit();
        } catch (RuntimeException e) {
            logger.error("Failed to save entity " + o + " with exception ", e);
            e.printStackTrace();
            if (tx != null) {
                tx.rollback();
            }
            //throw new PersistException(e);
        } finally {
            closeSession();
        }	
	}

	@Override
	public void save(Collection<ForecastNew> fns) throws PersistException {
        Transaction tx = null;
        try {
            openSession();
            tx = session.beginTransaction();
            for (ForecastNew o : fns) {
                session.save(o);
            }
            tx.commit();
        } catch (RuntimeException e) {
            logger.error("Failed to save entity " + logger + " with exception ", e);
            e.printStackTrace();
            if (tx != null) {
                tx.rollback();
            }
            //throw new PersistException(e);
        } finally {
            closeSession();
        }
		
	}

	@Override
	public boolean exists(Long runId, String asin, Integer iog, String realm) throws NamingException, RepositoryException, ClassNotFoundException {
        logger.debug("Query Forecast by " + asin + "|" + iog + "|" + runId);
        try {
            openSession();
            Criteria cri = session.createCriteria(ForecastNewDataBaseObject.class);
            cri.add(Restrictions.eq("asin", asin));
            cri.add(Restrictions.eq("iog", iog));
            cri.add(Restrictions.eq("runDate", runID2RunDateMapper.getRunDate(runId)));
            return cri.uniqueResult() != null;
        } catch (HibernateException e) {
            e.printStackTrace();
            logger.error("Fail to query ForecastDB " + e);
            throw new RepositoryException(e);
        }
	}

    @SuppressWarnings("unchecked")
	@Override
	public Collection<? extends ForecastNew> find(Long runId, String asin, Integer iog, String realm) throws NamingException, RepositoryException,
			ClassNotFoundException {
        logger.debug("Query MarkdownForecast by " + asin + "|" + iog + "|" + runId);
        try {
            openSession();
            Criteria cri = session.createCriteria(ForecastNewDataBaseObject.class);
            cri.add(Restrictions.eq("asin", asin));
            cri.add(Restrictions.eq("iog", iog));
            cri.add(Restrictions.eq("runDate", runID2RunDateMapper.getRunDate(runId)));
            cri.addOrder(Order.asc("probability"));
            return cri.list();
        } catch (HibernateException e) {
            e.printStackTrace();
            logger.error("Fail to query ForecastDB " + e);
            throw new RepositoryException(e);
        }
	}

	@Override
	public Collection<? extends ForecastNew> find(Long runId, String asin, Integer iog, ForecastType type, String realm) throws NamingException,
			RepositoryException, ClassNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}
	
    @SuppressWarnings("unchecked")
	@Override
	public List<? extends ForecastNew> findOrderedByProbability(Long runId,
			String asin, Integer iog, ForecastType type, String realm)
			throws NamingException, RepositoryException, ClassNotFoundException {
        logger.debug("Query MarkdownForecast by " + asin + "|" + iog + "|" + runId);
        try {
            openSession();
            Criteria cri = session.createCriteria(ForecastNewDataBaseObject.class);
            cri.add(Restrictions.eq("asin", asin));
            cri.add(Restrictions.eq("iog", iog));
            cri.add(Restrictions.eq("runDate", runID2RunDateMapper.getRunDate(runId)));
            cri.addOrder(Order.asc("probability"));
            return cri.list();
        } catch (HibernateException e) {
            e.printStackTrace();
            logger.error("Fail to query ForecastDB " + e);
            throw new RepositoryException(e);
        }
	}

	@Override
	public ForecastNew createForecast(Long runId, String asin, Integer iog, ForecastType type, Double probability, List<Double> forecasts, String realm)
			throws NamingException, RepositoryException, ClassNotFoundException {
		ForecastNewDataBaseObject f = new ForecastNewDataBaseObject();
	    f.setRealm(realm);
        f.setAsin(asin);
        f.setIog(iog);
        f.setRunDate(runID2RunDateMapper.getRunDate(runId));
        f.setProbability(probability);
        f.setWeek1(forecasts.get(0));
        f.setWeek2(forecasts.get(1));
        f.setWeek3(forecasts.get(2));
        f.setWeek4(forecasts.get(3));
        f.setWeek5(forecasts.get(4));
        f.setWeek6(forecasts.get(5));
        f.setWeek7(forecasts.get(6));
        f.setWeek8(forecasts.get(7));
        f.setWeek9(forecasts.get(8));
        f.setWeek10(forecasts.get(9));
        f.setWeek11(forecasts.get(10));
        f.setWeek12(forecasts.get(11));
        f.setWeek13(forecasts.get(12));
        f.setWeek14(forecasts.get(13));
        f.setWeek15(forecasts.get(14));
        f.setWeek16(forecasts.get(15));
        f.setWeek17(forecasts.get(16));
        f.setWeek18(forecasts.get(17));
        f.setWeek19(forecasts.get(18));
        f.setWeek20(forecasts.get(19));
        f.setWeek21(forecasts.get(20));
        f.setWeek22(forecasts.get(21));
        f.setWeek23(forecasts.get(22));
        f.setWeek24(forecasts.get(23));
        f.setWeek25(forecasts.get(24));
        f.setWeek26(forecasts.get(25));
        f.setWeek27(forecasts.get(26));
        f.setWeek28(forecasts.get(27));
        f.setWeek29(forecasts.get(28));
        f.setWeek30(forecasts.get(29));
        f.setWeek31(forecasts.get(30));
        f.setWeek32(forecasts.get(31));
        f.setWeek33(forecasts.get(32));
        return f;
	}


    private void openSession() {
        session = HibernateUtil.getSessionFactory().openSession();
    }

    private void closeSession() {
        if (session != null) {
            session.close();
        }
    }
}
