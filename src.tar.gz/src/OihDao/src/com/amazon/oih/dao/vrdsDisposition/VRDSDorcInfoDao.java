package com.amazon.oih.dao.vrdsDisposition;

import java.util.List;

import com.amazon.oih.dao.exception.OihPersistenceException;

public interface VRDSDorcInfoDao {

    public abstract void save(List<VRDSDorcInfo> info) throws OihPersistenceException;

    public abstract void save(VRDSDorcInfo info) throws OihPersistenceException;

    public abstract boolean exists(Long runId, String asin, Integer iog) throws OihPersistenceException;

    public abstract List<VRDSDorcInfo> find(Long runId, String asin, Integer iog) throws OihPersistenceException;

    public abstract VRDSDorcInfo createVRDSDorcInfo(Long runid, OIHDorcInfo dInfo) throws OihPersistenceException;
    
    public abstract List<VRDSDorcInfo> find(Long runId, String asin) throws OihPersistenceException;
    
    public abstract VRDSDorcInfo findByDsiId(Long runId, Integer iog, String asin, long dsiId) throws OihPersistenceException;
    
    public abstract void delete(Long runId, String asin, Integer iog) throws OihPersistenceException;
}
