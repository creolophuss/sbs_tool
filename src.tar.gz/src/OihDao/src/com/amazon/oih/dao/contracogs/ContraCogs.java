package com.amazon.oih.dao.contracogs;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import com.amazon.oih.common.RowKeyBuildType;
import com.amazon.oih.common.RowKeyType;
import com.amazon.oih.dao.hbase.base.CommonKVHBaseDao.HTable;
import com.amazon.oih.dao.hbase.converter.Column;
import com.amazon.oih.dao.hbase.converter.RowKey;
import com.amazon.oih.dao.hbase.converter.SubKey;

@RowKey({"asin", "scopeId"})
@SubKey({"vendor"})
@RowKeyBuildType(RowKeyType.ASIN_SCOPE)
@HTable(value = "ContraCogs", columFamilyName = "contra-cogs")
public class ContraCogs implements Serializable {

    private static final long serialVersionUID = -4219498998165583898L;

    private String asin;
    private String scopeId;
    private String vendor;
    
    @Column(name="value",index=0)
    private double dsiContraCogs; // CongraCogs of distributor shipment item
    
    @Column(name="value",index=1)
    private double coiContraCogs; // ContraCogs of customer order item
    
    @Column(name="value",index=2)
    private double csiContraCogs; // ContraCogs of customer shipment item

    /**
     * Keep this for common DAO init instance.
     */
    public ContraCogs() {
        
    }
    
    public ContraCogs(ContraCogs inContraCogs) {
        this.asin = inContraCogs.asin;
        this.scopeId = inContraCogs.scopeId;
        this.vendor = inContraCogs.vendor;
        this.dsiContraCogs = inContraCogs.dsiContraCogs;
        this.coiContraCogs = inContraCogs.coiContraCogs;
        this.csiContraCogs = inContraCogs.csiContraCogs;
    }

    public ContraCogs(String asin, String scopeId) {
        this.asin = asin;
        this.scopeId = scopeId;
    }

    public ContraCogs(String asin, String scopeId, 
            double dsiContraCogs, double coiContraCogs, double csiContraCogs) {
        this(asin, scopeId);
        this.dsiContraCogs = dsiContraCogs;
        this.coiContraCogs = coiContraCogs;
        this.csiContraCogs = csiContraCogs;
    }
    
    public static List<ContraCogs> findByAsinScope(String asin, String scopeId, Collection<ContraCogs> cogsList){
        List<ContraCogs> results = new ArrayList<ContraCogs>();
        for (ContraCogs cogs : cogsList){
            if (asin.equals(cogs.getAsin()) && scopeId.equals(cogs.getScopeId())) {
                results.add(cogs);
            }
        }
        return results;
    }
    
    public String getAsin() {
        return asin;
    }

    public void setAsin(String asin) {
        this.asin = asin;
    }
    

    @Override
    public String toString() {
        return "Contra-COGs: asin=" + asin + ", scopeId=" + scopeId + ", dsiContraCogs=" + dsiContraCogs + ", coiContraCogs=" + coiContraCogs +
                ", csiContraCogs=" + csiContraCogs;
    }

    public String getScopeId() {
        return scopeId;
    }
    
    public String getVendor() {
        return vendor;
    }
    
    public void setVendor(String vendor) {
        this.vendor = vendor;
    }

    public double getDsiContraCogs() {
        return dsiContraCogs;
    }

    public void setDsiContraCogs(double dsiContraCogs) {
        this.dsiContraCogs = dsiContraCogs;
    }

    public double getCoiContraCogs() {
        return coiContraCogs;
    }

    public void setCoiContraCogs(double coiContraCogs) {
        this.coiContraCogs = coiContraCogs;
    }

    public double getCsiContraCogs() {
        return csiContraCogs;
    }

    public void setCsiContraCogs(double csiContraCogs) {
        this.csiContraCogs = csiContraCogs;
    }

    public void setScopeId(String scopeId) {
        this.scopeId = scopeId;
    }
    
}
