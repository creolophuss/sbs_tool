package com.amazon.oih.dao.shipcosts;

import java.util.Date;

import com.amazon.oih.dao.hbase.base.ApplicationObjectHBaseDao;

public class AsinShipoutCostInfoHBaseObjectConverter extends ApplicationObjectHBaseDao<
        AsinShipoutCostInfo, AsinShipoutCostInfoHBaseObject>{

    public AsinShipoutCostInfoHBaseObjectConverter() {
        super(AsinShipoutCostInfoHBaseObject.class);
    }
    public AsinShipoutCostInfoHBaseObjectConverter(Class<AsinShipoutCostInfoHBaseObject> classObj, String additionalId,
            String realm, Date rundate) {
        super(classObj, additionalId, realm, rundate);
    }

}
