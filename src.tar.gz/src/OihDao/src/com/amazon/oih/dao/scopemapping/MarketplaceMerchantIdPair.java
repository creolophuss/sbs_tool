package com.amazon.oih.dao.scopemapping;

import com.google.common.base.Objects;
import com.google.common.collect.ComparisonChain;

public class MarketplaceMerchantIdPair implements Comparable<MarketplaceMerchantIdPair>{

    private long marketplaceId;

    private long merchantId;
    
    public MarketplaceMerchantIdPair() {
    }    
    
    public MarketplaceMerchantIdPair(long marketplaceId, long merchantId) {
        this.marketplaceId = marketplaceId;
        this.merchantId = merchantId;
    }
    
    public long getMarketplaceId() {
        return marketplaceId;
    }

    public void setMarketplaceId(long marketplaceId) {
        this.marketplaceId = marketplaceId;
    }

    public long getMerchantId() {
        return merchantId;
    }

    public void setMerchantId(long merchantId) {
        this.merchantId = merchantId;
    }
    
    @Override
    public boolean equals(Object other) {
        if (!(other instanceof MarketplaceMerchantIdPair)) {
            return false;
        }
        MarketplaceMerchantIdPair that = (MarketplaceMerchantIdPair) other;
        return Objects.equal(this.marketplaceId, that.marketplaceId) 
                && Objects.equal(this.merchantId, that.merchantId);
    }

    @Override
    public int compareTo(MarketplaceMerchantIdPair that) {
        return ComparisonChain.start()
                .compare(this.marketplaceId, that.marketplaceId)
                .compare(this.merchantId, that.merchantId)
                .result();
    }    
}
