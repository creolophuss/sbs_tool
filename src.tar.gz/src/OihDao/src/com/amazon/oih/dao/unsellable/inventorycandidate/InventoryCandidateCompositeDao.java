package com.amazon.oih.dao.unsellable.inventorycandidate;

import java.util.List;

import com.amazon.carbonado.Repository;
import com.amazon.oih.dao.exception.OihPersistenceException;

public interface InventoryCandidateCompositeDao {
    public void setRepository(Repository repository);

    public abstract void save(List<InventoryCandidateComposite> items) throws OihPersistenceException;

    public abstract void save(InventoryCandidateComposite item) throws OihPersistenceException;

    public abstract boolean exists(String asin, String fnsku, String fcsku, Integer iog, String condition,
            String warehouse) throws OihPersistenceException;

    public abstract InventoryCandidateComposite find(String asin, String fnsku, String fcsku, Integer iog,
            String condition, String warehouse) throws OihPersistenceException;

    public abstract InventoryCandidateComposite createICComposite(ICCItem item)
            throws OihPersistenceException;
}
