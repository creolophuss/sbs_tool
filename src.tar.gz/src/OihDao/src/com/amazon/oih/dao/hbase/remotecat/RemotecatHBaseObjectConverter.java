package com.amazon.oih.dao.hbase.remotecat;

import com.amazon.oih.dao.hbase.base.SubKeyAwareHBaseDao;
import com.amazon.oih.dao.remotecat.RemoteCat;

public class RemotecatHBaseObjectConverter extends SubKeyAwareHBaseDao<RemoteCat>{

	public RemotecatHBaseObjectConverter() {
		super(RemoteCat.class);
	}

}
