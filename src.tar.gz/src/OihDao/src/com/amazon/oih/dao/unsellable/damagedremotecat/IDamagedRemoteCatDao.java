package com.amazon.oih.dao.unsellable.damagedremotecat;

import java.util.List;

import com.amazon.carbonado.Repository;
import com.amazon.oih.dao.exception.OihPersistenceException;
import com.amazon.oih.dao.remotecat.RemoteCatValueObject;

public interface IDamagedRemoteCatDao {
    public void setRepository(Repository repository);

    public DamagedRemoteCatObject createRemoteCat(RemoteCatValueObject valueObject) throws OihPersistenceException;

    public void save(DamagedRemoteCatObject remoteCat) throws OihPersistenceException;

    public void save(List<DamagedRemoteCatObject> remoteCats) throws OihPersistenceException;

    public DamagedRemoteCatObject find(String asin, int iog) throws OihPersistenceException;

    public boolean exists(String asin, int iog) throws OihPersistenceException;
}
