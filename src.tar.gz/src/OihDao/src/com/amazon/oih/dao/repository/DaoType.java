package com.amazon.oih.dao.repository;

import com.amazon.oih.dao.OihDao;
import com.amazon.oih.dao.OihObject;
import com.amazon.oih.dao.forecast.ForecastDao;
import com.amazon.oih.dao.ilbo.IlboDao;
import com.amazon.oih.dao.ourprice.OurPriceDao;
import com.amazon.oih.utils.DaoUtil;

public enum DaoType {

    OUR_PRICE_DAO {
        public OurPriceDao getDao(String source) {
            if (RepositoryFactory.UNIT_TEST.equalsIgnoreCase(source)) {
                return DaoUtil.getOurPriceDao4UnitTest();
            }

            return new OurPriceDao(source);
        }
    },

    FORECAST_DAO {
        public ForecastDao getDao(String source) {
            if (RepositoryFactory.UNIT_TEST.equalsIgnoreCase(source)) {
                return DaoUtil.getForecatDao4UnitTest();
            }

            return new ForecastDao(source);
        }
    },

    ILBO_DAO {
        public IlboDao getDao(String source) {
            if (RepositoryFactory.UNIT_TEST.equalsIgnoreCase(source)) {
                return DaoUtil.getILBODao4UnitTest();
            }
            return new IlboDao(source);
        }
    };

    public abstract OihDao<? extends OihObject> getDao(String source);

}
