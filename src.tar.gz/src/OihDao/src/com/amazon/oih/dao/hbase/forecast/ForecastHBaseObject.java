package com.amazon.oih.dao.hbase.forecast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import amazon.platform.config.AppConfig;

import com.amazon.oih.dao.DaoConstants;
import com.google.common.base.Joiner;

public class ForecastHBaseObject {
    private final static int SMOOTH_FORECAST_LENGTH = 3;
    
    private String asin;
    private long marketplace;
    private Map<String, List<Double>> forecastMap = new HashMap<String, List<Double>>();
    private String realm;

    public Map<String, List<Double>> getForecastMap() {
        return forecastMap;
    }

    public void setForecast(Map<String, List<Double>> forecastMap) {
        if (forecastMap == null) {
            return;
        }
        Set<String> keySet = forecastMap.keySet();
        Iterator<String> it = keySet.iterator();
        while (it.hasNext()) {
            String key = (String) it.next();
            List<Double> forecastValueList = forecastMap.get(key);
            List<Double> thisForecastValueList = new ArrayList<Double>();
            for (double value : forecastValueList) {
                if (Double.isNaN(value) || Double.isInfinite(value)) {
                    thisForecastValueList.add(0.0);
                } else {
                    thisForecastValueList.add(value);
                }
            }
            
            int len = thisForecastValueList.size();
            if(len > SMOOTH_FORECAST_LENGTH){
                double lastForecast = thisForecastValueList.get(len - 1);
                if (lastForecast < 1e-6){
                    double totalForecast = 0;
                    for (int i=0; i< SMOOTH_FORECAST_LENGTH; i++){
                        double lastXForecast = thisForecastValueList.get(len - 2 - i);
                        totalForecast += lastXForecast;
                    }
                    double lastAverageForecast = totalForecast/SMOOTH_FORECAST_LENGTH;
                    lastForecast = lastAverageForecast;
                    thisForecastValueList.set(len - 1, lastForecast);
                }                
            }
            this.forecastMap.put(key, thisForecastValueList);
        }
    }

    public void setAsin(String asin) {
        this.asin = asin;
    }

    public String getAsin() {
        return asin;
    }

    public void setMarketplace(long marketplace) {
        this.marketplace = marketplace;
    }

    public long getMarketplace() {
        return marketplace;
    }

    public String getRealm() {
        return realm;
    }

    public void setRealm(String realm) {
        this.realm = realm;
    }

    public ForecastHBaseObject() {
    }

    public ForecastHBaseObject(String asin, long marketplace) {
        this.asin = asin;
        this.marketplace = marketplace;
        
        setRealm(AppConfig.getRealm().name());
    }

    public ForecastHBaseObject(String asin, long marketplace, Map<String, List<Double>> forecastMap) {
        this(asin, marketplace);

        setRealm(AppConfig.getRealm().name());

        setForecast(forecastMap);
    }

    public String getValues(String key) {
        List<Double> forecastValueList = forecastMap.get(key);
        if (forecastValueList == null) {
            throw new RuntimeException("Illegal Forecast Value. Asin: " + getAsin() + " Marketplace: "
                    + getMarketplace() + " Probability: " + key);
        }
        return Joiner.on(DaoConstants.WEEKLY_FORECAST_VALUE_SPLIT).join(forecastValueList);
    }
    
    public List<AnnoForecastHBaseObj> toAnnoForecastHBaseObj(){
        List<AnnoForecastHBaseObj> result = new ArrayList<AnnoForecastHBaseObj>();
        for (Map.Entry<String, List<Double>> entry : forecastMap.entrySet()){
            String probability = entry.getKey();
            List<Double> forecastList = entry.getValue();
            AnnoForecastHBaseObj annoObj = new AnnoForecastHBaseObj();
            annoObj.setAsin(this.asin);
            annoObj.setMarketplace(this.marketplace);
            annoObj.setProbability(probability);
            annoObj.setForecastSeq(forecastList);
            result.add(annoObj);
        }
        return result;
    }
}