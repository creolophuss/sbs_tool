package com.amazon.oih.dao.vrdsDisposition;

import java.util.List;

import com.amazon.oih.dao.exception.DaoRuntimeException;
import com.amazon.oih.dao.exception.OihPersistenceException;

public interface VRDSReturnTermsDao {

    public abstract void save(VRDSReturnTerms info) throws OihPersistenceException;

    public abstract boolean exists(Long runId, String asin, Integer iog, String vendor) throws DaoRuntimeException,
            OihPersistenceException;

    public abstract boolean exists(Long runId, String asin, Integer iog) throws DaoRuntimeException,
            OihPersistenceException;

    public abstract List<VRDSReturnTerms> find(Long runId, String asin, Integer iog, String vendor)
            throws DaoRuntimeException, OihPersistenceException;

    public abstract VRDSReturnTerms createVRDSReturnTerms(Long runid, ReturnTermInfo retInfo)
            throws DaoRuntimeException, OihPersistenceException;

    public abstract void save(List<VRDSReturnTerms> returnTerms) throws OihPersistenceException;
    
    public abstract void delete(Long runId, String asin, Integer iog)
           throws DaoRuntimeException, OihPersistenceException;
}
