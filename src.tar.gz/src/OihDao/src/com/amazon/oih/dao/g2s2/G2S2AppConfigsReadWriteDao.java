package com.amazon.oih.dao.g2s2;

import amazon.iop.metadata.g2s2.client.internal.G2S2InternalRepositoryClient;

/**
 * Created with IntelliJ IDEA. User: xlpeng Date: 8/1/12 Time: 12:00 AM To change this template use File | Settings |
 * File Templates.
 */
public interface G2S2AppConfigsReadWriteDao extends G2S2AppConfigsReadonlyDao {
    /**
     * save app config into G2S2 with provided key.
     * 
     * @param key
     *            key for app config
     * @param appConfig
     *            app config content
     */
    <T> void saveAppConfig(String key, T appConfig);

    /**
     * save app config into G2S2 with provided key.
     * 
     * @param key
     *            key key for app config
     * @param realm
     *            realm that the app config will be bound to.
     * @param appConfig
     *            app config content
     */
    <T> void saveAppConfig(String key, T appConfig, String realm);

    /**
     * save app config into G2S2 with provided key.
     * 
     * @param key
     *            key key key for app config
     * @param appConfig
     *            app config content
     * @param realm
     *            realm that the app config will be bound to.
     * @param domain
     *            domain that the app config will be bound to.
     */
    <T> void saveAppConfig(String key, T appConfig, String realm, String domain);

    /**
     * save app config into G2S2
     * 
     * @param appConfig
     *            app config content
     * @param realm
     *            realm that the app config will be bound to.
     * @param domain
     *            domain that the app config will be bound to.
     * @param <T>
     *            type of app config content with ConfigKey annotation
     */
    <T> void saveAppConfig(T appConfig, String realm, String domain);

    /**
     * retrieve G2S2InternalRepositoryClient that used while saving data to g2s2
     * 
     * @return instance of G2S2InternalRepositoryClient
     */
    G2S2InternalRepositoryClient getG2S2InternalRepositoryClient();

    /**
     * retrieve G2S2ClientConfigs that contains the G2S2 client configurations.
     * 
     * @return instance of G2S2ClientConfigs
     */
    G2S2ClientConfigs getG2S2ClientConfig();

    /**
     * used to begin g2s2 write transaction, will create a stage version based on the latest stage version, and the
     * following save method will write data to the new stage version before call G2S2WriteTransaction.commit().commit()
     * or G2S2WriteTransaction.close().
     * 
     * @return instance of G2S2WriteTransaction
     */
    G2S2WriteTransaction beginWriteTransacton();

}
