package com.amazon.oih.dao.hbase.ourprice;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import amazon.platform.config.AppConfig;

import com.amazon.oih.dao.DaoConstants;
import com.amazon.oih.dao.hbase.base.HBaseDaoImplAdaptor;
import com.amazon.oih.utils.HBaseRowkeyUtil;

/**
 * The HBaseDao imp for ourprice, there's only 1 columnFamily and 1 column in
 * that family
 * 
 * @author jialei
 * 
 */
@Deprecated
public class OurpriceHbaseDao extends HBaseDaoImplAdaptor<OurpriceHbaseObject> {
    /**
     * for every value, HBase has to repeat record/store/manage/sort the
     * COLUMN_FAMILY_NAME and COLUMN_NAME, try keep the column_name as short as
     * possible.
     */
    private final static String COLUMN_NAME = "price";
    private final static String TABLE_NAME = AppConfig.findString(DaoConstants.OUR_PRICE_INPUTNAME);
    
    public OurpriceHbaseDao(){
        super();
    }

    public OurpriceHbaseDao(String realm, Date rundate) {
        super(TABLE_NAME, realm, rundate);
    }

    @Override
    protected Map<String, String> generateColumnValueMap(OurpriceHbaseObject bObject) {
        Map<String, String> columnMap = new HashMap<String, String>();
        columnMap.put(COLUMN_NAME, String.valueOf(bObject.getOurprice()));

        return columnMap;
    }

    @Override
    protected OurpriceHbaseObject construct(String rowKey, Map<String, String> columnMap) {
        OurpriceHbaseObject ourPriceObj = HBaseRowkeyUtil.parseOurpriceHbaseObject(rowKey);
        ourPriceObj.setOurprice(Double.valueOf(columnMap.get(COLUMN_NAME)));

        return ourPriceObj;
    }

    @Override
    public String generateRowKey(OurpriceHbaseObject bObject) {
        return HBaseRowkeyUtil.getRowKeyForAsinIog(bObject.getAsin(), String.valueOf(bObject.getIog()));
    }
}
