package com.amazon.oih.dao.miscAsin;

import java.io.Serializable;

public class MiscAsin implements Serializable, Comparable<MiscAsin> {
    private static final long serialVersionUID = 744804609528226957L;
    private long runID;
    private String asin;
    private String org;
    private String type;
    
    public MiscAsin() {
    }
    
    public MiscAsin(String asin, String org, String type) {
        this.asin = asin;
        this.org = org;
        this.type = type;
    }

    public long getRunID() {
        return runID;
    }

    public void setRunID(long runID) {
        this.runID = runID;
    }

    public String getAsin() {
        return asin;
    }

    public void setAsin(String asin) {
        this.asin = asin;
    }

    public String getOrg() {
        return org;
    }

    public void setOrg(String org) {
        this.org = org;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((asin == null) ? 0 : asin.hashCode());
        result = prime * result + ((org == null) ? 0 : org.hashCode());
        result = prime * result + (int)(runID);
        result = prime * result + ((type == null) ? 0 : type.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        MiscAsin other = (MiscAsin) obj;
        if (asin == null) {
            if (other.asin != null)
                return false;
        } else if (!asin.equals(other.asin))
            return false;
        if (org == null) {
            if (other.org != null)
                return false;
        } else if (!org.equals(other.org))
            return false;
        if (runID != other.runID)
            return false;
        if (type == null) {
            if (other.type != null)
                return false;
        } else if (!type.equals(other.type))
            return false;
        return true;
    }

    @Override
    public String toString() {
        return "MiscAsin [runID=" + runID + ", asin=" + asin + ", org=" + org
                + ", type=" + type + "]";
    }

    @Override
    public int compareTo(MiscAsin arg0) {
        return this.toString().compareTo(arg0.toString());
    }
    
}
