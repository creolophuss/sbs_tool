package com.amazon.oih.dao.hbase.civ;

import java.util.Date;

import com.amazon.oih.dao.hbase.base.CommonKVHBaseDao;

public class CIVInfoHbaseDao extends CommonKVHBaseDao<CIVInfo> {

    public CIVInfoHbaseDao() {
        super(CIVInfo.class);
    }

    public CIVInfoHbaseDao(String additionalId, String realm, Date rundate) {
        super(CIVInfo.class, additionalId, realm, rundate);
    }
}