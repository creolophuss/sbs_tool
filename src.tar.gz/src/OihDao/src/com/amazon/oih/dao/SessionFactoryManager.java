package com.amazon.oih.dao;

import java.util.concurrent.ConcurrentHashMap;

import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;

import org.apache.log4j.Logger;

/**
 * Simple component that simply constructs a Hibernate SessionFactory
 * using the hibernate configuration available in current CLASSPATH. 
 * 
 * Apps  can either instantiate this class directly (typically at startup)
 * or inject it via configuration into a service/servlet container.
 * 
 * @author svisvan
 * 
 */
public class SessionFactoryManager {
    
    public final static String CONFIG_SCOSMET = "hibernate.scosmet.cfg.xml";
    
    public final static String CONFIG_VENDORFLEX = "hibernate.vendorflex.cfg.xml";
	
	private static Logger log = Logger.getLogger(SessionFactoryManager.class);
	
	private static Object mutex= new Object();
	
	public static ConcurrentHashMap<String, SessionFactory> fileSessionFactorys= new ConcurrentHashMap<String, SessionFactory>();
		
	private static SessionFactory buildSessionFactoryFromFile(String file){
		try {
			Configuration cfg = new AnnotationConfiguration();
			cfg.configure(file);
			return cfg.buildSessionFactory();
		} catch (HibernateException e) {
			log.error("Unable to setup sessionFactory from file "+ file);
			throw new RuntimeException("Unable to setup sessionFactory",e);
		}		
	}

	public static SessionFactory getSessionFactoryInstance(String file){
		SessionFactory sf = fileSessionFactorys.get(file);
		if(sf == null){
			synchronized(mutex){
				sf = fileSessionFactorys.get(file);
				if(sf == null){
					sf = buildSessionFactoryFromFile(file);
					registSessionFactory(file, sf);	
					log.info("SessionFactory setup from file "+ file);
				}
			}
		}
		return sf;
	}	

	public static SessionFactory getScosmetSessionFactoryInstance(){
		return getSessionFactoryInstance(CONFIG_SCOSMET);
	}

    public static SessionFactory getVendorFlexSessionFactoryInstance(){
        return getSessionFactoryInstance(CONFIG_VENDORFLEX);
    }
    
    static void registSessionFactory(String file, SessionFactory sf) {
        fileSessionFactorys.put(file, sf);
    }
}
