package com.amazon.oih.dao.hbase.base;

import java.io.IOException;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.hadoop.hbase.KeyValue;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.util.Bytes;

import com.amazon.oih.common.KeyValueDao;
import com.amazon.oih.dao.hbase.schema.HTableNameCFGeneratorImpl;
import com.google.common.collect.Sets;

/**
 * Helper Class for implementing a HBaseDao, subClass would be charged for define tableName and ColumFamilyName, By
 * using this class, you could build HBaseDao without knowing any HBase knowledge like {@link Put}, {@link Result} ...
 * etc..
 * 
 * @author jialei
 * 
 * @param <T>
 */
public abstract class HBaseDaoImplAdaptor<T> extends AbstractHBaseDaoImpl<T> implements KeyValueDao<String, T> {
    private static final String DEFAULT_COLUMN_FAMILY = "info";
    private Set<String> projections;
    
    public HBaseDaoImplAdaptor() {
        super();
    }

    public HBaseDaoImplAdaptor(String tableName, String columFamilyName, String realm, Date rundate) {
        super(new HTableNameCFGeneratorImpl(tableName, columFamilyName == null ? DEFAULT_COLUMN_FAMILY
                : columFamilyName, realm, rundate), realm);
    }
    
    public HBaseDaoImplAdaptor(String tableName, String columFamilyName, String realm, Date rundate,
            boolean skipRundateChecking) {
        super(new HTableNameCFGeneratorImpl(tableName, columFamilyName == null ? DEFAULT_COLUMN_FAMILY
                : columFamilyName, realm, rundate, skipRundateChecking), realm);
    }

    public HBaseDaoImplAdaptor(String tableName, String realm, Date rundate) {
        this(tableName, null, realm, rundate);
    }

    @Override
    protected T convert(String rowKey, Result rs) throws IOException {
        if (rs == null || rs.isEmpty()) {
            return null;
        }
        Map<String, String> comlumnMap = convertResult2KVMap(rs);

        return construct(rowKey, comlumnMap);
    }

    public static Map<String, String> convertResult2KVMap(Result rs) {
        Map<String, String> comlumnMap = new HashMap<String, String>();
        for (KeyValue kv : rs.raw()) {
            String columnName = new String(kv.getQualifier());
            String value = new String(kv.getValue());

            comlumnMap.put(columnName, value);
        }
        return comlumnMap;
    }

    @Override
    protected List<Put> convert(T bObject) throws IOException {
        String rowKey = generateRowKey(bObject);
        
        Put put = new Put(Bytes.toBytes(rowKey));

        Map<String, String> comlumnMap = generateColumnValueMap(bObject);
             
        if (projections != null && projections.size() != 0){
            comlumnMap = filterByProjections(comlumnMap);
        }
        Set<Entry<String, String>> entries = comlumnMap.entrySet();

        for (Entry<String, String> entry : entries) {
            String value = entry.getValue();
            String key = entry.getKey();
            put.add(Bytes.toBytes(columnFamily), Bytes.toBytes(key), Bytes.toBytes(value));
        }

        return Collections.singletonList(put);
    }
    
    private Map<String, String> filterByProjections(Map<String, String> orgMap){
        Map<String, String> projectionMap = new HashMap<String, String>();
        Set<String> matchedProjections = new HashSet<String>();
        for (Map.Entry<String, String> entry : orgMap.entrySet()) {
            String key = entry.getKey();
            String pojoColumnName = this.getPOJOColumnName(key);
            if (projections.contains(pojoColumnName)) {
                matchedProjections.add(pojoColumnName);
                projectionMap.put(key, entry.getValue());
            }
        }
        Set<String> unmatchedProjections = Sets.difference(projections, matchedProjections);
        if (unmatchedProjections.size() != 0) {
            throw new RuntimeException("invalid projections:" + unmatchedProjections);
        }
        return projectionMap;
    }

    @Override
    public T getValue4Key(String rowKey) throws IOException {
        return this.get(rowKey);
    }

    @Override
    public List<T> batchGet(List<String> rowkeys) throws IOException {
        return this.get(rowkeys);
    }
    
    public static <T> Set<String> findExistRowKeys(List<String> rowkeys, List<T> queryResult){
        Set<String> exsitingkeys = new HashSet<String>();
        for (int i=0; i< queryResult.size(); i++){
            if (queryResult.get(i) != null){
                exsitingkeys.add(rowkeys.get(i));
            }
        }
        return exsitingkeys;
    }

    @Override
    public void batchSave(List<T> objs) throws IOException {
        this.put(objs);
    }
    
    /**
     * With projections, HBaseDao only update HBase table for POJO whose @Column.name is in the projections list. The use case
     * is: When your POJO's data come from multiple datasource, e.g. from 2 different input services, usually you need to
     * call both services and build a intact POJO, then use subclass of HBaseDaoImplAdaptor<T> to put the entire POJO into
     * HBase. But this would make those 2 input collection work highly coupled(they must be finished in one JVM), while you
     * could not use subclass of HBaseDaoImplAdaptor<T> to directly put half built POJO into HBase, because those classes
     * consider fields un-init as null, and use null to override the corresponding value in HBase, and causes issue. While
     * using ProjectionBasedHBaseDao<T>, you could create 2 ProjectionBasedHBaseDao<T> for each of the 2 input service, and
     * use projections to limit the Dao only update HBase use POJO's fields which you want it to update HBase table, so you
     * could collect input and update HBase table using 2 jobs runs in 2 separate JVM.
     */
    public void setProjections(Set<String> projections){
        this.projections = projections;
    }

    /**
     * By default, HBase columnName is same with POJO columnName
     * @param hbaseColumnName
     * @return
     */
    protected String getPOJOColumnName(String hbaseColumnName){
        return hbaseColumnName;
    }
    
    public abstract String generateRowKey(T bObject);

    protected abstract Map<String, String> generateColumnValueMap(T bObject);

    protected abstract T construct(String rowKey, Map<String, String> columnMap);
}
