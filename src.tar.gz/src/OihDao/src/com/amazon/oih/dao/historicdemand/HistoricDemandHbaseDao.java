package com.amazon.oih.dao.historicdemand;

import java.util.Date;

import com.amazon.oih.dao.hbase.base.CommonKVHBaseDao;

public class HistoricDemandHbaseDao extends CommonKVHBaseDao<HistoricDemandRawData> {

    public HistoricDemandHbaseDao() {
        super(HistoricDemandRawData.class);
    }

    public HistoricDemandHbaseDao(String additionalId, String realm, Date rundate) {
        super(HistoricDemandRawData.class, additionalId, realm, rundate);
    }
    
}