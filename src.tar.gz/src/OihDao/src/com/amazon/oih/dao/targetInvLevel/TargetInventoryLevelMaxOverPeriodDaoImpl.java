package com.amazon.oih.dao.targetInvLevel;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import com.amazon.oih.dao.MySQLSessionFactoryUtil;
import com.amazon.oih.dao.exception.OihPersistenceException;
import com.amazon.oih.utils.AsinIogPair;
import com.amazon.oih.utils.Utils;

public class TargetInventoryLevelMaxOverPeriodDaoImpl implements TargetInventoryLevelMaxOverPeriodDao {
    private final static Logger logger = Logger.getLogger(TargetInventoryLevelMaxOverPeriodDaoImpl.class);
    protected Session session = null;

    public TargetInventoryLevelMaxOverPeriodDaoImpl(String domain) {
    }

    @Override
    public TargetInventoryLevelMaxOverPeriod createTargetInventoryLevelMaxOverPeriod(Long runid, String asin,
            Integer iog, Integer til, Integer cartonQty) {
        return new TargetInventoryLevelMaxOverPeriod(runid, asin, iog, til, cartonQty);
    }

    @Override
    public boolean exists(Long runId, String asin, Integer iog) throws OihPersistenceException {
        logger.debug("Query TargetInventoryLevelMaxOverPeriod by " + asin + "|" + iog + "|" + runId);
        try {
            openSession();
            Criteria cri = session.createCriteria(TargetInventoryLevelMaxOverPeriod.class);
            cri.add(Restrictions.eq("asin", asin));
            cri.add(Restrictions.eq("iog", iog));
            cri.add(Restrictions.eq("runID", runId));
            return cri.uniqueResult() != null;
        } catch (HibernateException e) {
            e.printStackTrace();
            logger.error("Fail to query TargetInventoryLevelMaxOverPeriod ", e);
            throw new OihPersistenceException(e);
        }
    }

    @Override
    public TargetInventoryLevelMaxOverPeriod find(Long runId, String asin, Integer iog) throws OihPersistenceException {
        logger.debug("Query TargetInventoryLevelMaxOverPeriod by " + asin + "|" + iog + "|" + runId);
        try {
            openSession();
            Criteria cri = session.createCriteria(TargetInventoryLevelMaxOverPeriod.class);
            cri.add(Restrictions.eq("asin", asin));
            cri.add(Restrictions.eq("iog", iog));
            cri.add(Restrictions.eq("runID", runId));
            return (TargetInventoryLevelMaxOverPeriod) cri.uniqueResult();
        } catch (HibernateException e) {
            e.printStackTrace();
            logger.error("Fail to query TargetInventoryLevelMaxOverPeriod ", e);
            throw new OihPersistenceException(e);
        }
    }

    @SuppressWarnings("unchecked")
    private List<TargetInventoryLevelMaxOverPeriod> find(Long runId, List<String> asins, int iog)
            throws OihPersistenceException {
        logger.info("Batch Query TargetInventoryLevelMaxOverPeriod for a batchList, batch size=" + asins.size()
                + " the first asin is " + asins.get(0) + "|" + iog);
        try {
            openSession();
            Criteria cri = session.createCriteria(TargetInventoryLevelMaxOverPeriod.class);
            cri.add(Restrictions.in("asin", asins));
            cri.add(Restrictions.eq("iog", iog));
            cri.add(Restrictions.eq("runID", runId));
            return (List<TargetInventoryLevelMaxOverPeriod>) cri.list();
        } catch (HibernateException e) {
            e.printStackTrace();
            logger.error("Fail to query TargetInventoryLevelMaxOverPeriod ", e);
            throw new OihPersistenceException(e);
        }
    }

    @Override
    public List<TargetInventoryLevelMaxOverPeriod> find(Long runId, List<AsinIogPair> asinIogPairs)
            throws OihPersistenceException {
        List<TargetInventoryLevelMaxOverPeriod> results = new ArrayList<TargetInventoryLevelMaxOverPeriod>();

        Map<Integer, List<String>> iog2AsinsMap = Utils.splitAsinIogList2AsinsMap(asinIogPairs);
        Iterator<Integer> iterator = iog2AsinsMap.keySet().iterator();

        try {
            while (iterator.hasNext()) {
                Integer iog = iterator.next();
                List<TargetInventoryLevelMaxOverPeriod> opObjects = find(runId, iog2AsinsMap.get(iog), iog);
                results.addAll(opObjects);
            }
            return results;
        } catch (HibernateException e) {
            logger.error("Fail to query TargetInventoryLevelMaxOverPeriod ", e);
            throw new OihPersistenceException(e);
        }
    }

    @Override
    public void save(List<TargetInventoryLevelMaxOverPeriod> tils) throws OihPersistenceException {
        Transaction tx = null;
        try {
            openSession();
            tx = session.beginTransaction();
            for (TargetInventoryLevelMaxOverPeriod o : tils) {
                session.save(o);
            }
            tx.commit();
        } catch (RuntimeException e) {
            logger.error("Failed to save entity " + logger + " with exception ", e);
            e.printStackTrace();
            if (tx != null) {
                tx.rollback();
            }
            throw new OihPersistenceException(e);
        } finally {
            closeSession();
        }
    }

    @Override
    public void save(TargetInventoryLevelMaxOverPeriod o) throws OihPersistenceException {
        Transaction tx = null;
        try {
            openSession();
            tx = session.beginTransaction();
            session.save(o);
            tx.commit();
        } catch (RuntimeException e) {
            logger.error("Failed to save entity " + o + " with exception ", e);
            e.printStackTrace();
            if (tx != null) {
                tx.rollback();
            }
            throw new OihPersistenceException(e);
        } finally {
            closeSession();
        }
    }

    /**
     * Delete all the elements from the database
     * 
     * @throws OihPersistenceException
     */
    @SuppressWarnings("unchecked")
    @Override
    public void deleteAll() throws OihPersistenceException {
        logger.debug("Trying to delete all the elements from the db");
        Transaction tx = null;
        try {
            openSession();
            tx = session.beginTransaction();
            Criteria cri = session.createCriteria(TargetInventoryLevelMaxOverPeriod.class);
            List<TargetInventoryLevelMaxOverPeriod> targetInventoryLevelMaxOverPeriods = cri.list();
            for (TargetInventoryLevelMaxOverPeriod object : targetInventoryLevelMaxOverPeriods) {
                session.delete(object);
            }
            tx.commit();
        } catch (HibernateException e) {
            e.printStackTrace();
            logger.error("Fail to query TargetInventoryLevelMaxOverPeriod ", e);
            throw new OihPersistenceException(e);
        }
    }

    /**
     * Delete the object from the database
     * 
     * @param o
     * @throws OihPersistenceException
     */
    @Override
    public void delete(TargetInventoryLevelMaxOverPeriod o) throws OihPersistenceException {
        Transaction tx = null;
        try {
            openSession();
            tx = session.beginTransaction();
            session.delete(o);
            tx.commit();
        } catch (RuntimeException e) {
            logger.error("Failed to save entity " + o + " with exception ", e);
            e.printStackTrace();
            if (tx != null) {
                tx.rollback();
            }
            throw new OihPersistenceException(e);
        } finally {
            closeSession();
        }
    }

    @Override
    public Integer getTotalCountByRunId(Long runId) throws OihPersistenceException {
        logger.debug("Trying to get count from the db");
        Integer totalCount = null;
        Transaction tx = null;
        try {
            openSession();
            tx = session.beginTransaction();
            Criteria cri = session.createCriteria(TargetInventoryLevelMaxOverPeriod.class);
            cri.setProjection(Projections.rowCount());
            cri.add(Restrictions.eq("runID", runId));
            totalCount = (Integer) cri.list().get(0);
            tx.commit();
        } catch (HibernateException e) {
            e.printStackTrace();
            logger.error("Fail to query TargetInventoryLevelMaxOverPeriod ", e);
            throw new OihPersistenceException(e);
        }
        return totalCount;
    }

    @Override
    public Integer getInvalidTILCountByRunId(Long runId) throws OihPersistenceException {
        logger.debug("Trying to get invalid data count from the db");
        Integer invalidDataCount = null;
        Transaction tx = null;
        try {
            openSession();
            tx = session.beginTransaction();
            Criteria cri = session.createCriteria(TargetInventoryLevelMaxOverPeriod.class);
            cri.setProjection(Projections.rowCount());
            cri.add(Restrictions.eq("til", -1));
            cri.add(Restrictions.eq("runID", runId));
            invalidDataCount = (Integer) cri.list().get(0);
            tx.commit();
        } catch (HibernateException e) {
            e.printStackTrace();
            logger.error("Fail to query TargetInventoryLevelMaxOverPeriod ", e);
            throw new OihPersistenceException(e);
        }
        return invalidDataCount;
    }

    private void openSession() {
        session = MySQLSessionFactoryUtil.getSessionFactory().openSession();
    }

    private void closeSession() {
        if (session != null) {
            session.close();
        }
    }

}