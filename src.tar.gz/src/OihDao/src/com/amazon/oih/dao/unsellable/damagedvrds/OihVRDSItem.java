package com.amazon.oih.dao.unsellable.damagedvrds;

import java.util.Date;

public class OihVRDSItem {
    private String fnsku;
    private String fcsku;
    private int iog;
    private String warehouse;
    private String condition;
    private String disposition;
    private long quantity;
    private String destVendor;
    private String sourceVendor = "";
    private double amount;
    private double cost;
    private long distributorShipmentItemId;
    private boolean isAuthorizationRequired = false;
    private String openAuthorizationNumber = "";
    private String baseCurrencyCode;
    private String refundBasisCode;
    private String vrdsDescription;
    private int returnByMinDays;
    private int returnByMaxDays;
    private Date shipmentReceiveDate = null;
    private Date distributorOrderDate = null;
    private String distributorShipmentId;
    private long distributorOrderType;
    private String distributorOrderId;
    private double price;
    private String distributorId;
    private String foreignCurrencyCode;
    private double refundAmountForeignCurrency;
    private double costForeignCurrency;
    private double distributorListPriceForeignCurrency;
    private double distributorCostForeignCurrency;
    
    
    public boolean isAuthorizationRequired() {
        return isAuthorizationRequired;
    }

    public void setAuthorizationRequired(boolean isAuthorizationRequired) {
        this.isAuthorizationRequired = isAuthorizationRequired;
    }

    public String getBaseCurrencyCode() {
        return baseCurrencyCode;
    }

    public void setBaseCurrencyCode(String baseCurrencyCode) {
        this.baseCurrencyCode = baseCurrencyCode;
    }

    public String getFnsku() {
        return fnsku;
    }

    public void setFnsku(String fnsku) {
        this.fnsku = fnsku;
    }

    public String getFcsku() {
        return fcsku;
    }

    public void setFcsku(String fcsku) {
        this.fcsku = fcsku;
    }

    public int getIog() {
        return iog;
    }

    public void setIog(int iog) {
        this.iog = iog;
    }

    public String getWarehouse() {
        return warehouse;
    }

    public void setWarehouse(String warehouse) {
        this.warehouse = warehouse;
    }

    public String getCondition() {
        return condition;
    }

    public void setCondition(String condition) {
        this.condition = condition;
    }

    public String getDisposition() {
        return disposition;
    }

    public void setDisposition(String disposition) {
        this.disposition = disposition;
    }

    public long getQuantity() {
        return quantity;
    }

    public void setQuantity(long quantity) {
        this.quantity = quantity;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public double getCost() {
        return cost;
    }

    public void setCost(double cost) {
        this.cost = cost;
    }

    public String getOpenAuthorizationNumber() {
        return openAuthorizationNumber;
    }

    public void setOpenAuthorizationNumber(String openAuthorizationNumber) {
        this.openAuthorizationNumber = openAuthorizationNumber;
    }

    public void setDestVendor(String destVendor) {
        this.destVendor = destVendor;
    }

    public String getDestVendor() {
        return destVendor;
    }

    public void setSourceVendor(String sourceVendor) {
        this.sourceVendor = sourceVendor;
    }

    public String getSourceVendor() {
        return sourceVendor;
    }

    public void setDistributorShipmentItemId(long distributorShipmentItemId) {
        this.distributorShipmentItemId = distributorShipmentItemId;
    }

    public long getDistributorShipmentItemId() {
        return distributorShipmentItemId;
    }

    public int getReturnByMinDays() {
        return returnByMinDays;
    }

    public void setReturnByMinDays(int returnByMinDays) {
        this.returnByMinDays = returnByMinDays;
    }

    public int getReturnByMaxDays() {
        return returnByMaxDays;
    }

    public void setReturnByMaxDays(int returnByMaxDays) {
        this.returnByMaxDays = returnByMaxDays;
    }

    public Date getShipmentReceiveDate() {
        return shipmentReceiveDate;
    }

    public void setShipmentReceiveDate(Date shipmentReceiveDate) {
        this.shipmentReceiveDate = shipmentReceiveDate;
    }

    public Date getDistributorOrderDate() {
        return distributorOrderDate;
    }

    public void setDistributorOrderDate(Date distributorOrderDate) {
        this.distributorOrderDate = distributorOrderDate;
    }

    public String getDistributorShipmentId() {
        return distributorShipmentId;
    }

    public void setDistributorShipmentId(String distributorShipmentId) {
        this.distributorShipmentId = distributorShipmentId;
    }

    public long getDistributorOrderType() {
        return distributorOrderType;
    }

    public void setDistributorOrderType(long distributorOrderType) {
        this.distributorOrderType = distributorOrderType;
    }

    public String getDistributorOrderId() {
        return distributorOrderId;
    }

    public void setDistributorOrderId(String distributorOrderId) {
        this.distributorOrderId = distributorOrderId;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getVrdsDescription() {
        return vrdsDescription;
    }

    public void setVrdsDescription(String vrdsDescription) {
        this.vrdsDescription = vrdsDescription;
    }

    public String getDistributorId() {
        return distributorId;
    }

    public void setDistributorId(String distributorId) {
        this.distributorId = distributorId;
    }

    public String getRefundBasisCode() {
        return refundBasisCode;
    }

    public void setRefundBasisCode(String refundBasisCode) {
        this.refundBasisCode = refundBasisCode;
    }

	public void setForeignCurrencyCode(String foreignCurrencyCode) {
		this.foreignCurrencyCode = foreignCurrencyCode;
	}

	public String getForeignCurrencyCode() {
		return foreignCurrencyCode;
	}

    public double getRefundAmountForeignCurrency() {
        return refundAmountForeignCurrency;
    }

    public void setRefundAmountForeignCurrency(double refundAmountForeignCurrency) {
        this.refundAmountForeignCurrency = refundAmountForeignCurrency;
    }

    public double getCostForeignCurrency() {
        return costForeignCurrency;
    }

    public void setCostForeignCurrency(double costForeignCurrency) {
        this.costForeignCurrency = costForeignCurrency;
    }

    public double getDistributorListPriceForeignCurrency() {
        return distributorListPriceForeignCurrency;
    }

    public void setDistributorListPriceForeignCurrency(double distributorListPriceForeignCurrency) {
        this.distributorListPriceForeignCurrency = distributorListPriceForeignCurrency;
    }

    public double getDistributorCostForeignCurrency() {
        return distributorCostForeignCurrency;
    }

    public void setDistributorCostForeignCurrency(double distributorCostForeignCurrency) {
        this.distributorCostForeignCurrency = distributorCostForeignCurrency;
    }
	
	

}
