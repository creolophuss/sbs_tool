package com.amazon.oih.dao.hbase.quantitybasedmarkdowninfo;

import java.io.IOException;
import java.util.Date;
import java.util.List;

import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.util.Bytes;

import amazon.platform.config.AppConfig;

import com.amazon.oih.dao.DaoConstants;
import com.amazon.oih.dao.hbase.base.AbstractHBaseDaoImpl;
import com.amazon.oih.dao.hbase.base.Converter;
import com.amazon.oih.dao.hbase.schema.HTableNameCFGeneratorImpl;
import com.amazon.oih.dao.quantitymarkdowninfo.QuantityBasedMarkdownInfo;

/**
 * @author gaoxing
 *
 */
public class QuantityBasedMarkdownInfoHBaseDao extends AbstractHBaseDaoImpl<QuantityBasedMarkdownInfo> {

    static final String columnMarkdownForecastDetail = "markdownForecastDetail";
    static final byte[] columnMarkdownForecastDetailBytes = Bytes.toBytes(columnMarkdownForecastDetail);

    static final String columnDataVersion = "dataVersion";
    static final byte[] columnDataVersionBytes = Bytes.toBytes(columnDataVersion);

    static final String columnDataLevel = "dataLevel";
    static final byte[] columnDataLevelBytes = Bytes.toBytes(columnDataLevel);

    static final String tableName = AppConfig.findString(DaoConstants.QUANTITY_BASED_MARKDOWN_INFO_TABLENAME);
    static final String columnFamily = AppConfig.findString(DaoConstants.QUANTITY_BASED_MARKDOWN_INFO_COLUMNFAMILY);

    static final byte[] columnFamilyBytes = Bytes.toBytes(columnFamily);
    Converter<QuantityBasedMarkdownInfo> converter;

    public QuantityBasedMarkdownInfoHBaseDao(Date rundate, String realm) {
        super(new HTableNameCFGeneratorImpl(tableName, columnFamily, realm, rundate), realm);
        converter = new QuantityBasedMarkdownInfoConverter();
    }

    @Override
    public QuantityBasedMarkdownInfo convert(String rowKey, Result rs) throws IOException {
        return converter.convert(rowKey, rs);
    }

    @Override
    protected List<Put> convert(QuantityBasedMarkdownInfo markdownInfoObject) throws IOException {
        return converter.convert(markdownInfoObject);
    }
}
