package com.amazon.oih.dao.scopemapping;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import com.amazon.oih.dao.g2s2.ConfigKey;

@ConfigKey(value = "MarketplaceAttr")
@JsonIgnoreProperties(ignoreUnknown = true)
public class Marketplace  extends ConfigEntity implements Comparable<Marketplace> {

    private Long marketplaceId;    
    private String marketplaceName;
    private String encryptedMarketplaceId;

    @ID
    public Long getMarketplaceId() {
        return this.marketplaceId;
    }

    public void setMarketplaceId(Long marketplaceId) {
        this.marketplaceId = marketplaceId;
    }

    public String getMarketplaceName() {
        return marketplaceName;
    }

    public void setMarketplaceName(String marketplaceName) {
        this.marketplaceName = marketplaceName;
    }

    public String getEncryptedMarketplaceId() {
        return this.encryptedMarketplaceId;
    }

    public void setEncryptedMarketplaceId(String encryptedMarketplaceId) {
        this.encryptedMarketplaceId = encryptedMarketplaceId;
    }
    

    @Override
    public int hashCode() {
        int hashCode = 1;
        hashCode += (getMarketplaceId() == null ? 0 : getMarketplaceId().hashCode());
        return hashCode;
    }

    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (o instanceof Marketplace)
            return compareTo((Marketplace) o) == 0;
        return false;

    }

    /**
     * compare by only MarketplaceId attribute
     */
    public int compareTo(Marketplace o) {
        if (o == null)
            return -1;
        if (o == this)
            return 0;
        Long o1 = getMarketplaceId();
        Long o2 = o.getMarketplaceId();
        if (o1 == null)
            return -1;
        if (o2 == null)
            return 1;
        return o1.compareTo(o2);

    }
    
    public String toString(){
        return String.format("Marketplace{id= %d,name=%s}", this.marketplaceId, this.marketplaceName);
    }
}