package com.amazon.oih.dao.abasics;

import java.util.Collections;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.amazon.oih.dao.MySQLSessionFactoryUtil;
import com.amazon.oih.dao.exception.OihPersistenceException;

public class ABasicsAsinDaoImpl implements ABasicsAsinDao {

    private static Logger log = Logger.getLogger(ABasicsAsinDaoImpl.class);
    
    @SuppressWarnings("unchecked")
    @Override
    public List<ABasicsAsin> getABasicsAsins(Long runId) throws OihPersistenceException {
        Session session = null;
        try {
            session = openSession();
            List<ABasicsAsin> result = (List<ABasicsAsin>)session.getNamedQuery("ABasicsAsin.FindABasicsAsinsByRunId")
                    .setParameter("runId", runId).list();
            
            return result == null ? Collections.<ABasicsAsin>emptyList() : result;
        } catch (Exception e){
            throw new OihPersistenceException("Exception when query abasics asin with runid " + runId, e);
        } finally {
            session.close();
        }
    }
    
    public void save(ABasicsAsin abasicAsin) throws OihPersistenceException {
        Transaction tx = null;
        Session session = null;
        try {
            session = openSession();
            tx = session.beginTransaction();
            session.save(abasicAsin);
            tx.commit();
        } catch (RuntimeException e) {
            log.error("Failed to save abasics asin " + abasicAsin.getAsin() + " with exception ", e);
            e.printStackTrace();
            if (tx != null) {
                tx.rollback();
            }
            throw new OihPersistenceException(e);
        } finally {
            closeSession(session);
        }
    }
    
    private Session openSession() {
        return MySQLSessionFactoryUtil.getSessionFactory().openSession();
    }

    private void closeSession(Session session) {
        if (session != null) {
            session.close();
        }
    }
}

