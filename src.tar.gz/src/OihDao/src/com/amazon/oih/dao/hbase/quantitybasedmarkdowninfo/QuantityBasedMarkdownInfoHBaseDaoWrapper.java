package com.amazon.oih.dao.hbase.quantitybasedmarkdowninfo;

import java.io.IOException;
import java.util.Collection;
import java.util.List;

import com.amazon.oih.dao.exception.OihPersistenceException;
import com.amazon.oih.dao.hbase.base.HBaseDao;
import com.amazon.oih.dao.markdowninfo.MarkdownInfo;
import com.amazon.oih.dao.quantitymarkdowninfo.IQuantityBasedMarkdownInfoDao;
import com.amazon.oih.dao.quantitymarkdowninfo.QuantityBasedMarkdownInfo;
import com.amazon.oih.utils.HBaseRowkeyUtil;

/**
 * @author gaoxing
 *
 */
public class QuantityBasedMarkdownInfoHBaseDaoWrapper implements HBaseDao<QuantityBasedMarkdownInfo>,
        IQuantityBasedMarkdownInfoDao {

    private QuantityBasedMarkdownInfoHBaseDao quantityBasedMarkdownInfoHBaseDao;

    public QuantityBasedMarkdownInfoHBaseDaoWrapper(QuantityBasedMarkdownInfoHBaseDao quantityBasedMarkdownInfoHBaseDao) {
        this.quantityBasedMarkdownInfoHBaseDao = quantityBasedMarkdownInfoHBaseDao;
    }

    @Override
    public void save(List<QuantityBasedMarkdownInfo> infos) throws OihPersistenceException {
        try {
            put(infos);
        } catch (IOException e) {
            throw new OihPersistenceException(e);
        }
    }

    @Override
    public void save(QuantityBasedMarkdownInfo info) throws OihPersistenceException {
        try {
        	putSingleElement(info);
        } catch (IOException e) {
            throw new OihPersistenceException(e);
        }
    }

    @Override
    public boolean exists(Long runId, String asin, long marketplaceId) throws OihPersistenceException {
        try {
            return exist(HBaseRowkeyUtil.getRowKeyBasedAsinMarketplace(asin, marketplaceId));
        } catch (IOException e) {
            throw new OihPersistenceException(e);
        }
    }

    @Override
    public QuantityBasedMarkdownInfo find(Long runId, String asin, long marketplaceId) throws OihPersistenceException {
        try {
            return get(HBaseRowkeyUtil.getRowKeyBasedAsinMarketplace(asin, marketplaceId));
        } catch (IOException e) {
            throw new OihPersistenceException(e);
        }
    }

    @Override
    public void putSingleElement(QuantityBasedMarkdownInfo bObject) throws IOException {
        quantityBasedMarkdownInfoHBaseDao.putSingleElement(bObject);
    }

    @Override
    public void put(List<QuantityBasedMarkdownInfo> bObjects) throws IOException {
        quantityBasedMarkdownInfoHBaseDao.put(bObjects);
    }

    @Override
    public QuantityBasedMarkdownInfo get(String rowKey) throws IOException {
        return quantityBasedMarkdownInfoHBaseDao.get(rowKey);
    }

    @Override
    public List<QuantityBasedMarkdownInfo> get(Collection<String> rowKeys) throws IOException {
        return quantityBasedMarkdownInfoHBaseDao.get(rowKeys);
    }

    @Override
    public boolean exist(String rowKey) throws IOException {
        return quantityBasedMarkdownInfoHBaseDao.exist(rowKey);
    }

    @Override
    public boolean exist(String rowKey, String qualifier) throws IOException {
        return quantityBasedMarkdownInfoHBaseDao.exist(rowKey, qualifier);
    }

    @Override
    public void deleteRow(String rowKey) throws IOException {
        quantityBasedMarkdownInfoHBaseDao.deleteRow(rowKey);
    }

    @Override
    public void deleteRows(List<String> rowKeys) throws IOException {
        quantityBasedMarkdownInfoHBaseDao.deleteRows(rowKeys);
    }

    @Override
    public void close() throws IOException {
        quantityBasedMarkdownInfoHBaseDao.close();
    }
}
