package com.amazon.oih.dao.hbase.sokoban;

import java.io.Serializable;

import com.amazon.oih.common.RowKeyBuildType;
import com.amazon.oih.common.RowKeyType;
import com.amazon.oih.dao.hbase.base.CommonKVHBaseDao.HTable;
import com.amazon.oih.dao.hbase.converter.Column;
import com.amazon.oih.dao.hbase.converter.RowKey;
import com.amazon.oih.dao.hbase.converter.SubKey;

@RowKey({"asin", "marketplaceId"})
@RowKeyBuildType(RowKeyType.ASIN_MARKETPLACE)
@SubKey({"warehouse"})
@HTable(value = "SokobanFasFactor")
public class SokobanFasFactor implements Serializable {

    private static final long serialVersionUID = -6027764372977021526L;
    
    private String asin;
    private String marketplaceId;
    
    
    private String warehouse;
    
    @Column(name="factor",index=0)
    private double factor;

    public String getAsin() {
        return asin;
    }

    public void setAsin(String asin) {
        this.asin = asin;
    }

    public String getMarketplaceId() {
        return marketplaceId;
    }

    public void setMarketplaceId(String marketplaceId) {
        this.marketplaceId = marketplaceId;
    }

    public String getWarehouse() {
        return warehouse;
    }

    public void setWarehouse(String warehouse) {
        this.warehouse = warehouse;
    }

    public double getFactor() {
        return factor;
    }

    public void setFactor(double factor) {
        this.factor = factor;
    } 
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        SokobanFasFactor other = (SokobanFasFactor) obj;
        if (asin == null) {
            if (other.asin != null)
                return false;
        } else if (!asin.equals(other.asin))
            return false;
        if (marketplaceId == null) {
            if (other.marketplaceId != null)
                return false;
        } else if (!marketplaceId.equals(other.marketplaceId))
            return false;
        if (warehouse == null) {
            if (other.warehouse != null)
                return false;
        } else if (!warehouse.equals(other.warehouse))
            return false;
        if (factor == 0){
            if (other.factor != 0)
                return false;
        } else if (factor != other.factor)
            return false;
        
        return true;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((asin == null) ? 0 : asin.hashCode());
        result = prime * result + ((marketplaceId == null) ? 0 : marketplaceId.hashCode());
        result = prime * result + ((warehouse == null) ? 0 : warehouse.hashCode());
        result = prime * result + (int)factor;
        return result;
    }
    
    @Override
    public String toString() {
        return "Vendor [asin=" + asin + ", marketplaceId=" + marketplaceId + ", warehouse=" + warehouse
                + ", factor=" + factor + "]";
    }

}
