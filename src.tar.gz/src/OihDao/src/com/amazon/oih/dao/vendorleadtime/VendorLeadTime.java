package com.amazon.oih.dao.vendorleadtime;

import java.io.Serializable;

public class VendorLeadTime implements Serializable {
    private static final long serialVersionUID = 1L;
    private long runID;
    private String vendor;
    private long merchantId;
    private int gl;
    private double averageVlt;


    public VendorLeadTime(long runID, String vendor, long merchantId, int gl , double averageVlt) {
        this.runID = runID;
        this.vendor = vendor;
        this.merchantId = merchantId;
        this.gl = gl;
        this.averageVlt = averageVlt;
    }

    public VendorLeadTime() {

    }

    public void setRunID(long runID) {
        this.runID = runID;
    }

    public long getRunID() {
        return runID;
    }

	public String getVendor() {
		return vendor;
	}

	public void setVendor(String vendor) {
		this.vendor = vendor;
	}

	public long getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(long merchantId) {
		this.merchantId = merchantId;
	}

	public int getGl() {
		return gl;
	}

	public void setGl(int gl) {
		this.gl = gl;
	}

	public double getAverageVlt() {
		return averageVlt;
	}

	public void setAverageVlt(double averageVlt) {
		this.averageVlt = averageVlt;
	}

	@Override
	public String toString(){
		return "vendor:" + vendor + " merchantId:" + merchantId + " runId:" + runID + " gl:" + gl + " averageVendorLeadTime:" + averageVlt;
	}
	
	@Override
    public boolean equals(Object obj) {
        if (obj instanceof VendorLeadTime == false) {
            return false;
        }
        if (this == obj) {
            return true;
        }

        VendorLeadTime other = (VendorLeadTime) obj;

        return this.runID == other.getRunID()  && this.vendor.equals(other.getVendor()) && this.merchantId == other.getMerchantId()  
        		&& this.gl == other.getGl() && Math.abs(this.averageVlt - other.getAverageVlt()) < 1e-6 ;
    }


    @Override
    public int hashCode() {
        final int prime = 127; // changed from default - 31 is a lame prime #
        int result = 1;
        result = prime * result + ((vendor == null) ? 0 : vendor.hashCode());
        result = prime * result + (int) merchantId;
        result = prime * result + (int) runID;
        result = prime * result + gl;
        return result;
    }
}
