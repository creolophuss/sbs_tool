package com.amazon.oih.dao.hbase.revenue;

public enum RevenueTableStatus {
    NotStarted("NotStarted"), Writing("Writing"), Ready("Ready");

    private String status;

    private RevenueTableStatus(String code) {
        this.status = code;
    }

    public String getStatus() {
        return status;
    }

    public static RevenueTableStatus getStatusByString(String status) {
        for (RevenueTableStatus stat : RevenueTableStatus.values()) {
            if (stat.getStatus().equalsIgnoreCase(status)) {
                return stat;
            }
        }
        return null;
    }
}
