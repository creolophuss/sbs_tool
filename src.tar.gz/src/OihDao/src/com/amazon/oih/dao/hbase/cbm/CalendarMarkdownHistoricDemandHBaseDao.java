package com.amazon.oih.dao.hbase.cbm;

import java.io.IOException;
import java.util.Date;
import java.util.List;

import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.util.Bytes;

import amazon.platform.config.AppConfig;

import com.amazon.oih.cbm.model.AsinMarketplace;
import com.amazon.oih.cbm.model.CalendarMarkdownHistoricDemand;
import com.amazon.oih.dao.DaoConstants;
import com.amazon.oih.dao.hbase.base.AbstractHBaseDaoImpl;
import com.amazon.oih.dao.hbase.base.Converter;
import com.amazon.oih.dao.hbase.schema.HTableNameCFGeneratorImpl;
import com.amazon.oih.utils.HBaseRowkeyUtil;
import com.google.common.base.Function;
import com.google.common.collect.Lists;


public class CalendarMarkdownHistoricDemandHBaseDao extends AbstractHBaseDaoImpl<CalendarMarkdownHistoricDemand>  implements ICalendarMarkdownHistoricDemandDao {
	Converter<CalendarMarkdownHistoricDemand> converter;
	
    public static final String COLUMN_DEMAND = "demand";
    public static final String TABLE_NAME = AppConfig.findString(DaoConstants.CALENDAR_MARKDOWN_HISTORIC_DEMAND_TABLE_NAME);
    public static final String COLUMN_FAMILY = AppConfig.findString(DaoConstants.CALENDAR_MARKDOWN_DEMAND_COLUMN_FAMILY);
    public static final byte[] COLUMN_DEMAND_BYTES = Bytes.toBytes(COLUMN_DEMAND);
    public static final byte[] COLUMN_FAMILY_BYTES = Bytes.toBytes(COLUMN_FAMILY);
    
    public CalendarMarkdownHistoricDemandHBaseDao(Date rundate, String realm) {
        super(new HTableNameCFGeneratorImpl(TABLE_NAME, COLUMN_FAMILY, realm, rundate, true), realm);
        converter = new CalendarMarkdownHistoricDemandConverter();
    }


	@Override
	protected CalendarMarkdownHistoricDemand convert(String rowKey, Result rs)
			throws IOException {
		return converter.convert(rowKey, rs);
	}

	@Override
	protected List<Put> convert(CalendarMarkdownHistoricDemand demand)
			throws IOException {
		return converter.convert(demand);
	}


	@Override
	public List<CalendarMarkdownHistoricDemand> getHistormicDemand(List<? extends AsinMarketplace> items) throws IOException {
		List<String> rowKeys = Lists.transform(items, new Function<AsinMarketplace, String>() {

			@Override
			public String apply(AsinMarketplace input) {
				return HBaseRowkeyUtil.getRowKeyBasedAsinMarketplace(input.getAsin(), input.getMarketplace());
			}});
		return get(rowKeys);
	}


	@Override
	public void save(List<CalendarMarkdownHistoricDemand> demands) throws IOException {
		put(demands);
	}



}
