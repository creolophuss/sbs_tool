package com.amazon.oih.dao;

public class DaoConstants {
    // The possible value of column is_current
    public static final String IS_CURRENT_Y = "Y";
    public static final String IS_CURRENT_N = "N";

    public static final String PROCURABLE = "Y";
    public static final String NON_PROCURABLE = "N";

    // The possible value of column status
    public static final String STATUS_OK = "OK";
    public static final String STATUS_ERROR = "STATUS_ERROR";
    public static final String STATUS_ROLLBACK = "ROLLBACK";

    public static final String EXPIRE_DATE = "2100-01-01";

    // Mark for UT
    public static final String UNIT_TEST = "UNIT_TEST";

    // HBase forecast value split
    public static final String WEEKLY_FORECAST_VALUE_SPLIT = ",";
    // HBase Forecast Tablename and ColumnFamily
    public static final String FORECAST_INPUTNAME = "IhrMetrics.ForecastDistributionHBase.TableName";
    public static final String FORECAST_COLUMNFAMILY = "IhrMetrics.ForecastDistributionHBase.ColumnFamily";

    // HBase VRDS Tablename and ColumnFamily
    public static final String VRDS_DORC_INFO_INPUTNAME = "IhrMetrics.VRDSHBaseDorcInfo.TableName";
    public static final String VRDS_DORC_INFO_COLUMNFAMILY = "IhrMetrics.VRDSHBaseDorcInfo.ColumnFamily";
    
    public static final String VRDS_RETURN_TERM_INPUTNAME = "IhrMetrics.VRDSHBaseReturnTerm.TableName";
    public static final String VRDS_RETURN_TERM_COLUMNFAMILY = "IhrMetrics.VRDSHBaseReturnTerm.ColumnFamily";

    public static final String OUR_PRICE_INPUTNAME = "IhrMetrics.OurPriceHBase.TableName";

 
    
    // HBase Revenue Asin Data - Inventories split
    public static final char INVENTORIES_SPLIT = '\n';
    // HBase Revenue Asin Data - Inventory-Revenue split
    public static final char INVENTORY_REVENUE_SPLIT = '=';
    // HBase Revenue Asin Data - Revenue value split
    public static final char REVENUE_SPLIT = ',';
    
    public static final String MARKDOWN_INFO_TABLENAME = "IhrMetrics.MarkdownInfo.TableName";
    public static final String MARKDOWN_INFO_COLUMNFAMILY = "IhrMetrics.MarkdownInfo.ColumnFamily";    
    public static final String MARKDOWN_INFO = "MarkdownInfo";
    
    // HBase QuantityBasedMarkdown Data
    public static final String QUANTITY_BASED_MARKDOWN_INFO_DATA_LEVEL_SPLIT = ",";
    public static final String QUANTITY_BASED_MARKDOWN_INFO_UNIT_SPLIT = ";";
    public static final String QUANTITY_BASED_MARKDOWN_INFO_QUANTITY_SPLIT = "=";
    public static final String QUANTITY_BASED_MARKDOWN_INFO_FORECAST_SPLIT = ",";
    public static final String QUANTITY_BASED_MARKDOWN_INFO_TABLENAME = "IhrMetrics.QuantityBasedMarkdownInfo.TableName";
    public static final String QUANTITY_BASED_MARKDOWN_INFO_COLUMNFAMILY = "IhrMetrics.QuantityBasedMarkdownInfo.ColumnFamily";    
    public static final String QUANTITY_BASED_MARKDOWN_INFO = "QuantityBasedMarkdownInfo";

    // HBase Remote Tablename and ColumnFamily
    public static final String REMOTECAT_TABLENAME = "IhrMetrics.RemoteCatHBase.TableName";
    public static final String REMOTECAT_COLUMNFAMILY = "IhrMetrics.RemoteCatHBase.ColumnFamily";
    public static final String REMOTECAT_USE_HBASE_CONFIG_KEY = "RemoteCat";
    
    // HBase Tax Tablename and ColumnFamily
    public static final String TAX_TABLENAME = "IhrMetrics.TaxHBase.TableName";
    public static final String TAX_COLUMNFAMILY = "IhrMetrics.TaxHBase.ColumnFamily";
    public static final String TAX_USE_HBASE_CONFIG_KEY = "Tax";
    
    // HBase compression
    public static final String HBASE_CF_COMPRESSION_ENABLED = "IhrMetrics.HBase.CF.Compression.enabled";
    public static final String HBASE_CF_COMPRESSION_CODEC = "IhrMetrics.HBase.CF.Compression.codec";
    
    
    //HBase CBM Historic Demand
    public static final String CALENDAR_MARKDOWN_HISTORIC_DEMAND_TABLE_NAME = "IhrMetrics.CalendarMarkdownHistoricDemandHBase.TableName";
    public static final String CALENDAR_MARKDOWN_DEMAND_COLUMN_FAMILY = "IhrMetrics.CalendarMarkdownHistoricDemandHBase.ColumnFamily";
    public static final String CALENDAR_MARKDOWN_HISTORIC_DEMAND_USE_HBASE_CONFIG_KEY = "CalendarMarkdownHistoricDemand";
}
