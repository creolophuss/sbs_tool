package com.amazon.oih.dao.hbase.base;

import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import com.amazon.oih.common.KeyValueBase.NamedValue;
import com.amazon.oih.dao.hbase.converter.Column;
import com.amazon.oih.dao.hbase.converter.SubKey;
import com.google.common.base.Predicates;
import com.google.common.collect.HashMultimap;
import com.google.common.collect.Maps;
import com.google.common.collect.Multimap;
import com.google.common.collect.Sets;

/***
 * Help Class for providing projections, e.g. use NamedValue to specify projection... etc..
 * 
 * @author jialei
 *
 * @param <T>
 */
public class ProjectionProvider<T> {
    private Map<String, String> namedValue2ColumnMap = new HashMap<String, String>();
    private Multimap<String, String> column2NamedValueMap = HashMultimap.create();
    private Map<String, String> namedValue2SubKeyMap = new HashMap<String, String>();
    private Set<String> subKeyFields = new HashSet<String>();

    public ProjectionProvider(Class<T> classObj) {
        SubKey subkey = classObj.getAnnotation(SubKey.class);
        if (subkey != null){
            subKeyFields.addAll(Arrays.asList(subkey.value()));
        }

        for (Field field : classObj.getDeclaredFields()) {
            NamedValue nameAno = field.getAnnotation(NamedValue.class);
            if (nameAno == null){
                continue;
            }
            Column column = field.getAnnotation(Column.class);
            if (column != null){
                namedValue2ColumnMap.put(nameAno.value(), column.name());
                column2NamedValueMap.put(column.name(), nameAno.value());
            }
            if (subKeyFields.contains(field.getName())){
                namedValue2SubKeyMap.put(nameAno.value(), field.getName());
            }
        }
    }

    /**
     * For a classObj's field annotated by both @Column and @NamedValue, find @NamedValue by matching
     * @NamedValue.value and namedValueTobeSeleted, then return the @Column.name which annotated the same field with
     * the matching @NamedValue
     * 
     * @param classObj
     * @param namedValueTobeSeleted
     * @return List of @Column.name which annotated the same fields with @NamedValue, which selected according to
     *         namedValueTobeSeleted
     */
    public Set<String> findProjectionsByNamedValue(Set<String> namedValueTobeSeleted) {
        if (subKeyFields.size() > 0){
            validSubKey(namedValueTobeSeleted);
        }
        Set<String> noColumnNamedValue = Sets.difference(namedValueTobeSeleted, namedValue2ColumnMap.keySet());
        Set<String> invalidNamedValue = Sets.difference(noColumnNamedValue, namedValue2SubKeyMap.keySet());
        if (invalidNamedValue.size() != 0) {
            throw new RuntimeException("Find invalid namedValue:" + invalidNamedValue + " validNamedValues are:" 
                    + namedValue2ColumnMap.keySet());       
        }

        Set<String> results = new HashSet<String>();
        for (String toSelect : namedValueTobeSeleted) {
            String columnName = namedValue2ColumnMap.get(toSelect);
            if (columnName != null) {
                results.add(columnName);
            }
        }
        validProjections(results, namedValueTobeSeleted);
        return results;
    }

    /**
     * For POJO's fields which annotated with same @Column.name, they will be updated together, they are called correlated fields.
     * It's not allowed to generate projections from part of correlated fields, either include them all, or exclude them all.
     * By generating projections from namedValue, we also not allow using namedValue to select part of the correlated fields.
     *    
     * @param projections
     * @param namedValueTobeSeleted
     */
    private void validProjections(Set<String> projections, Set<String> namedValueTobeSeleted) {
        Multimap<String, String> wrongProjections = HashMultimap.create();
        for (String projection : projections) {
            Set<String> nameValuesOfCorrelatedFiled = new HashSet<String>(column2NamedValueMap.get(projection));
            Set<String> unselectedNamedValue = Sets.difference(nameValuesOfCorrelatedFiled, namedValueTobeSeleted);
            if (unselectedNamedValue.size() != 0) {
                wrongProjections.putAll(projection, unselectedNamedValue);
            }
        }
        if (wrongProjections.size() > 0) {
            throw new RuntimeException(
                    "Invalid projection!! Following are NamedValues which will cause partly HBase update!!"
                            + wrongProjections);
        }
    }
    
    private void validSubKey(Set<String> namedValueTobeSeleted){
        Map<String, String> selectedFields = Maps.filterKeys(namedValue2SubKeyMap, Predicates.in(namedValueTobeSeleted));
        Set<String> unselectedSubKey = Sets.difference(subKeyFields, new HashSet<String>(selectedFields.values()));
        if (unselectedSubKey.size() != 0) {
            throw new RuntimeException(
                    "Invalid projection!! Following fields are subKey, but not selected!!"
                            + unselectedSubKey);
        }
    }
}