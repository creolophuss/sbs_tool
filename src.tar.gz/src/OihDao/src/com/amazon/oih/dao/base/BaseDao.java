package com.amazon.oih.dao.base;

import java.util.List;

/**
 * Configure the interface level transaction by Spring
 * 
 * @author zhongwei
 * 
 * @param <T>
 */
public interface BaseDao<T> {
    public void saveOrUpdate(T object);

    public void saveOrUpdate(List<T> objects);

    public void delete(T object);

    public List<T> findAll(Class<T> clazz);
}
