package com.amazon.oih.dao.run;

import java.util.List;

import org.joda.time.DateTime;

import com.amazon.oih.dao.exception.DaoRuntimeException;
import com.amazon.oih.dao.exception.OihPersistenceException;

public interface RunDao {
	
	public void save(Run o) throws OihPersistenceException;

	public Run find(Long runId) throws DaoRuntimeException,
			OihPersistenceException;

	public List<Run> find(DateTime rundate) throws DaoRuntimeException,
			OihPersistenceException;

	public List<Run> find(DateTime rundate, String domain, String realm)
			throws DaoRuntimeException, OihPersistenceException;

    public Run find(DateTime rundate, String domain, String realm, String tag)
            throws DaoRuntimeException, OihPersistenceException;
	
	public Run findOrCreateSave(DateTime rundate, String domain, String realm, String tag)
			throws DaoRuntimeException, OihPersistenceException;

	public Run createRun(DateTime rundate, String domain, String realm, String tag)
			throws DaoRuntimeException, OihPersistenceException;	
}
