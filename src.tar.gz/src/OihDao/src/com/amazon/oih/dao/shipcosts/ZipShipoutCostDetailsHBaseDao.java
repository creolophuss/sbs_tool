package com.amazon.oih.dao.shipcosts;

import java.io.IOException;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.client.Result;

import amazon.platform.config.AppConfig;

import com.amazon.oih.dao.hbase.base.AbstractHBaseDaoImpl;
import com.amazon.oih.dao.hbase.schema.HTableNameCFGeneratorImpl;

public class ZipShipoutCostDetailsHBaseDao extends AbstractHBaseDaoImpl<CNZipShipoutCostDetails>{

    private static final String tableName = AppConfig.findString("IhrMetrics.ShipoutCostDetails.TableName");
    private static final String columnFamily = AppConfig.findString("IhrMetrics.ShipoutCostDetails.ColumnFamily");
    
    private static final byte[] valueColumn = "details".getBytes();
    
    private static final byte[] tableNameBytes = tableName.getBytes();
    private static final byte[] columnFamilyBytes = columnFamily.getBytes();
    
    public ZipShipoutCostDetailsHBaseDao(String realm, Date rundate) {
        super(new HTableNameCFGeneratorImpl(tableName, columnFamily, realm, rundate), realm);
    }
    @Override
    protected CNZipShipoutCostDetails convert(String rowKey, Result rs) throws IOException {
        if (rs != null && !rs.isEmpty()) {
            byte[] ret = rs.getValue(tableNameBytes, valueColumn);
            String desc = new String(ret);
            
            return new CNZipShipoutCostDetails(desc);
        }
   
        return null;
    }

    @Override
    protected List<Put> convert(CNZipShipoutCostDetails bObject) throws IOException {
        byte[] rowKey = (bObject.getSource() + "-" + bObject.getDest()).getBytes();
        
        Put put = new Put(rowKey);
        put.add(columnFamilyBytes, valueColumn, bObject.toString().getBytes());
        return Collections.nCopies(1, put);
    }
}
