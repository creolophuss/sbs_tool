package com.amazon.oih.dao.repository;

import com.amazon.carbonado.ConfigurationException;
import com.amazon.carbonado.Repository;
import com.amazon.carbonado.RepositoryException;

public class ReadOnlyRundateAwareBDBRepositoryBuilder extends RundateAwareBDBRepositoryBuilder {
    private static boolean isReadonly = true;

    @Override
    public Repository build() throws ConfigurationException, RepositoryException {
        System.out.println(isReadonly);
        bdbRepositoryBuilder.setReadOnly(isReadonly);
        return bdbRepositoryBuilder.build();
    }

    public synchronized static void setReadonly(boolean readonly) {
        isReadonly = readonly;
    }

    public synchronized static boolean isReadonly() {
        return isReadonly;
    }
}
