package com.amazon.oih.dao.historicdemand;

import com.amazon.carbonado.Alias;
import com.amazon.carbonado.PrimaryKey;
import com.amazon.carbonado.Storable;
import com.amazon.carbonado.constraint.IntegerConstraint;
import com.amazon.carbonado.constraint.LengthConstraint;


@Deprecated
/**
 * Deprecated because we don't use BDB to store HistoricDemand 
 * 
 * Forecast bean with annotations for Carbonado ORM. Simple constraints added for data verification.
 */
@Alias("data_HistoricDemand_new")
@PrimaryKey( {
        "asin", "marketplace"
})
public abstract class HistoricDemand implements Storable<HistoricDemand> {
    public abstract String getAsin();

    @LengthConstraint(min = 10, max = 10)
    public abstract void setAsin(String asin);

    public abstract Long getMarketplace();

    @IntegerConstraint(min = 0, max = Long.MAX_VALUE)
    public abstract void setMarketplace(Long marketplace);

    @Alias("one_week")
    public abstract int getOneWeek();

    @IntegerConstraint(min = 0, max = Integer.MAX_VALUE)
    public abstract void setOneWeek(int demand);

    @Alias("two_week")
    public abstract int getTwoWeek();

    @IntegerConstraint(min = 0, max = Integer.MAX_VALUE)
    public abstract void setTwoWeek(int demand);

    @Alias("three_week")
    public abstract int getThreeWeek();

    @IntegerConstraint(min = 0, max = Integer.MAX_VALUE)
    public abstract void setThreeWeek(int demand);

    @Alias("four_week")
    public abstract int getFourWeek();

    @IntegerConstraint(min = 0, max = Integer.MAX_VALUE)
    public abstract void setFourWeek(int demand);

    @Alias("three_months")
    public abstract int getThreeMonths();

    @IntegerConstraint(min = 0, max = Integer.MAX_VALUE)
    public abstract void setThreeMonths(int demand);

    @Alias("one_year")
    public abstract int getOneYear();

    @IntegerConstraint(min = 0, max = Integer.MAX_VALUE)
    public abstract void setOneYear(int demand);
}