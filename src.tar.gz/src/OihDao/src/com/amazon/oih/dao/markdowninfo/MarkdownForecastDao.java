package com.amazon.oih.dao.markdowninfo;

import java.util.List;

import com.amazon.oih.dao.exception.OihPersistenceException;
import com.amazon.oih.utils.AsinIogPair;

public interface MarkdownForecastDao {
    public abstract void save(MarkdownForecast o) throws OihPersistenceException;

    public abstract void save(List<MarkdownForecast> mfs) throws OihPersistenceException;

    public abstract boolean exists(Long runId, String asin, Integer marketplaceId) throws OihPersistenceException;

    public abstract MarkdownForecast find(Long runId, String asin, Integer marketplaceId) throws OihPersistenceException;

    public abstract MarkdownForecast createInstance(Long runid, String asin, Integer marketplaceId, Double demandIncrease,
            Double demandIncreaseRate, Double recoveryRate, String dataVersion, String dataLevel);

    public abstract void delete(MarkdownForecast o) throws OihPersistenceException;

    public abstract void deleteAll() throws OihPersistenceException;

}
