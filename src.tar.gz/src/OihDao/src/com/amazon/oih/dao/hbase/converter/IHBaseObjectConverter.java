package com.amazon.oih.dao.hbase.converter;

import java.util.List;

import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.client.Result;

public interface IHBaseObjectConverter <T>{
    public T convert(Class<T> clazz, String rowKey, Result rs);
    
    List<Put> convert(String columnFamily, T hBaseObj);
    
    public String getRowKey(T hBaseObj);
}
