package com.amazon.oih.dao.unsellable.inventorycandidate;

public class ICCItem {
    private String asin;
    private String fcsku;
    private String fnsku;
    private int iog;
    private String warehouse;
    private String condition;
    private int onhandQuantity;
    private int boundQuantity;
    private int psQuantity;
    private int fsQuantity;

    public String getAsin() {
        return asin;
    }

    public void setAsin(String asin) {
        this.asin = asin;
    }

    public String getFcsku() {
        return fcsku;
    }

    public void setFcsku(String fcsku) {
        this.fcsku = fcsku;
    }

    public String getFnsku() {
        return fnsku;
    }

    public void setFnsku(String fnsku) {
        this.fnsku = fnsku;
    }

    public int getIog() {
        return iog;
    }

    public void setIog(int iog) {
        this.iog = iog;
    }

    public String getWarehouse() {
        return warehouse;
    }

    public void setWarehouse(String warehouse) {
        this.warehouse = warehouse;
    }

    public String getCondition() {
        return condition;
    }

    public void setCondition(String condition) {
        this.condition = condition;
    }

    public int getOnhandQuantity() {
        return onhandQuantity;
    }

    public void setOnhandQuantity(int onhandQuantity) {
        this.onhandQuantity = onhandQuantity;
    }

    public int getBoundQuantity() {
        return boundQuantity;
    }

    public void setBoundQuantity(int boundQuantity) {
        this.boundQuantity = boundQuantity;
    }

    public int getPsQuantity() {
        return psQuantity;
    }

    public void setPsQuantity(int psQuantity) {
        this.psQuantity = psQuantity;
    }

    public int getFsQuantity() {
        return fsQuantity;
    }

    public void setFsQuantity(int fsQuantity) {
        this.fsQuantity = fsQuantity;
    }
}
