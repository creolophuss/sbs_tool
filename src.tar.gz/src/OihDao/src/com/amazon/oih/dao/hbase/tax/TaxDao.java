package com.amazon.oih.dao.hbase.tax;

import java.io.IOException;
import java.util.Date;
import java.util.List;

import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.client.Result;

import amazon.platform.config.AppConfig;

import com.amazon.oih.dao.DaoConstants;
import com.amazon.oih.dao.hbase.base.AbstractHBaseDaoImpl;
import com.amazon.oih.dao.hbase.base.Converter;
import com.amazon.oih.dao.hbase.schema.HTableNameCFGeneratorImpl;
import com.amazon.oih.utils.TimerHelper;

@Deprecated
public class TaxDao extends AbstractHBaseDaoImpl<Tax> {

    private Converter<Tax> converter = new TaxConverter();
    private final static String TAX_TABLENAME = AppConfig.findString(DaoConstants.TAX_TABLENAME);
    private final static String TAX_COLUMNFAMILY = AppConfig.findString(DaoConstants.TAX_COLUMNFAMILY);

    public TaxDao(Date rundate, String realm) {
        super(new HTableNameCFGeneratorImpl(TAX_TABLENAME, TAX_COLUMNFAMILY, realm, rundate), realm);
    }

    @Override
    protected Tax convert(String rowKey, Result rs) throws IOException {
        long start = System.currentTimeMillis();
        Tax ret = converter.convert(rowKey, rs);
        TimerHelper.getInstance().addPhase("TaxHBaseDao#convertToRemoteCat", start);
        return ret;
    }

    @Override
    protected List<Put> convert(Tax bObject) throws IOException {
        long start = System.currentTimeMillis();
        List<Put> ret = converter.convert(bObject);
        TimerHelper.getInstance().addPhase("TaxHBaseDao#convertToPut", start);
        return ret;
    }

    public boolean exists(String asin, String scope) throws IOException {
        long start = System.currentTimeMillis();
        boolean ret = exist(converter.getRowKey(new Tax(asin, scope)));
        TimerHelper.getInstance().addPhase("TaxHBaseDao#exists", start);
        return ret;
    }
}
