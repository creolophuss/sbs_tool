package com.amazon.oih.dao.scopemapping;

import com.amazon.oih.dao.g2s2.ConfigKey;


@ConfigKey(value = "IOGAttr")
public class InventoryOwnerGroup extends ConfigEntity implements Comparable<InventoryOwnerGroup> {
    
    private Long iogId;
    private String iogName;
    private String iogType;

    private boolean considerUnsellable = false;
    private boolean considerSellable = true;    
    
    private String countryCode;
        
    @ID
    public Long getIogId() {
        return this.iogId;
    }

    public void setIogId(Long iogId) {
        this.iogId = iogId;
    }

    public String getIogName() {
        return this.iogName;
    }

    public void setIogName(String iogName) {
        this.iogName = iogName;
    }

    public String getIogType() {
        return this.iogType;
    }

    public void setIogType(String iogType) {
        this.iogType = iogType;
    }

    public boolean isConsiderUnsellable() {
        return considerUnsellable;
    }

    public void setConsiderUnsellable(boolean considerUnsellable) {
        this.considerUnsellable = considerUnsellable;
    }

    public boolean isConsiderSellable() {
        return considerSellable;
    }

    public void setConsiderSellable(boolean considerSellable) {
        this.considerSellable = considerSellable;
    }
    
    public String getCountryCode() {
        return this.countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    @Override
    public int hashCode() {
        int hashCode = 1;
        hashCode += (getIogId() == null ? 0 : getIogId().hashCode());
        return hashCode;
    }

    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (o instanceof InventoryOwnerGroup)
            return compareTo((InventoryOwnerGroup) o) == 0;
        return false;
    }
    
    /**
     * compare by only IogId attribute
     */
    public int compareTo(InventoryOwnerGroup o) {
        if (o == null)
            return -1;
        if (o == this)
            return 0;
        Long o1 = getIogId();
        Long o2 = o.getIogId();
        if (o1 == null)
            return -1;
        if (o2 == null)
            return 1;
        return o1.compareTo(o2);
    }

}