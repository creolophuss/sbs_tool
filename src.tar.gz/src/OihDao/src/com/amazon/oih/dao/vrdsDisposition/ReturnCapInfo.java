package com.amazon.oih.dao.vrdsDisposition;

public class ReturnCapInfo {
	String basis;
	double amount;
	String returnCapTimePeriod;
	
	public String getBasis() {
		return basis;
	}
	public void setBasis(String basis) {
		this.basis = basis;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public String getReturnCapTimePeriod() {
		return returnCapTimePeriod;
	}
	public void setReturnCapTimePeriod(String returnCapTimePeriod) {
		this.returnCapTimePeriod = returnCapTimePeriod;
	}
	
	public String toString(){
		StringBuffer str = new StringBuffer();
		str.append("basis: ");
		str.append(basis);
		str.append(" amount: ");
		str.append(amount);
		str.append(" period: ");
		str.append(returnCapTimePeriod);
		return str.toString();
	}
}
