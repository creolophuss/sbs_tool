package com.amazon.oih.dao.hbase.quantitybasedmarkdowninfo;

import java.io.Serializable;

import com.amazon.oih.common.RowKeyBuildType;
import com.amazon.oih.common.RowKeyType;
import com.amazon.oih.dao.hbase.base.CommonKVHBaseDao.HTable;
import com.amazon.oih.dao.hbase.converter.Column;
import com.amazon.oih.dao.hbase.converter.RowKey;


@HTable(value = "QuantityBasedMarkdownInfo", columFamilyName = "QMI", separator = ":")
@RowKey({"asin", "marketplaceId"})
@RowKeyBuildType(RowKeyType.ASIN_MARKETPLACE)
public class QtyBasedMarkdownHBaseObj implements Serializable {
    private static final long serialVersionUID = -795375303954895856L;
    private String asin;
    private int marketplaceId;
    
    @Column(name="markdownForecastDetail",index=0)
    private String rawMarkdownInfo;
    
    @Column(name="dataVersion",index=0)
    private String dataVersion;

    @Column(name="dataLevel",index=0)
    private String rawDataLevels;

    public String getAsin() {
        return asin;
    }

    public void setAsin(String asin) {
        this.asin = asin;
    }

    public int getMarketplaceId() {
        return marketplaceId;
    }

    public void setMarketplaceId(int marketplaceId) {
        this.marketplaceId = marketplaceId;
    }

    public String getRawMarkdownInfo() {
        return rawMarkdownInfo;
    }

    public void setRawMarkdownInfo(String rawMarkdownInfo) {
        this.rawMarkdownInfo = rawMarkdownInfo;
    }

    public String getDataVersion() {
        return dataVersion;
    }

    public void setDataVersion(String dataVersion) {
        this.dataVersion = dataVersion;
    }

    public String getRawDataLevels() {
        return rawDataLevels;
    }

    public void setRawDataLevels(String rawDataLevels) {
        this.rawDataLevels = rawDataLevels;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((asin == null) ? 0 : asin.hashCode());
        result = prime * result + ((dataVersion == null) ? 0 : dataVersion.hashCode());
        result = prime * result + marketplaceId;
        result = prime * result + ((rawDataLevels == null) ? 0 : rawDataLevels.hashCode());
        result = prime * result + ((rawMarkdownInfo == null) ? 0 : rawMarkdownInfo.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        QtyBasedMarkdownHBaseObj other = (QtyBasedMarkdownHBaseObj) obj;
        if (asin == null) {
            if (other.asin != null)
                return false;
        } else if (!asin.equals(other.asin))
            return false;
        if (dataVersion == null) {
            if (other.dataVersion != null)
                return false;
        } else if (!dataVersion.equals(other.dataVersion))
            return false;
        if (marketplaceId != other.marketplaceId)
            return false;
        if (rawDataLevels == null) {
            if (other.rawDataLevels != null)
                return false;
        } else if (!rawDataLevels.equals(other.rawDataLevels))
            return false;
        if (rawMarkdownInfo == null) {
            if (other.rawMarkdownInfo != null)
                return false;
        } else if (!rawMarkdownInfo.equals(other.rawMarkdownInfo))
            return false;
        return true;
    }

    @Override
    public String toString() {
        return "QtyBasedMarkdownHBaseObj [asin=" + asin + ", marketplaceId=" + marketplaceId + ", rawMarkdownInfo="
                + rawMarkdownInfo + ", dataVersion=" + dataVersion + ", rawDataLevels=" + rawDataLevels + "]";
    }
    
    
}
