package com.amazon.oih.dao;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public abstract class OihObject {

    private long sequenceId;
    private String asin;
    private int iog;
    private String source;
    private long version;
    private String isCurrent;
    private String status;
    private String statusReason;
    private Date firstLoadDate;
    private Date lastLoadDate;
    private Date expiredDate;

    public OihObject() {
    }

    public OihObject(String asin, int iog, String source) {
        this.asin = asin;
        this.iog = iog;
        this.source = source;
        this.version = 0;
        this.isCurrent = DaoConstants.IS_CURRENT_Y;
        this.status = DaoConstants.STATUS_OK;
        setDates(new Date());
    }

    public OihObject(String asin, int iog, String source, Date runDate) {
        this.asin = asin;
        this.iog = iog;
        this.source = source;
        this.version = 0;
        this.isCurrent = DaoConstants.IS_CURRENT_Y;
        this.status = DaoConstants.STATUS_OK;
        setDates(runDate);
    }

    
    public long getSequenceId() {
        return sequenceId;
    }

    public void setSequenceId(long sequenceId) {
        this.sequenceId = sequenceId;
    }

    public String getAsin() {
        return asin;
    }

    public void setAsin(String asin) {
        this.asin = asin;
    }

    public int getIog() {
        return iog;
    }

    public void setIog(int iog) {
        this.iog = iog;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public long getVersion() {
        return version;
    }

    public void setVersion(long version) {
        this.version = version;
    }

    public String getIsCurrent() {
        return isCurrent;
    }

    public void setIsCurrent(String isCurrent) {
        this.isCurrent = isCurrent;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getStatusReason() {
        return statusReason;
    }

    public void setStatusReason(String statusReason) {
        this.statusReason = statusReason;
    }


    public Date getFirstLoadDate() {
        return firstLoadDate;
    }

    public void setFirstLoadDate(Date firstLoadDate) {
        this.firstLoadDate = firstLoadDate;
    }

    public Date getLastLoadDate() {
        return lastLoadDate;
    }

    public void setLastLoadDate(Date lastLoadDate) {
        this.lastLoadDate = lastLoadDate;
    }

    public Date getExpiredDate() {
        return expiredDate;
    }

    public void setExpiredDate(Date expiredDate) {
        this.expiredDate = expiredDate;
    }
    
    public void setDates(Date date){
        this.firstLoadDate = date;
        this.lastLoadDate = date;
        
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date exp = null;
        try {
            exp = dateFormat.parse(DaoConstants.EXPIRE_DATE);
        } catch (ParseException e) {
            e.printStackTrace();
        } 
        this.expiredDate = exp;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (obj instanceof OihObject == false){
            return false;
        }
        
        OihObject other = (OihObject) obj;

        if (!this.asin.equals(other.getAsin())) {
            return false;
        }
        if (this.iog != other.getIog()) {
            return false;
        }
        if (!this.source.equals(other.getSource())) {
            return false;
        }
        if (!this.status.equals(other.getStatus())) {
            return false;
        }
        if (this.isCurrent != null && other.getIsCurrent() != null) {
            return this.isCurrent.equals(other.getIsCurrent());
        } else if ((this.isCurrent == null && other.getIsCurrent() != null)
                || (this.isCurrent != null && other.getIsCurrent() == null)) {
            return false;
        }

        return true;
    }

    /**
     * hashCode of the key
     */
    public abstract int hashCode();
    /**
     * Usually set all value to 0
     */
    public abstract void cleanValues();
    
    /**
     * copy value accorind to other obj
     * @param obj
     */
    public abstract void copyValues(Object obj);
    
    /**
     * get key of this object like asin|iog|warehouse
     * @return
     */
    public abstract String getKey();
    
    /**
     * get values of this object like 1|1|0|0
     * @return
     */
    public abstract String getValues();
}
