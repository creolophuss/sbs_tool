package com.amazon.oih.dao.hbase.forecast;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.apache.hadoop.hbase.KeyValue;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.util.Bytes;

import com.amazon.oih.dao.DaoConstants;
import com.amazon.oih.dao.hbase.base.Converter;
import com.amazon.oih.utils.HBaseRowkeyUtil;
import com.google.common.base.Splitter;

/**
 * 
 * @author xlpeng
 * 
 */
@Deprecated
public class ForecastConverter implements Converter<ForecastHBaseObject> {
    @Override
    public ForecastHBaseObject convert(String rowKey, Result rs) throws IOException {
        if (rs == null || rs.isEmpty()) {
            return null;
        }
        ForecastHBaseObject forecastHBaseObject = HBaseRowkeyUtil.parseForecastRowkey(rowKey);
        Map<String, List<Double>> forecast = new HashMap<String, List<Double>>();
        for (KeyValue kv : rs.raw()) {
            String probability = new String(kv.getQualifier());
            List<Double> forecastValueList = new ArrayList<Double>();
            String value = new String(kv.getValue());
            if( !StringUtils.isEmpty(value)){
                Iterable<String> weeklyForecastDemands = Splitter.on(DaoConstants.WEEKLY_FORECAST_VALUE_SPLIT).split(value);
                for (String weeklyForecastDemand : weeklyForecastDemands) {
                    forecastValueList.add(Double.valueOf(weeklyForecastDemand));
                }
            }
            forecast.put(probability, forecastValueList);
        }
        forecastHBaseObject.setForecast(forecast);
        return forecastHBaseObject;
    }

    @Override
    public List<Put> convert(ForecastHBaseObject bObject) throws IOException {
        String rowKey = getRowKey(bObject);

        Set<String> keySet = bObject.getForecastMap().keySet();
        Iterator<String> it = keySet.iterator();
        List<Put> puts = new ArrayList<Put>();
        while (it.hasNext()) {
            String key = (String) it.next();
            String value = bObject.getValues(key);
            Put put = new Put(Bytes.toBytes(rowKey));
            put.add(Bytes.toBytes(ForecastHBaseDao.FORECAST_COLUMNFAMILY), Bytes.toBytes(key), Bytes.toBytes(value));
            puts.add(put);
        }
        return puts;
    }

    @Override
    public ForecastHBaseObject convert(Result rs) throws IOException {
        if (rs == null || rs.isEmpty()) {
            return null;
        }
        return convert(Bytes.toString(rs.getRow()), rs);
    }

    @Override
    public String getRowKey(ForecastHBaseObject object) {
        return HBaseRowkeyUtil.getRowKeyBasedAsinMarketplace(object.getAsin(), object.getMarketplace());
    }
}
