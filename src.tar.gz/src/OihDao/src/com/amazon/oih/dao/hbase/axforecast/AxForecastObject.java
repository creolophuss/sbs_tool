package com.amazon.oih.dao.hbase.axforecast;

import java.util.ArrayList;
import java.util.List;

import com.amazon.oih.common.RowKeyBuildType;
import com.amazon.oih.common.RowKeyType;
import com.amazon.oih.dao.hbase.base.CommonKVHBaseDao.HTable;
import com.amazon.oih.dao.hbase.converter.Column;
import com.amazon.oih.dao.hbase.converter.RowKey;
import com.google.common.base.Joiner;

@RowKey({
        "asin", "marketplace"
})
@RowKeyBuildType(RowKeyType.ASIN_MARKETPLACE)
@HTable(value = "AxForecast", columFamilyName = "Forecast", separator = ":")
public class AxForecastObject {
    private static final String SEPARATOR = ",";

    private List<Double> data;

    private long marketplace;

    private String asin;

    private int iog;

    @Column(name = "distribution", index = 0)
    private String distribution;

    public List<Double> getData() {
        return data;
    }

    public void setData(List<Double> data) {
        this.data = data;
        if (data != null)
            this.distribution = Joiner.on(SEPARATOR).join(data);
        else
            this.distribution = null;
    }

    public long getMarketplace() {
        return marketplace;
    }

    public void setMarketplace(long marketplace) {
        this.marketplace = marketplace;
    }

    public String getAsin() {
        return asin;
    }

    public void setAsin(String asin) {
        this.asin = asin;
    }

    public int getIog() {
        return iog;
    }

    public void setIog(int iog) {
        this.iog = iog;
    }

    public String getDistribution() {
        return distribution;
    }

    public void setDistribution(String distribution) {
        this.distribution = distribution;
        if (distribution != null) {
            this.data = new ArrayList<Double>();
            String[] arr = distribution.split(SEPARATOR);
            for (String e : arr) {
                this.data.add(Double.valueOf(e));
            }
        } else {
            this.data = null;
        }
    }
}
