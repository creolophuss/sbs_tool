package com.amazon.oih.dao.hazmatwhitelist;

import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;

/**
 * Interface for VReturnsProperties DAO
 * 
 */
public class VReturnsPropertiesDAOImpl implements VReturnsPropertiesDao {
    private static final Logger logger = Logger.getLogger(VReturnsPropertiesDAOImpl.class);
    private SessionFactory sessionFactory = null;

    /**
     * 
     */
    public void save(final VReturnsProperties p) {
        if (null == p) {
            throw new IllegalArgumentException("input parameter property is null");
        }

        String category = p.getPropertyCategoryName();
        String type = p.getPropertyTypeName();

        if (null == category || category.trim().length() == 0) {
            throw new IllegalArgumentException("category is empty");
        }

        if (null == type || type.trim().length() == 0) {
            throw new IllegalArgumentException("type is empty");
        }

        List<VReturnsProperties> props = find(category, type);

        Date now = new Date(System.currentTimeMillis());

        VReturnsProperties tmp = null;
        if (props.size() == 0) {
            tmp = new VReturnsProperties(p);
            tmp.setLastUpdatedDate(now);
        } else if (props.size() == 1) {
            tmp = props.get(0);
            tmp.setPropertyValue(p.getPropertyValue());
            tmp.setLastUpdatedDate(now);
            tmp.setLastUpdatedBy(p.getLastUpdatedBy());
            tmp.setLastActedUponBy(p.getLastActedUponBy());
        } else {
            throw new RuntimeException("found multiple properties for " + p);
        }

        try {
            Session session = getSession();
            session.save(tmp);
            logger.info("updated property: " + tmp);
        } catch (HibernateException ex) {
            throw new RuntimeException(ex);
        }
    }

    /**
     * 
     */
    public void delete(final VReturnsProperties p) {
        if (null == p) {
            throw new IllegalArgumentException("input parameter property is null");
        }

        try {
            List<VReturnsProperties> props = find(p.getPropertyCategoryName(), p.getPropertyTypeName());

            Session session = getSession();
            for (VReturnsProperties i : props) {
                session.delete(i);
                logger.info("deleted property: " + i);
            }
        } catch (HibernateException ex) {
            throw new RuntimeException(ex);
        }
    }

    /**
     * 
     */
    public VReturnsProperties find(final Long id) {
        if (null == id) {
            throw new IllegalArgumentException("input parameter id is null");
        }

        try {
            logger.info("searching properties by id: " + id);

            Criteria criteria = getSession().createCriteria(VReturnsProperties.class);
            criteria.add(Restrictions.eq("id", id));
            VReturnsProperties property = (VReturnsProperties) criteria.uniqueResult();
            if (null == property) {
                return null;
            }

            logger.info("found property: " + property);

            return property;
        } catch (HibernateException ex) {
            throw new RuntimeException(ex);
        }
    }

    /**
     * 
     */
    @SuppressWarnings("unchecked")
    public List<VReturnsProperties> find(String category, String type) {

        boolean hasCategory = false;
        boolean hasType = false;

        if (null != category && category.trim().length() > 0) {
            hasCategory = true;
        }

        if (null != type && type.trim().length() > 0) {
            hasType = true;
        }
        
        Session session = getSession();

        try {
            logger.info(String.format("searching properties by category [%s] and type [%s]", category, type));

            Criteria criteria = session.createCriteria(VReturnsProperties.class);

            if (hasCategory) {
                criteria.add(Restrictions.eq("propertyCategoryName", category));
            }

            if (hasType) {
                criteria.add(Restrictions.eq("propertyTypeName", type));
            }

            List<VReturnsProperties> properties = (List<VReturnsProperties>) criteria.list();

            if (null == properties) {
                return Collections.emptyList();
            }

            logger.info("found properties: " + properties);

            return properties;
        } catch (HibernateException ex) {
            throw new RuntimeException(ex);
        } finally{
            if(session != null ){
                session.close();
            }            
        }
    }

    private Session getSession() {
        return getSessionFactory().openSession();
    }

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    public SessionFactory getSessionFactory() {
        return sessionFactory;
    }
}
