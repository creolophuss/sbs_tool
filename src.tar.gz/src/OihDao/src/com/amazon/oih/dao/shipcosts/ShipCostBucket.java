package com.amazon.oih.dao.shipcosts;

import java.util.Arrays;

public class ShipCostBucket {
    private String currencyCode;
    private Double[] costTable;
    private String[] dests;
    private String[] shipOptions;
    private String[] sources;
    
    private Double weight;
    private String json;
    
    public ShipCostBucket() {
        this(null);
    }
    
    public ShipCostBucket(Double weight) {
        this.weight = weight;
    }
    
    public void setInfo(String currencyCode, Double[] costTable, String[]dests, String[]shipOptions, String[]sources) {
        this.currencyCode = currencyCode;
        this.costTable = costTable;
        this.dests = dests;
        this.shipOptions = shipOptions;
        this.sources = sources;
        
        this.json = toJson(this);
    }
  
    public double getWeight() {
        return weight;
    }
    public void setWeight(Double weight) {
        this.weight = weight;
    }
    
    public int getSourceIndex(String target) {
        return getObjectIndex(target, sources);
    }
    
    public int getDestIndex(String target) {
        return getObjectIndex(target, dests);        
    }
    
    public Double getCost(int index) {
        return costTable[index];
    }

    public int getSourceSize() {
        return sources.length;
    }
    
    public int getDestSize() {
        return dests.length;
    }
    
    
    @Override
    public String toString() {
        return "ShipCostBucket [dests=" + Arrays.toString(dests) + ", shipOptions=" + Arrays.toString(shipOptions)
                + ", sources=" + Arrays.toString(sources) + ", weight=" + weight + ", costTable=" + Arrays.toString(costTable) + "]";
    }

    public static String toJson(ShipCostBucket info) {
        return "";
    }
    
    public static ShipCostBucket fromJson(double weight, String desc) {
        return null;
    }
    
    private int getObjectIndex(String target, String[]array) {
        int index = -1;
        for(String object : array) {
            ++index;
            if (target.equals(object)) {
                return index;
            }
        }
        
        return -1;
    }
}
