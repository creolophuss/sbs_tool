package com.amazon.oih.dao.markdowninfo;

import com.amazon.carbonado.Alias;
import com.amazon.carbonado.PrimaryKey;
import com.amazon.carbonado.Storable;
import com.amazon.carbonado.constraint.FloatConstraint;
import com.amazon.carbonado.constraint.IntegerConstraint;
import com.amazon.carbonado.constraint.LengthConstraint;

@Alias("data_markdown_info")
@PrimaryKey( {
        "runID", "asin", "marketplaceId"
})
public abstract class MarkdownInfoBDBObject implements Storable<MarkdownInfoBDBObject> {
    @Alias("run_id")
    public abstract long getRunID();

    public abstract void setRunID(long runid);

    public abstract String getAsin();

    @LengthConstraint(min = 10, max = 10)
    public abstract void setAsin(String asin);

    public abstract long getMarketplaceId();

    @IntegerConstraint(min = 1, max = Integer.MAX_VALUE)
    public abstract void setMarketplaceId(long marketplaceId);

    public abstract Double getDemandIncrease();

    @FloatConstraint(min = 0.0, max = Double.MAX_VALUE)
    public abstract void setDemandIncrease(Double demandIncrease);

    public abstract Double getDemandIncreaseRate();

    @FloatConstraint(min = 0.0, max = Double.MAX_VALUE)
    public abstract void setDemandIncreaseRate(Double demandIncreaseRate);

    public abstract Double getRecoveryRate();

    @FloatConstraint(min = 0.0, max = Double.MAX_VALUE)
    public abstract void setRecoveryRate(Double recoveryRate);

    public abstract String getDataVersion();

    public abstract void setDataVersion(String dataVersion);

    public abstract String getDataLevel();

    public abstract void setDataLevel(String dataLevel);
}