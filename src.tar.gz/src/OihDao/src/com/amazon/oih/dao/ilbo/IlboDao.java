package com.amazon.oih.dao.ilbo;

import org.apache.log4j.Logger;
import org.hibernate.CacheMode;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.ScrollMode;
import org.hibernate.ScrollableResults;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import com.amazon.oih.dao.DaoConstants;
import com.amazon.oih.dao.HibernateUtil;
import com.amazon.oih.dao.OihDao;
import com.amazon.oih.dao.exception.DaoRuntimeException;
import com.amazon.oih.dao.exception.OihPersistenceException;

public class IlboDao extends OihDao<IlboObject> {
    final static Logger log = Logger.getLogger(IlboDao.class);

    public IlboDao(String source) {
        super(source);
    }
    
    @Override
    public String getType() {
        // TODO Auto-generated method stub
        return IlboObject.class.getName();
    }

    @Override
    public IlboObject findCurrent(IlboObject obj) throws OihPersistenceException, DaoRuntimeException {
        if (obj == null) {
            log.info("findCurrent request is null");
            return null;
        }
       
        log.debug("Query Ilbo by " + obj.toString());
        try {
            if (session == null || !session.isOpen()) {
                session = HibernateUtil.getSessionFactory().openSession();
            }       
            Criteria cri = session.createCriteria(IlboObject.class);
            cri.add(Restrictions.eq("asin", obj.getAsin()));
            cri.add(Restrictions.eq("iog", obj.getIog()));
            cri.add(Restrictions.eq("warehouseId", obj.getWarehouseId()));
            cri.add(Restrictions.eq("source", obj.getSource()));
            cri.add(Restrictions.eq("isCurrent", DaoConstants.IS_CURRENT_Y));
            cri.add(Restrictions.eq("status", obj.getStatus())); 

            IlboObject result = (IlboObject)cri.uniqueResult();
            return result;
        } catch ( HibernateException e ) {
            log.error("Fail to query Ilbo " + e);
            e.printStackTrace();
            throw new OihPersistenceException(e);
        } 
    }

    /*
     * ***************************************************************************
     * The following code are suspending code.
     * Currently are not used. Should be used in future
     * ***************************************************************************
     */
    public IlboObject getNextIlboObject() throws OihPersistenceException, DaoRuntimeException {
        return null;
    }

}