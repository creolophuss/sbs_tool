package com.amazon.oih.dao.hbase.adjustedrol;

import com.amazon.oih.dao.hbase.base.CommonKVHBaseDao;

public class AdjustedMaxROLConverter extends CommonKVHBaseDao<AdjustedMaxROL> {

    public AdjustedMaxROLConverter() {
        super(AdjustedMaxROL.class);
    }

}
