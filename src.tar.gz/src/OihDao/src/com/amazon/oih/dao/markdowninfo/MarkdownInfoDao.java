package com.amazon.oih.dao.markdowninfo;

import java.util.List;

import amazon.platform.profiler.Profiler;
import amazon.platform.profiler.ProfilerScope;

import com.amazon.carbonado.ConfigurationException;
import com.amazon.carbonado.FetchException;
import com.amazon.carbonado.IsolationLevel;
import com.amazon.carbonado.PersistException;
import com.amazon.carbonado.Repository;
import com.amazon.carbonado.RepositoryException;
import com.amazon.carbonado.Storage;
import com.amazon.carbonado.Transaction;
import com.amazon.oih.dao.exception.DaoRuntimeException;
import com.amazon.oih.dao.exception.OihPersistenceException;

/**
 * 
 * @author zhongwei
 * 
 */
public class MarkdownInfoDao implements IMarkdownInfoDao {
    protected String domain = null;
    protected Repository repository = null;

    public MarkdownInfoDao(String domain) {
        this.domain = domain;
    }

    public void setRepository(Repository repository) {
        if (null == repository) {
            throw new IllegalArgumentException("repository is null");
        }
        this.repository = repository;
    }

    @Override
    public MarkdownInfo createMarkdownInfo(Long runId, String asin, long marketplaceId, double recoveryRate,
            double demandIncrease, double demandIncreaseRate, String dataLevel, String dataVersion)
            throws OihPersistenceException {
        return new MarkdownInfo(runId, asin, (int) marketplaceId, demandIncrease, demandIncreaseRate, recoveryRate,
                dataVersion, dataLevel);
    }

    @Override
    public boolean exists(Long runId, String asin, long marketplaceId) throws OihPersistenceException {
        ProfilerScope scope = Profiler.scopeStart(this.getClass().getName() + "::existsWithVendor");

        try {
            Storage<MarkdownInfoBDBObject> sf = repository.storageFor(MarkdownInfoBDBObject.class);
            boolean retVal = sf.query("runID = ? & marketplaceId = ? & asin = ?").with(runId).with(marketplaceId)
                    .with(asin).exists();

            return retVal;
        } catch (ConfigurationException e) {
            throw new DaoRuntimeException(e);
        } catch (RepositoryException e) {
            throw new OihPersistenceException(e);
        } finally {
            Profiler.scopeEnd(scope);
        }

    }

    @Override
    public MarkdownInfo find(Long runId, String asin, long marketplaceId) throws OihPersistenceException {
        ProfilerScope scope = Profiler.scopeStart(this.getClass().getName() + "::find");

        try {
            Storage<MarkdownInfoBDBObject> sf = repository.storageFor(MarkdownInfoBDBObject.class);
            return convert(sf.query("runID = ? & marketplaceId = ? & asin = ?").with(runId).with(marketplaceId)
                    .with(asin).loadOne());
        } catch (FetchException e) {// find nothing from the DB
            return null;
        } catch (Exception e) {
            throw new OihPersistenceException(e);
        } finally {
            Profiler.scopeEnd(scope);
        }

    }

    @Override
    public void save(List<MarkdownInfo> infos) throws OihPersistenceException {
        Transaction txn = repository.enterTransaction(IsolationLevel.READ_UNCOMMITTED);
        try {
            for (MarkdownInfo markdownInfoData : infos) {
                MarkdownInfoBDBObject markdownInfo = convert(markdownInfoData);
                if (!markdownInfo.tryLoad()) {
                    markdownInfo.insert();
                }
            }
            txn.commit();
        } catch (PersistException e) {
            throw new OihPersistenceException(e);
        } catch (Exception e) {
            throw new DaoRuntimeException(e);
        } finally {
            exitTransaction(txn);
        }
    }

    @Override
    public void save(MarkdownInfo info) throws OihPersistenceException {
        ProfilerScope scope = Profiler.scopeStart(this.getClass().getName() + "::save");
        try {
            convert(info).insert();
        } catch (PersistException e) {
            throw new OihPersistenceException(e);
        } finally {
            Profiler.scopeEnd(scope);
        }
    }

    private MarkdownInfoBDBObject convert(MarkdownInfo markdownForecast) throws OihPersistenceException {
        ProfilerScope scope = Profiler.scopeStart(this.getClass().getName() + "::create");
        try {
            Storage<MarkdownInfoBDBObject> sMarkdownInfo = repository.storageFor(MarkdownInfoBDBObject.class);
            MarkdownInfoBDBObject markdownInfo = sMarkdownInfo.prepare();
            markdownInfo.setRunID(markdownForecast.getRunID());
            markdownInfo.setMarketplaceId(markdownForecast.getMarketplaceId());
            markdownInfo.setAsin(markdownForecast.getAsin());
            markdownInfo.setRecoveryRate(markdownForecast.getRecoveryRate());
            markdownInfo.setDemandIncrease(markdownForecast.getDemandIncrease());
            markdownInfo.setDemandIncreaseRate(markdownForecast.getDemandIncreaseRate());
            markdownInfo.setDataVersion(markdownForecast.getDataVersion());
            markdownInfo.setDataLevel(markdownForecast.getDataLevel());

            return markdownInfo;
        } catch (ConfigurationException e) {
            throw new DaoRuntimeException(e);
        } catch (RepositoryException e) {
            throw new OihPersistenceException(e);
        } finally {
            Profiler.scopeEnd(scope);
        }
    }

    private MarkdownInfo convert(MarkdownInfoBDBObject markdownInfo) {
        if (markdownInfo == null) {
            return null;
        }
        MarkdownInfo markdownForecast = new MarkdownInfo();
        markdownForecast.setRunID(markdownInfo.getRunID());
        markdownForecast.setMarketplaceId((int) markdownInfo.getMarketplaceId());
        markdownForecast.setAsin(markdownInfo.getAsin());
        markdownForecast.setRecoveryRate(markdownInfo.getRecoveryRate());
        markdownForecast.setDemandIncrease(markdownInfo.getDemandIncrease());
        markdownForecast.setDemandIncreaseRate(markdownInfo.getDemandIncreaseRate());
        markdownForecast.setDataVersion(markdownInfo.getDataVersion());
        markdownForecast.setDataLevel(markdownInfo.getDataLevel());
        return markdownForecast;
    }

    private void exitTransaction(Transaction txn) throws OihPersistenceException {
        try {
            txn.exit();
        } catch (PersistException e) {
            throw new OihPersistenceException(e);
        }
    }
}
