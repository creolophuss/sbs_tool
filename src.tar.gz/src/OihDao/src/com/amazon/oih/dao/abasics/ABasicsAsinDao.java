package com.amazon.oih.dao.abasics;

import java.util.List;

import com.amazon.oih.dao.exception.OihPersistenceException;

public interface ABasicsAsinDao {
    
    public List<ABasicsAsin> getABasicsAsins(Long runId) throws OihPersistenceException;
    
    public void save(ABasicsAsin asin) throws OihPersistenceException;
}
