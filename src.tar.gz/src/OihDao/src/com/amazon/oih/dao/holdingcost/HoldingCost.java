package com.amazon.oih.dao.holdingcost;

import java.io.Serializable;

import com.amazon.oih.common.Identifiable;
import com.amazon.oih.common.KVFormater.FileColumnNames;
import com.amazon.oih.common.KeyValueBase.NamedValue;

@FileColumnNames(value = {"Realm", "GL", "WarehouseId", "StartDate", "EndDate", "HoldingCost", "Currency"})
public class HoldingCost implements Serializable, Identifiable {

    private static final long serialVersionUID = -8775806860908364942L;

    @NamedValue("StartDate")
    private String startDate; // This is in format of 04-30

    @NamedValue("EndDate")
    private String endDate; // This is in format of 04-30

    @NamedValue("Realm")
    private String realm;
    
    @NamedValue("GL")
    private String gl;      // Default by -1, it represents all GLs

    @NamedValue("WarehouseId")
    private String warehouse;

    @NamedValue("Currency")
    private String currency;

    @NamedValue("HoldingCost")
    private double holdingCost;

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public String getRealm() {
        return realm;
    }

    public void setRealm(String realm) {
        this.realm = realm;
    }

    public String getGl() {
        return gl;
    }

    public void setGl(String gl) {
        this.gl = gl;
    }

    public String getWarehouse() {
        return warehouse;
    }

    public void setWarehouse(String warehouse) {
        this.warehouse = warehouse;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public double getHoldingCost() {
        return holdingCost;
    }

    public void setHoldingCost(double holdingCost) {
        this.holdingCost = holdingCost;
    }


    @Override
    public String getIdentity() {
        return "" + realm + "|" + gl + "|" + warehouse + "|" + startDate + "|" + endDate;
    }
    
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((currency == null) ? 0 : currency.hashCode());
        result = prime * result + ((endDate == null) ? 0 : endDate.hashCode());
        long temp;
        temp = Double.doubleToLongBits(holdingCost);
        result = prime * result + (int) (temp ^ (temp >>> 32));
        result = prime * result + ((realm == null) ? 0 : realm.hashCode());
        result = prime * result + ((startDate == null) ? 0 : startDate.hashCode());
        result = prime * result + ((warehouse == null) ? 0 : warehouse.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        HoldingCost other = (HoldingCost) obj;
        if (currency == null) {
            if (other.currency != null)
                return false;
        } else if (!currency.equals(other.currency))
            return false;
        if (endDate == null) {
            if (other.endDate != null)
                return false;
        } else if (!endDate.equals(other.endDate))
            return false;
        if (Double.doubleToLongBits(holdingCost) != Double.doubleToLongBits(other.holdingCost))
            return false;
        if (realm == null) {
            if (other.realm != null)
                return false;
        } else if (!realm.equals(other.realm))
            return false;
        if (startDate == null) {
            if (other.startDate != null)
                return false;
        } else if (!startDate.equals(other.startDate))
            return false;
        if (warehouse == null) {
            if (other.warehouse != null)
                return false;
        } else if (!warehouse.equals(other.warehouse))
            return false;
        return true;
    }
}
