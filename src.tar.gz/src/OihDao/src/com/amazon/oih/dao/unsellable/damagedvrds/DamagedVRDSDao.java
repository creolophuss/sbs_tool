package com.amazon.oih.dao.unsellable.damagedvrds;

import java.util.List;

import amazon.platform.profiler.Profiler;
import amazon.platform.profiler.ProfilerScope;

import com.amazon.carbonado.IsolationLevel;
import com.amazon.carbonado.PersistException;
import com.amazon.carbonado.Repository;
import com.amazon.carbonado.RepositoryException;
import com.amazon.carbonado.Storage;
import com.amazon.carbonado.SupportException;
import com.amazon.carbonado.Transaction;
import com.amazon.oih.dao.exception.DaoRuntimeException;
import com.amazon.oih.dao.exception.OihPersistenceException;

public class DamagedVRDSDao implements IDamagedVRDSDao {
    protected String domain = null;
    protected Repository repository = null;

    public DamagedVRDSDao(String domain) {
        this.domain = domain;
    }

    public void setRepository(Repository repository) {
        if (null == repository) {
            throw new IllegalArgumentException("repository is null");
        }
        this.repository = repository;
    }

    @Override
    public DamagedVRDSItem createDamagedVRDSItem(OihVRDSItem oihVRDSItem) throws OihPersistenceException {
        ProfilerScope scope = Profiler.scopeStart(this.getClass().getName() + "::create");
        try {
            Storage<DamagedVRDSItem> damagedVRDSItemStorable = repository.storageFor(DamagedVRDSItem.class);
            DamagedVRDSItem damagedVRDSItem = damagedVRDSItemStorable.prepare();

            setValues(damagedVRDSItem, oihVRDSItem);

            return damagedVRDSItem;
        } catch (SupportException e) {
            throw new OihPersistenceException(e);
        } catch (RepositoryException e) {
            throw new OihPersistenceException(e);
        } finally {
            Profiler.scopeEnd(scope);
        }

    }

    @Override
    public boolean exists(String fnsku, Integer iog) throws OihPersistenceException {
        ProfilerScope scope = Profiler.scopeStart(this.getClass().getName() + "::exists");
        try {
            Storage<DamagedVRDSItem> sf = repository.storageFor(DamagedVRDSItem.class);
            boolean retVal = sf.query("iog = ? & fnsku = ?").with(iog).with(fnsku).exists();

            return retVal;
        } catch (SupportException e) {
            throw new DaoRuntimeException(e);
        } catch (RepositoryException e) {
            throw new OihPersistenceException(e);
        } finally {
            Profiler.scopeEnd(scope);
        }
    }

    @Override
    public List<DamagedVRDSItem> find(String fnsku, Integer iog) throws OihPersistenceException {
        ProfilerScope scope = Profiler.scopeStart(this.getClass().getName() + "::find");

        try {
            Storage<DamagedVRDSItem> sf = repository.storageFor(DamagedVRDSItem.class);

            return sf.query("iog = ? & fnsku = ?").with(iog).with(fnsku).fetch().toList();

        } catch (SupportException e) {
            throw new DaoRuntimeException(e);
        } catch (RepositoryException e) {
            throw new OihPersistenceException(e);
        } finally {
            Profiler.scopeEnd(scope);
        }

    }

    @Override
    public void save(List<DamagedVRDSItem> items) throws OihPersistenceException {
        Transaction txn = repository.enterTransaction(IsolationLevel.READ_UNCOMMITTED);

        try {
            for (DamagedVRDSItem di : items) {
                if (!di.tryLoad())
                    di.insert();
            }
            txn.commit();
        } catch (PersistException e) {
            throw new OihPersistenceException(e);
        } catch (Exception e) {
            throw new DaoRuntimeException(e);
        } finally {
            exitTransaction(txn);
        }
    }

    @Override
    public void save(DamagedVRDSItem item) throws OihPersistenceException {
        ProfilerScope scope = Profiler.scopeStart(this.getClass().getName() + "::save");
        try {
            item.insert();
        } catch (PersistException e) {
            throw new OihPersistenceException(e);
        } finally {
            Profiler.scopeEnd(scope);
        }
    }

    private void setValues(DamagedVRDSItem damagedVRDSItem, OihVRDSItem oihVRDSItem) {

        damagedVRDSItem.setFnsku(oihVRDSItem.getFnsku());
        damagedVRDSItem.setIog(Integer.valueOf(oihVRDSItem.getIog()));
        damagedVRDSItem.setFcsku(oihVRDSItem.getFcsku());
        damagedVRDSItem.setWarehouse(oihVRDSItem.getWarehouse());
        damagedVRDSItem.setCondition(oihVRDSItem.getCondition());

        damagedVRDSItem.setDestVendor(oihVRDSItem.getDestVendor());
        damagedVRDSItem.setSourceVendor(oihVRDSItem.getSourceVendor());
        damagedVRDSItem.setDisposition(oihVRDSItem.getDisposition());
        damagedVRDSItem.setQuantity(oihVRDSItem.getQuantity());
        damagedVRDSItem.setBaseCurrencyCode(oihVRDSItem.getBaseCurrencyCode());
        damagedVRDSItem.setRefundBasicCode(oihVRDSItem.getRefundBasisCode());

        damagedVRDSItem.setCost(oihVRDSItem.getCost());
        damagedVRDSItem.setRefundAmount(oihVRDSItem.getAmount());
        damagedVRDSItem.setPrice(oihVRDSItem.getPrice());

        damagedVRDSItem.setVRDSDescription(oihVRDSItem.getVrdsDescription());
        
        damagedVRDSItem.setIsAuthorizationRequired(oihVRDSItem.isAuthorizationRequired());
        damagedVRDSItem.setOpenAuthorizationNumber(oihVRDSItem.getOpenAuthorizationNumber());
        damagedVRDSItem.setReturnByMaxDays(oihVRDSItem.getReturnByMaxDays());
        damagedVRDSItem.setReturnByMinDays(oihVRDSItem.getReturnByMinDays());

        damagedVRDSItem.setDistributorShipmentItemId(oihVRDSItem.getDistributorShipmentItemId());

        damagedVRDSItem.setDistributorId(oihVRDSItem.getDistributorId());
        damagedVRDSItem.setDistributorShipmentId(oihVRDSItem.getDistributorShipmentId());
        damagedVRDSItem.setShipmentReceiveDate(oihVRDSItem.getShipmentReceiveDate());
        damagedVRDSItem.setDistributorOrderDate(oihVRDSItem.getDistributorOrderDate());
        damagedVRDSItem.setDistributorOrderId(oihVRDSItem.getDistributorOrderId());
        damagedVRDSItem.setDistributorOrderType(oihVRDSItem.getDistributorOrderType());
        
        //Foreign currency properties
        damagedVRDSItem.setForeignCurrencyCode(oihVRDSItem.getForeignCurrencyCode());
        damagedVRDSItem.setCostForeignCurrency(oihVRDSItem.getCostForeignCurrency());
        damagedVRDSItem.setRefundAmountForeignCurrency(oihVRDSItem.getRefundAmountForeignCurrency());
        damagedVRDSItem.setDistributorListPriceForeignCurrency(oihVRDSItem.getDistributorListPriceForeignCurrency());
        damagedVRDSItem.setDistributorCostForeignCurrency(oihVRDSItem.getDistributorCostForeignCurrency());
    }

    private void exitTransaction(Transaction txn) throws OihPersistenceException {
        try {
            txn.exit();
        } catch (PersistException e) {
            throw new OihPersistenceException(e);
        }
    }

    @Override
    public List<DamagedVRDSItem> find(String fnsku, String fcsku, Integer iog, String warehouse, String condition)
            throws OihPersistenceException {
        ProfilerScope scope = Profiler.scopeStart(this.getClass().getName() + "::find");

        try {
            Storage<DamagedVRDSItem> sf = repository.storageFor(DamagedVRDSItem.class);

            return sf.query("iog = ? & fnsku = ? & fcsku = ? & warehouse = ? & condition = ? ").with(iog).with(fnsku).with(fcsku).with(
                    warehouse).with(condition).fetch().toList();

        } catch (SupportException e) {
            throw new DaoRuntimeException(e);
        } catch (RepositoryException e) {
            throw new OihPersistenceException(e);
        } finally {
            Profiler.scopeEnd(scope);
        }
    }
}