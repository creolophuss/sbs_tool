package com.amazon.oih.dao.hbase.ourprice;

import java.io.Serializable;

import com.amazon.oih.common.RowKeyBuildType;
import com.amazon.oih.common.RowKeyType;
import com.amazon.oih.dao.hbase.base.CommonKVHBaseDao.HTable;
import com.amazon.oih.dao.hbase.converter.Column;
import com.amazon.oih.dao.hbase.converter.RowKey;

@RowKey({"asin", "iog"})
@RowKeyBuildType(RowKeyType.ASIN_IOG)
@HTable("OurPrice")
public class OurpriceHbaseObject implements Serializable {
    private static final long serialVersionUID = 1558979976207261761L;
    private String asin;
	private int iog;
	
	@Column(name="price",index=0)
	private double ourprice;

	public OurpriceHbaseObject(){}
	
	public OurpriceHbaseObject(String asin, int iog, double ourprice) {
		this.asin = asin;
		this.iog = iog;
		this.ourprice = ourprice;
	}

	public String getAsin() {
		return asin;
	}

	public void setAsin(String asin) {
		this.asin = asin;
	}

	public int getIog() {
		return iog;
	}

	public void setIog(int iog) {
		this.iog = iog;
	}

	public double getOurprice() {
		return ourprice;
	}

	public void setOurprice(double ourprice) {
		this.ourprice = ourprice;
	}
	
	@Override
	public String toString(){
	    return asin + "|" + iog + "|" + ourprice;
	}
}
