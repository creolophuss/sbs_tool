package com.amazon.oih.dao.targetInvLevel;

import java.io.Serializable;

import com.amazon.oih.common.RowKeyBuildType;
import com.amazon.oih.common.RowKeyType;
import com.amazon.oih.common.KeyValueBase.NamedValue;
import com.amazon.oih.dao.hbase.base.CommonKVHBaseDao.HTable;
import com.amazon.oih.dao.hbase.converter.Column;
import com.amazon.oih.dao.hbase.converter.RowKey;

@RowKey({"asin", "scopeId"})
@RowKeyBuildType(RowKeyType.ASIN_SCOPE)
@HTable("ScopeROL")
public class TargetInventoryLevelScope implements Serializable {   
    
    private static final long serialVersionUID = 1L;
    
    public static final int EXCEPTION_TIP = -100;
    
    private String asin;

    private String scopeId;
    
    @Column(name="ROL",index=0)
    private int til;          //This is actually max rol, but there is too much references, so we keep it in old name
    
    @Column(name="ROL",index=1)
    private int cartonQty;
    
    @Column(name="ROL",index=2)
    private int noIPCResponsable = -1;
    
    @Column(name="ROL",index=4)
    private int minROL;
    
    @Column(name="ROL",index=3)
    private int idealTIL;     //This is actually ideal TIP
    
    private long runID;
    
    public TargetInventoryLevelScope() {
    }

    public TargetInventoryLevelScope(long runID, String asin, String scopeId, int til, int cartonQty) {
        this.runID = runID;
        this.asin = asin;
        this.scopeId = scopeId;
        this.til = til;
        this.cartonQty = cartonQty;
    }

    public TargetInventoryLevelScope(long runID, String asin, String scopeId, int til, int cartonQty,
            int idealTIL, int minROL) {
        this(runID, asin, scopeId, til, cartonQty);
        this.idealTIL = idealTIL;
        this.minROL = minROL;
    }

    public int getNoIPCResponsable() {
        return noIPCResponsable;
    }

    public void setNoIPCResponsable(int noIPCResponsable) {
        this.noIPCResponsable = noIPCResponsable;
    }
    
    public boolean isNotIPCResponsable() {
    	return noIPCResponsable > 0;
    }


    public void setRunID(long runID) {
        this.runID = runID;
    }

    public long getRunID() {
        return runID;
    }

    public void setAsin(String asin) {
        this.asin = asin;
    }

    public String getAsin() {
        return asin;
    }

    public void setScopeId(String scope) {
        this.scopeId = scope;
    }

    public String getScopeId() {
        return scopeId;
    }

    public void setTil(int til) {
        this.til = til;
    }

    public int getTil() {
        return til;
    }
    
    public boolean isExceptionTil(){
        return EXCEPTION_TIP == til;
    }

    public void setCartonQty(int cartonQty) {
        this.cartonQty = cartonQty;
    }

    public int getCartonQty() {
        return cartonQty;
    }

    public int getMinROL() {
        return minROL;
    }

    public void setMinROL(int minROL) {
        this.minROL = minROL;
    }

    public int getIdealTIL() {
        return idealTIL;
    }

    public void setIdealTIL(int idealTIL) {
        this.idealTIL = idealTIL;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof TargetInventoryLevel == false) {
            return false;
        }
        if (this == obj) {
            return true;
        }

        TargetInventoryLevelScope other = (TargetInventoryLevelScope) obj;

        return this.asin.equals(other.getAsin()) && this.scopeId.equals(other.getScopeId())
                && this.til == other.getTil() && this.cartonQty == other.getCartonQty()
                && this.idealTIL == other.getIdealTIL() && this.minROL == other.getMinROL();
    }

    @Override
    public String toString() {
        return asin + "|" + scopeId + ":[" + til + "," + cartonQty + "," + idealTIL + "," + minROL + "]";
    }

    @Override
    public int hashCode() {
        final int prime = 127; // changed from default - 31 is a lame prime #
        int result = 1;
        result = prime * result + ((asin == null) ? 0 : asin.hashCode());
        result = prime * result + scopeId.hashCode();
        return result;
    }

}
