package com.amazon.oih.dao.hbase.base;

import java.io.IOException;
import java.util.List;

import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.client.Result;

/**
 * @author xlpeng
 *
 * @param <T>
 */
public interface Converter<T> {
    T convert(String rowKey, Result rs) throws IOException;
    T convert(Result rs) throws IOException;
    List<Put> convert(T object) throws IOException;
    String getRowKey(T object);
}