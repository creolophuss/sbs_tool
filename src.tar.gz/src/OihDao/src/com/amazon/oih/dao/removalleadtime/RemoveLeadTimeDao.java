package com.amazon.oih.dao.removalleadtime;

import java.util.List;

import com.amazon.oih.dao.exception.OihPersistenceException;

public interface RemoveLeadTimeDao {
    public abstract void save(RemoveLeadTime o) throws OihPersistenceException;

    public abstract void save(List<RemoveLeadTime> vlts) throws OihPersistenceException;

    public abstract boolean exists(Long runId, String asin, Integer iog, Integer gl, Disposition disposition) throws OihPersistenceException;

    public abstract RemoveLeadTime find(Long runId, String asin, Integer iog, Integer gl, Disposition disposition) throws OihPersistenceException;

    public abstract RemoveLeadTime findAsinLevelData(Long runId, String asin, Integer iog, Disposition disposition) throws OihPersistenceException;

    public abstract RemoveLeadTime findGLLevelData(Long runId, Integer iog, Integer gl, Disposition disposition) throws OihPersistenceException;

    public abstract RemoveLeadTime createInstance(Long runId, String asin, Integer iog, Integer gl, Disposition disposition, Double removalLeadTime);

    public abstract void delete(RemoveLeadTime o) throws OihPersistenceException;

    public abstract void deleteAll() throws OihPersistenceException;

}
