package com.amazon.oih.dao.targetInvLevel;

import java.util.List;

import com.amazon.oih.dao.exception.OihPersistenceException;
import com.amazon.oih.utils.AsinIogPair;

public interface TargetInventoryLevelMaxOverPeriodDao {
    public abstract void save(TargetInventoryLevelMaxOverPeriod o) throws OihPersistenceException;

    public abstract void save(List<TargetInventoryLevelMaxOverPeriod> tils) throws OihPersistenceException;

    public abstract boolean exists(Long runId, String asin, Integer iog) throws OihPersistenceException;

    public abstract TargetInventoryLevelMaxOverPeriod find(Long runId, String asin, Integer iog)
            throws OihPersistenceException;

    public abstract List<TargetInventoryLevelMaxOverPeriod> find(Long runId, List<AsinIogPair> asinIogPairs)
            throws OihPersistenceException;

    public abstract TargetInventoryLevelMaxOverPeriod createTargetInventoryLevelMaxOverPeriod(Long runid, String asin,
            Integer iog, Integer til, Integer carton_qty);

    public abstract void delete(TargetInventoryLevelMaxOverPeriod o) throws OihPersistenceException;

    public abstract void deleteAll() throws OihPersistenceException;

    public abstract Integer getTotalCountByRunId(Long runId) throws OihPersistenceException;

    public abstract Integer getInvalidTILCountByRunId(Long runId) throws OihPersistenceException;
}
