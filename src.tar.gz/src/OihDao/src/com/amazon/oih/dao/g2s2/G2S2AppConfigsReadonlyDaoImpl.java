package com.amazon.oih.dao.g2s2;

import java.io.IOException;
import java.lang.annotation.Annotation;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javassist.Modifier;

import org.apache.commons.lang.StringUtils;
import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.type.TypeReference;

import amazon.iop.metadata.cache.QueryCache;
import amazon.iop.metadata.cache.impl.ConcurrentQueryCache;
import amazon.iop.metadata.g2s2.client.G2S2Exception;
import amazon.iop.metadata.g2s2.client.G2S2RepositoryClient;
import amazon.iop.metadata.g2s2.client.Metadatum;
import amazon.iop.metadata.g2s2.client.cache.CachingClient;
import amazon.iop.metadata.g2s2.client.impl.ThinRESTClient;
import amazon.platform.config.AppConfig;

import com.amazon.ion.IonBlob;
import com.amazon.ion.IonBool;
import com.amazon.ion.IonClob;
import com.amazon.ion.IonDecimal;
import com.amazon.ion.IonFloat;
import com.amazon.ion.IonInt;
import com.amazon.ion.IonList;
import com.amazon.ion.IonString;
import com.amazon.ion.IonStruct;
import com.amazon.ion.IonSymbol;
import com.amazon.ion.IonSystem;
import com.amazon.ion.IonText;
import com.amazon.ion.IonTimestamp;
import com.amazon.ion.IonValue;
import com.amazon.ion.system.IonSystemBuilder;
import com.amazon.jacksonion.JoiObjectMapper;
import com.amazon.oih.dao.g2s2.exceptions.EmptyConfigKeyException;
import com.amazon.oih.dao.g2s2.exceptions.G2S2ConnectionException;
import com.amazon.oih.dao.g2s2.exceptions.IonMappingException;

/**
 * implement for interface G2S2AppConfigsReadonlyDao, including all g2s2 read method.
 */
public class G2S2AppConfigsReadonlyDaoImpl implements G2S2AppConfigsReadonlyDao {
    static final String g2s2ReadEndpointConfigKey = "g2s2.ReadEndpoint";
    static final String g2s2StageVersionLabelConfigKey = "g2s2.StageVersionLabel";
    protected static final Integer MAX_CACHE_QUESTIONS = 5000;
    protected static final Integer MAX_CACHE_ANSWERS = 5000;        
    
    protected static final IonSystem ios = IonSystemBuilder.standard().build();
    protected static final JoiObjectMapper ionMapper = new JoiObjectMapper();

    protected G2S2ClientConfigs g2s2Configurations;

    public G2S2AppConfigsReadonlyDaoImpl() {
        initG2S2Client();
    }

    private void initG2S2Client() {
        String domain = AppConfig.getDomain();
        String realm = AppConfig.getRealm().name();
        String g2s2ReadEndpoint = AppConfig.findString(g2s2ReadEndpointConfigKey);
        String stageVersionLabel = AppConfig.findString(g2s2StageVersionLabelConfigKey);
        g2s2Configurations = new G2S2ClientConfigs(domain, realm, g2s2ReadEndpoint, null, stageVersionLabel, true, true);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public <T> T getAppConfig(String key, Class<? extends T> clazz) {
        return getAppConfig(key, clazz, g2s2Configurations.getRealm());
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public <T> T getAppConfig(String key, Class<? extends T> clazz, String realm) {
        return getAppConfig(key, clazz, realm, g2s2Configurations.getDomain());
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public <T> T getAppConfig(String key, Class<? extends T> clazz, String realm, String domain) {
        return getAppConfig(key, clazz, realm, domain, false);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public <T> T getAppConfig(String key, Class<? extends T> clazz, String realm, String domain, boolean ignoreCache) {

        checkConfigyKey(key);

        try {
            Iterator<Metadatum> metadatumIterator = getConfigMetadatum(key, ignoreCache, realm, domain, null);
            if (metadatumIterator == null || !metadatumIterator.hasNext()) {
                return null;
            }
            return convertMetadatumToAppConfig(clazz, metadatumIterator.next());
        } catch (G2S2Exception e) {
            throw new G2S2ConnectionException("G2S2Exception is thrown by G2S2 when get app config from G2S2!", e);
        } catch (IllegalArgumentException e) {
            throw new G2S2ConnectionException(
                    "IllegalArgumentException is thrown by G2S2 when get app config from G2S2!", e);
        }
    }

    protected void checkConfigyKey(String configKey) {
        if (configKey == null || configKey.isEmpty()) {
            throw new EmptyConfigKeyException("Config key can not be empty or null!");
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public <T> T getAppConfig(Class<? extends T> clazz, String realm, String domain, boolean ignoreCache) {
        String key = getConfigKey(clazz);
        return getAppConfig(key, clazz, realm, domain, ignoreCache);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public <T> List<T> getAppConfigList(String key, Class<? extends T> clazz) {
        return getAppConfigList(key, clazz, g2s2Configurations.getRealm());
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public <T> List<T> getAppConfigList(String key, Class<? extends T> clazz, String realm) {
        return getAppConfigList(key, clazz, realm, g2s2Configurations.getDomain());
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public <T> List<T> getAppConfigList(String key, Class<? extends T> clazz, String realm, String domain) {
        return getAppConfigList(key, clazz, realm, domain, false);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public <T> List<T> getAppConfigList(String key, Class<? extends T> clazz, String realm, String domain,
            boolean ignoreCache) {

        checkConfigyKey(key);

        try {
            Iterator<Metadatum> metadatumIterator = getConfigMetadatum(key, ignoreCache, realm, domain, null);
            if (metadatumIterator == null || !metadatumIterator.hasNext()) {
                return null;
            }
            return convertMetadatumToAppConfigList(clazz, metadatumIterator.next());
        } catch (G2S2Exception e) {
            throw new G2S2ConnectionException("G2S2Exception is thrown by G2S2 when get app config from G2S2!", e);
        } catch (IllegalArgumentException e) {
            throw new G2S2ConnectionException(
                    "IllegalArgumentException is thrown by G2S2 when get app config from G2S2!", e);
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public <T> List<T> getAppConfigList(Class<? extends T> clazz, String realm, String domain, boolean ignoreCache) {
        String key = getConfigKey(clazz);
        return getAppConfigList(key, clazz, realm, domain, ignoreCache);
    }

    protected Iterator<Metadatum> getConfigMetadatum(String key, boolean ignoreCache, String realm, String domain,
            String stageVersion) {
        if (stageVersion == null || stageVersion.isEmpty()) {
            stageVersion = this.findLatestStageVersionFromG2S2(ignoreCache);
        }
        Map<String, String> query = assembleAppConfigQueryKey(key, realm, domain, stageVersion);
        Iterator<Metadatum> metadatumIterator;
        if (ignoreCache) {
            metadatumIterator = getRepositoryClient().get(G2S2Constants.APP_CONFIGS_TABLE, query);
        } else {
            metadatumIterator = getRepositoryClientWithCache().get(G2S2Constants.APP_CONFIGS_TABLE, query);
        }
        return metadatumIterator;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String findLatestStageVersionFromG2S2(boolean ignoreCache) {
        Map<String, String> keys = new HashMap<String, String>();
        keys.put(G2S2Constants.STAGE_VERSION_LABEL, g2s2Configurations.getG2s2StageVersionLabel());
        Iterator<Metadatum> itr;

        try {
            if (ignoreCache) {
                itr = getRepositoryClient().get(G2S2Constants.STAGE_VERSION_TABLE, keys);
            } else {
                itr = getRepositoryClientWithCache().get(G2S2Constants.STAGE_VERSION_TABLE, keys);
            }
        } catch (G2S2Exception e) {
            throw new G2S2ConnectionException("G2S2Exception is thrown by G2S2 when read stage version from G2S2!", e);
        } catch (IllegalArgumentException e) {
            throw new G2S2ConnectionException(
                    "IllegalArgumentException is thrown by G2S2 when read stage version from G2S2!", e);
        }

        if (itr == null || !itr.hasNext()) {
            throw new RuntimeException(String.format("Stage version label %s not found in G2S2.",
                    g2s2Configurations.getG2s2StageVersionLabel()));
        }

        Metadatum md = itr.next();
        IonValue svlIon = md.getPayload();
        if (!(svlIon instanceof IonStruct)) {
            throw new RuntimeException("Bad metadata for stage_version_label in G2S2!");
        }
        IonValue svIon = ((IonStruct) svlIon).get(G2S2Constants.STAGE_VERSION);
        if (!(svIon instanceof IonText)) {
            throw new RuntimeException("Bad metadata for stage_version in G2S2!");
        }

        return ((IonText) svIon).stringValue();
    }

    protected String getConfigKey(Class<?> clazz) {
        Annotation[] annotations = clazz.getAnnotations();
        for (Annotation annotation : annotations) {
            if (annotation.annotationType().equals(ConfigKey.class)) {
                return ((ConfigKey) annotation).value();
            }
        }
        return null;
    }

    protected Map<String, String> assembleAppConfigQueryKey(String key, String realm, String domain, String stageVersion) {
        Map<String, String> query = new HashMap<String, String>();
        query.put(G2S2Constants.APP_CONFIG_OVERRIDE_HIERARCHY, G2S2Constants.APP_CONFIG_OVERRIDE_HIERARCHY_VALUE);
        query.put(G2S2Constants.APP_CONFIG_NAME, G2S2Constants.APP_CONFIG_NAME_VALUE);
        if (StringUtils.isNotBlank(domain)) {
            query.put(G2S2Constants.APP_CONFIG_DOMAIN, domain);
        }
        if (StringUtils.isNotBlank(realm)) {
            query.put(G2S2Constants.APP_CONFIG_REALM, realm);
        }
        query.put(G2S2Constants.APP_CONFIG_KEY, key);
        query.put(G2S2Constants.STAGE_VERSION, stageVersion);
        return query;
    }

    @SuppressWarnings("unchecked")
    protected <T> T convertMetadatumToAppConfig(Class<? extends T> clazz, Metadatum metadatum) {
        clazz = checkClassType(clazz);
        try {
            IonValue value = ((IonStruct) metadatum.getPayload()).get(G2S2Constants.APP_CONFIG);
            if (value instanceof IonList) {
                if (!clazz.isArray() && 
                    !List.class.isAssignableFrom(clazz) && 
                    !Set.class.isAssignableFrom(clazz) &&
                    !Object.class.equals(clazz)) {
                    if (((IonList) value).size() > 0) {
                        value = ((IonList) value).get(0);
                    }
                }
            }
            if(clazz.equals(Object.class)){
                clazz = (Class<? extends T>) resolveClassByIonValue(value, clazz);
            }
            return ionMapper.readValue(ios.newReader(value), clazz);
        } catch (JsonParseException e) {
            throw new IonMappingException(
                    "JsonParseException is thrown by  JoiObjectMapper while mapping Ion to Object!", e);
        } catch (JsonMappingException e) {
            throw new IonMappingException(
                    "JsonMappingException is thrown by  JoiObjectMapper while mapping Ion to Object!", e);
        } catch (IOException e) {
            throw new IonMappingException("IOException is thrown by  JoiObjectMapper while mapping Ion to Object!", e);
        }
    }
    
    protected <T> T convertMetadatumToAppConfig(TypeReference<T> typeReference, Metadatum metadatum) {
        try {
            IonValue value = ((IonStruct) metadatum.getPayload()).get(G2S2Constants.APP_CONFIG);
            return ionMapper.readValue(ios.newReader(value), typeReference);
        } catch (JsonParseException e) {
            throw new IonMappingException(
                    "JsonParseException is thrown by  JoiObjectMapper while mapping Ion to Object!", e);
        } catch (JsonMappingException e) {
            throw new IonMappingException(
                    "JsonMappingException is thrown by  JoiObjectMapper while mapping Ion to Object!", e);
        } catch (IOException e) {
            throw new IonMappingException("IOException is thrown by  JoiObjectMapper while mapping Ion to Object!", e);
        }
    }

    @SuppressWarnings("unchecked")
    protected <T> List<T> convertMetadatumToAppConfigList(Class<? extends T> clazz, Metadatum metadatum) {
        clazz = checkClassType(clazz);
        try {
            List<T> configList = new ArrayList<T>();
            boolean shouldResolveClass = Object.class.equals(clazz);
            IonValue value = ((IonStruct) metadatum.getPayload()).get(G2S2Constants.APP_CONFIG);
            // newCacheMap.put(key,
            // ((IonStruct)value).get(G2S2Constants.APP_CONFIG));
            if (!(value instanceof IonList)) {
                if(shouldResolveClass){
                    clazz = (Class<? extends T>) resolveClassByIonValue(value, clazz);
                }
                configList.add(ionMapper.readValue(ios.newReader(value), clazz));
            } else {
                for (IonValue v : (IonList) value) {
                    if(shouldResolveClass){
                        clazz = (Class<? extends T>) resolveClassByIonValue(v, clazz);
                    }
                    configList.add(ionMapper.readValue(ios.newReader(v), clazz));
                }
            }
            return configList;
        } catch (JsonParseException e) {
            throw new IonMappingException(
                    "JsonParseException is thrown by  JoiObjectMapper while mapping Ion to Object!", e);
        } catch (JsonMappingException e) {
            throw new IonMappingException(
                    "JsonMappingException is thrown by  JoiObjectMapper while mapping Ion to Object!", e);
        } catch (IOException e) {
            throw new IonMappingException("IOException is thrown by  JoiObjectMapper while mapping Ion to Object!", e);
        }
    }
    
    @SuppressWarnings("unchecked")
    private <T> Class<? extends T> checkClassType(Class<T> clazz){
        if(clazz.equals(Map.class)){
            return (Class<? extends T>) HashMap.class;
        }
        if(clazz.equals(List.class)){
            return (Class<? extends T>) ArrayList.class;
        }
        if(clazz.equals(Set.class)){
            return (Class<? extends T>) HashSet.class;
        }
        if(clazz.isArray()){
            return clazz;
        }
        if(Modifier.isAbstract(clazz.getModifiers()) || Modifier.isInterface(clazz.getModifiers())){
           throw new IonMappingException("Parameter clazz can not be a abstract class or interface."); 
        }
        return clazz;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public <T> List<AppConfigInfo<T>> queryAppConfig(String key, Class<? extends T> clazz) {
        checkConfigyKey(key);

        try {
            List<AppConfigInfo<T>> appConfigs = new ArrayList<AppConfigInfo<T>>();

            Iterator<Metadatum> metadatumIterator = getConfigMetadatum(key, true, null, null, null);
            if (metadatumIterator == null || !metadatumIterator.hasNext()) {
                return appConfigs;
            }
            while (metadatumIterator.hasNext()) {
                Metadatum metadatum = metadatumIterator.next();
                IonStruct value = (IonStruct) metadatum.getPayload();
                appConfigs.add(new AppConfigInfo<T>(value.get(G2S2Constants.APP_CONFIG_REALM).toString(), 
                        value.get(G2S2Constants.APP_CONFIG_DOMAIN).toString(), 
                        value.get(G2S2Constants.APP_CONFIG_KEY).toString(),
                        convertMetadatumToAppConfig(clazz, metadatum)));
            }
            return appConfigs;
        } catch (G2S2Exception e) {
            throw new G2S2ConnectionException("G2S2Exception is thrown by G2S2 when get app config from G2S2!", e);
        } catch (IllegalArgumentException e) {
            throw new G2S2ConnectionException(
                    "IllegalArgumentException is thrown by G2S2 when get app config from G2S2!", e);
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public <T> List<AppConfigInfo<T>> queryAppConfig(String key, TypeReference<T> typeReference) {
        try {
            List<AppConfigInfo<T>> appConfigLists = new ArrayList<AppConfigInfo<T>>();

            Iterator<Metadatum> metadatumIterator = getConfigMetadatum(key, true, null, null, null);
            if (metadatumIterator == null || !metadatumIterator.hasNext()) {
                return appConfigLists;
            }
            while (metadatumIterator.hasNext()) {
                Metadatum md = metadatumIterator.next();
                IonStruct value = (IonStruct) md.getPayload();
                appConfigLists.add(new AppConfigInfo<T>(value.get(G2S2Constants.APP_CONFIG_REALM).toString(), 
                        value.get(G2S2Constants.APP_CONFIG_DOMAIN).toString(), 
                        value.get(G2S2Constants.APP_CONFIG_KEY).toString(), 
                        convertMetadatumToAppConfig(typeReference, md)));
            }
            return appConfigLists;
        } catch (G2S2Exception e) {
            throw new G2S2ConnectionException("G2S2Exception is thrown by G2S2 when get app config from G2S2!", e);
        } catch (IllegalArgumentException e) {
            throw new G2S2ConnectionException(
                    "IllegalArgumentException is thrown by G2S2 when get app config from G2S2!", e);
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void flushCache() throws G2S2Exception {
        getRepositoryClientWithCache().flushCache();
    }

    protected Class<?> resolveClassByIonValue(IonValue ionValue, Class<?> clazz){
        for(Entry<Class<? extends IonValue>, Class<?>> entry : ionTypeMap.entrySet()){
            if(entry.getKey().isAssignableFrom(ionValue.getClass())){
                return entry.getValue();
            }
        }
        return clazz;
    }
    
    protected static final Map<Class<? extends IonValue>, Class<?>> ionTypeMap;
    static{
    	Map<Class<? extends IonValue>, Class<?>> typeMap = new HashMap<Class<? extends IonValue>, Class<?>>();
    	typeMap.put(IonString.class, String.class);
    	typeMap.put(IonInt.class, Long.class);
    	typeMap.put(IonFloat.class,Double.class);
    	typeMap.put(IonBool.class,Boolean.class);
    	typeMap.put(IonList.class, ArrayList.class);
    	typeMap.put(IonStruct.class, HashMap.class);
        typeMap.put(IonTimestamp.class, Date.class);
        typeMap.put(IonDecimal.class, Double.class);
        typeMap.put(IonSymbol.class, String.class);
        typeMap.put(IonClob.class, byte[].class);
        typeMap.put(IonBlob.class, byte[].class);
        ionTypeMap = Collections.unmodifiableMap(typeMap);
    }
    
    
    protected G2S2RepositoryClient getRepositoryClient() {
        return G2S2RepositoryClientHolder.repositoryClient;
    }

    protected G2S2RepositoryClient getRepositoryClientWithCache() {
        return G2S2RepositoryClientHolder.repositoryClientWithCache;
    }
   
    
    /**
     * use static nested class to delay G2S2RepositoryClient init, another implement for lazy init.
     * @author xlpeng
     *
     */
    
    public static void initializeClientHolder() {
    	G2S2RepositoryClientHolder.initialize();
    }
    
    static class G2S2RepositoryClientHolder{
        static G2S2RepositoryClient repositoryClient;
        static G2S2RepositoryClient repositoryClientWithCache;
        static{
        	if(!usingMockedG2S2Repository){
        		initialize();
        	}
        }
        public static void initialize() {
             String g2s2ReadEndpoint = AppConfig.findString(g2s2ReadEndpointConfigKey);
             G2S2RepositoryClientHolder.repositoryClient = new ThinRESTClient(ios, g2s2ReadEndpoint);
             QueryCache<Object, Object> cache = new ConcurrentQueryCache<Object, Object>();
             cache.setMaxQuestions(MAX_CACHE_QUESTIONS);
             cache.setMaxAnswers(MAX_CACHE_ANSWERS);
             G2S2RepositoryClientHolder.repositoryClientWithCache = new CachingClient(G2S2RepositoryClientHolder.repositoryClient, cache);
        }
    }
    //true condition only for UT
    static boolean usingMockedG2S2Repository = false;
}
