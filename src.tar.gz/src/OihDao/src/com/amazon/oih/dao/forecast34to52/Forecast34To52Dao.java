package com.amazon.oih.dao.forecast34to52;

import java.util.Collection;
import java.util.List;

import com.amazon.carbonado.PersistException;
import com.amazon.carbonado.RepositoryException;
import com.amazon.carbonado.SupportException;
import com.amazon.oih.dao.forecast.ForecastType;

public interface Forecast34To52Dao {

    void save(Forecast34To52 o) throws PersistException;

    void save(Collection<Forecast34To52> o) throws PersistException;

    boolean exists(String asin, Integer marketplaceId) throws RepositoryException;
    
    boolean exists(String asin, Integer marketplaceId, ForecastType type) throws RepositoryException;

    /**
     * Return all forecasts for the given asin. Includes all forecast type.
     * @param asin
     * @param iog
     * @return
     * @throws RepositoryException
     */
    List<Forecast34To52> find(String asin, Integer marketplaceId) throws RepositoryException;

    /**
     * Return forecasts for the given asin and type.
     * @param asin
     * @param iog
     * @param type
     * @return
     * @throws RepositoryException
     */
    Forecast34To52 find(String asin, Integer marketplaceId, ForecastType type) throws RepositoryException;
    /**
     * create Forecast34To52 object
     * @param asin
     * @param iog
     * @param type
     * @param forecasts
     * @return
     * @throws SupportException
     * @throws RepositoryException
     */
    Forecast34To52 createForecast34To52(String asin, Integer marketplaceId, ForecastType type, List<Double> forecasts) throws SupportException, RepositoryException;
}
