package com.amazon.oih.dao.ourprice;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.criterion.Restrictions;

import amazon.platform.config.AppConfig;

import com.amazon.oih.dao.DaoConstants;
import com.amazon.oih.dao.OihDao;
import com.amazon.oih.dao.exception.DaoRuntimeException;
import com.amazon.oih.dao.exception.OihPersistenceException;
import com.amazon.oih.utils.AsinIogPair;
import com.amazon.oih.utils.Utils;

/**
 * Our Price Dao
 * 
 * @author zhongwei
 * 
 */
public class OurPriceDao extends OihDao<OurPriceObject> {
    final static Logger log = Logger.getLogger(OurPriceDao.class);

    public OurPriceDao(String source) {
        super(source);
    }

    @Override
    public String getType() {
        return OurPriceObject.class.getName();
    }

    /**
     * Find the Our Price Object by the asin, iog, source
     * 
     * @param asin
     * @param iog
     * @param source
     * @return
     * @throws OihPersistenceException
     */
    public OurPriceObject findCurrent(String asin, int iog, String source) throws OihPersistenceException {
        log.debug("Query OurPrice by " + asin + "|" + iog + "|" + source);
        try {
            openSession();
            Criteria cri = session.createCriteria(OurPriceObject.class);
            cri.add(Restrictions.eq("asin", asin));
            cri.add(Restrictions.eq("iog", iog));
            cri.add(Restrictions.eq("realm", AppConfig.getRealm().name()));
            cri.add(Restrictions.eq("source", source));
            cri.add(Restrictions.eq("isCurrent", DaoConstants.IS_CURRENT_Y));
            OurPriceObject result = (OurPriceObject) cri.uniqueResult();
            return result;
        } catch (HibernateException e) {
            e.printStackTrace();
            log.error("Fail to query OurPrice " + e);
            throw new OihPersistenceException(e);
        }
    }

    @Override
    /**
     * find the OurPriceObject by the given obj
     */
    public OurPriceObject findCurrent(OurPriceObject obj) throws OihPersistenceException, DaoRuntimeException {
        if (obj == null) {
            log.info("findCurrent request is null");
            return null;
        }
        log.debug("Query OurPrice by " + obj.getKey());

        return findCurrent(obj.getAsin(), obj.getIog(), obj.getSource());
    }

    /**
     * Find the Our Price Object by the asin, iog, source
     * 
     * @param asin
     * @param iog
     * @param source
     * @return
     * @throws OihPersistenceException
     */
    public OurPriceObject find(String asin, int iog, String source, Date runDate) throws OihPersistenceException {
        log.debug("Query OurPrice by " + asin + "|" + iog + "|" + source);
        try {
            openSession();
            Criteria cri = session.createCriteria(OurPriceObject.class);
            cri.add(Restrictions.eq("asin", asin));
            cri.add(Restrictions.eq("iog", iog));
            cri.add(Restrictions.eq("realm", AppConfig.getRealm().name()));
            cri.add(Restrictions.eq("source", source));
            cri.add(Restrictions.le("firstLoadDate", runDate));
            cri.add(Restrictions.gt("expiredDate", runDate));
            OurPriceObject result = (OurPriceObject) cri.uniqueResult();
            return result;
        } catch (HibernateException e) {
            e.printStackTrace();
            log.error("Fail to query OurPrice " + e);
            throw new OihPersistenceException(e);
        }
    }

    /**
     * Find the Our Price Object by the asin, iog, source
     * 
     * @param asin
     * @param iog
     * @param source
     * @return
     * @throws OihPersistenceException
     */
    @SuppressWarnings("unchecked")
    public List<OurPriceObject> find(String[] asins, String[] realms, String source, Date runDate) throws OihPersistenceException {
        try {
            openSession();
            Criteria cri = session.createCriteria(OurPriceObject.class);
            cri.add(Restrictions.in("asin", asins));
            cri.add(Restrictions.in("realm", realms));
            cri.add(Restrictions.eq("source", source));
            cri.add(Restrictions.le("firstLoadDate", runDate));
            cri.add(Restrictions.gt("expiredDate", runDate));
            List<OurPriceObject> results = (List<OurPriceObject>) cri.list();
            return results;
        } catch (HibernateException e) {
            e.printStackTrace();
            log.error("Fail to query OurPrice " + e);
            throw new OihPersistenceException(e);
        }
    }
    
    /**
     * find the OurPriceObject by the given obj
     */
    public OurPriceObject find(OurPriceObject obj, Date runDate) throws OihPersistenceException, DaoRuntimeException {
        if (obj == null) {
            log.info("findCurrent request is null");
            return null;
        }
        log.debug("Query OurPrice by " + obj.toString());

        return find(obj.getAsin(), obj.getIog(), obj.getSource(), runDate);
    }

    /**
     * Find the Our Price Object by the asin, iog, source
     * 
     * @param asin
     * @param iog
     * @param source
     * @return
     * @throws OihPersistenceException
     */
    public List<OurPriceObject> find(List<AsinIogPair> asinIogPairs, String source, Date runDate)
            throws OihPersistenceException {
        List<OurPriceObject> results = new ArrayList<OurPriceObject>();

        Map<Integer, List<String>> iog2AsinsMap = Utils.splitAsinIogList2AsinsMap(asinIogPairs);
        Iterator<Integer> iterator = iog2AsinsMap.keySet().iterator();

        try {
            while (iterator.hasNext()) {
                Integer iog = iterator.next();
                List<OurPriceObject> opObjects = find(iog2AsinsMap.get(iog), iog, source, runDate);
                for (OurPriceObject object : opObjects) {
                    results.add(object);
                }
            }
            return results;
        } catch (HibernateException e) {
            e.printStackTrace();
            log.error("Fail to query OurPrice " + e);
            throw new OihPersistenceException(e);
        }
    }

    /**
     * 
     * @param asins
     * @param iog
     * @param source
     * @param runDate
     * @return
     * @throws OihPersistenceException
     */
    @SuppressWarnings("unchecked")
    public List<OurPriceObject> find(List<String> asins, int iog, String source, Date runDate)
            throws OihPersistenceException {
        log.debug("Batch Query OurPrice for " + asins.size() + "asins |" + iog + "|" + source);
        try {
            openSession();
            Criteria cri = session.createCriteria(OurPriceObject.class);
            cri.add(Restrictions.in("asin", asins));
            cri.add(Restrictions.eq("iog", iog));
            cri.add(Restrictions.eq("realm", AppConfig.getRealm().name()));
            cri.add(Restrictions.eq("source", source));
            cri.add(Restrictions.le("firstLoadDate", runDate));
            cri.add(Restrictions.gt("expiredDate", runDate));
            List<OurPriceObject> results = (List<OurPriceObject>) cri.list();
            return results;
        } catch (HibernateException e) {
            e.printStackTrace();
            log.error("Fail to query OurPrice " + e);
            throw new OihPersistenceException(e);
        }
    }

}