package com.amazon.oih.dao.hbase.quantitybasedmarkdowninfo;

import static com.amazon.oih.dao.DaoConstants.QUANTITY_BASED_MARKDOWN_INFO_UNIT_SPLIT;
import static com.amazon.oih.dao.hbase.quantitybasedmarkdowninfo.QuantityBasedMarkdownInfoHBaseDao.columnDataLevelBytes;
import static com.amazon.oih.dao.hbase.quantitybasedmarkdowninfo.QuantityBasedMarkdownInfoHBaseDao.columnDataVersionBytes;
import static com.amazon.oih.dao.hbase.quantitybasedmarkdowninfo.QuantityBasedMarkdownInfoHBaseDao.columnFamilyBytes;
import static com.amazon.oih.dao.hbase.quantitybasedmarkdowninfo.QuantityBasedMarkdownInfoHBaseDao.columnMarkdownForecastDetailBytes;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang.StringUtils;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.util.Bytes;
import org.apache.log4j.Logger;

import com.amazon.oih.dao.DaoConstants;
import com.amazon.oih.dao.hbase.base.Converter;
import com.amazon.oih.dao.markdowninfo.MarkdownInfo;
import com.amazon.oih.dao.quantitymarkdowninfo.QuantityBasedMarkdownInfo;
import com.amazon.oih.utils.HBaseRowkeyUtil;
import com.google.common.base.Function;
import com.google.common.base.Joiner;
import com.google.common.base.Splitter;
import com.google.common.collect.Iterables;

/**
 * @author gaoxing
 *
 */
public class QuantityBasedMarkdownInfoConverter implements Converter<QuantityBasedMarkdownInfo> {
    private static final Logger logger = Logger.getLogger(QuantityBasedMarkdownInfoConverter.class); 

    @Override
    public QuantityBasedMarkdownInfo convert(String rowKey, Result rs) throws IOException {
        if (rs != null && !rs.isEmpty()) {
            if (rowKey == null) {
                rowKey = Bytes.toString(rs.getRow());
            }
            QuantityBasedMarkdownInfo markdownInfoObject = HBaseRowkeyUtil.parseQuantityBasedMarkdownInfoRowKey(rowKey);

            Map<Integer, MarkdownInfo> quantityBasedMarkdownInfoMap = new HashMap<Integer, MarkdownInfo>();
            String value = new String(rs.getValue(columnFamilyBytes, columnMarkdownForecastDetailBytes));
            if (!StringUtils.isEmpty(value)) {
                parseQuantityBasedMarkdownInfo(quantityBasedMarkdownInfoMap, value);
            } else {
                logger.error("Unexpected KeyValue " + rs.getValue(columnFamilyBytes, columnMarkdownForecastDetailBytes));
            }
            markdownInfoObject.setMarkdownInfos(quantityBasedMarkdownInfoMap);
            
            String rawDataLevel = Bytes.toString(rs.getValue(columnFamilyBytes, columnDataLevelBytes));
            ArrayList<String> dataLevelList = parseDataLevel(rawDataLevel);
            
            markdownInfoObject.setDataLevels(dataLevelList);
            markdownInfoObject.setDataVersion(Bytes.toString(rs.getValue(columnFamilyBytes, columnDataVersionBytes)));

            return markdownInfoObject;
        }
        return null;
    }

    public QuantityBasedMarkdownInfo convert(QtyBasedMarkdownHBaseObj hObj){        
        QuantityBasedMarkdownInfo markdownInfoObject = new QuantityBasedMarkdownInfo();
        markdownInfoObject.setAsin(hObj.getAsin());
        markdownInfoObject.setMarketplaceId(hObj.getMarketplaceId());
        Map<Integer, MarkdownInfo> quantityBasedMarkdownInfoMap = new HashMap<Integer, MarkdownInfo>();
        if (!StringUtils.isEmpty(hObj.getRawMarkdownInfo())) {
             parseQuantityBasedMarkdownInfo(quantityBasedMarkdownInfoMap, hObj.getRawMarkdownInfo());
        }
        markdownInfoObject.setMarkdownInfos(quantityBasedMarkdownInfoMap);
        
        ArrayList<String> dataLevelList = parseDataLevel(hObj.getRawDataLevels());        
        markdownInfoObject.setDataLevels(dataLevelList);
        
        markdownInfoObject.setDataVersion(hObj.getDataVersion());
        
        return markdownInfoObject;
    }
    
    private ArrayList<String> parseDataLevel(String rawDataLevel) {
        Iterable<String> dataLevels = Splitter.on(DaoConstants.QUANTITY_BASED_MARKDOWN_INFO_DATA_LEVEL_SPLIT).split(rawDataLevel);
        ArrayList<String> dataLevelList = new ArrayList<String>();
        for (String dataLevel : dataLevels) {
            dataLevelList.add(dataLevel);
        }
        return dataLevelList;
    }

    private void parseQuantityBasedMarkdownInfo(Map<Integer, MarkdownInfo> quantityBasedMarkdownInfoMap, String value) {
        Iterable<String> quantityBasedMarkdownForecasts = Splitter.on(QUANTITY_BASED_MARKDOWN_INFO_UNIT_SPLIT).split(value);
        for (String quantityBasedMarkdownForecast : quantityBasedMarkdownForecasts) {
            Iterable<String> eachMarkdownForecastDetails = Splitter.on(DaoConstants.QUANTITY_BASED_MARKDOWN_INFO_QUANTITY_SPLIT).split(quantityBasedMarkdownForecast);
            String markdownInventoryQty = Iterables.get(eachMarkdownForecastDetails, 0);
            Integer inventoryQuantity = new Integer(markdownInventoryQty);
            String markdownForecastFactors = Iterables.get(eachMarkdownForecastDetails, 1);
            Iterable<String> eachMarkdownForecastFactors = Splitter.on(DaoConstants.QUANTITY_BASED_MARKDOWN_INFO_FORECAST_SPLIT).split(markdownForecastFactors);

            MarkdownInfo markdownInfo = new MarkdownInfo();
            markdownInfo.setRecoveryRate(Double.parseDouble(Iterables.get(eachMarkdownForecastFactors, 0)));
            markdownInfo.setDemandIncrease(Double.parseDouble(Iterables.get(eachMarkdownForecastFactors, 1)));
            markdownInfo.setDemandIncreaseRate(Double.parseDouble(Iterables.get(eachMarkdownForecastFactors, 2)));
            quantityBasedMarkdownInfoMap.put(inventoryQuantity, markdownInfo);
        }
    }

    @Override
    public QuantityBasedMarkdownInfo convert(Result rs) throws IOException {
        return convert(null, rs);
    }

    @Override
    public List<Put> convert(QuantityBasedMarkdownInfo markdownInfo) throws IOException {
        byte[] rowKey = Bytes.toBytes(getRowKey(markdownInfo));

        Put put = new Put(rowKey);
        Map<Integer, MarkdownInfo> markdownInfos = markdownInfo.getMarkdownInfos();

        Iterable<String> userDefinedIterator = Iterables.transform(markdownInfos.entrySet(),
                new Function<Map.Entry<Integer, MarkdownInfo>, String>() {
                    @Override
                    public String apply(Entry<Integer, MarkdownInfo> markdownInfoEntry) {
                        MarkdownInfo markDownForecast = markdownInfoEntry.getValue();
                        String markdownForecastInfo = Joiner.on(
                                DaoConstants.QUANTITY_BASED_MARKDOWN_INFO_FORECAST_SPLIT).join(
                                markDownForecast.getRecoveryRate(), markDownForecast.getDemandIncrease(),
                                markDownForecast.getDemandIncreaseRate());
                        return Joiner.on(DaoConstants.QUANTITY_BASED_MARKDOWN_INFO_QUANTITY_SPLIT).join(
                                markdownInfoEntry.getKey(), markdownForecastInfo);
                    }
                });
        String markdownForecastDetails = Joiner.on(DaoConstants.QUANTITY_BASED_MARKDOWN_INFO_UNIT_SPLIT).join(
                userDefinedIterator);

        put.add(columnFamilyBytes, columnMarkdownForecastDetailBytes, Bytes.toBytes(markdownForecastDetails));

        ArrayList<String> dataLevel = markdownInfo.getDataLevels();
        String dataLevelStr = Joiner.on(DaoConstants.QUANTITY_BASED_MARKDOWN_INFO_DATA_LEVEL_SPLIT).join(dataLevel);
        put.add(columnFamilyBytes, columnDataLevelBytes, Bytes.toBytes(dataLevelStr));
        put.add(columnFamilyBytes, columnDataVersionBytes, Bytes.toBytes(markdownInfo.getDataVersion()));

        return Collections.nCopies(1, put);
    }
    
    @Override
    public String getRowKey(QuantityBasedMarkdownInfo quantityBasedMarkdownInfo) {
        return HBaseRowkeyUtil.getRowKeyBasedAsinMarketplace(quantityBasedMarkdownInfo.getAsin(), quantityBasedMarkdownInfo.getMarketplaceId());
    }

}
