package com.amazon.oih.dao.experiments;

import java.util.List;

import org.joda.time.DateTime;

import com.amazon.oih.dao.exception.OihPersistenceException;

public interface ExperimentDao {
    public List<Experiment> find() throws OihPersistenceException;

    public List<Experiment> find(boolean active) throws OihPersistenceException;

    public List<Experiment> find(DateTime dt, boolean active) throws OihPersistenceException;

    public List<Experiment> find(String name) throws OihPersistenceException;

    public List<Experiment> find(String name, boolean active) throws OihPersistenceException;

    public List<Experiment> find(String name, DateTime dt, boolean active) throws OihPersistenceException;

    public Experiment createExperiment(String name, DateTime startDate, DateTime endDate, boolean active, int iog,
            int gl, boolean usePopulationFile) throws OihPersistenceException;

    public void save(Experiment e) throws OihPersistenceException;
}
