package com.amazon.oih.dao.holdingcost;

import java.util.List;

public interface HoldingCostDao {

    public List<HoldingCost> getHoldingCosts(String realm) throws Exception;

    public List<HoldingCost> getHoldingCosts(String realm, String warehouse) throws Exception;

    public void save(HoldingCost holdingCost) throws Exception;

}
