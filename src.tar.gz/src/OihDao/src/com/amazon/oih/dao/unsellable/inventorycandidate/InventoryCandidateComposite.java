package com.amazon.oih.dao.unsellable.inventorycandidate;

import com.amazon.carbonado.Alias;
import com.amazon.carbonado.PrimaryKey;
import com.amazon.carbonado.Storable;
import com.amazon.carbonado.constraint.IntegerConstraint;
import com.amazon.carbonado.constraint.LengthConstraint;

@Alias("inventory_candidate_composite")
@PrimaryKey({
        "asin", "fcsku", "fnsku", "iog", "warehouse", "condition"
})
public abstract class InventoryCandidateComposite implements Storable<InventoryCandidateComposite> {
    public abstract String getAsin();

    @LengthConstraint(min = 10, max = 10)
    public abstract void setAsin(String asin);

    public abstract String getFcsku();

    @LengthConstraint(min = 10, max = 10)
    public abstract void setFcsku(String fcsku);

    public abstract String getFnsku();

    @LengthConstraint(min = 10, max = 10)
    public abstract void setFnsku(String fnsku);

    public abstract int getIog();

    public abstract String getWarehouse();

    @LengthConstraint(min = 0, max = 4)
    public abstract void setWarehouse(String warehouse);

    public abstract String getCondition();

    public abstract void setCondition(String condition);

    @IntegerConstraint(min = 1, max = Integer.MAX_VALUE)
    public abstract void setIog(int iog);

    public abstract int getOnhandQuantity();

    @IntegerConstraint(min = 0, max = Integer.MAX_VALUE)
    public abstract void setOnhandQuantity(int onhandQuantity);

    public abstract int getBoundQuantity();

    @IntegerConstraint(min = 0, max = Integer.MAX_VALUE)
    public abstract void setBoundQuantity(int boundQuantity);

    public abstract int getPlanningSideQuantity();

    @IntegerConstraint(min = 0, max = Integer.MAX_VALUE)
    public abstract void setPlanningSideQuantity(int psQuantity);

    public abstract int getFcSideQuantity();

    @IntegerConstraint(min = 0, max = Integer.MAX_VALUE)
    public abstract void setFcSideQuantity(int fsQuantity);
}
