package com.amazon.oih.dao.hbase.civ;

import java.io.Serializable;

import com.amazon.oih.common.RowKeyBuildType;
import com.amazon.oih.common.RowKeyType;
import com.amazon.oih.common.KVFormater.FileColumnNames;
import com.amazon.oih.common.KeyValueBase.NamedValue;
import com.amazon.oih.dao.hbase.base.CommonKVHBaseDao.HTable;
import com.amazon.oih.dao.hbase.converter.Column;
import com.amazon.oih.dao.hbase.converter.RowKey;

@RowKey({"asin", "marketplaceId"})
@RowKeyBuildType(RowKeyType.ASIN_MARKETPLACE)
@HTable("CIVInfo")
@FileColumnNames({"ASIN", "MarketPlace Id", "civ_per_gv", "civ_per_sale", "gv", "offered_weeks", "ft_gv_13w"})
public class CIVInfo implements Serializable {
    private static final long serialVersionUID = -3955211462790963051L;

    @NamedValue("ASIN")
    private String asin;
    
    @NamedValue("MarketPlace Id")
    private long marketplaceId;

    //civ per glance view
    @NamedValue("civ_per_gv")
    @Column(name="civ",index=0)
    private double civPerGV = 0;
    
    //civ per sale
    @Column(name="civ",index=1)
    @NamedValue("civ_per_sale")
    private double civPerSale = 0;
    
    @NamedValue("gv")
    @Column(name="civ",index=2)    
    //average weekly glance view count in a year
    private double weeklyGv = 0; 

    @NamedValue("offered_weeks")
    @Column(name="civ",index=3)    
    //number of weeks with retail offer for last 13 weeks
    private int offeredWeeks;
    
    @NamedValue("ft_gv_13w")
    @Column(name="civ",index=4)
    //fast track gv within last 13 weeks
    private double fastTrackGv;

    public String getAsin() {
        return asin;
    }

    public void setAsin(String asin) {
        this.asin = asin;
    }

    public long getMarketplaceId() {
        return marketplaceId;
    }

    public void setMarketplaceId(long marketplaceId) {
        this.marketplaceId = marketplaceId;
    }

    public double getCivPerGV() {
        return civPerGV;
    }

    public void setCivPerGV(double civPerGV) {
        this.civPerGV = civPerGV;
    }

    public double getCivPerSale() {
        return civPerSale;
    }

    public void setCivPerSale(double civPerSale) {
        this.civPerSale = civPerSale;
    }

    public double getWeeklyGv() {
        return weeklyGv;
    }

    public void setWeeklyGv(double weeklyGv) {
        this.weeklyGv = weeklyGv;
    }

    public int getOfferedWeeks() {
        return offeredWeeks;
    }

    public void setOfferedWeeks(int offeredWeeks) {
        this.offeredWeeks = offeredWeeks;
    }

    public double getFastTrackGv() {
        return fastTrackGv;
    }

    public void setFastTrackGv(double fastTrackGv) {
        this.fastTrackGv = fastTrackGv;
    }

}
