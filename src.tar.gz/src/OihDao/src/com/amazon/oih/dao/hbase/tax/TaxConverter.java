package com.amazon.oih.dao.hbase.tax;

import java.io.IOException;
import java.util.List;

import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.util.Bytes;

import amazon.platform.config.AppConfig;

import com.amazon.oih.dao.DaoConstants;
import com.amazon.oih.dao.hbase.base.Converter;
import com.amazon.oih.dao.hbase.converter.HBaseConverterFactory;
import com.amazon.oih.dao.hbase.converter.IHBaseObjectConverter;

@Deprecated
public class TaxConverter implements Converter<Tax> {
    private IHBaseObjectConverter<Tax> convertor = HBaseConverterFactory.getDefaultConverter();
    private final static String TAX_COLUMNFAMILY = AppConfig.findString(DaoConstants.TAX_COLUMNFAMILY);

    @Override
    public Tax convert(String rowKey, Result rs) throws IOException {
        return convertor.convert(Tax.class, rowKey, rs);
    }

    @Override
    public Tax convert(Result rs) throws IOException {
        return convertor.convert(Tax.class, Bytes.toString(rs.getRow()), rs);
    }

    @Override
    public List<Put> convert(Tax object) throws IOException {
        return convertor.convert(TAX_COLUMNFAMILY, object);
    }

    @Override
    public String getRowKey(Tax object) {
        return convertor.getRowKey(object);
    }

}
