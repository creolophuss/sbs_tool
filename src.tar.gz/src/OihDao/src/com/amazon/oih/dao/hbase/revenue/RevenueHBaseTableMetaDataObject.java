package com.amazon.oih.dao.hbase.revenue;

public class RevenueHBaseTableMetaDataObject {
    private String tableName;
    private RevenueTableStatus status;

    public RevenueHBaseTableMetaDataObject(String tableName, RevenueTableStatus status) {
        this.tableName = tableName;
        this.status = status;
    }

    public RevenueHBaseTableMetaDataObject(String tableName, String status) {
        this(tableName, RevenueTableStatus.valueOf(status));
    }

    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public RevenueTableStatus getStatus() {
        return status;
    }

    public void setStatus(RevenueTableStatus status) {
        this.status = status;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((status == null) ? 0 : status.hashCode());
        result = prime * result + ((tableName == null) ? 0 : tableName.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        RevenueHBaseTableMetaDataObject other = (RevenueHBaseTableMetaDataObject) obj;
        if (status != other.status)
            return false;
        if (tableName == null) {
            if (other.tableName != null)
                return false;
        } else if (!tableName.equals(other.tableName))
            return false;
        return true;
    }

    @Override
    public String toString() {
        return "RevenueHBaseTableMetaDataObject [tableName=" + tableName + ", status=" + status + "]";
    }

}
