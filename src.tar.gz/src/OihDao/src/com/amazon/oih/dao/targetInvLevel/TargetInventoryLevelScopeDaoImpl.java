package com.amazon.oih.dao.targetInvLevel;

import java.util.Collection;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;

import com.amazon.oih.dao.MySQLSessionFactoryUtil;
import com.amazon.oih.dao.exception.OihPersistenceException;

public class TargetInventoryLevelScopeDaoImpl implements TargetInventoryLevelScopeDao {
    private final static Logger logger = Logger.getLogger(TargetInventoryLevelDaoImpl.class);
    protected Session session = null;

    public TargetInventoryLevelScopeDaoImpl(String domain) {
    }

    @Override
    public TargetInventoryLevelScope create(Long runid, String asin, String scopeId, Integer til, Integer cartonQty, 
            Integer idealTIL, Integer minROL) {
        return new TargetInventoryLevelScope(runid, asin, scopeId, til, cartonQty, idealTIL, minROL);
    }

    @Override
    public boolean exists(Long runId, String asin, String scopeId) throws OihPersistenceException {
        logger.debug("Query TargetInventoryLevelScope by " + asin + "|" + scopeId + "|" + runId);
        try {
            openSession();
            Criteria cri = session.createCriteria(TargetInventoryLevelScope.class);
            cri.add(Restrictions.eq("asin", asin));
            cri.add(Restrictions.eq("scopeId", scopeId));
            cri.add(Restrictions.eq("runID", runId));
            return cri.uniqueResult() != null;
        } catch (HibernateException e) {
            e.printStackTrace();
            logger.error("Fail to query TargetInventoryLevelScope ", e);
            throw new OihPersistenceException(e);
        }
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<TargetInventoryLevelScope> find(Long runId, Collection<String> asins, String scopeId)
            throws OihPersistenceException {
        logger.debug("Query TargetInventoryLevelScope size=" + asins.size() + "| scope id=" + scopeId + "|" + runId);
        try {
            openSession();
            Criteria cri = session.createCriteria(TargetInventoryLevelScope.class);
            cri.add(Restrictions.in("asin", asins));
            cri.add(Restrictions.eq("scopeId", scopeId));
            cri.add(Restrictions.eq("runID", runId));
            return (List<TargetInventoryLevelScope>) cri.list();
        } catch (HibernateException e) {
            e.printStackTrace();
            logger.error("Fail to batch query TargetInventoryLevelScope. asins=" + asins + ", scope=" + scopeId + ".",
                    e);
            throw new OihPersistenceException(e);
        }
    }

    @Override
    public TargetInventoryLevelScope find(Long runId, String asin, String scopeId) throws OihPersistenceException {
        logger.debug("Query TargetInventoryLevelScope by " + asin + "|" + scopeId + "|" + runId);
        try {
            openSession();
            Criteria cri = session.createCriteria(TargetInventoryLevelScope.class);
            cri.add(Restrictions.eq("asin", asin));
            cri.add(Restrictions.eq("scopeId", scopeId));
            cri.add(Restrictions.eq("runID", runId));
            return (TargetInventoryLevelScope) cri.uniqueResult();
        } catch (HibernateException e) {
            e.printStackTrace();
            logger.error("Fail to query TargetInventoryLevelScope ", e);
            throw new OihPersistenceException(e);
        }
    }

    @Override
    public void save(List<TargetInventoryLevelScope> tils) throws OihPersistenceException {
        Transaction tx = null;
        try {
            openSession();
            tx = session.beginTransaction();
            for (TargetInventoryLevelScope o : tils) {
                session.save(o);
            }
            tx.commit();
        } catch (RuntimeException e) {
            logger.error("Failed to save entity " + logger + " with exception ", e);
            e.printStackTrace();
            if (tx != null) {
                tx.rollback();
            }
            throw new OihPersistenceException(e);
        } finally {
            closeSession();
        }
    }
    
    @Override
    public void saveOrUpdate(List<TargetInventoryLevelScope> tils) throws OihPersistenceException {
        Transaction tx = null;
        try {
            openSession();
            tx = session.beginTransaction();
            for (TargetInventoryLevelScope o : tils) {
                session.saveOrUpdate(o);
            }
            tx.commit();
        } catch (RuntimeException e) {
            logger.error("Failed to save entity " + logger + " with exception ", e);
            e.printStackTrace();
            if (tx != null) {
                tx.rollback();
            }
            throw new OihPersistenceException(e);
        } finally {
            closeSession();
        }
    }

    @Override
    public void save(TargetInventoryLevelScope o) throws OihPersistenceException {
        Transaction tx = null;
        try {
            openSession();
            tx = session.beginTransaction();
            session.save(o);
            tx.commit();
        } catch (RuntimeException e) {
            logger.error("Failed to save entity " + o + " with exception ", e);
            e.printStackTrace();
            if (tx != null) {
                tx.rollback();
            }
            throw new OihPersistenceException(e);
        } finally {
            closeSession();
        }
    }

    /**
     * Delete all the elements from the database
     * 
     * @throws OihPersistenceException
     */
    @SuppressWarnings("unchecked")
    @Override
    public void deleteAll() throws OihPersistenceException {
        logger.debug("Trying to delete all the elements from the db");
        Transaction tx = null;
        try {
            openSession();
            tx = session.beginTransaction();
            Criteria cri = session.createCriteria(TargetInventoryLevelScope.class);
            List<TargetInventoryLevelScope> TargetInventoryLevelScopes = cri.list();
            for (TargetInventoryLevelScope object : TargetInventoryLevelScopes) {
                session.delete(object);
            }
            tx.commit();
        } catch (HibernateException e) {
            e.printStackTrace();
            logger.error("Fail to query TargetInventoryLevelScope ", e);
            throw new OihPersistenceException(e);
        }
    }

    /**
     * Delete the object from the database
     * 
     * @param o
     * @throws OihPersistenceException
     */
    @Override
    public void delete(TargetInventoryLevelScope o) throws OihPersistenceException {
        Transaction tx = null;
        try {
            openSession();
            tx = session.beginTransaction();
            session.delete(o);
            tx.commit();
        } catch (RuntimeException e) {
            logger.error("Failed to save entity " + o + " with exception ", e);
            e.printStackTrace();
            if (tx != null) {
                tx.rollback();
            }
            throw new OihPersistenceException(e);
        } finally {
            closeSession();
        }
    }

    private void openSession() {
        session = MySQLSessionFactoryUtil.getSessionFactory().openSession();
    }

    private void closeSession() {
        if (session != null) {
            session.close();
        }
    }
}
