package com.amazon.oih.dao.targetInvLevel;

import java.util.Collection;
import java.util.List;

import com.amazon.oih.dao.exception.OihPersistenceException;

public interface TargetInventoryLevelScopeDao {
    public abstract void save(TargetInventoryLevelScope o) throws OihPersistenceException;

    public abstract void save(List<TargetInventoryLevelScope> tils) throws OihPersistenceException;

    public abstract void saveOrUpdate(List<TargetInventoryLevelScope> tils) throws OihPersistenceException;

    public abstract boolean exists(Long runId, String asin, String scopeId) throws OihPersistenceException;

    public abstract TargetInventoryLevelScope find(Long runId, String asin, String scopeId)
            throws OihPersistenceException;

    public abstract TargetInventoryLevelScope create(Long runid, String asin, String scopeId, Integer til,
            Integer carton_qty, Integer idealTIL, Integer minROL);

    public abstract void delete(TargetInventoryLevelScope o) throws OihPersistenceException;

    public abstract void deleteAll() throws OihPersistenceException;

    List<TargetInventoryLevelScope> find(Long runId, Collection<String> asins, String scopeId)
            throws OihPersistenceException;
}
