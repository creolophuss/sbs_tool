package com.amazon.oih.dao.hbase.vrds;

import java.io.IOException;
import java.util.List;

import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.client.Result;

import com.amazon.oih.dao.hbase.base.Converter;
import com.amazon.oih.dao.hbase.converter.HBaseConverterFactory;
import com.amazon.oih.dao.hbase.converter.IHBaseObjectConverter;

@Deprecated
public class VRDSHBaseDorcInfoConverter implements Converter<VRDSHBaseDorcInfo> {
    private IHBaseObjectConverter<VRDSHBaseDorcInfo> vrdsHBaseDorcInfoConverter = HBaseConverterFactory.getDefaultConverter();
    
    @Override
    public VRDSHBaseDorcInfo convert(String rowKey, Result rs) throws IOException {
        try {
            return vrdsHBaseDorcInfoConverter.convert(VRDSHBaseDorcInfo.class, rowKey, rs);
        } catch (Exception e) {
            e.printStackTrace();
            throw new IOException(e);
        }
    }

    @Override
    public VRDSHBaseDorcInfo convert(Result rs) throws IOException {
        return convert(new String(rs.getRow()), rs);
    }

    @Override
    public List<Put> convert(VRDSHBaseDorcInfo object) throws IOException {
        return vrdsHBaseDorcInfoConverter.convert(VRDSHBaseDorcInfoDao.DORC_INFO_COLUMNFAMILY, object);
    }

    @Override
    public String getRowKey(VRDSHBaseDorcInfo object) {
        return vrdsHBaseDorcInfoConverter.getRowKey(object);
    }

}
