package com.amazon.oih.dao.ilbo;

import com.amazon.oih.dao.OihObject;

public class IlboObject extends OihObject {

    private String warehouseId;
    private int sellableOnHandQty;
    private int sellableAllocatedQty;
    private int sellableUnallocated;
    private int unsellableOnHandQty;

    public IlboObject(){}
    
    public IlboObject(String asin, int iog, String source, String warehouseId, int sellableOnHandQty,
            int sellableAllocatedQty, int sellableUnallocated, int unsellableOnHandQty) {
        super(asin, iog, source);
        this.warehouseId = warehouseId;
        this.sellableOnHandQty = sellableOnHandQty;
        this.sellableAllocatedQty = sellableAllocatedQty;
        this.sellableUnallocated = sellableUnallocated;
        this.unsellableOnHandQty = unsellableOnHandQty;
    }
    
    public String getWarehouseId() {
        return warehouseId;
    }

    public void setWarehouseId(String warehouseId) {
        this.warehouseId = warehouseId;
    }

    public int getSellableOnHandQty() {
        return sellableOnHandQty;
    }

    public void setSellableOnHandQty(int sellableOnHandQty) {
        this.sellableOnHandQty = sellableOnHandQty;
    }

    public int getSellableAllocatedQty() {
        return sellableAllocatedQty;
    }

    public void setSellableAllocatedQty(int sellableAllocatedQty) {
        this.sellableAllocatedQty = sellableAllocatedQty;
    }

    public int getSellableUnallocated() {
        return sellableUnallocated;
    }

    public void setSellableUnallocated(int sellableUnallocated) {
        this.sellableUnallocated = sellableUnallocated;
    }

    public int getUnsellableOnHandQty() {
        return unsellableOnHandQty;
    }

    public void setUnsellableOnHandQty(int unsellableOnHandQty) {
        this.unsellableOnHandQty = unsellableOnHandQty;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof IlboObject == false)  {
            return false;
        }
        if (this == obj) {
            return true;
        }
        super.equals(obj);
       
        IlboObject other = (IlboObject)obj;
        return this.warehouseId.equals(other.getWarehouseId())
              && this.getSellableOnHandQty() == other.getSellableOnHandQty()
              && this.getSellableAllocatedQty() == other.getSellableAllocatedQty()
              && this.getSellableUnallocated() == other.getSellableUnallocated()
              && this.unsellableOnHandQty == other.getUnsellableOnHandQty();
    }
    
    @Override
    public void cleanValues() {
        this.sellableOnHandQty = 0;
        this.sellableAllocatedQty = 0;
        this.sellableUnallocated = 0;
        this.unsellableOnHandQty = 0;
    }

    @Override
    public void copyValues(Object obj) {
        
        if (obj == null || obj instanceof IlboObject == false)  {
            throw new RuntimeException("Wrong instance type.");
        }
        IlboObject other = (IlboObject)obj;
        this.sellableOnHandQty = other.getSellableOnHandQty();
        this.sellableAllocatedQty = other.getSellableAllocatedQty();
        this.sellableUnallocated = other.getSellableUnallocated();
        this.unsellableOnHandQty = other.getUnsellableOnHandQty();
    }

    @Override
    public String getKey() {
        return this.getAsin()+"|"+ this.getIog() + "|" + warehouseId;
    }
    
    @Override
    public String getValues() {
        return sellableOnHandQty+"|"+ sellableAllocatedQty + "|" + sellableUnallocated + "|" + unsellableOnHandQty;
    }

	@Override
	public int hashCode() {
		return getKey().hashCode();
	}
}
