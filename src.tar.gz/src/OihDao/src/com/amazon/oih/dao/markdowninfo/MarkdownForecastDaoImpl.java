package com.amazon.oih.dao.markdowninfo;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import com.amazon.oih.dao.MySQLSessionFactoryUtil;
import com.amazon.oih.dao.exception.OihPersistenceException;
import com.amazon.oih.utils.AsinIogPair;
import com.amazon.oih.utils.Utils;

public class MarkdownForecastDaoImpl implements MarkdownForecastDao {
    private final static Logger logger = Logger.getLogger(MarkdownForecastDaoImpl.class);
    protected Session session = null;

    public MarkdownForecastDaoImpl(String domain) {
    }

    @Override
    public MarkdownForecast createInstance(Long runid, String asin, Integer marketplaceId, Double demandIncrease,
            Double demandIncreaseRate, Double recoveryRate, String dataVersion, String dataLevel) {
        return new MarkdownForecast(runid, asin, marketplaceId, demandIncrease, demandIncreaseRate, recoveryRate, dataVersion, dataLevel);
    }

    @Override
    public boolean exists(Long runId, String asin, Integer marketplaceId) throws OihPersistenceException {
        logger.debug("Query MarkdownForecast by " + asin + "|" + marketplaceId + "|" + runId);
        try {
            openSession();
            Criteria cri = session.createCriteria(MarkdownForecast.class);
            cri.add(Restrictions.eq("asin", asin));
            cri.add(Restrictions.eq("marketplaceId", marketplaceId));
            cri.add(Restrictions.eq("runID", runId));
            return cri.uniqueResult() != null;
        } catch (HibernateException e) {
            e.printStackTrace();
            logger.error("Fail to query TargetInventoryLevel " + e);
            throw new OihPersistenceException(e);
        }
    }

    @Override
    public MarkdownForecast find(Long runId, String asin, Integer marketplaceId) throws OihPersistenceException {
        logger.debug("Query MarkdownForecast by " + asin + "|" + marketplaceId + "|" + runId);
        try {
            openSession();
            Criteria cri = session.createCriteria(MarkdownForecast.class);
            cri.add(Restrictions.eq("asin", asin));
            cri.add(Restrictions.eq("marketplaceId", marketplaceId));
            cri.add(Restrictions.eq("runID", runId));
            return (MarkdownForecast) cri.uniqueResult();
        } catch (HibernateException e) {
            e.printStackTrace();
            logger.error("Fail to query TargetInventoryLevel " + e);
            throw new OihPersistenceException(e);
        }
    }

    /*@SuppressWarnings("unchecked")
    private List<MarkdownForecast> find(Long runId, List<String> asins, int marketplaceId) throws OihPersistenceException {
        logger.info("Batch Query MarkdownForecast for a batchList, the first asin is " + asins.get(0) + "|" + marketplaceId);
        try {
            openSession();
            Criteria cri = session.createCriteria(MarkdownForecast.class);
            cri.add(Restrictions.in("asin", asins));
            cri.add(Restrictions.eq("iog", marketplaceId));
            cri.add(Restrictions.eq("runID", runId));
            return (List<MarkdownForecast>) cri.list();
        } catch (HibernateException e) {
            e.printStackTrace();
            logger.error("Fail to query TargetInventoryLevel " + e);
            throw new OihPersistenceException(e);
        }
    }

    @Override
    public List<MarkdownForecast> find(Long runId, List<AsinIogPair> asinIogPairs) throws OihPersistenceException {
        List<MarkdownForecast> results = new ArrayList<MarkdownForecast>();

        Map<Integer, List<String>> iog2AsinsMap = Utils.splitAsinIogList2AsinsMap(asinIogPairs);
        Iterator<Integer> iterator = iog2AsinsMap.keySet().iterator();

        try {
            while (iterator.hasNext()) {
                Integer iog = iterator.next();
                
                List<MarkdownForecast> opObjects = find(runId, iog2AsinsMap.get(iog), iog);
                for (MarkdownForecast object : opObjects) {
                    results.add(object);
                }
            }
            return results;
        } catch (HibernateException e) {
            logger.error("Fail to query TargetInventoryLevel " + e);
            throw new OihPersistenceException(e);
        }
    }*/

    @Override
    public void save(List<MarkdownForecast> tils) throws OihPersistenceException {
        Transaction tx = null;
        try {
            openSession();
            tx = session.beginTransaction();
            for (MarkdownForecast o : tils) {
                session.save(o);
            }
            tx.commit();
        } catch (RuntimeException e) {
            logger.error("Failed to save entity " + logger + " with exception ", e);
            e.printStackTrace();
            if (tx != null) {
                tx.rollback();
            }
            throw new OihPersistenceException(e);
        } finally {
            closeSession();
        }
    }

    @Override
    public void save(MarkdownForecast o) throws OihPersistenceException {
        Transaction tx = null;
        try {
            openSession();
            tx = session.beginTransaction();
            session.save(o);
            tx.commit();
        } catch (RuntimeException e) {
            logger.error("Failed to save entity " + o + " with exception ", e);
            e.printStackTrace();
            if (tx != null) {
                tx.rollback();
            }
            throw new OihPersistenceException(e);
        } finally {
            closeSession();
        }
    }

    /**
     * Delete all the elements from the database
     * 
     * @throws OihPersistenceException
     */
    @SuppressWarnings("unchecked")
    @Override
    public void deleteAll() throws OihPersistenceException {
        logger.debug("Trying to delete all the elements from the db");
        Transaction tx = null;
        try {
            openSession();
            tx = session.beginTransaction();
            Criteria cri = session.createCriteria(MarkdownForecast.class);
            List<MarkdownForecast> targetInventoryLevels = cri.list();
            for (MarkdownForecast object : targetInventoryLevels) {
                session.delete(object);
            }
            tx.commit();
        } catch (HibernateException e) {
            e.printStackTrace();
            logger.error("Fail to query TargetInventoryLevel " + e);
            throw new OihPersistenceException(e);
        }
    }

    /**
     * Delete the object from the database
     * 
     * @param o
     * @throws OihPersistenceException
     */
    @Override
    public void delete(MarkdownForecast o) throws OihPersistenceException {
        Transaction tx = null;
        try {
            openSession();
            tx = session.beginTransaction();
            session.delete(o);
            tx.commit();
        } catch (RuntimeException e) {
            logger.error("Failed to save entity " + o + " with exception ", e);
            e.printStackTrace();
            if (tx != null) {
                tx.rollback();
            }
            throw new OihPersistenceException(e);
        } finally {
            closeSession();
        }
    }

    private void openSession() {
        session = MySQLSessionFactoryUtil.getSessionFactory().openSession();
    }

    private void closeSession() {
        if (session != null) {
            session.close();
        }
    }
}