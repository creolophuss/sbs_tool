package com.amazon.oih.dao.vrdsDisposition;

import java.util.List;

import amazon.platform.profiler.Profiler;
import amazon.platform.profiler.ProfilerScope;

import com.amazon.carbonado.ConfigurationException;
import com.amazon.carbonado.IsolationLevel;
import com.amazon.carbonado.PersistException;
import com.amazon.carbonado.Query;
import com.amazon.carbonado.Repository;
import com.amazon.carbonado.RepositoryException;
import com.amazon.carbonado.Storage;
import com.amazon.carbonado.Transaction;
import com.amazon.oih.dao.exception.DaoRuntimeException;
import com.amazon.oih.dao.exception.OihPersistenceException;

public class VRDSReturnTermsDaoImpl implements VRDSReturnTermsDao {

    protected String _domain = null;
    protected Repository repository = null;

    public VRDSReturnTermsDaoImpl(String domain) {
        _domain = domain;
    }

    public void setRepository(Repository repository) {
        if (null == repository) {
            throw new IllegalArgumentException("repository is null");
        }
        this.repository = repository;
    }

    @Override
    public boolean exists(Long runId, String asin, Integer iog, String vendor) throws OihPersistenceException {
        ProfilerScope scope = Profiler.scopeStart(this.getClass().getName() + "::existsWithVendor");

        try {
            Storage<VRDSReturnTerms> sf = repository.storageFor(VRDSReturnTerms.class);
            vendor = vendor.trim();
            boolean retVal = sf.query("runID = ? & iog = ? & asin = ? & vendor = ?").with(runId).with(iog).with(asin)
                    .with(vendor).exists();

            return retVal;
        } catch (ConfigurationException e) {
            throw new DaoRuntimeException(e);
        } catch (RepositoryException e) {
            throw new OihPersistenceException(e);
        } finally {
            Profiler.scopeEnd(scope);
        }

    }

    @Override
    public List<VRDSReturnTerms> find(Long runId, String asin, Integer iog, String vendor)
            throws OihPersistenceException {
        ProfilerScope scope = Profiler.scopeStart(this.getClass().getName() + "::find");

        try {
            Storage<VRDSReturnTerms> sf = repository.storageFor(VRDSReturnTerms.class);
            vendor=vendor.trim();
            return sf.query("runID = ? & iog = ? & asin = ? & vendor = ?").with(runId).with(iog).with(asin)
                    .with(vendor).fetch().toList();

        } catch (ConfigurationException e) {
            throw new DaoRuntimeException(e);
        } catch (RepositoryException e) {
            throw new OihPersistenceException(e);
        } finally {
            Profiler.scopeEnd(scope);
        }
    }

    @Override
    public void save(VRDSReturnTerms info) throws OihPersistenceException {
        ProfilerScope scope = Profiler.scopeStart(this.getClass().getName() + "::save");
        try {
            info.insert();
        } catch (PersistException e) {
            throw new OihPersistenceException(e);
        } finally {
            Profiler.scopeEnd(scope);
        }

    }

    @Override
    public VRDSReturnTerms createVRDSReturnTerms(Long runid, ReturnTermInfo retInfo) throws OihPersistenceException {
        ProfilerScope scope = Profiler.scopeStart(this.getClass().getName() + "::create");
        try {
            Storage<VRDSReturnTerms> sRetTerms = repository.storageFor(VRDSReturnTerms.class);
            VRDSReturnTerms myRetTerms = sRetTerms.prepare();

            myRetTerms.setRunID(runid);

            setValues(myRetTerms, retInfo);

            return myRetTerms;

        } catch (ConfigurationException e) {
            throw new DaoRuntimeException(e);
        } catch (RepositoryException e) {
            throw new OihPersistenceException(e);
        } finally {
            Profiler.scopeEnd(scope);
        }

    }

    private void setValues(VRDSReturnTerms myRetTerms, ReturnTermInfo retInfo) {
        myRetTerms.setAsin(retInfo.asin);
        myRetTerms.setIog(retInfo.iog);
        myRetTerms.setMarketplaceId(retInfo.marketplaceId);
        myRetTerms.setVendor(retInfo.vendor.trim());
        myRetTerms.setRefundPercentage(retInfo.refundPercentage);
        myRetTerms.setRefundBasisCode(retInfo.refundBasisCode);
        myRetTerms.setIsReturnAllowed(retInfo.isReturnAllowed);
        myRetTerms.setIsAsinReturnAllowed(retInfo.isAsinReturnAllowed);
        myRetTerms.setIsAuthorizationRequired(retInfo.isAuthRequired);
        myRetTerms.setReturnByMinDays(Integer.valueOf(retInfo.returnByMinDays));
        myRetTerms.setReturnByMaxDays(Integer.valueOf(retInfo.returnByMaxDays));
        myRetTerms.setPerUnitRestockingValue(retInfo.perUnitRestockingValue);
        myRetTerms.setPerUnitRestockingBasis(retInfo.perUnitRestockingBasis);
        if (retInfo.getReturnCap() != null){
            myRetTerms.setReturnCapBasis(retInfo.getReturnCap().getBasis());
            myRetTerms.setReturnCapAmount(Double.valueOf(retInfo.getReturnCap().getAmount()));
            myRetTerms.setReturnCapTimePeriod(retInfo.getReturnCap().getReturnCapTimePeriod());
        }
        myRetTerms.setOpenAuthorizationNumber(retInfo.getOpenAuthorizationNumber());
    }

    @Override
    public boolean exists(Long runId, String asin, Integer iog) throws OihPersistenceException {
        ProfilerScope scope = Profiler.scopeStart(this.getClass().getName() + "::existsNoVendor");
        try {
            Storage<VRDSReturnTerms> sf = repository.storageFor(VRDSReturnTerms.class);
            return sf.query("runID = ? & iog = ?  & asin = ?").with(runId).with(iog).with(asin).exists();
        } catch (ConfigurationException e) {
            throw new DaoRuntimeException(e);
        } catch (RepositoryException e) {
            throw new OihPersistenceException(e);
        } finally {
            Profiler.scopeEnd(scope);
        }
    }

    private void exitTransaction(Transaction txn) throws OihPersistenceException {
        try {
            txn.exit();
        } catch (PersistException e) {
            throw new OihPersistenceException(e);
        }
    }

    @Override
    public void save(List<VRDSReturnTerms> returnTerms) throws OihPersistenceException {
        Transaction txn = repository.enterTransaction(IsolationLevel.READ_UNCOMMITTED);
        try {
            for (VRDSReturnTerms rt : returnTerms) {
                if(!rt.tryLoad()) {
                    rt.insert();
                }
            }

            txn.commit();
        } catch (PersistException e) {
            throw new OihPersistenceException(e);
        } catch (Exception e) {
            throw new DaoRuntimeException(e);
        } finally {
            exitTransaction(txn);
        }
    }
    
    @Override
    public void delete(Long runId, String asin, Integer iog) throws OihPersistenceException {
        ProfilerScope scope = Profiler.scopeStart(this.getClass().getName() + "::delete");
        try {
            Storage<VRDSReturnTerms> sf = repository.storageFor(VRDSReturnTerms.class);
            Query<VRDSReturnTerms> q=sf.query("runID = ? & iog = ? & asin = ?").with(runId).with(iog).with(asin);
            q.deleteAll();
        } catch (ConfigurationException e) {
            throw new DaoRuntimeException(e);
        } catch (RepositoryException e) {
            throw new OihPersistenceException(e);
        } finally {
            Profiler.scopeEnd(scope);
        }
    }
}
