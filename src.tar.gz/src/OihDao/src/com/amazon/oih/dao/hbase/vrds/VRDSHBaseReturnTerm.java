package com.amazon.oih.dao.hbase.vrds;

import java.io.Serializable;

import com.amazon.oih.common.RowKeyBuildType;
import com.amazon.oih.common.RowKeyType;
import com.amazon.oih.dao.hbase.base.CommonKVHBaseDao.HTable;
import com.amazon.oih.dao.hbase.converter.Column;
import com.amazon.oih.dao.hbase.converter.RowKey;
import com.amazon.oih.dao.hbase.converter.SubKey;

@RowKey({"asin", "iog"})
@RowKeyBuildType(RowKeyType.ASIN_IOG)
@SubKey({"vendor"})
@HTable(value = "ReturnTerm", columFamilyName = "ReturnTerm")
public class VRDSHBaseReturnTerm implements Serializable {
    private static final long serialVersionUID = 446822442174871196L;
    private String asin;
    private String iog;
    private String vendor;

    @Column(name="Term",index=0)
    private String marketplace = "";
    
    @Column(name="Term",index=1)
    private double refundPercentage = 0;
    
    @Column(name="Term",index=2)
    private String refundBasisCode = "";
    
    @Column(name="Term",index=3)
    private boolean returnAllowed = false;
    
    @Column(name="Term",index=4)
    private boolean asinReturnAllowed = false;

    @Column(name="Term",index=5)
    private boolean authorizationRequired = false;
    
    @Column(name="Term",index=6)
    private int returnByMinDays = 0;
    
    @Column(name="Term",index=7)
    private int returnByMaxDays = 0;
    
    @Column(name="Term",index=8)
    private double perUnitRestockingValue = 0;
    
    @Column(name="Term",index=9)
    private String perUnitRestockingBasis = "";
    
    @Column(name="Term",index=10)
    private String returnCapBasis = "";
    
    @Column(name="Term",index=11)
    private double returnCapAmount = 0;
    
    @Column(name="Term",index=12)
    private String returnCapTimePeriod = "";
    
    @Column(name="Term",index=13)
    private String openAuthorizationNumber = "";

    public VRDSHBaseReturnTerm(){}
    
	public void setAsin(String asin) {
		this.asin = asin;
	}

	public String getAsin() {
		return asin;
	}

	public void setMarketplace(String marketplace) {
		this.marketplace = marketplace;
	}

	public String getMarketplace() {
		return marketplace;
	}

	public void setIog(String iog) {
		this.iog = iog;
	}

	public String getIog() {
		return iog;
	}

	public String getVendor() {
		return vendor;
	}

	public void setVendor(String vendor) {
		this.vendor = vendor;
	}

	public double getRefundPercentage() {
		return refundPercentage;
	}

	public void setRefundPercentage(double refundPercentage) {
		this.refundPercentage = refundPercentage;
	}

	public String getRefundBasisCode() {
		return refundBasisCode;
	}

	public void setRefundBasisCode(String refundBasisCode) {
		this.refundBasisCode = refundBasisCode;
	}

	public boolean isReturnAllowed() {
		return returnAllowed;
	}

	public void setReturnAllowed(boolean returnAllowed) {
		this.returnAllowed = returnAllowed;
	}

	public boolean isAsinReturnAllowed() {
		return asinReturnAllowed;
	}

	public void setAsinReturnAllowed(boolean asinReturnAllowed) {
		this.asinReturnAllowed = asinReturnAllowed;
	}

	public boolean isAuthorizationRequired() {
		return authorizationRequired;
	}

	public void setAuthorizationRequired(boolean authorizationRequired) {
		this.authorizationRequired = authorizationRequired;
	}

	public int getReturnByMinDays() {
		return returnByMinDays;
	}

	public void setReturnByMinDays(int returnByMinDays) {
		this.returnByMinDays = returnByMinDays;
	}

	public int getReturnByMaxDays() {
		return returnByMaxDays;
	}

	public void setReturnByMaxDays(int returnByMaxDays) {
		this.returnByMaxDays = returnByMaxDays;
	}

	public double getPerUnitRestockingValue() {
		return perUnitRestockingValue;
	}

	public void setPerUnitRestockingValue(double perUnitRestockingValue) {
		this.perUnitRestockingValue = perUnitRestockingValue;
	}

	public String getPerUnitRestockingBasis() {
		return perUnitRestockingBasis;
	}

	public void setPerUnitRestockingBasis(String perUnitRestockingBasis) {
		this.perUnitRestockingBasis = perUnitRestockingBasis;
	}

	public String getReturnCapBasis() {
		return returnCapBasis;
	}

	public void setReturnCapBasis(String returnCapBasis) {
		this.returnCapBasis = returnCapBasis;
	}

	public double getReturnCapAmount() {
		return returnCapAmount;
	}

	public void setReturnCapAmount(double returnCapAmount) {
		this.returnCapAmount = returnCapAmount;
	}

	public String getReturnCapTimePeriod() {
		return returnCapTimePeriod;
	}

	public void setReturnCapTimePeriod(String returnCapTimePeriod) {
		this.returnCapTimePeriod = returnCapTimePeriod;
	}

	public String getOpenAuthorizationNumber() {
		return openAuthorizationNumber;
	}

	public void setOpenAuthorizationNumber(String openAuthorizationNumber) {
		this.openAuthorizationNumber = openAuthorizationNumber;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((asin == null) ? 0 : asin.hashCode());
		result = prime * result + ((iog == null) ? 0 : iog.hashCode());
		result = prime * result + ((vendor == null) ? 0 : vendor.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		VRDSHBaseReturnTerm other = (VRDSHBaseReturnTerm) obj;
		if (asin == null) {
			if (other.asin != null)
				return false;
		} else if (!asin.equals(other.asin))
			return false;
		if (iog == null) {
			if (other.iog != null)
				return false;
		} else if (!iog.equals(other.iog))
			return false;
		if (vendor == null) {
			if (other.vendor != null)
				return false;
		} else if (!vendor.equals(other.vendor))
			return false;
		return true;
	}

    @Override
    public String toString() {
        return "VRDSHBaseReturnTerm [asin=" + asin + ", iog=" + iog + ", marketplace=" + marketplace + ", vendor="
                + vendor + ", refundPercentage=" + refundPercentage + ", refundBasisCode=" + refundBasisCode
                + ", returnAllowed=" + returnAllowed + ", asinReturnAllowed=" + asinReturnAllowed
                + ", authorizationRequired=" + authorizationRequired + ", returnByMinDays=" + returnByMinDays
                + ", returnByMaxDays=" + returnByMaxDays + ", perUnitRestockingValue=" + perUnitRestockingValue
                + ", perUnitRestockingBasis=" + perUnitRestockingBasis + ", returnCapBasis=" + returnCapBasis
                + ", returnCapAmount=" + returnCapAmount + ", returnCapTimePeriod=" + returnCapTimePeriod
                + ", openAuthorizationNumber=" + openAuthorizationNumber + "]";
    }

	
}
