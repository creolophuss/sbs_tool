package com.amazon.oih.dao.hbase.vrds;


import java.io.Serializable;

import org.apache.commons.lang.StringUtils;

import com.amazon.oih.common.RowKeyBuildType;
import com.amazon.oih.common.RowKeyType;
import com.amazon.oih.dao.hbase.base.CommonKVHBaseDao.HTable;
import com.amazon.oih.dao.hbase.converter.Column;
import com.amazon.oih.dao.hbase.converter.RowKey;
import com.amazon.oih.dao.hbase.converter.SubKey;

@RowKey({"asin", "iog"})
@RowKeyBuildType(RowKeyType.ASIN_IOG)
@SubKey({"dsiId","fcsku","warehouse"})
@HTable(value = "VRDSFcskuInfo", columFamilyName = "fcsku")
public class VRDSFcskuInfo implements Serializable {
    private static final long serialVersionUID = -9013824224508754442L;
    private String asin;
    private Long iog;
    
    private String dsiId;    
    private String warehouse;
    private String fcsku;
            
    @Column(name="sku",index=0)  
    private String vendor;
    
    @Column(name="sku",index=1)    
    private Integer quantity;
    
    @Column(name="sku",index=2)  
    private String lpn; //optional

    public String getAsin() {
        return asin;
    }

    public void setAsin(String asin) {
        this.asin = asin;
    }

    public Long getIog() {
        return iog;
    }

    public void setIog(Long iog) {
        this.iog = iog;
    }

    public String getDsiId() {
        return dsiId;
    }

    public void setDsiId(String dsiId) {
        this.dsiId = dsiId;
    }

    public String getWarehouse() {
        return warehouse;
    }

    public void setWarehouse(String warehouse) {
        this.warehouse = warehouse;
    }

    public String getFcsku() {
        return fcsku;
    }

    public void setFcsku(String fcsku) {
        this.fcsku = fcsku;
    }

    public String getVendor() {
        return vendor;
    }

    public void setVendor(String vendor) {
        this.vendor = vendor;
    }
    
    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }
    
    public String getLpn() {
        return lpn;
    }

    public void setLpn(String lpn) {
        this.lpn = lpn;
    }
    
    public boolean isTracked(){
        return StringUtils.isNotBlank(this.getWarehouse()) 
                && StringUtils.isNotBlank(this.getDsiId()) 
                && StringUtils.isNotBlank(this.getFcsku()) 
                && !this.getFcsku().equals(this.getAsin())
                && this.getQuantity() > 0;
    }

}
