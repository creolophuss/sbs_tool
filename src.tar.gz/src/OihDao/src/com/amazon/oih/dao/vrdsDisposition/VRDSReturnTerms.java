package com.amazon.oih.dao.vrdsDisposition;

import com.amazon.carbonado.Alias;
import com.amazon.carbonado.AlternateKeys;
import com.amazon.carbonado.Key;
import com.amazon.carbonado.Nullable;
import com.amazon.carbonado.PrimaryKey;
import com.amazon.carbonado.Sequence;
import com.amazon.carbonado.Storable;
import com.amazon.carbonado.constraint.IntegerConstraint;
import com.amazon.carbonado.constraint.LengthConstraint;

@Alias("data_return_terms")
@PrimaryKey("id")
@AlternateKeys({
    @Key({
            "runID", "asin", "iog", "vendor"
    })
})
public abstract class VRDSReturnTerms implements Storable<VRDSReturnTerms> {

    @Sequence("id")
    public abstract long getId();

    public abstract void setId(long id);

    @Alias("run_id")
    public abstract long getRunID();

    public abstract void setRunID(long runid);

    public abstract String getAsin();

    @LengthConstraint(min = 10, max = 10)
    public abstract void setAsin(String asin);

    public abstract int getIog();

    @IntegerConstraint(min = 1, max = Integer.MAX_VALUE)
    public abstract void setIog(int iog);

    public abstract int getMarketplaceId();

    @IntegerConstraint(min = 1, max = Integer.MAX_VALUE)
    public abstract void setMarketplaceId(int marketplaceId);

    public abstract String getVendor();

    @LengthConstraint(min = 0, max = 5)
    public abstract void setVendor(String vendor);

    public abstract double getRefundPercentage();

    public abstract void setRefundPercentage(double refundPercentage);

    public abstract String getRefundBasisCode();

    public abstract void setRefundBasisCode(String refundBasisCode);

    public abstract boolean getIsReturnAllowed();

    public abstract void setIsReturnAllowed(boolean returnAllowed);

    public abstract boolean getIsAsinReturnAllowed();

    public abstract void setIsAsinReturnAllowed(boolean isAsinReturnAllowed);
    
    public abstract boolean getIsAuthorizationRequired();

    public abstract void setIsAuthorizationRequired(boolean authRequired);

    @Nullable
    public abstract Integer getReturnByMinDays();

    @IntegerConstraint(min = 0, max = Integer.MAX_VALUE)
    public abstract void setReturnByMinDays(Integer returnByMinDays);

    @Nullable
    public abstract Integer getReturnByMaxDays();

    @IntegerConstraint(min = 0, max = Integer.MAX_VALUE)
    public abstract void setReturnByMaxDays(Integer returnByMaxDays);

    @Nullable
    public abstract Double getPerUnitRestockingValue();

    public abstract void setPerUnitRestockingValue(Double restockValue);

    // missing from interface
    @Nullable
    public abstract String getPerUnitRestockingBasis();

    public abstract void setPerUnitRestockingBasis(String restockBasis);
    
    @Nullable
    public abstract String getReturnCapBasis();

    public abstract void setReturnCapBasis(String returnCapBasis);

    @Nullable
    public abstract Double getReturnCapAmount();

    public abstract void setReturnCapAmount(Double returnCapAmount);
    
    @Nullable
    public abstract String getReturnCapTimePeriod();

    public abstract void setReturnCapTimePeriod(String returnCapTimePeriod);
    
    @Nullable
    public abstract String getOpenAuthorizationNumber();
    
    public abstract void setOpenAuthorizationNumber(String openAuthorizationNumber);
}
