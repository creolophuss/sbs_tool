package com.amazon.oih.dao.run;

import java.util.List;

import org.apache.log4j.Logger;
import org.joda.time.DateTime;

import com.amazon.carbonado.ConfigurationException;
import com.amazon.carbonado.PersistException;
import com.amazon.carbonado.Repository;
import com.amazon.carbonado.RepositoryException;
import com.amazon.carbonado.Storage;
import com.amazon.carbonado.filter.Filter;
import com.amazon.carbonado.filter.RelOp;
import com.amazon.oih.dao.exception.DaoRuntimeException;
import com.amazon.oih.dao.exception.OihPersistenceException;

public class RunDaoBase implements RunDao {
    final static Logger _log = Logger.getLogger(RunDaoBase.class);

    protected String _domain = null;

    protected Repository repository = null;
    
    public RunDaoBase(String domain) {
        _domain = domain;
    }

    public void setRepository(Repository repository) {
        if (null == repository) {
            throw new IllegalArgumentException("repository cannot be null.");
        }
        
        this.repository = repository;
    }
    
    @Override
    synchronized public Run createRun(DateTime rundate, String domain, String realm, String tag) throws DaoRuntimeException,
            OihPersistenceException {
        DateTime date = rundate.withTime(0, 0, 0, 0);
        try {
            Storage<Run> sf = repository.storageFor(Run.class);
            Run f = sf.prepare();

            f.setRunDate(date);
            f.setDomain(domain);
            f.setRealm(realm);
            f.setTag(tag);

            return f;
        } catch (ConfigurationException e) {
            throw new DaoRuntimeException(e);
        } catch (RepositoryException e) {
            throw new OihPersistenceException(e);
        }
    }

    @Override
    synchronized public Run find(Long runId) throws DaoRuntimeException, OihPersistenceException {
        try {
            Storage<Run> sf = repository.storageFor(Run.class);
            Filter<Run> filter = Filter.getClosedFilter(Run.class);
            filter = filter.or("runID", RelOp.EQ, runId);
            Run data = sf.query(filter).loadOne();

            return data;
        } catch (ConfigurationException e) {
            throw new DaoRuntimeException(e);
        } catch (RepositoryException e) {
            throw new OihPersistenceException(e);
        }
    }

    @Override
    synchronized public List<Run> find(DateTime rundate) throws DaoRuntimeException, OihPersistenceException {
        DateTime date = rundate.withTime(0, 0, 0, 0);

        try {
            Storage<Run> sf = repository.storageFor(Run.class);

            List<Run> data = sf.query("runDate = ?").with(date).fetch().toList();

            return data;
        } catch (ConfigurationException e) {
            throw new DaoRuntimeException(e);
        } catch (RepositoryException e) {
            throw new OihPersistenceException(e);
        }
    }

    @Override
    synchronized public List<Run> find(DateTime rundate, String domain, String realm) throws DaoRuntimeException,
            OihPersistenceException {
        try {
            DateTime date = rundate.withTime(0, 0, 0, 0);
            Storage<Run> sf = repository.storageFor(Run.class);
            List<Run> data = sf.query("runDate = ? & domain = ? & realm = ?").with(date).with(domain).with(realm)
                    .fetch().toList();

            return data;
        } catch (ConfigurationException e) {
            throw new DaoRuntimeException(e);
        } catch (RepositoryException e) {
            throw new OihPersistenceException(e);
        }
    }

    @Override
    synchronized public Run find(DateTime rundate, String domain, String realm, String tag) throws DaoRuntimeException,
            OihPersistenceException {
        try {
            DateTime date = rundate.withTime(0, 0, 0, 0);
            Storage<Run> sf = repository.storageFor(Run.class);
            List<Run> data = sf.query("runDate = ? & domain = ? & realm = ? & tag = ?").with(date).with(domain).with(realm).with(tag)
                    .fetch().toList();

            if (data.size() == 0) {
                return null;
            } 
            
            return data.get(0);
        } catch (ConfigurationException e) {
            throw new DaoRuntimeException(e);
        } catch (RepositoryException e) {
            throw new OihPersistenceException(e);
        }
    }

    @Override
    synchronized public void save(Run o) throws OihPersistenceException {
        try {
            o.insert();
        } catch (PersistException e) {
            throw new OihPersistenceException(e);
        }
    }

    @Override
    synchronized public Run findOrCreateSave(DateTime rundate, String domain, String realm, String tag) throws DaoRuntimeException,
            OihPersistenceException {
        DateTime date = rundate.withTime(0, 0, 0, 0);
        Run data = find(date, domain, realm, tag);
        
        if (null == data) {
            try {
                data = createRun(date, domain, realm, tag);
                save(data);
            } catch (OihPersistenceException e) {
                // Race condition, another process may have created the runId between our 'find' and 'save'.
                // Try 'find' once more and if that fails then pass along the exception.
                data = find(date, domain, realm, tag);
                if (null == data) {
                    throw e;
                }
                _log.warn("Recovered from race condition: failed to persist runId info into the database, but retrying find found the desired entry.");
            }
        }
        
        return data;
    }

    @Override
    synchronized public String toString() {
        StringBuilder s = new StringBuilder();

        s.append(this.getClass().getName());
        s.append(" :: ");
        s.append(" domain = ").append(_domain);

        return s.toString();
    }
}
