package com.amazon.oih.dao.g2s2.exceptions;

public class G2S2ConnectionException extends RuntimeException {

    private static final long serialVersionUID = 1991824820588252681L;

    /**
     * Constructs a new exception with the given cause.
     * 
     * @param cause
     *            the cause exception
     */
    public G2S2ConnectionException(final Throwable cause) {
        super(cause);
    }

    /**
     * Constrcuts a new exception with the given message.
     * 
     * @param msg
     *            the exception message.
     */

    public G2S2ConnectionException(final String msg) {
        super(msg);
    }

    /**
     * Constructs a new exception with the given cause and message.
     * 
     * @param msg
     *            the exception message
     * @param cause
     *            the cause exception
     */
    public G2S2ConnectionException(String msg, Throwable cause) {
        super(msg, cause);
    }

    /**
     * Construct an exception with no cause and message.
     */
    public G2S2ConnectionException() {
        super();
    }

}
