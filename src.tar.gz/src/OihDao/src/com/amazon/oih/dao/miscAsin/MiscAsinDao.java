package com.amazon.oih.dao.miscAsin;

import com.amazon.oih.dao.exception.OihPersistenceException;

public interface MiscAsinDao {
    public abstract void save(MiscAsin o) throws OihPersistenceException;
    public abstract boolean exists(Long runId, String asin, String org, String type) throws OihPersistenceException;
    public abstract MiscAsin createMiscAsin(Long runId, String asin, String org, String type);
    public void deleteAll() throws OihPersistenceException;
}
