package com.amazon.oih.dao.hbase.ourprice;

import com.amazon.oih.dao.hbase.base.CommonKVHBaseDao;

public class OurPriceHbaseObjectConverter extends CommonKVHBaseDao<OurpriceHbaseObject> {

	public OurPriceHbaseObjectConverter() {
		super(OurpriceHbaseObject.class);
	}
}
