package com.amazon.oih.dao.apub;

import java.io.Serializable;

public class ApubAsin implements Serializable{
    
    /**
     * 
     */
    private static final long serialVersionUID = 4870931641517852562L;
    
    private String org;
    private String asin;
    
    private String type;
    private Long runId;

    public String getOrg() {
        return org;
    }

    public void setOrg(String org) {
        this.org = org;
    }

    public String getAsin() {
        return asin;
    }

    public void setAsin(String asin) {
        this.asin = asin;
    }

    public Long getRunId() {
        return runId;
    }

    public void setRunId(Long runId) {
        this.runId = runId;
    }
    
    public void setType(String type) {
        this.type = type;
    }
    
    public String getType() {
        return type;
    }
}
