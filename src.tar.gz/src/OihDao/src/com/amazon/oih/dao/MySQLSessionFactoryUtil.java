package com.amazon.oih.dao;

import org.apache.log4j.Logger;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class MySQLSessionFactoryUtil {
    final static Logger log = Logger.getLogger(HibernateUtil.class);

    private static SessionFactory sessionFactory = null;
    private static SessionFactory sessionFactoryForInspector = null;

    private static SessionFactory buildSessionFactory() {
        try {
            log.info("Constructiong a session factory against hibernate.mysql.cfg.xml");
            Configuration cfg = new Configuration();
            cfg.configure("hibernate.target.cfg.xml");
            return cfg.buildSessionFactory();
        } catch (Throwable ex) {// Make sure you log the exception, as it might be swallowed
            log.error("Initial SessionFactory creation failed." + ex);
            throw new ExceptionInInitializerError(ex);
        }
    }
    
    private static SessionFactory buildSessionFactoryForInspector() {
        try {
            log.info("Constructiong a session factory against hibernate.inspector.cfg.xml");
            Configuration cfg = new Configuration();
            cfg.configure("hibernate.inspector.cfg.xml");
            return cfg.buildSessionFactory();
        } catch (Throwable ex) {// Make sure you log the exception, as it might be swallowed
            log.error("Initial SessionFactory creation failed." + ex);
            throw new ExceptionInInitializerError(ex);
        }
    }

    public static SessionFactory getSessionFactory() {
        if (sessionFactory == null) {
            sessionFactory = buildSessionFactory();
        }
        return sessionFactory;
    }

    public static void setSessionFactory(SessionFactory sf) {
        sessionFactory = sf;
    }
    
    public static SessionFactory getSessionFactoryForInspector() {
        if (sessionFactoryForInspector == null) {
        	sessionFactoryForInspector = buildSessionFactoryForInspector();
        }
        return sessionFactoryForInspector;
    }

    public static void setSessionFactoryForInspector(SessionFactory sf) {
    	sessionFactoryForInspector = sf;
    }
}
