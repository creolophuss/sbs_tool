package com.amazon.oih.dao.miscAsin;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;

import com.amazon.oih.dao.MySQLSessionFactoryUtil;
import com.amazon.oih.dao.exception.OihPersistenceException;

public class MiscAsinDaoImpl implements MiscAsinDao {
    private final static Logger logger = Logger.getLogger(MiscAsinDaoImpl.class);

    public MiscAsinDaoImpl(String domain) {
        
    }
    
    @Override
    public void save(MiscAsin o) throws OihPersistenceException {
        Transaction tx = null;
        Session session = null;
        try {
            session = openSession();
            tx = session.beginTransaction();
            session.save(o);
            tx.commit();
        } catch (RuntimeException e) {
            logger.error("Failed to save entity " + o + " with exception ", e);
            e.printStackTrace();
            if (tx != null) {
                tx.rollback();
            }
            throw new OihPersistenceException(e);
        } finally {
            closeSession(session);
        }
    }

    @Override
    public boolean exists(Long runId, String asin, String org, String type)
            throws OihPersistenceException {
        logger.debug("Query MiscAsin by " + runId + "|" + asin + "|" + org + "|" + type);
        Session session = null;
        try {
            session = openSession();
            Criteria cri = session.createCriteria(MiscAsin.class);
            cri.add(Restrictions.eq("runID", runId));
            cri.add(Restrictions.eq("asin", asin));
            cri.add(Restrictions.eq("org", org));
            cri.add(Restrictions.eq("type", type));
            return cri.uniqueResult() != null;
        } catch (HibernateException e) {
            e.printStackTrace();
            logger.error("Fail to query MiscAsin ",e);
            throw new OihPersistenceException(e);
        } finally {
            closeSession(session);
        }
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public void deleteAll() throws OihPersistenceException {
        logger.debug("Trying to delete all the elements from the db");
        Session session = null;
        Transaction tx = null;        
        try {
            session = openSession();
            tx = session.beginTransaction();
            Criteria cri = session.createCriteria(MiscAsin.class);
            List<MiscAsin> miscAsins = cri.list();
            for (MiscAsin object : miscAsins) {
                session.delete(object);
            }
            tx.commit();
        } catch (HibernateException e) {
            e.printStackTrace();
            logger.error("Fail to query MiscAsin ",e);
            throw new OihPersistenceException(e);
        } finally {
            closeSession(session);
        }

    }
    
    private Session openSession() {
        return MySQLSessionFactoryUtil.getSessionFactory().openSession();
    }

    private void closeSession(Session session) {
        if (session != null) {
            session.close();
        }
    }

    @Override
    public MiscAsin createMiscAsin(Long runId, String asin, String org,
            String type) {
        MiscAsin result = new MiscAsin(asin,org,type);
        result.setRunID(runId);
        return result;
    }

}
