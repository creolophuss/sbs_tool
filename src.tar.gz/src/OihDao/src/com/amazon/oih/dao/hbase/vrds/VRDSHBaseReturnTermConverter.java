package com.amazon.oih.dao.hbase.vrds;

import java.io.IOException;
import java.util.List;

import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.client.Result;

import com.amazon.oih.dao.hbase.base.Converter;
import com.amazon.oih.dao.hbase.converter.HBaseConverterFactory;
import com.amazon.oih.dao.hbase.converter.IHBaseObjectConverter;

@Deprecated
public class VRDSHBaseReturnTermConverter implements Converter<VRDSHBaseReturnTerm> {
    private IHBaseObjectConverter<VRDSHBaseReturnTerm> vrdsHBaseReturnTermConverter = HBaseConverterFactory.getDefaultConverter();
    
    @Override
    public VRDSHBaseReturnTerm convert(String rowKey, Result rs) throws IOException {
        try {
            return vrdsHBaseReturnTermConverter.convert(VRDSHBaseReturnTerm.class, rowKey, rs);
        } catch (Exception e) {
            e.printStackTrace();
            throw new IOException(e);
        }
    }

    @Override
    public VRDSHBaseReturnTerm convert(Result rs) throws IOException {
        return convert(new String(rs.getRow()), rs);
    }

    @Override
    public List<Put> convert(VRDSHBaseReturnTerm object) throws IOException {
        return vrdsHBaseReturnTermConverter.convert(VRDSHBaseReturnTermDao.RETURN_TERM_COLUMNFAMILY, object);
    }

    @Override
    public String getRowKey(VRDSHBaseReturnTerm object) {
        return vrdsHBaseReturnTermConverter.getRowKey(object);
    } 
    

}
