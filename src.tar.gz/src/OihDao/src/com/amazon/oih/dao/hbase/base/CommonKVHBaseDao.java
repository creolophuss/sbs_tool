package com.amazon.oih.dao.hbase.base;

import java.io.IOException;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.util.Date;
import java.util.Map;

import org.apache.hadoop.hbase.client.Result;

import com.amazon.oih.dao.hbase.converter.HBaseObjectDefaultConverter;

/**
 * Build a HBaseDao based on Object and Annotations of @HTableName/@RowKey/@Column TODO: deprecate
 * RemoteCatConverter/RemoteCatHBaseDao, and similiar code for VRDS
 * 
 * @author jialei
 * 
 * @param <T>
 */
public class CommonKVHBaseDao<T> extends HBaseDaoImplAdaptor<T> {
    protected Class<T> classObj;
    private HBaseObjectDefaultConverter<T> converter;

    public CommonKVHBaseDao(Class<T> classObj) {
        super();
        this.classObj = classObj;
        this.converter = getConverter(classObj);
    }

    public CommonKVHBaseDao(Class<T> classObj, String additionalId, String realm, Date rundate) {
        this(classObj, additionalId, realm, rundate, false);
    }

    public CommonKVHBaseDao(Class<T> classObj, String additionalId, String realm, Date rundate,
            boolean skipRundateChecking) {
        super(obtainTableName(classObj, additionalId), obtainColumnFamilyName(classObj), realm, rundate,
                skipRundateChecking);
        this.classObj = classObj;
        this.converter = getConverter(classObj);
    }

    @SuppressWarnings("unchecked")
    public CommonKVHBaseDao(String classDesc) throws ClassNotFoundException {
        this((Class<T>)Class.forName(classDesc));
    }
    
    @Override
    public String generateRowKey(T bObject) {
        return converter.getRowKey(bObject);
    }

    public T convert(Result res) throws IOException {
        return this.convert(new String(res.getRow()), res);
    }
    
    @Override
    protected Map<String, String> generateColumnValueMap(T bObject) {
        return converter.getValues(bObject);
    }

    @Override
    protected T construct(String rowKey, Map<String, String> columnMap) {
        return converter.convert(classObj, rowKey, columnMap);
    }

    public static <T> HBaseObjectDefaultConverter<T> getConverter(final Class<T> targetObj){
        return new HBaseObjectDefaultConverter<T>(){
            @Override
            public String getValueSplit(){
                return obtainColumnSeparator(targetObj);
            }
        };
    }
    
    public static String obtainTableName(Class<?> classObj, String additionalId) {
        HTable anno = obtainHTableMeta(classObj);
        return anno.value() + (additionalId == null? "" : additionalId);
    }
    
    public static <T> String obtainColumnFamilyName(Class<T> classObj) {
        HTable anno = obtainHTableMeta(classObj);
        return anno.columFamilyName();
    }
    
    public static <T> String obtainColumnSeparator(Class<T> classObj) {
        HTable anno = obtainHTableMeta(classObj);
        return anno.separator();
    }

    private static <T> HTable obtainHTableMeta(Class<T> classObj) {
        HTable anno = classObj.getAnnotation(HTable.class);
        if (anno == null) {
            throw new RuntimeException("do not specify Table name for " + classObj.getCanonicalName());
        }
        return anno;
    }
    
    @Retention(RetentionPolicy.RUNTIME)
    @Target(ElementType.TYPE)
    public static @interface HTable {
        String value();
        String separator() default ","; 
        String columFamilyName() default "info";
    }
}
