package com.amazon.oih.dao.unsellable.inventorycandidate;

import java.util.List;

import amazon.platform.profiler.Profiler;
import amazon.platform.profiler.ProfilerScope;

import com.amazon.carbonado.IsolationLevel;
import com.amazon.carbonado.PersistException;
import com.amazon.carbonado.Repository;
import com.amazon.carbonado.RepositoryException;
import com.amazon.carbonado.Storage;
import com.amazon.carbonado.SupportException;
import com.amazon.carbonado.Transaction;
import com.amazon.oih.dao.exception.DaoRuntimeException;
import com.amazon.oih.dao.exception.OihPersistenceException;

public class InventoryCandidateCompositeDaoImpl implements InventoryCandidateCompositeDao {
    protected String domain = null;
    protected Repository repository = null;

    public InventoryCandidateCompositeDaoImpl(String domain) {
        this.domain = domain;
    }

    @Override
    public void setRepository(Repository repository) {
        this.repository = repository;
    }

    @Override
    public InventoryCandidateComposite createICComposite(ICCItem item) throws OihPersistenceException {
        ProfilerScope scope = Profiler.scopeStart(this.getClass().getName() + "::create");

        Storage<InventoryCandidateComposite> iccStorable;
        try {
            iccStorable = repository.storageFor(InventoryCandidateComposite.class);
            InventoryCandidateComposite iccItem = iccStorable.prepare();

            setValues(iccItem, item);
            return iccItem;
        } catch (SupportException e) {
            e.printStackTrace();
            throw new OihPersistenceException(e);
        } catch (RepositoryException e) {
            e.printStackTrace();
            throw new OihPersistenceException(e);
        } finally {
            Profiler.scopeEnd(scope);
        }
    }

    private void setValues(InventoryCandidateComposite iccItem, ICCItem item) {
        iccItem.setAsin(item.getAsin());
        iccItem.setFnsku(item.getFnsku());
        iccItem.setFcsku(item.getFcsku());
        iccItem.setCondition(item.getCondition());
        iccItem.setIog(item.getIog());
        iccItem.setWarehouse(item.getWarehouse());

        iccItem.setOnhandQuantity(item.getOnhandQuantity());
        iccItem.setBoundQuantity(item.getBoundQuantity());
        iccItem.setPlanningSideQuantity(item.getPsQuantity());
        iccItem.setFcSideQuantity(item.getFsQuantity());
    }

    @Override
    public void save(List<InventoryCandidateComposite> items) throws OihPersistenceException {
        Transaction txn = repository.enterTransaction(IsolationLevel.READ_UNCOMMITTED);

        try {
            for (InventoryCandidateComposite iccItem : items) {
                if (!iccItem.tryLoad()) {
                    iccItem.insert();
                }
            }
            txn.commit();
        } catch (PersistException e) {
            throw new OihPersistenceException(e);
        } catch (Exception e) {
            throw new DaoRuntimeException(e);
        } finally {
            exitTransaction(txn);
        }
    }

    @Override
    public void save(InventoryCandidateComposite item) throws OihPersistenceException {
        ProfilerScope scope = Profiler.scopeStart(this.getClass().getName() + "::save");
        try {
            item.insert();
        } catch (PersistException e) {
            throw new OihPersistenceException(e);
        } finally {
            Profiler.scopeEnd(scope);
        }
    }

    @Override
    public boolean exists(String asin, String fnsku, String fcsku, Integer iog, String condition, String warehouse)
            throws OihPersistenceException {
        ProfilerScope scope = Profiler.scopeStart(this.getClass().getName() + "::exists");
        try {
            Storage<InventoryCandidateComposite> sf = repository.storageFor(InventoryCandidateComposite.class);
            boolean retVal = sf.query(" asin = ? & fnsku = ? & fcsku = ? & iog = ? & condition = ? & warehouse = ? ")
                    .with(asin).with(fnsku).with(fcsku).with(iog).with(condition).with(warehouse).exists();

            return retVal;
        } catch (SupportException e) {
            throw new DaoRuntimeException(e);
        } catch (RepositoryException e) {
            throw new OihPersistenceException(e);
        } finally {
            Profiler.scopeEnd(scope);
        }
    }

    @Override
    public InventoryCandidateComposite find(String asin, String fnsku, String fcsku, Integer iog, String condition,
            String warehouse) throws OihPersistenceException {
        ProfilerScope scope = Profiler.scopeStart(this.getClass().getName() + "::exists");
        try {
            Storage<InventoryCandidateComposite> sf = repository.storageFor(InventoryCandidateComposite.class);
            InventoryCandidateComposite result = sf
                    .query(" asin = ? & fnsku = ? & fcsku = ? & iog = ? & condition = ? & warehouse = ? ").with(asin)
                    .with(fnsku).with(fcsku).with(iog).with(condition).with(warehouse).loadOne();

            return result;
        } catch (SupportException e) {
            throw new DaoRuntimeException(e);
        } catch (RepositoryException e) {
            throw new OihPersistenceException(e);
        } finally {
            Profiler.scopeEnd(scope);
        }
    }

    private void exitTransaction(Transaction txn) throws OihPersistenceException {
        try {
            txn.exit();
        } catch (PersistException e) {
            throw new OihPersistenceException(e);
        }
    }
}
