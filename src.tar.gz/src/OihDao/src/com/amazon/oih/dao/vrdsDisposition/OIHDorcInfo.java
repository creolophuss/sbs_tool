package com.amazon.oih.dao.vrdsDisposition;

import java.util.Date;

public class OIHDorcInfo {
	
	String asin;
	int iog;
	int marketplaceId;
	int gl;
	String vendor;
	String dispositionType; //change this to enum
	String warehouse;
	long qtyAssigned;
	long orderType;
	long dorcId;
	int qtyReceived;
	int qtyReturned;
	int qtyInUse;
	long dsiId;
	double distributorCost;
	String baseCurrencyCode;
	double distributorListPrice;
	String distributorOrderId;
	Date distributorOrderDate;
	Date shipmentReceivedDate;
	String distributorId;
	String distributorShipmentId;
	double cost; //not sure what the meaning of cost is
	double refundAmount;
	String foreignCurrencyCode;
	double costForeignCurrency;
	double refundAmountForeignCurrency;
    double distributorCostForeignCurrency;
    double distributorListPriceForeignCurrency;
	
	public OIHDorcInfo() {
		//initialize stuff to some default values
		//that way if we dont get back some fields from VRDS, we are still fine.
		
		
	}
	
	public String getAsin() {
		return asin;
	}
	public void setAsin(String asin) {
		this.asin = asin;
	}
	public int getIog() {
		return iog;
	}
	public void setIog(int iog) {
		this.iog = iog;
	}
	public int getMarketplaceId() {
		return marketplaceId;
	}
	public void setMarketplaceId(int marketplaceId) {
		this.marketplaceId = marketplaceId;
	}
	public int getGl() {
		return gl;
	}
	public void setGl(int gl) {
		this.gl = gl;
	}
	public String getVendor() {
		return vendor;
	}
	public void setVendor(String vendor) {
		this.vendor = vendor;
	}
	public String getDispositionType() {
		return dispositionType;
	}
	public void setDispositionType(String dispositionType) {
		this.dispositionType = dispositionType;
	}
	public String getWarehouse() {
		return warehouse;
	}
	public void setWarehouse(String warehouse) {
		this.warehouse = warehouse;
	}
	public long getQtyAssigned() {
		return qtyAssigned;
	}
	public void setQtyAssigned(long qtyAssigned) {
		this.qtyAssigned = qtyAssigned;
	}
	public long getOrderType() {
		return orderType;
	}
	public void setOrderType(long orderType) {
		this.orderType = orderType;
	}
	public long getDorcId() {
		return dorcId;
	}
	public void setDorcId(long dorcId) {
		this.dorcId = dorcId;
	}
	public int getQtyReceived() {
		return qtyReceived;
	}
	public void setQtyReceived(int qtyReceived) {
		this.qtyReceived = qtyReceived;
	}
	public int getQtyReturned() {
		return qtyReturned;
	}
	public void setQtyReturned(int qtyReturned) {
		this.qtyReturned = qtyReturned;
	}
	public int getQtyInUse() {
		return qtyInUse;
	}
	public void setQtyInUse(int qtyInUse) {
		this.qtyInUse = qtyInUse;
	}
	public long getDsiId() {
		return dsiId;
	}
	public void setDsiId(long dsiId) {
		this.dsiId = dsiId;
	}
	public double getDistributorCost() {
		return distributorCost;
	}
	public void setDistributorCost(double distributorCost) {
		this.distributorCost = distributorCost;
	}
	public String getBaseCurrencyCode() {
		return baseCurrencyCode;
	}
	public void setBaseCurrencyCode(String baseCurrencyCode) {
		this.baseCurrencyCode = baseCurrencyCode;
	}
	public double getDistributorListPrice() {
		return distributorListPrice;
	}
	public void setDistributorListPrice(double distributorListPrice) {
		this.distributorListPrice = distributorListPrice;
	}
	public String getDistributorOrderId() {
		return distributorOrderId;
	}
	public void setDistributorOrderId(String distributorOrderId) {
		this.distributorOrderId = distributorOrderId;
	}
	public Date getDistributorOrderDate() {
		return distributorOrderDate;
	}
	public void setDistributorOrderDate(Date distributorOrderDate) {
		this.distributorOrderDate = distributorOrderDate;
	}
	public Date getShipmentReceivedDate() {
		return shipmentReceivedDate;
	}
	public void setShipmentReceivedDate(Date shipmentReceivedDate) {
		this.shipmentReceivedDate = shipmentReceivedDate;
	}
	public String getDistributorId() {
		return distributorId;
	}
	public void setDistributorId(String distributorId) {
		this.distributorId = distributorId;
	}
	public String getDistributorShipmentId() {
		return distributorShipmentId;
	}
	public void setDistributorShipmentId(String distributorShipmentId) {
		this.distributorShipmentId = distributorShipmentId;
	}
	public double getCost() {
		return cost;
	}
	public void setCost(double cost) {
		this.cost = cost;
	}
	
	public String toString() {
		StringBuffer str  = new StringBuffer();
		str.append("asin: ");
		str.append(asin);
		str.append(" iog: ");
		str.append(iog);
		str.append(" marketplace: ");
		str.append(marketplaceId);
		str.append(" gl: ");
		str.append(gl);
		str.append(" vendor: ");
		str.append(vendor);
		str.append(" warehouse: ");
		str.append(warehouse);
		str.append(" disposition type: ");
		str.append(dispositionType);
		str.append(" dsiId: ");
		str.append(dsiId);
		str.append(" Qty Assigned: ");
		str.append(qtyAssigned);
		str.append(" Qty Received: ");
		str.append(qtyReceived);
		str.append(" Qty Returned: ");
		str.append(qtyReturned);
		str.append(" Qty In use: ");
		str.append(qtyInUse);
		return str.toString();
	}

	public double getRefundAmount() {
		return refundAmount;
	}

	public void setRefundAmount(double refundAmount) {
		this.refundAmount = refundAmount;
	}
	
	public double getRefundAmountForeignCurrency() {
		return refundAmountForeignCurrency;
	}
	
	public void setRefundAmountForeignCurrency(double refundAmountForeignCurrency) {
		this.refundAmountForeignCurrency = refundAmountForeignCurrency;
	}
	
	public double getCostForeignCurrency() {
		return costForeignCurrency;
	}
	
	public void setCostForeignCurrency(double costForeignCurrency) {
		this.costForeignCurrency = costForeignCurrency;
	}
	
	public String getForeignCurrencyCode() {
		return foreignCurrencyCode;
	}
	
	public void setForeignCurrencyCode(String foreignCurrencyCode) {
		this.foreignCurrencyCode = foreignCurrencyCode;
	}

    public double getDistributorCostForeignCurrency() {
        return distributorCostForeignCurrency;
    }

    public void setDistributorCostForeignCurrency(double distributorCostForeignCurrency) {
        this.distributorCostForeignCurrency = distributorCostForeignCurrency;
    }

    public double getDistributorListPriceForeignCurrency() {
        return distributorListPriceForeignCurrency;
    }

    public void setDistributorListPriceForeignCurrency(double distributorListPriceForeignCurrency) {
        this.distributorListPriceForeignCurrency = distributorListPriceForeignCurrency;
    }
	
}
