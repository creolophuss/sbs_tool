 /**
  * Copyright (c) 2014 Amazon.com, Inc.  All rights reserved.
  * 
  * Owner: oih-cn@
  */
package com.amazon.oih.dao.rebuycost;

import java.io.Serializable;

import com.amazon.oih.common.RowKeyBuildType;
import com.amazon.oih.common.RowKeyType;
import com.amazon.oih.common.KVFormater.FileColumnNames;
import com.amazon.oih.common.KeyValueBase.NamedValue;
import com.amazon.oih.dao.hbase.base.CommonKVHBaseDao.HTable;
import com.amazon.oih.dao.hbase.converter.Column;
import com.amazon.oih.dao.hbase.converter.RowKey;

/**
 * @author gaoxing
 *
 */
@RowKey({"asin", "iog"})
@RowKeyBuildType(RowKeyType.ASIN_IOG)
@HTable("RebuyCost")
@FileColumnNames({"ASIN", "unit_cost", "Inventory Owner Group Id"})
public class RebuyCost implements Serializable {

    private static final long serialVersionUID = -7231627571236871971L;

    @NamedValue("ASIN")
    private String asin;
    @NamedValue("Inventory Owner Group Id")
    private int iog;
    
    @NamedValue("unit_cost")
    @Column(name="cost",index=1)
    private double cost;

    /**
     * Keep this for common DAO init instance.
     */
    public RebuyCost(){
    }

    public RebuyCost(String asin, int iog, double rebuyCost){
        this.asin = asin;
        this.iog = iog;
        this.cost = rebuyCost;
    }
    
    public String getAsin() {
        return asin;
    }

    public void setAsin(String asin) {
        this.asin = asin;
    }

    public int getIog() {
        return iog;
    }

    public void setIog(int iog) {
        this.iog = iog;
    }

    public double getCost() {
        return cost;
    }

    public void setCost(double cost) {
        this.cost = cost;
    }

    @Override
    public String toString() {
        return "RebuyCost [asin=" + asin + ", iog=" + iog + ", cost=" + cost + "]";
    }
}
