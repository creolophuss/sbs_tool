package com.amazon.oih.dao.hbase.forecast;

import java.io.IOException;
import java.util.Date;
import java.util.List;

import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.client.Result;

import amazon.platform.config.AppConfig;

import com.amazon.oih.dao.DaoConstants;
import com.amazon.oih.dao.hbase.base.AbstractHBaseDaoImpl;
import com.amazon.oih.dao.hbase.base.Converter;
import com.amazon.oih.dao.hbase.schema.HTableNameCFGeneratorImpl;

@Deprecated
public class ForecastHBaseDao extends AbstractHBaseDaoImpl<ForecastHBaseObject> {

    final static String FORECAST_INPUTNAME = AppConfig.findString(DaoConstants.FORECAST_INPUTNAME);
    final static String FORECAST_COLUMNFAMILY = AppConfig.findString(DaoConstants.FORECAST_COLUMNFAMILY);
    Converter<ForecastHBaseObject> converter;
    
    public ForecastHBaseDao(Date rundate, String realm) {
        super(new HTableNameCFGeneratorImpl(FORECAST_INPUTNAME, FORECAST_COLUMNFAMILY, realm, rundate), realm);
        converter = new ForecastConverter();
    }
    
    @Override
    protected ForecastHBaseObject convert(String rowKey, Result rs) throws IOException {
        return converter.convert(rowKey, rs);
    }

    @Override
    protected List<Put> convert(ForecastHBaseObject bObject) throws IOException {
        return converter.convert(bObject);
    }
}
