package com.amazon.oih.dao.vendorleadtime;

import java.util.List;

import com.amazon.oih.dao.exception.OihPersistenceException;

public interface VendorLeadTimeDao {
    public abstract void save(VendorLeadTime o) throws OihPersistenceException;

    public abstract void save(List<VendorLeadTime> vlts) throws OihPersistenceException;

    public abstract boolean exists(Long runId, String vendor, long merchantId, int gl) throws OihPersistenceException;

    public abstract VendorLeadTime find(Long runId, String vendor, long merchantId, int gl) throws OihPersistenceException;

    public abstract VendorLeadTime createInstance(long runID, String vendor, long merchantId, int gl , double averageVlt);

    public abstract void delete(VendorLeadTime o) throws OihPersistenceException;

    public abstract void deleteAll() throws OihPersistenceException;

}
