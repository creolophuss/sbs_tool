package com.amazon.oih.dao.forecastnew;

import java.io.IOException;

import org.apache.hadoop.hbase.client.Result;

import com.amazon.oih.dao.hbase.base.SubKeyAwareHBaseDao;
import com.amazon.oih.dao.hbase.forecast.AnnoForecastHBaseObj;
import com.amazon.oih.dao.hbase.forecast.ForecastHBaseObject;

public class ForecastHBaseConverter {
	
    private SubKeyAwareHBaseDao<AnnoForecastHBaseObj> dao = null;
	
    public ForecastHBaseConverter() {
        dao = new SubKeyAwareHBaseDao<AnnoForecastHBaseObj> (AnnoForecastHBaseObj.class);
    }
	
    public ForecastHBaseObject convert(Result res) throws IOException {
    	return AnnoForecastHBaseObj.toForecastHBaseObject(dao.convert(res));
    }
}
