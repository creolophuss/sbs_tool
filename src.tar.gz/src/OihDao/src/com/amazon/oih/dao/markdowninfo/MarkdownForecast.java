package com.amazon.oih.dao.markdowninfo;

import java.io.Serializable;

public class MarkdownForecast implements Serializable {
    private static final long serialVersionUID = 1L;
    private long runID;
    private String asin;
    private int marketplaceId;
    private double demandIncrease;
    private double demandIncreaseRate;
    private double recoveryRate;
    private String dataVersion;
    private String dataLevel;

    public MarkdownForecast(long runID, String asin, int marketplaceId, double demandIncrease, double demandIncreaseRate,
    		double recoveryRate, String dataVersion, String dataLevel) {
        this.runID = runID;
        this.asin = asin;
        this.marketplaceId = marketplaceId;
        this.demandIncrease = demandIncrease;
        this.demandIncreaseRate = demandIncreaseRate;
        this.recoveryRate = recoveryRate;
        this.dataVersion = dataVersion;
        this.dataLevel = dataLevel;
    }

    public MarkdownForecast() {

    }

    public void setRunID(long runID) {
        this.runID = runID;
    }

    public long getRunID() {
        return runID;
    }

    public void setAsin(String asin) {
        this.asin = asin;
    }

    public String getAsin() {
        return asin;
    }


    public int getMarketplaceId() {
		return marketplaceId;
	}

	public void setMarketplaceId(int marketplaceId) {
		this.marketplaceId = marketplaceId;
	}

	public double getDemandIncrease() {
		return demandIncrease;
	}

	public void setDemandIncrease(double demandIncrease) {
		this.demandIncrease = demandIncrease;
	}

	public double getDemandIncreaseRate() {
		return demandIncreaseRate;
	}

	public void setDemandIncreaseRate(double demandIncreaseRate) {
		this.demandIncreaseRate = demandIncreaseRate;
	}

	public double getRecoveryRate() {
		return recoveryRate;
	}

	public void setRecoveryRate(double recoveryRate) {
		this.recoveryRate = recoveryRate;
	}

	public String getDataVersion() {
		return dataVersion;
	}

	public void setDataVersion(String dataVersion) {
		this.dataVersion = dataVersion;
	}

	public String getDataLevel() {
		return dataLevel;
	}

	public void setDataLevel(String dataLevel) {
		this.dataLevel = dataLevel;
	}

	@Override
	public String toString(){
		return "asin:" + asin + " marketplaceId:" + marketplaceId + " runId:" + runID;
	}
	
	@Override
    public boolean equals(Object obj) {
        if (obj instanceof MarkdownForecast == false) {
            return false;
        }
        if (this == obj) {
            return true;
        }

        MarkdownForecast other = (MarkdownForecast) obj;

        return this.asin.equals(other.getAsin()) && this.marketplaceId == other.getMarketplaceId() && 
        		Math.abs(this.demandIncrease - other.getDemandIncrease()) < 1e-6 && 
        		Math.abs(this.demandIncreaseRate - other.getDemandIncreaseRate()) < 1e-6 &&
        		Math.abs(this.recoveryRate - other.getRecoveryRate()) <  1e-6 &&
        		this.dataVersion.equals(other.getDataVersion()) && this.dataLevel.equals(other.getDataLevel());
    }


    @Override
    public int hashCode() {
        final int prime = 127; // changed from default - 31 is a lame prime #
        int result = 1;
        result = prime * result + ((asin == null) ? 0 : asin.hashCode());
        result = prime * result + marketplaceId;
        result = prime * result + (int) runID;
        return result;
    }
}
