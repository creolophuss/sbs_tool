package com.amazon.oih.dao.g2s2;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;

import amazon.iop.metadata.cache.QueryCache;
import amazon.iop.metadata.cache.impl.ConcurrentQueryCache;
import amazon.iop.metadata.g2s2.client.G2S2Exception;
import amazon.iop.metadata.g2s2.client.Metadatum;
import amazon.iop.metadata.g2s2.client.internal.G2S2InternalRepositoryClient;
import amazon.iop.metadata.g2s2.client.internal.cache.FullCachingClient;
import amazon.iop.metadata.g2s2.client.internal.impl.InternalRESTClient;
import amazon.platform.config.AppConfig;

import com.amazon.ion.IonStruct;
import com.amazon.ion.IonSymbol;
import com.amazon.ion.IonValue;
import com.amazon.oih.dao.g2s2.exceptions.G2S2ConnectionException;
import com.amazon.oih.dao.g2s2.exceptions.IonMappingException;
/**
 * Don't use G2S2AppConfigsReadWriteDaoImpl when you only need to read config from g2s2, 
 * because G2S2AppConfigsReadWriteDaoImpl use global endpoint to read and write  configs.
 * @author xlpeng
 *
 */
public class G2S2AppConfigsReadWriteDaoImpl extends G2S2AppConfigsReadonlyDaoImpl implements G2S2AppConfigsReadWriteDao {
    static final String g2s2WriteEndpointConfigKey = "g2s2.WriteEndpoint";

    public G2S2AppConfigsReadWriteDaoImpl() {
        super();
        String g2s2WriteEndpoint = AppConfig.findString(g2s2WriteEndpointConfigKey);
        getG2S2ClientConfig().setG2s2WriteEndpoint(g2s2WriteEndpoint);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public <T> void saveAppConfig(String key, T appConfig) {
        saveAppConfig(key, appConfig, g2s2Configurations.getRealm());
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public <T> void saveAppConfig(String key, T appConfig, String realm) {
        saveAppConfig(key, appConfig, realm, g2s2Configurations.getDomain());
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public <T> void saveAppConfig(String key, T appConfig, String realm, String domain) {

        checkConfigyKey(key);

        // if should manage transaction in method?
        boolean shouldManageTransaction = !G2S2WriteTransaction.hasTransaction();
        G2S2WriteTransaction writeTransaction = null;

        try {
            writeTransaction = beginWriteTransacton();

            addAppConfigKeyIfNotExist(key);
            addAppConfigDomainIfNotExist(domain);
            addAppConfigRealmIfNotExist(realm);

            IonValue ionValue = ionMapper.writeValueAsIonValue(appConfig);
            IonStruct appConfigAsG2S2Record = assembleAppConfigMetadatum(key, realm, domain,
                    writeTransaction.getNewStageVersion(), ionValue);
            Map<String, String> keys = assembleQueryKey(appConfigAsG2S2Record, writeTransaction.getNewStageVersion());
            getRepositoryClientWithCache().put(G2S2Constants.APP_CONFIGS_TABLE, keys, appConfigAsG2S2Record);

            if (shouldManageTransaction) {
                writeTransaction.commit();
            }
        } catch (G2S2Exception e) {
            throw new G2S2ConnectionException("G2S2Exception is thrown by G2S2 when put app config to G2S2!", e);
        } catch (UnsupportedOperationException e) {
            throw new G2S2ConnectionException(
                    "UnsupportedOperationException is thrown by G2S2 when put app config to G2S2!", e);
        } catch (JsonGenerationException e) {
            throw new IonMappingException(
                    "JsonGenerationException is thrown by  JoiObjectMapper while mapping Object to Ion!", e);
        } catch (JsonMappingException e) {
            throw new IonMappingException(
                    "JsonMappingException is thrown by  JoiObjectMapper while mapping Object to Ion!", e);
        } catch (IOException e) {
            throw new IonMappingException("IOException is thrown by  JoiObjectMapper while mapping Object to Ion!", e);
        } finally {
            if (shouldManageTransaction && writeTransaction != null) {
                writeTransaction.close();
            }
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public <T> void saveAppConfig(T appConfig, String realm, String domain) {
        String key = getConfigKey(appConfig.getClass());
        saveAppConfig(key, appConfig, realm, domain);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public G2S2InternalRepositoryClient getG2S2InternalRepositoryClient() {
        return getRepositoryClientWithCache();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public G2S2ClientConfigs getG2S2ClientConfig() {
        return g2s2Configurations;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public G2S2WriteTransaction beginWriteTransacton() {
        return G2S2WriteTransaction.getWriteTransaction(this);
    }

    private void addAppConfigKeyIfNotExist(String key) {
        G2S2WriteTransaction writeTransaction = G2S2WriteTransaction.getWriteTransaction(this);
        Map<String, String> appConfigKeyQuery = new HashMap<String, String>();

        appConfigKeyQuery.put(G2S2Constants.APP_CONFIG_NAME, G2S2Constants.APP_CONFIG_NAME_VALUE);
        appConfigKeyQuery.put(G2S2Constants.APP_CONFIG_KEY, key);
        appConfigKeyQuery.put(G2S2Constants.STAGE_VERSION, writeTransaction.getLatestStageVersion());

        Iterator<Metadatum> metadatumsIteror = getRepositoryClient().get(G2S2Constants.APP_CONFIG_KEYS_TABLE,
                appConfigKeyQuery);
        if (metadatumsIteror == null || !metadatumsIteror.hasNext()) {
            IonStruct appConfigKey = assembleAppConfigKeyMetadatum(key, writeTransaction.getNewStageVersion());
            appConfigKeyQuery.put(G2S2Constants.STAGE_VERSION, writeTransaction.getNewStageVersion());
            getRepositoryClientWithCache().put(G2S2Constants.APP_CONFIG_KEYS_TABLE, appConfigKeyQuery, appConfigKey);
        }
    }

    private void addAppConfigRealmIfNotExist(String realm) {
        if (G2S2Constants.DEFAULT.equals(realm)) {
            return;
        }
        G2S2WriteTransaction writeTransaction = G2S2WriteTransaction.getWriteTransaction(this);
        Map<String, String> appConfigRealmQuery = new HashMap<String, String>();

        appConfigRealmQuery.put(G2S2Constants.APP_CONFIG_REALM, realm);
        appConfigRealmQuery.put(G2S2Constants.STAGE_VERSION, writeTransaction.getLatestStageVersion());

        Iterator<Metadatum> metadatumsIteror = getRepositoryClient().get(G2S2Constants.APP_CONFIG_REALMS_TABLE,
                appConfigRealmQuery);
        if (metadatumsIteror == null || !metadatumsIteror.hasNext()) {
            IonStruct appConfigRealm = ios.newEmptyStruct();
            appConfigRealm.put(G2S2Constants.TABLE_NAME, ios.newSymbol(G2S2Constants.APP_CONFIG_REALMS_TABLE));
            appConfigRealm.put(G2S2Constants.APP_CONFIG_REALM, ios.newSymbol(realm));
            appConfigRealm.put(G2S2Constants.STAGE_VERSION, ios.newString(writeTransaction.getNewStageVersion()));

            appConfigRealmQuery.put(G2S2Constants.STAGE_VERSION, writeTransaction.getNewStageVersion());

            getRepositoryClientWithCache().put(G2S2Constants.APP_CONFIG_REALMS_TABLE, appConfigRealmQuery,
                    appConfigRealm);
        }

    }

    private void addAppConfigDomainIfNotExist(String domain) {
        if (G2S2Constants.DEFAULT.equals(domain)) {
            return;
        }
        G2S2WriteTransaction writeTransaction = G2S2WriteTransaction.getWriteTransaction(this);
        Map<String, String> appConfigDomainQuery = new HashMap<String, String>();

        appConfigDomainQuery.put(G2S2Constants.APP_CONFIG_DOMAIN, domain);
        appConfigDomainQuery.put(G2S2Constants.STAGE_VERSION, writeTransaction.getLatestStageVersion());

        Iterator<Metadatum> metadatumsIteror = getRepositoryClient().get(G2S2Constants.APP_CONFIG_DOMAINS_TABLE,
                appConfigDomainQuery);
        if (metadatumsIteror == null || !metadatumsIteror.hasNext()) {
            IonStruct appConfigDomain = ios.newEmptyStruct();
            appConfigDomain.put(G2S2Constants.TABLE_NAME, ios.newSymbol(G2S2Constants.APP_CONFIG_DOMAINS_TABLE));
            appConfigDomain.put(G2S2Constants.APP_CONFIG_DOMAIN, ios.newSymbol(domain));
            appConfigDomain.put(G2S2Constants.STAGE_VERSION, ios.newString(writeTransaction.getNewStageVersion()));

            appConfigDomainQuery.put(G2S2Constants.STAGE_VERSION, writeTransaction.getNewStageVersion());

            getRepositoryClientWithCache().put(G2S2Constants.APP_CONFIG_DOMAINS_TABLE, appConfigDomainQuery,
                    appConfigDomain);
        }

    }

    private Map<String, String> assembleQueryKey(IonStruct ionStruct, String stageVersion) {
        Map<String, String> query = new HashMap<String, String>();
        query.put(G2S2Constants.APP_CONFIG_OVERRIDE_HIERARCHY,
                ((IonSymbol) (ionStruct.get(G2S2Constants.APP_CONFIG_OVERRIDE_HIERARCHY))).stringValue());
        query.put(G2S2Constants.APP_CONFIG_NAME,
                ((IonSymbol) (ionStruct.get(G2S2Constants.APP_CONFIG_NAME))).stringValue());
        query.put(G2S2Constants.APP_CONFIG_DOMAIN,
                ((IonSymbol) (ionStruct.get(G2S2Constants.APP_CONFIG_DOMAIN))).stringValue());
        query.put(G2S2Constants.APP_CONFIG_REALM,
                ((IonSymbol) (ionStruct.get(G2S2Constants.APP_CONFIG_REALM))).stringValue());
        query.put(G2S2Constants.APP_CONFIG_KEY,
                ((IonSymbol) (ionStruct.get(G2S2Constants.APP_CONFIG_KEY))).stringValue());
        query.put(G2S2Constants.STAGE_VERSION, stageVersion);
        return query;
    }

    @SuppressWarnings("unused")
    private IonStruct assembleAppConfigMetadatum(IonStruct ionStruct, String newStageVersion, IonValue appConfigValue) {
        IonStruct newStruct = ios.newEmptyStruct();

        newStruct.put(G2S2Constants.TABLE_NAME,
                ios.newSymbol(((IonSymbol) (ionStruct.get(G2S2Constants.TABLE_NAME))).stringValue()));
        newStruct
                .put(G2S2Constants.APP_CONFIG_OVERRIDE_HIERARCHY, ios.newSymbol(((IonSymbol) (ionStruct
                        .get(G2S2Constants.APP_CONFIG_OVERRIDE_HIERARCHY))).stringValue()));
        newStruct.put(G2S2Constants.APP_CONFIG_NAME,
                ios.newSymbol(((IonSymbol) (ionStruct.get(G2S2Constants.APP_CONFIG_NAME))).stringValue()));
        newStruct.put(G2S2Constants.APP_CONFIG_DOMAIN,
                ios.newSymbol(((IonSymbol) (ionStruct.get(G2S2Constants.APP_CONFIG_DOMAIN))).stringValue()));
        newStruct.put(G2S2Constants.APP_CONFIG_REALM,
                ios.newSymbol(((IonSymbol) (ionStruct.get(G2S2Constants.APP_CONFIG_REALM))).stringValue()));
        newStruct.put(G2S2Constants.APP_CONFIG_KEY,
                ios.newSymbol(((IonSymbol) (ionStruct.get(G2S2Constants.APP_CONFIG_KEY))).stringValue()));
        newStruct.put(G2S2Constants.STAGE_VERSION, ios.newString(newStageVersion));
        newStruct.put(G2S2Constants.APP_CONFIG, appConfigValue);
        return newStruct;
    }

    private IonStruct assembleAppConfigMetadatum(String key, String realm, String domain, String newStageVersion,
            IonValue appConfigValue) {
        IonStruct newStruct = ios.newEmptyStruct();
        newStruct.put(G2S2Constants.TABLE_NAME, ios.newSymbol(G2S2Constants.APP_CONFIGS_TABLE));
        newStruct.put(G2S2Constants.APP_CONFIG_OVERRIDE_HIERARCHY,
                ios.newSymbol(G2S2Constants.APP_CONFIG_OVERRIDE_HIERARCHY_VALUE));
        newStruct.put(G2S2Constants.APP_CONFIG_NAME, ios.newSymbol(G2S2Constants.APP_CONFIG_NAME_VALUE));
        newStruct.put(G2S2Constants.APP_CONFIG_DOMAIN, ios.newSymbol(domain));
        newStruct.put(G2S2Constants.APP_CONFIG_REALM, ios.newSymbol(realm));
        newStruct.put(G2S2Constants.APP_CONFIG_KEY, ios.newSymbol(key));
        newStruct.put(G2S2Constants.STAGE_VERSION, ios.newString(newStageVersion));
        newStruct.put(G2S2Constants.APP_CONFIG, appConfigValue);
        return newStruct;
    }

    private IonStruct assembleAppConfigKeyMetadatum(String key, String stageVersion) {
        IonStruct appConfigKey = ios.newEmptyStruct();
        appConfigKey.put(G2S2Constants.TABLE_NAME, ios.newSymbol(G2S2Constants.APP_CONFIG_KEYS_TABLE));
        appConfigKey.put(G2S2Constants.APP_CONFIG_NAME, ios.newSymbol(G2S2Constants.APP_CONFIG_NAME_VALUE));
        appConfigKey.put(G2S2Constants.APP_CONFIG_KEY, ios.newSymbol(key));
        appConfigKey.put(G2S2Constants.STAGE_VERSION, ios.newString(stageVersion));
        return appConfigKey;
    }

    @Override
    protected G2S2InternalRepositoryClient getRepositoryClientWithCache() {
        return G2S2FullFeatureRepositoryClientHolder.readWriteClient;
    }

    @Override
    protected G2S2InternalRepositoryClient getRepositoryClient() {
        return G2S2FullFeatureRepositoryClientHolder.readWriteCachedClient;
    }
    
    /**
     * use static nested class to delay G2S2RepositoryClient init, another implement for lazy init.
     * @author xlpeng
     *
     */
    static class G2S2FullFeatureRepositoryClientHolder {
        static G2S2InternalRepositoryClient readWriteClient;
        static G2S2InternalRepositoryClient readWriteCachedClient;
        static{
            if(!usingMockedG2S2Repository){
                initialize();
            }
        }
        public static void initialize() {
        	String g2s2WriteEndpoint = AppConfig.findString(g2s2WriteEndpointConfigKey);
            readWriteClient = new InternalRESTClient(ios, g2s2WriteEndpoint);
            
            QueryCache<Object, Object> cache = new ConcurrentQueryCache<Object, Object>();
            cache.setMaxQuestions(MAX_CACHE_QUESTIONS);
            cache.setMaxAnswers(MAX_CACHE_ANSWERS);
            readWriteCachedClient = new FullCachingClient(G2S2FullFeatureRepositoryClientHolder.readWriteClient, cache);
        }
    }
}
