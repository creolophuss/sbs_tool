package com.amazon.oih.dao.shipcosts;

import com.amazon.oih.dao.hbase.base.AsinScopeValueHBaseObject;
import com.amazon.oih.dao.hbase.base.CommonKVHBaseDao.HTable;


@HTable("AsinShipoutCostInfo")
public class AsinShipoutCostInfoHBaseObject extends AsinScopeValueHBaseObject<AsinShipoutCostInfo> {

    @Override
    public AsinShipoutCostInfo toApplicationObject() {
        return AsinShipoutCostInfoEncoder.hBaseObjectToAsinShipoutCostInfo(this);
    }
}
