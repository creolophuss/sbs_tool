package com.amazon.oih.dao.g2s2;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;

import amazon.iop.metadata.g2s2.client.G2S2Exception;

import com.amazon.oih.dao.g2s2.exceptions.G2S2ConnectionException;
/**
 * 
 * simple transaction that control g2s2 writing process.
 * 1.open a write transaction &lt;br&gt;
 *   create a new stage version for writing based on the latest stage version on stage version label(like branch in version control system.)
 * 2.commit change.&lt;br&gt;
 *   freeze the writing stage version and promote the change to stage version label, and the changes will take effect.(like integrate code change for development branch to release branch.)
 * 3.close transaction.
 *   remove transaction instance from ThreadLocal
 *   
 * G2S2WriteTransaction doesn't support rollback feature, for g2s2 dose not support remove and rollback.
 * 
 */
public class G2S2WriteTransaction {
    private static final ThreadLocal<G2S2WriteTransaction> transactionHolder = new ThreadLocal<G2S2WriteTransaction>();
    private static final String STAGE_VERSION_PREFIX = "OIH";
    private String newStageVersion;
    private String latestStageVersion;
    private G2S2AppConfigsReadWriteDao g2s2AppConfigsAccessLayer;

    private G2S2WriteTransaction(G2S2AppConfigsReadWriteDao g2s2AppConfigsAccessLayer) {
        this.g2s2AppConfigsAccessLayer = g2s2AppConfigsAccessLayer;

        DateFormat df = new SimpleDateFormat("yyyy-MM-ddHH:mm:ss.SSS");
        String strIndex = df.format(new Date());
        newStageVersion = STAGE_VERSION_PREFIX + strIndex + (int) Math.random() * 1000000;
        try {
            latestStageVersion = g2s2AppConfigsAccessLayer.findLatestStageVersionFromG2S2(true);
            g2s2AppConfigsAccessLayer.getG2S2InternalRepositoryClient().createStageVersion(newStageVersion,
                    latestStageVersion, null);
        } catch (G2S2Exception e) {
            throw new G2S2ConnectionException("G2S2Exception is thrown by G2S2 when create stage version from G2S2!", e);
        } catch (UnsupportedOperationException e) {
            throw new G2S2ConnectionException(
                    "UnsupportedOperationException is thrown by G2S2 when create stage version from G2S2!", e);
        }
    }

    /**
     * get a G2S2WriteTransaction, maybe will create a new stage version
     * 
     * @param g2s2AppConfigsAccessLayer
     * @return
     */
    static G2S2WriteTransaction getWriteTransaction(G2S2AppConfigsReadWriteDao g2s2AppConfigsAccessLayer) {
        if (hasTransaction()) {
            return transactionHolder.get();
        }
        G2S2WriteTransaction writeTransaction = new G2S2WriteTransaction(g2s2AppConfigsAccessLayer);
        transactionHolder.set(writeTransaction);
        return writeTransaction;
    }

    /**
     * freeze stage version and promote the new stage version to stage version label, and remove G2S2WriteTransaction
     * instance from thread local
     */
    public void commit() {
        if (transactionHolder.get() == null) {
            return;
        }
        try {
            g2s2AppConfigsAccessLayer.getG2S2InternalRepositoryClient().freezeStageVersion(newStageVersion);
            g2s2AppConfigsAccessLayer.getG2S2InternalRepositoryClient().promote(
                    g2s2AppConfigsAccessLayer.getG2S2ClientConfig().getG2s2StageVersionLabel(), newStageVersion, Collections.<String, String>emptyMap());
        } catch (G2S2Exception e) {
            throw new G2S2ConnectionException("G2S2Exception is thrown by G2S2 when promote change into G2S2!", e);
        } catch (UnsupportedOperationException e) {
            throw new G2S2ConnectionException(
                    "UnsupportedOperationException is thrown by G2S2 when promote change into G2S2!", e);
        }
    }

    /**
     * remove G2S2WriteTransaction instance from thread local
     */
    public void close() {
        transactionHolder.remove();
    }

    public static boolean hasTransaction() {
        return transactionHolder.get() != null;
    }

    public String getNewStageVersion() {
        return newStageVersion;
    }

    public String getLatestStageVersion() {
        return latestStageVersion;
    }

}
