package com.amazon.oih.dao.g2s2.exceptions;

public class EmptyConfigKeyException extends RuntimeException {
    private static final long serialVersionUID = 8893322930030317084L;

    public EmptyConfigKeyException() {
    }

    public EmptyConfigKeyException(String s) {
        super(s);
    }

    public EmptyConfigKeyException(String s, Throwable throwable) {
        super(s, throwable);
    }

    public EmptyConfigKeyException(Throwable throwable) {
        super(throwable);
    }
}
