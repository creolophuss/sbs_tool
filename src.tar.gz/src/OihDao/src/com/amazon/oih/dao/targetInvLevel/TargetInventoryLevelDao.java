package com.amazon.oih.dao.targetInvLevel;

import java.util.List;

import com.amazon.oih.dao.exception.OihPersistenceException;
import com.amazon.oih.utils.AsinIogPair;

public interface TargetInventoryLevelDao {
    public abstract void save(TargetInventoryLevel o) throws OihPersistenceException;

    public abstract void save(List<TargetInventoryLevel> tils) throws OihPersistenceException;

    public abstract boolean exists(Long runId, String asin, Integer iog) throws OihPersistenceException;

    public abstract TargetInventoryLevel find(Long runId, String asin, Integer iog) throws OihPersistenceException;

    public abstract List<TargetInventoryLevel> find(Long runId, List<AsinIogPair> asinIogPairs)
            throws OihPersistenceException;

    public abstract TargetInventoryLevel createTargetInventoryLevel(Long runid, String asin, Integer iog, Integer til,
            Integer carton_qty);

    public abstract void delete(TargetInventoryLevel o) throws OihPersistenceException;

    public abstract void deleteAll() throws OihPersistenceException;

    public abstract Integer getTotalCountByRunId(Long runId) throws OihPersistenceException;

    public abstract Integer getInvalidTILCountByRunId(Long runId) throws OihPersistenceException;

}
