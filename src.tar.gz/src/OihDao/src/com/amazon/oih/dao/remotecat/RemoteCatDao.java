package com.amazon.oih.dao.remotecat;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import amazon.platform.profiler.Profiler;
import amazon.platform.profiler.ProfilerScope;

import com.amazon.carbonado.ConfigurationException;
import com.amazon.carbonado.FetchException;
import com.amazon.carbonado.IsolationLevel;
import com.amazon.carbonado.PersistException;
import com.amazon.carbonado.Repository;
import com.amazon.carbonado.RepositoryException;
import com.amazon.carbonado.Storage;
import com.amazon.carbonado.Transaction;
import com.amazon.oih.dao.exception.DaoRuntimeException;
import com.amazon.oih.dao.exception.OihPersistenceException;
import com.google.common.base.Joiner;

/**
 * This is no longer used, know we are reading the HBase even for single machine version.
 * @author zhongwei
 * 
 */
@Deprecated
public class RemoteCatDao implements IRemoteCatDao {
    protected String domain = null;
    protected Repository repository = null;

    public RemoteCatDao(String domain) {
        this.domain = domain;
    }

    public void setRepository(Repository repository) {
        if (null == repository) {
            throw new IllegalArgumentException("repository is null");
        }
        this.repository = repository;
    }

    @Override
    public RemoteCat createRemoteCat(long runId, RemoteCatValueObject valueObject) throws OihPersistenceException {
        return new RemoteCat(runId, valueObject);
    }

    @Override
    public boolean exists(Long runId, String asin, long marketplaceId, long merchantId) throws OihPersistenceException {
        ProfilerScope scope = Profiler.scopeStart(this.getClass().getName() + "::existsWithVendor");

        try {
            Storage<RemoteCatBDB> sf = repository.storageFor(RemoteCatBDB.class);
            boolean retVal = sf.query("runID = ? & asin = ? & marketplace = ? & merchant = ?")
                               .with(runId).with(asin).with(marketplaceId).with(merchantId).exists();

            return retVal;
        } catch (ConfigurationException e) {
            throw new DaoRuntimeException(e);
        } catch (RepositoryException e) {
            throw new OihPersistenceException(e);
        } finally {
            Profiler.scopeEnd(scope);
        }

    }

    @Override
    public RemoteCat find(Long runId, String asin, long marketplaceId, long merchantId) throws OihPersistenceException {
        ProfilerScope scope = Profiler.scopeStart(this.getClass().getName() + "::find");

        try {
            Storage<RemoteCatBDB> sf = repository.storageFor(RemoteCatBDB.class);
            return convert(sf.query("runID = ? & asin = ? & marketplace = ? & merchant = ?").with(runId).with(asin).with(marketplaceId).with(merchantId).loadOne());
        } catch (FetchException e) {// find nothing from the DB
            return null;
        } catch (Exception e) {
            throw new OihPersistenceException(e);
        } finally {
            Profiler.scopeEnd(scope);
        }
    }
    
    @Override
    public List<RemoteCat> find(Long runId, List<String> asins, long marketplaceId, long merchantId) throws OihPersistenceException {
        ProfilerScope scope = Profiler.scopeStart(this.getClass().getName() + "::find");

        try {
            Storage<RemoteCatBDB> sf = repository.storageFor(RemoteCatBDB.class);
            return convert(sf.query("runID = ? & asin in (?) & marketplace = ? & merchant = ?").with(runId).
                    with(concatStrings(asins)).with(marketplaceId).with(merchantId).fetch().toList());
        } catch (FetchException e) {// find nothing from the DB
            return null;
        } catch (Exception e) {
            throw new OihPersistenceException(e);
        } finally {
            Profiler.scopeEnd(scope);
        }
    }

    @Override
    public void save(List<RemoteCat> remoteCats) throws OihPersistenceException {
        Transaction txn = repository.enterTransaction(IsolationLevel.READ_UNCOMMITTED);
        try {
            for (RemoteCat remoteCat : remoteCats) {
                RemoteCatBDB rcBDB = convert(remoteCat);
                if (!rcBDB.tryLoad()) {
                    rcBDB.insert();
                }
            }

            txn.commit();
        } catch (PersistException e) {
            throw new OihPersistenceException(e);
        } catch (Exception e) {
            throw new DaoRuntimeException(e);
        } finally {
            exitTransaction(txn);
        }
    }

    @Override
    public void save(RemoteCat remoteCat) throws OihPersistenceException {
        ProfilerScope scope = Profiler.scopeStart(this.getClass().getName() + "::save");
        try {
            RemoteCatBDB rcBDB = convert(remoteCat);
            rcBDB.insert();
        } catch (PersistException e) {
            throw new OihPersistenceException(e);
        } finally {
            Profiler.scopeEnd(scope);
        }
    }

    private String concatStrings(Collection<String> strings) {
        Joiner joiner = Joiner.on("','");
        StringBuilder sb = new StringBuilder();
        joiner.appendTo(sb, strings);
        return "'" + sb.toString() + "'";
    }
    
    private void exitTransaction(Transaction txn) throws OihPersistenceException {
        try {
            txn.exit();
        } catch (PersistException e) {
            throw new OihPersistenceException(e);
        }
    }
    
    private RemoteCatBDB convert(RemoteCat remoteCat) throws OihPersistenceException{
        ProfilerScope scope = Profiler.scopeStart(this.getClass().getName() + "::create");
        //TODO use fileds
        try {
            Storage<RemoteCatBDB> sRemoteCat = repository.storageFor(RemoteCatBDB.class);
            RemoteCatBDB myRemoteCat = sRemoteCat.prepare();
            myRemoteCat.setRunID(remoteCat.getRunId());
            myRemoteCat.setAsin(remoteCat.getAsin());
            myRemoteCat.setMarketplace(remoteCat.getMarketplace());
            myRemoteCat.setMerchant(remoteCat.getMerchant());
            myRemoteCat.setBinding(remoteCat.getBinding());
            myRemoteCat.setBrandName(remoteCat.getBrandName());
            myRemoteCat.setBrandCode(remoteCat.getBrandCode());
            myRemoteCat.setCategory(remoteCat.getCategory());
            myRemoteCat.setEan(remoteCat.getEan());
            myRemoteCat.setGl(remoteCat.getGl());
            myRemoteCat.setHazmatException(remoteCat.getHazmatException());
            myRemoteCat.setHazmatItem(remoteCat.getHazmatItem());
            myRemoteCat.setHazmatTransportationRegularClass(remoteCat.getHazmatTransportationRegularClass());
            myRemoteCat.setMapRequired(remoteCat.getMapRequired());
            myRemoteCat.setUnPrepRequired(remoteCat.isUnPrepRequired());
            myRemoteCat.setListPrice(remoteCat.getListPrice());
            myRemoteCat.setMapEndDate(remoteCat.getMapEndDate());
            myRemoteCat.setMapPrice(remoteCat.getMapPrice());
            myRemoteCat.setMapStrict(remoteCat.getMapStrict());
            myRemoteCat.setMapStrictPrice(remoteCat.getMapStrictPrice());
            myRemoteCat.setModelNumber(remoteCat.getModelNumber());
            myRemoteCat.setOurPrice(remoteCat.getOurPrice());
            myRemoteCat.setParentAsin(remoteCat.getParentAsin());
            myRemoteCat.setPublicationDate(remoteCat.getPublicationDate());
            myRemoteCat.setPublisherCode(remoteCat.getPublisherCode());
            myRemoteCat.setReleaseDate(remoteCat.getReleaseDate());
            myRemoteCat.setReplenishmentCategory(remoteCat.getReplenishmentCategory());
            myRemoteCat.setSeasons(remoteCat.getSeasons());
            myRemoteCat.setSiteLaunchDate(remoteCat.getSiteLaunchDate());
            myRemoteCat.setSourceCountryCode(remoteCat.getSourceCountryCode());
            myRemoteCat.setSubCategory(remoteCat.getSubCategory());
            myRemoteCat.setTextbookType(remoteCat.getTextbookType());
            myRemoteCat.setTitle(remoteCat.getTitle());
            myRemoteCat.setUpc(remoteCat.getUpc());
            myRemoteCat.setModelYear(remoteCat.getModelYear());
            myRemoteCat.setFormat(remoteCat.getFormat());
            myRemoteCat.setRestrictedPriceDiscountCountry(remoteCat.getRestrictedPriceDiscountCountry());
            myRemoteCat.setAvailability(remoteCat.getAvailability());
            myRemoteCat.setRetailOffer(remoteCat.getRetailOffer());
            
            return myRemoteCat;
        } catch (ConfigurationException e) {
            throw new DaoRuntimeException(e);
        } catch (RepositoryException e) {
            throw new OihPersistenceException(e);
        } finally {
            Profiler.scopeEnd(scope);
        }
    }
    
    private List<RemoteCat> convert(List<RemoteCatBDB> remoteCatBDBs){
        if (remoteCatBDBs == null || remoteCatBDBs.size() == 0) {
            return null;
        }
        List<RemoteCat> remoteCats = new ArrayList<RemoteCat>();
        for (RemoteCatBDB remoteCatBdb : remoteCatBDBs) {
            remoteCats.add(convert(remoteCatBdb));
        }
        return remoteCats;
    }
    
    private RemoteCat convert(RemoteCatBDB remoteCatBDB){
        RemoteCat myRemoteCat = new RemoteCat();
        myRemoteCat.setAsin(remoteCatBDB.getAsin());
        myRemoteCat.setMarketplace(remoteCatBDB.getMarketplace());
        myRemoteCat.setMerchant(remoteCatBDB.getMerchant());
        myRemoteCat.setBinding(remoteCatBDB.getBinding());
        myRemoteCat.setBrandName(remoteCatBDB.getBrandName());
        myRemoteCat.setBrandCode(remoteCatBDB.getBrandCode());
        myRemoteCat.setCategory(remoteCatBDB.getCategory());
        myRemoteCat.setEan(remoteCatBDB.getEan());
        myRemoteCat.setGl(remoteCatBDB.getGl());
        myRemoteCat.setHazmatException(remoteCatBDB.getHazmatException());
        myRemoteCat.setHazmatItem(remoteCatBDB.getHazmatItem());
        myRemoteCat.setHazmatTransportationRegularClass(remoteCatBDB.getHazmatTransportationRegularClass());
        myRemoteCat.setMapRequired(remoteCatBDB.getMapRequired());
        myRemoteCat.setUnPrepRequired(remoteCatBDB.isUnPrepRequired());
        myRemoteCat.setListPrice(remoteCatBDB.getListPrice());
        myRemoteCat.setMapEndDate(remoteCatBDB.getMapEndDate());
        myRemoteCat.setMapPrice(remoteCatBDB.getMapPrice());
        myRemoteCat.setMapStrict(remoteCatBDB.getMapStrict());
        myRemoteCat.setMapStrictPrice(remoteCatBDB.getMapStrictPrice());
        myRemoteCat.setModelNumber(remoteCatBDB.getModelNumber());
        myRemoteCat.setOurPrice(remoteCatBDB.getOurPrice());
        myRemoteCat.setParentAsin(remoteCatBDB.getParentAsin());
        myRemoteCat.setPublicationDate(remoteCatBDB.getPublicationDate());
        myRemoteCat.setPublisherCode(remoteCatBDB.getPublisherCode());
        myRemoteCat.setReleaseDate(remoteCatBDB.getReleaseDate());
        myRemoteCat.setReplenishmentCategory(remoteCatBDB.getReplenishmentCategory());
        myRemoteCat.setSeasons(remoteCatBDB.getSeasons());
        myRemoteCat.setSiteLaunchDate(remoteCatBDB.getSiteLaunchDate());
        myRemoteCat.setSourceCountryCode(remoteCatBDB.getSourceCountryCode());
        myRemoteCat.setSubCategory(remoteCatBDB.getSubCategory());
        myRemoteCat.setTextbookType(remoteCatBDB.getTextbookType());
        myRemoteCat.setTitle(remoteCatBDB.getTitle());
        myRemoteCat.setUpc(remoteCatBDB.getUpc());
        myRemoteCat.setModelYear(remoteCatBDB.getModelYear());
        myRemoteCat.setFormat(remoteCatBDB.getFormat());
        myRemoteCat.setRestrictedPriceDiscountCountry(remoteCatBDB.getRestrictedPriceDiscountCountry());
        myRemoteCat.setAvailability(remoteCatBDB.getAvailability());
        myRemoteCat.setRetailOffer(remoteCatBDB.getRetailOffer());
        
        return myRemoteCat;
    }
    
    
}
