package com.amazon.oih.dao.forecastnew;

import java.util.*;

import javax.naming.NamingException;
import com.amazon.carbonado.*;
import com.amazon.oih.dao.forecast.ForecastType;

public interface ForecastNewDao {
    void save(ForecastNew o) throws PersistException;
    void save(Collection<ForecastNew> o) throws PersistException;
    
    boolean exists(Long runId, String asin, Integer iog, String realm)
        throws NamingException, RepositoryException, ClassNotFoundException;

    /**
     * Return forecasts for the given runId and asin.  Includes all forecast types and periods.
     * @param runId the runId
     * @param asin the asin
     * @param iog 
     * @return all forecasts for the given runId and asin
     * @throws NamingException
     * @throws RepositoryException
     * @throws ClassNotFoundException
     */
    Collection<? extends ForecastNew> find(Long runId, String asin, Integer iog, String realm)
        throws NamingException, RepositoryException, ClassNotFoundException;

    /**
     * Return forecasts for the given runId and asin and type.  Includes all forecast periods.
     * @param runId the runId
     * @param asin the asin
     * @param iog the iog
     * @param type the type of forecast
     * @return all forecasts for the given runId, asin, and type
     * @throws NamingException
     * @throws RepositoryException
     * @throws ClassNotFoundException
     */
    Collection<? extends ForecastNew> find(Long runId, String asin, Integer iog, ForecastType type, String realm)
       throws NamingException, RepositoryException, ClassNotFoundException;
    
    List<? extends ForecastNew> findOrderedByProbability(Long runId, String asin, Integer iog, ForecastType type, String realm)
    throws NamingException, RepositoryException, ClassNotFoundException;

    ForecastNew createForecast(Long runId, String asin, Integer iog, ForecastType type, Double probability, List<Double> forecasts, String realm) 
        throws NamingException, RepositoryException, ClassNotFoundException;
}
