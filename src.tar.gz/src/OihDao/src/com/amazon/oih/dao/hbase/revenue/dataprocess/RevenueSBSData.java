package com.amazon.oih.dao.hbase.revenue.dataprocess;

public class RevenueSBSData {

    public String asin;
    public String gl;

    public int maxInventory;

    public double revenue;
    public double ourprice;

    public String getAsin() {
        return asin;
    }

    public void setAsin(String asin) {
        this.asin = asin;
    }

    public String getGl() {
        return gl;
    }

    public void setGl(String gl) {
        this.gl = gl;
    }

    public double getRevenue() {
        return revenue;
    }

    public void setRevenue(double revenue) {
        this.revenue = revenue;
    }

    public double getOurprice() {
        return ourprice;
    }

    public void setOurprice(double ourprice) {
        this.ourprice = ourprice;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((asin == null) ? 0 : asin.hashCode());
        result = prime * result + ((gl == null) ? 0 : gl.hashCode());
        result = prime * result + maxInventory;
        long temp;
        temp = Double.doubleToLongBits(ourprice);
        result = prime * result + (int) (temp ^ (temp >>> 32));
        temp = Double.doubleToLongBits(revenue);
        result = prime * result + (int) (temp ^ (temp >>> 32));
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        RevenueSBSData other = (RevenueSBSData) obj;
        if (asin == null) {
            if (other.asin != null)
                return false;
        } else if (!asin.equals(other.asin))
            return false;
        if (gl == null) {
            if (other.gl != null)
                return false;
        } else if (!gl.equals(other.gl))
            return false;
        if (maxInventory != other.maxInventory)
            return false;
        if (Double.doubleToLongBits(ourprice) != Double.doubleToLongBits(other.ourprice))
            return false;
        if (Double.doubleToLongBits(revenue) != Double.doubleToLongBits(other.revenue))
            return false;
        return true;
    }

    public int getMaxInventory() {
        return maxInventory;
    }

    public void setMaxInventory(int maxInventory) {
        this.maxInventory = maxInventory;
    }

    @Override
    public String toString() {
        return "RevenueSBSData [asin=" + asin + ", gl=" + gl + ", maxInventory=" + maxInventory + ", revenue="
                + revenue + ", ourprice=" + ourprice + "]";
    }

}
