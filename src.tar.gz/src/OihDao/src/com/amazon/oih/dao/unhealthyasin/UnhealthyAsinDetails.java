package com.amazon.oih.dao.unhealthyasin;

import java.util.Date;

public class UnhealthyAsinDetails {
    private long sequenceId;
    private Date rundate;
    private String asin;
    private Integer iog;
    private Integer gl;
    private Integer targetInventoryLevel;
    private Integer totalInventory;
    private Double weeklyForecastDemand;
    private Double weeklyCptlHoldingCost;
    private Integer oneWeekHistoricDemand;
    private Integer twoWeeksHistoricDemand;
    private Integer threeWeeksHistoricDemand;
    private Integer fourWeeksHistoricDemand;
    private Integer oneYearHistoricDemand;
    private Double ourPrice;
    private Double costUsedForCalculations;
    private Double vendorCost;
    private Double retailContribution;
    private Double returnContribution;
    private String titleDescription;
    private Double cube;
    private Date publicationDate;
    private Date releaseDate;
    private Integer sortType;
    private String upc;
    private Boolean isUnprepRequired;
    private Integer allocatedInventory;
    private Integer inProcessInventory;
    private Integer unsellableInventory;
    private String warehouse;
    private String vendor;
    private Integer orderType;
    private String removalType;
    private Double weeklyFcHoldingCost;
    private Double fcReceiptCost;
    private Double fcRemovalCost;
    private Double removalAmount;       
    private Double totalSavings;
    private Integer unhealthyQuantity;
    private Integer healthyQuantity;
    private String dsiId;
    private Date receiptDate;
    private Date cannotReturnBefore;
    private Date mustReturnBefore;
    private String doId;
    private String dsId;
    private Date doDate;
    private Date dsDate;
    private Double distributorPrice;
    private Double distributorCost;
    private String exclusionReason;
    private String excludedVendor;
    private Integer excludedOrderType;
    private String excludedRemovalType;
    private Double excludedRemovalAmount;
    private Double excludedTotalSavings;
    private Integer excludedUnhealthyQuantity;
    private String excludedDsiId;
    private Date excludedReceiptDate;
    private Date excludedCannotReturnBefore;
    private Date excludedMustReturnBefore;
    private String excludedDoId;
    private String excludedDsId;
    private Date excludedDoDate;
    private Date excludedDsDate;
    private Double excludedDistributorPrice;
    private Double excludedDistributorCost;
    private String category;
    private String subCategory;
    private Double markdownQty;
    private Double markdownPrice;
    private Double markdownDuration;
    private Double markdownDemandFactor;    
    private Double elasticity;
    private Double totalHealthyQuantity;
    private Double totalUnhealthyQuantity;
    private Double totalHealthyWoc;
    private Double totalWoc;
    private Double warehouseQuantity;
    private String vendorName;
    private String shipToName;
    private String shipToAddressLine1;
    private String shipToAddressLine2;
    private String shipToAddressLine3;
    private String shipToAddressCity;
    private String shipToAddressState;
    private String shipToAddressProvince;
    private String shipToAddressPostalCode;
    private String shipToAddressCountryCode;
    private String ean;
    private Double listPrice;
    private Double mapPrice;
    private Boolean isMapRequired;
    private String publisherCode;
    private Double costUsedForReporting;
    private String parentAsin;
    private String replenishmentCategory;
    private String childAsin;
    private Integer bundleQuantity;
    private Boolean isForcedMarkdown;
    private String meanAge;
    private Boolean isDeadwood;
    private String fcsku;
    private Date expirationDate;
    private String realm;
    private String dsiCurrency;
    private String foreignCurrencyCode;
    private Double refundAmountForeignCurrency;
    private Double costForeignCurrency;
    private Double distributorListPriceFcur;
    private Double distributorCostFcur;
    public Date getRundate() {
        return rundate;
    }
    public void setRundate(Date rundate) {
        this.rundate = rundate;
    }
    public String getAsin() {
        return asin;
    }
    public void setAsin(String asin) {
        this.asin = asin;
    }
    public Integer getIog() {
        return iog;
    }
    public void setIog(Integer iog) {
        this.iog = iog;
    }
    public Integer getGl() {
        return gl;
    }
    public void setGl(Integer gl) {
        this.gl = gl;
    }
    public Integer getTargetInventoryLevel() {
        return targetInventoryLevel;
    }
    public void setTargetInventoryLevel(Integer targetInventoryLevel) {
        this.targetInventoryLevel = targetInventoryLevel;
    }
    public Integer getTotalInventory() {
        return totalInventory;
    }
    public void setTotalInventory(Integer totalInventory) {
        this.totalInventory = totalInventory;
    }
    public Double getWeeklyForecastDemand() {
        return weeklyForecastDemand;
    }
    public void setWeeklyForecastDemand(Double weeklyForecastDemand) {
        this.weeklyForecastDemand = weeklyForecastDemand;
    }
    public Double getWeeklyCptlHoldingCost() {
        return weeklyCptlHoldingCost;
    }
    public void setWeeklyCptlHoldingCost(Double weeklyCptlHoldingCost) {
        this.weeklyCptlHoldingCost = weeklyCptlHoldingCost;
    }
    public Integer getOneWeekHistoricDemand() {
        return oneWeekHistoricDemand;
    }
    public void setOneWeekHistoricDemand(Integer oneWeekHistoricDemand) {
        this.oneWeekHistoricDemand = oneWeekHistoricDemand;
    }
    public Integer getTwoWeeksHistoricDemand() {
        return twoWeeksHistoricDemand;
    }
    public void setTwoWeeksHistoricDemand(Integer twoWeeksHistoricDemand) {
        this.twoWeeksHistoricDemand = twoWeeksHistoricDemand;
    }
    public Integer getThreeWeeksHistoricDemand() {
        return threeWeeksHistoricDemand;
    }
    public void setThreeWeeksHistoricDemand(Integer threeWeeksHistoricDemand) {
        this.threeWeeksHistoricDemand = threeWeeksHistoricDemand;
    }
    public Integer getFourWeeksHistoricDemand() {
        return fourWeeksHistoricDemand;
    }
    public void setFourWeeksHistoricDemand(Integer fourWeeksHistoricDemand) {
        this.fourWeeksHistoricDemand = fourWeeksHistoricDemand;
    }
    public Integer getOneYearHistoricDemand() {
        return oneYearHistoricDemand;
    }
    public void setOneYearHistoricDemand(Integer oneYearHistoricDemand) {
        this.oneYearHistoricDemand = oneYearHistoricDemand;
    }
    public Double getOurPrice() {
        return ourPrice;
    }
    public void setOurPrice(Double ourPrice) {
        this.ourPrice = ourPrice;
    }
    public Double getCostUsedForCalculations() {
        return costUsedForCalculations;
    }
    public void setCostUsedForCalculations(Double costUsedForCalculations) {
        this.costUsedForCalculations = costUsedForCalculations;
    }
    public Double getVendorCost() {
        return vendorCost;
    }
    public void setVendorCost(Double vendorCost) {
        this.vendorCost = vendorCost;
    }
    public Double getRetailContribution() {
        return retailContribution;
    }
    public void setRetailContribution(Double retailContribution) {
        this.retailContribution = retailContribution;
    }
    public Double getReturnContribution() {
        return returnContribution;
    }
    public void setReturnContribution(Double returnContribution) {
        this.returnContribution = returnContribution;
    }
    public String getTitleDescription() {
        return titleDescription;
    }
    public void setTitleDescription(String titleDescription) {
        this.titleDescription = titleDescription;
    }
    public Double getCube() {
        return cube;
    }
    public void setCube(Double cube) {
        this.cube = cube;
    }
    public Date getPublicationDate() {
        return publicationDate;
    }
    public void setPublicationDate(Date publicationDate) {
        this.publicationDate = publicationDate;
    }
    public Date getReleaseDate() {
        return releaseDate;
    }
    public void setReleaseDate(Date releaseDate) {
        this.releaseDate = releaseDate;
    }
    public Integer getSortType() {
        return sortType;
    }
    public void setSortType(Integer sortType) {
        this.sortType = sortType;
    }
    public String getUpc() {
        return upc;
    }
    public void setUpc(String upc) {
        this.upc = upc;
    }
    public Boolean getIsUnprepRequired() {
        return isUnprepRequired;
    }
    public void setIsUnprepRequired(Boolean isUnprepRequired) {
        this.isUnprepRequired = isUnprepRequired;
    }
    public Integer getAllocatedInventory() {
        return allocatedInventory;
    }
    public void setAllocatedInventory(Integer allocatedInventory) {
        this.allocatedInventory = allocatedInventory;
    }
    public Integer getInProcessInventory() {
        return inProcessInventory;
    }
    public void setInProcessInventory(Integer inProcessInventory) {
        this.inProcessInventory = inProcessInventory;
    }
    public Integer getUnsellableInventory() {
        return unsellableInventory;
    }
    public void setUnsellableInventory(Integer unsellableInventory) {
        this.unsellableInventory = unsellableInventory;
    }
    public String getWarehouse() {
        return warehouse;
    }
    public void setWarehouse(String warehouse) {
        this.warehouse = warehouse;
    }
    public String getVendor() {
        return vendor;
    }
    public void setVendor(String vendor) {
        this.vendor = vendor;
    }
    public Integer getOrderType() {
        return orderType;
    }
    public void setOrderType(Integer orderType) {
        this.orderType = orderType;
    }
    public String getRemovalType() {
        return removalType;
    }
    public void setRemovalType(String removalType) {
        this.removalType = removalType;
    }
    public Double getWeeklyFcHoldingCost() {
        return weeklyFcHoldingCost;
    }
    public void setWeeklyFcHoldingCost(Double weeklyFcHoldingCost) {
        this.weeklyFcHoldingCost = weeklyFcHoldingCost;
    }
    public Double getFcReceiptCost() {
        return fcReceiptCost;
    }
    public void setFcReceiptCost(Double fcReceiptCost) {
        this.fcReceiptCost = fcReceiptCost;
    }
    public Double getFcRemovalCost() {
        return fcRemovalCost;
    }
    public void setFcRemovalCost(Double fcRemovalCost) {
        this.fcRemovalCost = fcRemovalCost;
    }
    public Double getRemovalAmount() {
        return removalAmount;
    }
    public void setRemovalAmount(Double removalAmount) {
        this.removalAmount = removalAmount;
    }
    public Double getTotalSavings() {
        return totalSavings;
    }
    public void setTotalSavings(Double totalSavings) {
        this.totalSavings = totalSavings;
    }
    public Integer getUnhealthyQuantity() {
        return unhealthyQuantity;
    }
    public void setUnhealthyQuantity(Integer unhealthyQuantity) {
        this.unhealthyQuantity = unhealthyQuantity;
    }
    public Integer getHealthyQuantity() {
        return healthyQuantity;
    }
    public void setHealthyQuantity(Integer healthyQuantity) {
        this.healthyQuantity = healthyQuantity;
    }
    public String getDsiId() {
        return dsiId;
    }
    public void setDsiId(String dsiId) {
        this.dsiId = dsiId;
    }
    public Date getReceiptDate() {
        return receiptDate;
    }
    public void setReceiptDate(Date receiptDate) {
        this.receiptDate = receiptDate;
    }
    public Date getCannotReturnBefore() {
        return cannotReturnBefore;
    }
    public void setCannotReturnBefore(Date cannotReturnBefore) {
        this.cannotReturnBefore = cannotReturnBefore;
    }
    public Date getMustReturnBefore() {
        return mustReturnBefore;
    }
    public void setMustReturnBefore(Date mustReturnBefore) {
        this.mustReturnBefore = mustReturnBefore;
    }
    public String getDoId() {
        return doId;
    }
    public void setDoId(String doId) {
        this.doId = doId;
    }
    public String getDsId() {
        return dsId;
    }
    public void setDsId(String dsId) {
        this.dsId = dsId;
    }
    public Date getDoDate() {
        return doDate;
    }
    public void setDoDate(Date doDate) {
        this.doDate = doDate;
    }
    public Date getDsDate() {
        return dsDate;
    }
    public void setDsDate(Date dsDate) {
        this.dsDate = dsDate;
    }
    public Double getDistributorPrice() {
        return distributorPrice;
    }
    public void setDistributorPrice(Double distributorPrice) {
        this.distributorPrice = distributorPrice;
    }
    public Double getDistributorCost() {
        return distributorCost;
    }
    public void setDistributorCost(Double distributorCost) {
        this.distributorCost = distributorCost;
    }
    public String getExclusionReason() {
        return exclusionReason;
    }
    public void setExclusionReason(String exclusionReason) {
        this.exclusionReason = exclusionReason;
    }
    public String getExcludedVendor() {
        return excludedVendor;
    }
    public void setExcludedVendor(String excludedVendor) {
        this.excludedVendor = excludedVendor;
    }
    public Integer getExcludedOrderType() {
        return excludedOrderType;
    }
    public void setExcludedOrderType(Integer excludedOrderType) {
        this.excludedOrderType = excludedOrderType;
    }
    public String getExcludedRemovalType() {
        return excludedRemovalType;
    }
    public void setExcludedRemovalType(String excludedRemovalType) {
        this.excludedRemovalType = excludedRemovalType;
    }
    public Double getExcludedRemovalAmount() {
        return excludedRemovalAmount;
    }
    public void setExcludedRemovalAmount(Double excludedRemovalAmount) {
        this.excludedRemovalAmount = excludedRemovalAmount;
    }
    public Double getExcludedTotalSavings() {
        return excludedTotalSavings;
    }
    public void setExcludedTotalSavings(Double excludedTotalSavings) {
        this.excludedTotalSavings = excludedTotalSavings;
    }
    public Integer getExcludedUnhealthyQuantity() {
        return excludedUnhealthyQuantity;
    }
    public void setExcludedUnhealthyQuantity(Integer excludedUnhealthyQuantity) {
        this.excludedUnhealthyQuantity = excludedUnhealthyQuantity;
    }
    public String getExcludedDsiId() {
        return excludedDsiId;
    }
    public void setExcludedDsiId(String excludedDsiId) {
        this.excludedDsiId = excludedDsiId;
    }
    public Date getExcludedReceiptDate() {
        return excludedReceiptDate;
    }
    public void setExcludedReceiptDate(Date excludedReceiptDate) {
        this.excludedReceiptDate = excludedReceiptDate;
    }
    public Date getExcludedCannotReturnBefore() {
        return excludedCannotReturnBefore;
    }
    public void setExcludedCannotReturnBefore(Date excludedCannotReturnBefore) {
        this.excludedCannotReturnBefore = excludedCannotReturnBefore;
    }
    public Date getExcludedMustReturnBefore() {
        return excludedMustReturnBefore;
    }
    public void setExcludedMustReturnBefore(Date excludedMustReturnBefore) {
        this.excludedMustReturnBefore = excludedMustReturnBefore;
    }
    public String getExcludedDoId() {
        return excludedDoId;
    }
    public void setExcludedDoId(String excludedDoId) {
        this.excludedDoId = excludedDoId;
    }
    public String getExcludedDsId() {
        return excludedDsId;
    }
    public void setExcludedDsId(String excludedDsId) {
        this.excludedDsId = excludedDsId;
    }
    public Date getExcludedDoDate() {
        return excludedDoDate;
    }
    public void setExcludedDoDate(Date excludedDoDate) {
        this.excludedDoDate = excludedDoDate;
    }
    public Date getExcludedDsDate() {
        return excludedDsDate;
    }
    public void setExcludedDsDate(Date excludedDsDate) {
        this.excludedDsDate = excludedDsDate;
    }
    public Double getExcludedDistributorPrice() {
        return excludedDistributorPrice;
    }
    public void setExcludedDistributorPrice(Double excludedDistributorPrice) {
        this.excludedDistributorPrice = excludedDistributorPrice;
    }
    public Double getExcludedDistributorCost() {
        return excludedDistributorCost;
    }
    public void setExcludedDistributorCost(Double excludedDistributorCost) {
        this.excludedDistributorCost = excludedDistributorCost;
    }
    public String getCategory() {
        return category;
    }
    public void setCategory(String category) {
        this.category = category;
    }
    public String getSubCategory() {
        return subCategory;
    }
    public void setSubCategory(String subCategory) {
        this.subCategory = subCategory;
    }
    public Double getMarkdownQty() {
        return markdownQty;
    }
    public void setMarkdownQty(Double markdownQty) {
        this.markdownQty = markdownQty;
    }
    public Double getMarkdownPrice() {
        return markdownPrice;
    }
    public void setMarkdownPrice(Double markdownPrice) {
        this.markdownPrice = markdownPrice;
    }
    public Double getMarkdownDuration() {
        return markdownDuration;
    }
    public void setMarkdownDuration(Double markdownDuration) {
        this.markdownDuration = markdownDuration;
    }
    public Double getMarkdownDemandFactor() {
        return markdownDemandFactor;
    }
    public void setMarkdownDemandFactor(Double markdownDemandFactor) {
        this.markdownDemandFactor = markdownDemandFactor;
    }
    public Double getElasticity() {
        return elasticity;
    }
    public void setElasticity(Double elasticity) {
        this.elasticity = elasticity;
    }
    public Double getTotalHealthyQuantity() {
        return totalHealthyQuantity;
    }
    public void setTotalHealthyQuantity(Double totalHealthyQuantity) {
        this.totalHealthyQuantity = totalHealthyQuantity;
    }
    public Double getTotalUnhealthyQuantity() {
        return totalUnhealthyQuantity;
    }
    public void setTotalUnhealthyQuantity(Double totalUnhealthyQuantity) {
        this.totalUnhealthyQuantity = totalUnhealthyQuantity;
    }
    public Double getTotalHealthyWoc() {
        return totalHealthyWoc;
    }
    public void setTotalHealthyWoc(Double totalHealthyWoc) {
        this.totalHealthyWoc = totalHealthyWoc;
    }
    public Double getTotalWoc() {
        return totalWoc;
    }
    public void setTotalWoc(Double totalWoc) {
        this.totalWoc = totalWoc;
    }
    public Double getWarehouseQuantity() {
        return warehouseQuantity;
    }
    public void setWarehouseQuantity(Double warehouseQuantity) {
        this.warehouseQuantity = warehouseQuantity;
    }
    public String getVendorName() {
        return vendorName;
    }
    public void setVendorName(String vendorName) {
        this.vendorName = vendorName;
    }
    public String getShipToName() {
        return shipToName;
    }
    public void setShipToName(String shipToName) {
        this.shipToName = shipToName;
    }
    public String getShipToAddressLine1() {
        return shipToAddressLine1;
    }
    public void setShipToAddressLine1(String shipToAddressLine1) {
        this.shipToAddressLine1 = shipToAddressLine1;
    }
    public String getShipToAddressLine2() {
        return shipToAddressLine2;
    }
    public void setShipToAddressLine2(String shipToAddressLine2) {
        this.shipToAddressLine2 = shipToAddressLine2;
    }
    public String getShipToAddressLine3() {
        return shipToAddressLine3;
    }
    public void setShipToAddressLine3(String shipToAddressLine3) {
        this.shipToAddressLine3 = shipToAddressLine3;
    }
    public String getShipToAddressCity() {
        return shipToAddressCity;
    }
    public void setShipToAddressCity(String shipToAddressCity) {
        this.shipToAddressCity = shipToAddressCity;
    }
    public String getShipToAddressState() {
        return shipToAddressState;
    }
    public void setShipToAddressState(String shipToAddressState) {
        this.shipToAddressState = shipToAddressState;
    }
    public String getShipToAddressProvince() {
        return shipToAddressProvince;
    }
    public void setShipToAddressProvince(String shipToAddressProvince) {
        this.shipToAddressProvince = shipToAddressProvince;
    }
    public String getShipToAddressPostalCode() {
        return shipToAddressPostalCode;
    }
    public void setShipToAddressPostalCode(String shipToAddressPostalCode) {
        this.shipToAddressPostalCode = shipToAddressPostalCode;
    }
    public String getShipToAddressCountryCode() {
        return shipToAddressCountryCode;
    }
    public void setShipToAddressCountryCode(String shipToAddressCountryCode) {
        this.shipToAddressCountryCode = shipToAddressCountryCode;
    }
    public String getEan() {
        return ean;
    }
    public void setEan(String ean) {
        this.ean = ean;
    }
    public Double getListPrice() {
        return listPrice;
    }
    public void setListPrice(Double listPrice) {
        this.listPrice = listPrice;
    }
    public Double getMapPrice() {
        return mapPrice;
    }
    public void setMapPrice(Double mapPrice) {
        this.mapPrice = mapPrice;
    }
    public Boolean getIsMapRequired() {
        return isMapRequired;
    }
    public void setIsMapRequired(Boolean isMapRequired) {
        this.isMapRequired = isMapRequired;
    }
    public String getPublisherCode() {
        return publisherCode;
    }
    public void setPublisherCode(String publisherCode) {
        this.publisherCode = publisherCode;
    }
    public Double getCostUsedForReporting() {
        return costUsedForReporting;
    }
    public void setCostUsedForReporting(Double costUsedForReporting) {
        this.costUsedForReporting = costUsedForReporting;
    }
    public String getParentAsin() {
        return parentAsin;
    }
    public void setParentAsin(String parentAsin) {
        this.parentAsin = parentAsin;
    }
    public String getReplenishmentCategory() {
        return replenishmentCategory;
    }
    public void setReplenishmentCategory(String replenishmentCategory) {
        this.replenishmentCategory = replenishmentCategory;
    }
    public String getChildAsin() {
        return childAsin;
    }
    public void setChildAsin(String childAsin) {
        this.childAsin = childAsin;
    }
    public Integer getBundleQuantity() {
        return bundleQuantity;
    }
    public void setBundleQuantity(Integer bundleQuantity) {
        this.bundleQuantity = bundleQuantity;
    }
    public Boolean getIsForcedMarkdown() {
        return isForcedMarkdown;
    }
    public void setIsForcedMarkdown(Boolean isForcedMarkdown) {
        this.isForcedMarkdown = isForcedMarkdown;
    }
    public String getMeanAge() {
        return meanAge;
    }
    public void setMeanAge(String meanAge) {
        this.meanAge = meanAge;
    }
    public Boolean getIsDeadwood() {
        return isDeadwood;
    }
    public void setIsDeadwood(Boolean isDeadwood) {
        this.isDeadwood = isDeadwood;
    }
    public String getFcsku() {
        return fcsku;
    }
    public void setFcsku(String fcsku) {
        this.fcsku = fcsku;
    }
    public Date getExpirationDate() {
        return expirationDate;
    }
    public void setExpirationDate(Date expirationDate) {
        this.expirationDate = expirationDate;
    }
    public String getRealm() {
        return realm;
    }
    public void setRealm(String realm) {
        this.realm = realm;
    }
    public String getDsiCurrency() {
        return dsiCurrency;
    }
    public void setDsiCurrency(String dsiCurrency) {
        this.dsiCurrency = dsiCurrency;
    }
    public String getForeignCurrencyCode() {
        return foreignCurrencyCode;
    }
    public void setForeignCurrencyCode(String foreignCurrencyCode) {
        this.foreignCurrencyCode = foreignCurrencyCode;
    }
    public Double getRefundAmountForeignCurrency() {
        return refundAmountForeignCurrency;
    }
    public void setRefundAmountForeignCurrency(Double refundAmountForeignCurrency) {
        this.refundAmountForeignCurrency = refundAmountForeignCurrency;
    }
    public Double getCostForeignCurrency() {
        return costForeignCurrency;
    }
    public void setCostForeignCurrency(Double costForeignCurrency) {
        this.costForeignCurrency = costForeignCurrency;
    }
    
    @Override
    public String toString() {
        return "UnhealthyAsinDetails [rundate=" + rundate + ", asin=" + asin + ", iog=" + iog + ", gl=" + gl
                + ", warehouse=" + warehouse + ", vendor=" + vendor + ", removalType=" + removalType + ", dsiId="
                + dsiId + ", excludedVendor=" + excludedVendor + ", excludedDsiId=" + excludedDsiId + ", fcsku="
                + fcsku + "]";
    }
    public long getSequenceId() {
        return sequenceId;
    }
    public void setSequenceId(long sequenceId) {
        this.sequenceId = sequenceId;
    }
    public Double getDistributorListPriceFcur() {
        return distributorListPriceFcur;
    }
    public void setDistributorListPriceFcur(Double distributorListPriceFcur) {
        this.distributorListPriceFcur = distributorListPriceFcur;
    }
    public Double getDistributorCostFcur() {
        return distributorCostFcur;
    }
    public void setDistributorCostFcur(Double distributorCostFcur) {
        this.distributorCostFcur = distributorCostFcur;
    }
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((asin == null) ? 0 : asin.hashCode());
        result = prime * result + ((dsiId == null) ? 0 : dsiId.hashCode());
        result = prime * result + ((excludedDsiId == null) ? 0 : excludedDsiId.hashCode());
        result = prime * result + ((excludedVendor == null) ? 0 : excludedVendor.hashCode());
        result = prime * result + ((fcsku == null) ? 0 : fcsku.hashCode());
        result = prime * result + ((iog == null) ? 0 : iog.hashCode());
        result = prime * result + ((removalType == null) ? 0 : removalType.hashCode());
        result = prime * result + ((rundate == null) ? 0 : rundate.hashCode());
        result = prime * result + ((vendor == null) ? 0 : vendor.hashCode());
        result = prime * result + ((warehouse == null) ? 0 : warehouse.hashCode());
        return result;
    }
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        UnhealthyAsinDetails other = (UnhealthyAsinDetails) obj;
        if (asin == null) {
            if (other.asin != null)
                return false;
        } else if (!asin.equals(other.asin))
            return false;
        if (dsiId == null) {
            if (other.dsiId != null)
                return false;
        } else if (!dsiId.equals(other.dsiId))
            return false;
        if (excludedDsiId == null) {
            if (other.excludedDsiId != null)
                return false;
        } else if (!excludedDsiId.equals(other.excludedDsiId))
            return false;
        if (excludedVendor == null) {
            if (other.excludedVendor != null)
                return false;
        } else if (!excludedVendor.equals(other.excludedVendor))
            return false;
        if (fcsku == null) {
            if (other.fcsku != null)
                return false;
        } else if (!fcsku.equals(other.fcsku))
            return false;
        if (iog == null) {
            if (other.iog != null)
                return false;
        } else if (!iog.equals(other.iog))
            return false;
        if (removalType == null) {
            if (other.removalType != null)
                return false;
        } else if (!removalType.equals(other.removalType))
            return false;
        if (rundate == null) {
            if (other.rundate != null)
                return false;
        } else if (!rundate.equals(other.rundate))
            return false;
        if (vendor == null) {
            if (other.vendor != null)
                return false;
        } else if (!vendor.equals(other.vendor))
            return false;
        if (warehouse == null) {
            if (other.warehouse != null)
                return false;
        } else if (!warehouse.equals(other.warehouse))
            return false;
        return true;
    }

    
}
