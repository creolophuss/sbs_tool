package com.amazon.oih.dao.hbase.forecast;

public enum ForecastColumn {
    P10("P10", 0.1), 
    P20("P20", 0.2), 
    P30("P30", 0.3), 
    P40("P40", 0.4), 
    P50("P50", 0.5), 
    P60("P60", 0.6), 
    P70("P70", 0.7), 
    P80("P80", 0.8), 
    P90("P90", 0.9), 
    P50L("P50L", 0.0);

    private String code;
    private double probability;

    private ForecastColumn(String code, double probability) {
        this.code = code;
        this.probability = probability;
    }

    public static String getCodeByProbability(double probability) {
        for (ForecastColumn fc : ForecastColumn.values()) {
            if (Math.abs(fc.probability - probability) < 1e-6) {
                return fc.code;
            }
        }
        return null;
    }

    public String getCode() {
        return code;
    }

    public double getProbability() {
        return probability;
    }

}
