package com.amazon.oih.dao.recall;

import java.util.List;

import amazon.platform.profiler.Profiler;
import amazon.platform.profiler.ProfilerScope;

import com.amazon.carbonado.FetchException;
import com.amazon.carbonado.IsolationLevel;
import com.amazon.carbonado.PersistException;
import com.amazon.carbonado.Repository;
import com.amazon.carbonado.RepositoryException;
import com.amazon.carbonado.Storage;
import com.amazon.carbonado.SupportException;
import com.amazon.carbonado.Transaction;
import com.amazon.oih.dao.exception.DaoRuntimeException;
import com.amazon.oih.dao.exception.OihPersistenceException;

/**
 * 
 * @author zhongwei
 *
 */
public class RecallDao implements IRecallDao {
    protected Repository repository = null;

    public void setRepository(Repository repository) {
        if (null == repository) {
            throw new IllegalArgumentException("repository is null");
        }
        this.repository = repository;
    }

    @Override
    public RecallObject createRecall(RecallInfo valueObject) throws OihPersistenceException {
        ProfilerScope scope = Profiler.scopeStart(this.getClass().getName() + "::create");
        try {
            Storage<RecallObject> sRecall = repository.storageFor(RecallObject.class);
            RecallObject myRecall = sRecall.prepare();
            myRecall.setAsin(valueObject.getAsin());
            myRecall.setIog(Integer.valueOf(valueObject.getIog()));
            myRecall.setRecalled(valueObject.isRecalled());
            return myRecall;

        } catch (SupportException e) {
            throw new DaoRuntimeException(e);
        } catch (RepositoryException e) {
            throw new OihPersistenceException(e);
        } finally {
            Profiler.scopeEnd(scope);
        }
    }

    @Override
    public boolean exists(String asin, int iog) throws OihPersistenceException {
        ProfilerScope scope = Profiler.scopeStart(this.getClass().getName() + "::existsWithVendor");

        try {
            Storage<RecallObject> sf = repository.storageFor(RecallObject.class);
            return sf.query("asin = ? & iog = ? ").with(asin).with(iog).exists();
        } catch (SupportException e) {
            throw new DaoRuntimeException(e);
        } catch (RepositoryException e) {
            throw new OihPersistenceException(e);
        } finally {
            Profiler.scopeEnd(scope);
        }
    }

    @Override
    public RecallObject find(String asin, int iog) throws OihPersistenceException {
        ProfilerScope scope = Profiler.scopeStart(this.getClass().getName() + "::find");

        try {
            Storage<RecallObject> sf = repository.storageFor(RecallObject.class);
            return sf.query("asin = ? & iog = ? ").with(asin).with(iog).loadOne();
        } catch (FetchException e) {// find nothing from the DB
            return null;
        } catch (Exception e) {
            throw new OihPersistenceException(e);
        } finally {
            Profiler.scopeEnd(scope);
        }
    }

    @Override
    public void save(RecallObject recall) throws OihPersistenceException {
        ProfilerScope scope = Profiler.scopeStart(this.getClass().getName() + "::save");
        try {
            recall.insert();
        } catch (PersistException e) {
            throw new OihPersistenceException(e);
        } finally {
            Profiler.scopeEnd(scope);
        }
    }

    @Override
    public void save(List<RecallObject> recalls) throws OihPersistenceException {
        Transaction txn = repository.enterTransaction(IsolationLevel.READ_UNCOMMITTED);
        try {
            for (RecallObject recall : recalls) {
                if (!recall.tryLoad()) {
                    recall.insert();
                }
            }
            txn.commit();
        } catch (PersistException e) {
            throw new OihPersistenceException(e);
        } catch (Exception e) {
            throw new DaoRuntimeException(e);
        } finally {
            try {
                txn.exit();
            } catch (PersistException e) {
                throw new OihPersistenceException(e);
            }
        }
    }
}
