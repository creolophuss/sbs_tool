package com.amazon.oih.dao.forecast;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.criterion.Restrictions;

import amazon.platform.config.AppConfig;

import com.amazon.oih.dao.DaoConstants;
import com.amazon.oih.dao.OihDao;
import com.amazon.oih.dao.exception.DaoRuntimeException;
import com.amazon.oih.dao.exception.OihPersistenceException;
import com.amazon.oih.utils.AsinIogPair;
import com.amazon.oih.utils.Utils;

/**
 * Forecast Dao
 * 
 * @author zhongwei
 * 
 */
public class ForecastDao extends OihDao<ForecastObject> {
    final static Logger log = Logger.getLogger(ForecastDao.class);
    private Date runDate = new Date();

    public ForecastDao(String source) {
        super(source);
    }

    /**
     * Find the current object by the given obj
     */
    @Override
    public ForecastObject findCurrent(ForecastObject obj) throws OihPersistenceException, DaoRuntimeException {
        if (obj == null) {
            throw new RuntimeException("ForecastObject is null for findCurrent function");
        }

        return findCurrent(obj.getAsin(), obj.getIog(), obj.getSource(), obj.getType());
    }

    /**
     * Find the current Forecast Object from the database by asin, iog, source
     * 
     * @param asin
     * @param iog
     * @param source
     * @return
     * @throws OihPersistenceException
     */
    public ForecastObject findCurrent(String asin, int iog, String source) throws OihPersistenceException {
        return findCurrent(asin, iog, source, ForecastType.DEFAULT_TYPE);
    }

    /**
     * Find the current Forecast Object from the database by asin, iog, source
     * 
     * @param asin
     * @param iog
     * @param source
     * @param type
     * @return
     * @throws OihPersistenceException
     */
    public ForecastObject findCurrent(String asin, int iog, String source, ForecastType type) throws OihPersistenceException {
        try {
            openSession();
            Criteria cri = session.createCriteria(ForecastObject.class);
            cri.add(Restrictions.eq("asin", asin));
            cri.add(Restrictions.eq("iog", iog));
            cri.add(Restrictions.eq("source", source));
            cri.add(Restrictions.eq("realm", AppConfig.getRealm().name()));
            cri.add(Restrictions.eq("isCurrent", DaoConstants.IS_CURRENT_Y));
            cri.add(Restrictions.eq("type", type));
            return (ForecastObject) cri.uniqueResult();
        } catch (HibernateException e) {
            e.printStackTrace();
            log.error("Fail to query Ilbo " + e);
            throw new OihPersistenceException(e);
        }
    }
    /**
     * Find the current object by the given obj
     */
    public ForecastObject find(ForecastObject obj, Date runDate) throws OihPersistenceException, DaoRuntimeException {
        if (obj == null) {
            throw new RuntimeException("ForecastObject is null for find function");
        }

        return find(obj.getAsin(), obj.getIog(), obj.getSource(), runDate, obj.getType());
    }

    /**
     * Find the current Forecast Object from the database by asin, iog, source
     * 
     * @param asin
     * @param iog
     * @param source
     * @return
     * @throws OihPersistenceException
     */
    public ForecastObject find(String asin, int iog, String source, Date runDate) throws OihPersistenceException {
    	return find(asin, iog, source, runDate, ForecastType.DEFAULT_TYPE);
    }

    
    public ForecastObject find(String asin, int iog, String realm, String source, Date runDate) throws OihPersistenceException {
    	return find(asin, iog, realm, source, runDate, ForecastType.DEFAULT_TYPE);
    }

    /**
     * Find the current Forecast Object from the database by asin, iog, source
     * 
     * @param asin
     * @param iog
     * @param realm
     * @param source
     * @param type
     * @return
     * @throws OihPersistenceException
     */
    public ForecastObject findNoRealm(String asin, int iog, String source, Date runDate, ForecastType type) throws OihPersistenceException {
        try {
            openSession();
            Criteria cri = session.createCriteria(ForecastObject.class);
            cri.add(Restrictions.eq("asin", asin));
            cri.add(Restrictions.eq("iog", iog));
            cri.add(Restrictions.eq("source", source));
            cri.add(Restrictions.le("firstLoadDate", runDate));
            cri.add(Restrictions.gt("expiredDate", runDate));
            List<ForecastObject> forecasts = ((List<ForecastObject>) cri.list());
            if (forecasts == null || forecasts.size() == 0){
                return null;
            } else {
                return forecasts.get(0);
            }
        } catch (HibernateException e) {
            e.printStackTrace();
            log.error("Fail to query Ilbo " + e);
            throw new OihPersistenceException(e);
        }
    }
    /**
     * Find the current Forecast Object from the database by asin, iog, source
     * 
     * @param asin
     * @param iog
     * @param realm
     * @param source
     * @param type
     * @return
     * @throws OihPersistenceException
     */
    public ForecastObject find(String asin, int iog, String realm, String source, Date runDate, ForecastType type) throws OihPersistenceException {
        try {
            openSession();
            Criteria cri = session.createCriteria(ForecastObject.class);
            cri.add(Restrictions.eq("asin", asin));
            cri.add(Restrictions.eq("iog", iog));
            cri.add(Restrictions.eq("source", source));
            cri.add(Restrictions.eq("realm", realm));
            cri.add(Restrictions.le("firstLoadDate", runDate));
            cri.add(Restrictions.gt("expiredDate", runDate));
            return ((ForecastObject) cri.uniqueResult());
        } catch (HibernateException e) {
            e.printStackTrace();
            log.error("Fail to query Ilbo " + e);
            throw new OihPersistenceException(e);
        }
    }
    /**
     * Find the current Forecast Object from the database by asin, iog, source
     * 
     * @param asin
     * @param iog
     * @param source
     * @param type
     * @return
     * @throws OihPersistenceException
     */
    public ForecastObject find(String asin, int iog, String source, Date runDate, ForecastType type) throws OihPersistenceException {
        try {
            openSession();
            Criteria cri = session.createCriteria(ForecastObject.class);
            cri.add(Restrictions.eq("asin", asin));
            cri.add(Restrictions.eq("iog", iog));
            cri.add(Restrictions.eq("source", source));
            cri.add(Restrictions.eq("realm", AppConfig.getRealm().name()));
            cri.add(Restrictions.le("firstLoadDate", runDate));
            cri.add(Restrictions.gt("expiredDate", runDate));
            return ((ForecastObject) cri.uniqueResult());
        } catch (HibernateException e) {
            e.printStackTrace();
            log.error("Fail to query Ilbo " + e);
            throw new OihPersistenceException(e);
        }
    }
    /**
     * Find the current Forecast Object from the database by asin, realm, source
     * 
     * @param asin
     * @param realms
     * @param source
     * @return
     * @throws OihPersistenceException
     */
    public List<ForecastObject> find(String[] asins, String[] realms, String source, Date runDate) throws OihPersistenceException {
        return find(asins, realms, source, runDate, ForecastType.DEFAULT_TYPE);
    }

    /**
     * Find the current Forecast Object from the database by asin, realm, source
     * 
     * @param asin
     * @param realms
     * @param source
     * @param type
     * @return
     * @throws OihPersistenceException
     */
    @SuppressWarnings("unchecked")
    public List<ForecastObject> find(String[] asins, String[] realms, String source, Date runDate, ForecastType type) throws OihPersistenceException {
        try {
            openSession();
            Criteria cri = session.createCriteria(ForecastObject.class);
            cri.add(Restrictions.in("asin", asins));
            cri.add(Restrictions.eq("source", source));
            cri.add(Restrictions.in("realm", realms));
            cri.add(Restrictions.le("firstLoadDate", runDate));
            cri.add(Restrictions.gt("expiredDate", runDate));
            cri.add(Restrictions.eq("type", type));
            List<ForecastObject> results = (List<ForecastObject>) cri.list();
            return results;
        } catch (HibernateException e) {
            e.printStackTrace();
            log.error("Fail to query Ilbo " + e);
            throw new OihPersistenceException(e);
        }
    }
    /**
     * Find the Our Price Object by the asin, iog, source
     * 
     * @param asin
     * @param iog
     * @param source
     * @return
     * @throws OihPersistenceException
     */
    public List<ForecastObject> find(List<AsinIogPair> asinIogPairs, String source, Date runDate)
            throws OihPersistenceException {
        return find(asinIogPairs, source, runDate, ForecastType.DEFAULT_TYPE);
    }

    /**
     * Find the Our Price Object by the asin, iog, source
     * 
     * @param asin
     * @param iog
     * @param source
     * @param type
     * @return
     * @throws OihPersistenceException
     */
    public List<ForecastObject> find(List<AsinIogPair> asinIogPairs, String source, Date runDate, ForecastType type)
            throws OihPersistenceException {
        List<ForecastObject> results = new ArrayList<ForecastObject>();

        Map<Integer, List<String>> iog2AsinsMap = Utils.splitAsinIogList2AsinsMap(asinIogPairs);
        Iterator<Integer> iterator = iog2AsinsMap.keySet().iterator();

        try {
            while (iterator.hasNext()) {
                Integer iog = iterator.next();
                List<ForecastObject> opObjects = find(iog2AsinsMap.get(iog), iog, source, runDate, type);
                if (opObjects != null && opObjects.size() > 0) {
                    results.addAll(opObjects);
                }
            }
            return results;
        } catch (HibernateException e) {
            e.printStackTrace();
            log.error("Fail to query ForecastObject " + e);
            throw new OihPersistenceException(e);
        }
    }
    /**
     * 
     * @param asins
     * @param iog
     * @param source
     * @param runDate
     * @return
     * @throws OihPersistenceException
     */
    public List<ForecastObject> find(List<String> asins, int iog, String source, Date runDate)
            throws OihPersistenceException {
        log.debug("Batch Query ForecastObject for " + asins.size() + "asins |" + iog + "|" + source);
        return find(asins, iog, source, runDate, ForecastType.DEFAULT_TYPE);
    }
    /**
     * 
     * @param asins
     * @param iog
     * @param source
     * @param runDate
     * @param type
     * @return
     * @throws OihPersistenceException
     */
    @SuppressWarnings("unchecked")
    public List<ForecastObject> find(List<String> asins, int iog, String source, Date runDate, ForecastType type)
            throws OihPersistenceException {
        log.debug("Batch Query ForecastObject for " + asins.size() + "asins |" + iog + "|" + source + "|" + runDate + "|" + type);
        try {
            openSession();
            Criteria cri = session.createCriteria(ForecastObject.class);
            cri.add(Restrictions.in("asin", asins));
            cri.add(Restrictions.eq("iog", iog));
            cri.add(Restrictions.eq("source", source));
            cri.add(Restrictions.eq("realm", AppConfig.getRealm().name()));
            cri.add(Restrictions.le("firstLoadDate", runDate));
            cri.add(Restrictions.gt("expiredDate", runDate));
            cri.add(Restrictions.eq("type", type));
            List<ForecastObject> results = (List<ForecastObject>) cri.list();
            return results;
        } catch (HibernateException e) {
            e.printStackTrace();
            log.error("Fail to query ForecastObject " + e);
            throw new OihPersistenceException(e);
        }
    }
    public void setRunDate(Date runDate) {
        this.runDate = runDate;
    }

    public Date getRunDate() {
        return runDate;
    }

    @Override
    public String getType() {
        return ForecastObject.class.getName();
    }
}