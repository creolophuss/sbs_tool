package com.amazon.oih.dao.scopemapping;

import com.amazon.oih.dao.g2s2.ConfigKey;

@ConfigKey(value = "MerchantAttr")
public class Merchant  extends ConfigEntity  implements Comparable<Merchant>{

    private Long merchantId;    
    private String encryptedMerchantId;
    private String merchantName;
    
    @ID
    public Long getMerchantId() {
        return merchantId;
    }
    
    public void setMerchantId(Long merchantId) {
        this.merchantId = merchantId;
    }
    
    public String getEncryptedMerchantId() {
        return encryptedMerchantId;
    }
    
    public void setEncryptedMerchantId(String encryptedMerchantId) {
        this.encryptedMerchantId = encryptedMerchantId;
    }
    
    public String getMerchantName() {
        return merchantName;
    }
    
    public void setMerchantName(String merchantName) {
        this.merchantName = merchantName;
    }
    
    @Override 
    public boolean equals(Object o){
        if (o == this)
            return true;
        if (o instanceof Merchant)
            return compareTo((Merchant) o) == 0;
        return false;
    }

    
    @Override
    public int compareTo(Merchant o) {
        if (o == null)
            return -1;
        if (o == this)
            return 0;
        Long o1 = this.getMerchantId();
        Long o2 = o.getMerchantId();
        if (o1 == null)
            return -1;
        if (o2 == null)
            return 1;
        return o1.compareTo(o2);
    }    
    
    public String toString(){
        return String.format("Merchant{id= %d,name=%s}", this.merchantId, this.merchantName );
    }
}
