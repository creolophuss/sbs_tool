package com.amazon.oih.dao.holdingcost;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;

import com.amazon.oih.common.KVDao;
import com.amazon.oih.dao.SessionFactoryManager;
import com.amazon.oih.dao.exception.OihPersistenceException;

public class HoldingCostDaoImpl implements HoldingCostDao, KVDao<HoldingCost> {

    private final static Logger logger = Logger.getLogger(HoldingCostDaoImpl.class);
    
    private final static String ALL_REALM = "*";
    
    private final static String SEPARATOR = "|";

    @Override
    public List<HoldingCost> getHoldingCosts(String realm) throws OihPersistenceException {
        List<HoldingCost> costs = getHoldingCosts(new String[] {
            "realm"
        }, new Object[] {
                getMatchedRealms(realm)
        });
        return reorg(costs);
    }

    @Override
    public List<HoldingCost> getHoldingCosts(String realm, String warehouse) throws OihPersistenceException {
        List<HoldingCost> costs = getHoldingCosts(new String[] {
                "realm", "warehouse"
        }, new Object[] {
                getMatchedRealms(realm), warehouse
        });
        return reorg(costs);
    }
    
    private List<HoldingCost> reorg(List<HoldingCost> orignal){
        Map<String,HoldingCost> fcWithRealmMap = new HashMap<String,HoldingCost>();
        for (HoldingCost cost : orignal){
            if (!ALL_REALM.equals(cost.getRealm())){
                fcWithRealmMap.put(genKey(cost), cost);
            }
        }
        for (HoldingCost cost : orignal){
            if (ALL_REALM.equals(cost.getRealm())){
                String key = genKey(cost);
                if (!fcWithRealmMap.containsKey(key)){
                    fcWithRealmMap.put(key, cost);
                }
            }
        }
        List<HoldingCost> target = new ArrayList<HoldingCost>();
        target.addAll(fcWithRealmMap.values());
        return target;
    }
    
    private String genKey(HoldingCost cost){
        return cost.getWarehouse() + SEPARATOR + cost.getGl() 
                + SEPARATOR + cost.getStartDate() + SEPARATOR + cost.getEndDate();
    }
    
    private String[] getMatchedRealms(String realm){
        return new String[]{realm, ALL_REALM};
    }

    @SuppressWarnings("unchecked")
    private List<HoldingCost> getHoldingCosts(String[] names, Object[] values) throws OihPersistenceException {
        Session session = null;
        try {
            session = openSession();
            Criteria cri = session.createCriteria(HoldingCost.class);
            if (names.length != values.length) {
                throw new RuntimeException("Fail to query monthly holding cost with parameters "
                        + Arrays.toString(names) + "  values " + Arrays.toString(values));
            }
            for (int i = 0; i < names.length; i++) {
                Object value = values[i];
                if (value instanceof String[]){
                    cri.add(Restrictions.in(names[i], (String[])value));
                } else {
                    cri.add(Restrictions.eq(names[i], value));
                }
            }
            return (List<HoldingCost>) cri.list();
        } catch (HibernateException e) {
            logger.error("Fail to query monthly holding cost " + e);
            throw new OihPersistenceException(e);
        } finally {
            closeSession(session);
        }
    }

    @Override
    public void save(HoldingCost holdingCost) throws Exception {
        Session session = null;
        Transaction tx = null;
        try {
            session = openSession();
            tx = session.beginTransaction();
            session.save(holdingCost);
            tx.commit();
        } catch (HibernateException e) {
            if (tx != null) {
                tx.rollback();
            }
            logger.error("Fail to save monthly holding cost " + e);
            throw new OihPersistenceException(e);
        } finally {
            closeSession(session);
        }
    }
    
    public void save(Collection<HoldingCost> holdingCosts) throws Exception {
        Session session = null;
        Transaction tx = null;
        try {
            session = openSession();
            tx = session.beginTransaction();
            for (HoldingCost cost : holdingCosts){
                session.saveOrUpdate(cost);
            }
            tx.commit();
        } catch (HibernateException e) {
            if (tx != null) {
                tx.rollback();
            }
            logger.error("Fail to save monthly holding cost " + e);
            throw new OihPersistenceException(e);
        } finally {
            closeSession(session);
        }
    }

    private Session openSession() {
        return SessionFactoryManager.getVendorFlexSessionFactoryInstance().openSession();
    }

    private void closeSession(Session session) {
        if (session != null) {
            session.close();
        }
    }

    @Override
    public List<HoldingCost> loadAll(String realm) throws OihPersistenceException {
        return getHoldingCosts(realm);
    }

    @Override
    public String getPhysicalId(HoldingCost t) {
        return t.getIdentity();
    }

    @Override
    public void saveAll(Collection<HoldingCost> all, Collection<HoldingCost> changed) throws OihPersistenceException {
        try {
            save(changed);
        } catch (Exception e) {
            throw new OihPersistenceException(e);
        }      
    }

}
