package com.amazon.oih.dao.inventorysourcingcost;

import java.io.Serializable;

public class InventorySourcingCost implements Serializable {
    private static final long serialVersionUID = 1L;
    private long runID;
    private String asin;
    private String scopeId;
    private String currency;
    private double cost;

    public InventorySourcingCost() {
    }

    public InventorySourcingCost(long runID, String asin, String scopeId, String currency, double cost) {
        this.runID = runID;
        this.asin = asin;
        this.scopeId = scopeId;
        this.currency = currency;
        this.cost = cost;
    }

    public long getRunID() {
        return runID;
    }

    public void setRunID(long runID) {
        this.runID = runID;
    }

    public String getAsin() {
        return asin;
    }

    public void setAsin(String asin) {
        this.asin = asin;
    }

    public String getScopeId() {
        return scopeId;
    }

    public void setScopeId(String scopeId) {
        this.scopeId = scopeId;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public double getCost() {
        return cost;
    }

    public void setCost(double cost) {
        this.cost = cost;
    }

    @Override
    public String toString() {
        return "InventorySourcingCost [runID=" + runID + ", asin=" + asin + ", scopeId=" + scopeId + ", currency="
                + currency + ", cost=" + cost + "]";
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((asin == null) ? 0 : asin.hashCode());
        result = prime * result + (int) (runID ^ (runID >>> 32));
        result = prime * result + ((scopeId == null) ? 0 : scopeId.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        InventorySourcingCost other = (InventorySourcingCost) obj;
        if (asin == null) {
            if (other.asin != null)
                return false;
        } else if (!asin.equals(other.asin))
            return false;
        if (runID != other.runID)
            return false;
        if (scopeId == null) {
            if (other.scopeId != null)
                return false;
        } else if (!scopeId.equals(other.scopeId))
            return false;
        return true;
    }

}
