package com.amazon.oih.dao.experiments;

import org.joda.time.DateTime;

import com.amazon.carbonado.Alias;
import com.amazon.carbonado.AlternateKeys;
import com.amazon.carbonado.Automatic;
import com.amazon.carbonado.Key;
import com.amazon.carbonado.PrimaryKey;
import com.amazon.carbonado.Storable;
import com.amazon.carbonado.constraint.IntegerConstraint;
import com.amazon.carbonado.constraint.LengthConstraint;

@Alias("data_ipc_experiments")
@AlternateKeys({
    @Key({
            "name", "iog", "gl"
    })
})
@PrimaryKey({
    "id"
})
public abstract class Experiment implements Storable<Experiment> {
    public abstract String getName();

    @LengthConstraint(min = 1, max = 40)
    public abstract void setName(String name);

    public abstract boolean getActive();

    public abstract void setActive(boolean active);

    @Alias("start_date")
    public abstract DateTime getStartDate();

    public abstract void setStartDate(DateTime time);

    @Alias("end_date")
    public abstract DateTime getEndDate();

    public abstract void setEndDate(DateTime time);

    @Automatic
    @Alias("id")
    public abstract int getId();

    public abstract void setId(int id);

    public abstract int getIog();

    @IntegerConstraint(min = 1, max = Integer.MAX_VALUE)
    public abstract void setIog(int iog);

    public abstract int getGl();

    @IntegerConstraint(min = 1, max = Integer.MAX_VALUE)
    public abstract void setGl(int gl);
    
    @Alias("use_population_file")
    public abstract boolean getUsePopulationFile();

    public abstract void setUsePopulationFile(boolean use);
}
