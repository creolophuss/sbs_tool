package com.amazon.oih.dao.recall;

import com.amazon.carbonado.Alias;
import com.amazon.carbonado.PrimaryKey;
import com.amazon.carbonado.Storable;
import com.amazon.carbonado.constraint.IntegerConstraint;
import com.amazon.carbonado.constraint.LengthConstraint;

@Alias("Recall")
@PrimaryKey( {
        "asin", "iog"
})
public abstract class RecallObject implements Storable<RecallObject> {
    public abstract String getAsin();

    @LengthConstraint(min = 10, max = 10)
    public abstract void setAsin(String asin);

    public abstract int getIog();

    @IntegerConstraint(min = 1, max = Integer.MAX_VALUE)
    public abstract void setIog(int iog);
    
    public abstract boolean isRecalled();

    public abstract void setRecalled(boolean isRecalled);
}
