package com.amazon.oih.dao.hbase.revenue;

import java.io.IOException;
import java.util.Collections;
import java.util.List;

import org.apache.hadoop.hbase.KeyValue;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.util.Bytes;

import com.amazon.oih.dao.hbase.base.AbstractHBaseDaoImpl;
import com.amazon.oih.utils.RevenueHBaseTableUtil;

/**
 * 
 * @author mengzang
 * 
 */
public class RevenueHBaseTableMetaDataDao extends AbstractHBaseDaoImpl<RevenueHBaseTableMetaDataObject> {

    private static final String tableName = RevenueHBaseTableUtil.RevenueMetadataTableName;

    private final static String columnFamily = "metadata";
    private final static byte[] columnFamilyBytes = Bytes.toBytes(columnFamily);
    private final static String column = "data";
    private final static byte[] columnBytes = Bytes.toBytes(column);

    public RevenueHBaseTableMetaDataDao(String realm) throws IOException {
        super(tableName, columnFamily, realm, RevenueHBaseTableUtil.RevenueTableSourceIdentity);
    }

    public void setRevenueTableReady(String tableName) throws IOException {
        RevenueHBaseTableMetaDataObject row = new RevenueHBaseTableMetaDataObject(tableName, RevenueTableStatus.Ready);
        this.putSingleElement(row);
    }

    public void setRevenueTableWriting(String tableName) throws IOException {
        RevenueHBaseTableMetaDataObject row = new RevenueHBaseTableMetaDataObject(tableName, RevenueTableStatus.Writing);
        this.putSingleElement(row);
    }

    public void setRevenueTableNotStart(String tableName) throws IOException {
        RevenueHBaseTableMetaDataObject row = new RevenueHBaseTableMetaDataObject(tableName,
                RevenueTableStatus.NotStarted);
        this.putSingleElement(row);
    }

    @Override
    protected RevenueHBaseTableMetaDataObject convert(String rowKey, Result rs) throws IOException {
        if (rs == null || rs.isEmpty()) {
            return new RevenueHBaseTableMetaDataObject(rowKey, RevenueTableStatus.NotStarted);
        }
        String key = rowKey;
        KeyValue revenueRawData = rs.raw()[0];
        String value = new String(revenueRawData.getValue());
        return new RevenueHBaseTableMetaDataObject(key, value);
    }

    @Override
    protected List<Put> convert(RevenueHBaseTableMetaDataObject bObject) throws IOException {
        String rowKey = bObject.getTableName();
        String value = bObject.getStatus().toString();

        Put put = new Put(Bytes.toBytes(rowKey));
        put.add(columnFamilyBytes, columnBytes, Bytes.toBytes(value));
        return Collections.nCopies(1, put);
    }
}
