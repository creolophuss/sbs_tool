package com.amazon.oih.dao.inventorysourcingcost;

import java.util.Collection;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;

import com.amazon.oih.dao.MySQLSessionFactoryUtil;
import com.amazon.oih.dao.exception.OihPersistenceException;

/**
 * 
 * @author mengzang
 * 
 */
public class InventorySourcingCostDaoImpl implements InventorySourcingCostDao {
    private final static Logger logger = Logger.getLogger(InventorySourcingCostDaoImpl.class);
    protected Session session = null;

    public InventorySourcingCostDaoImpl(String domain) {
    }

    @Override
    public void save(InventorySourcingCost cost) throws OihPersistenceException {
        Transaction tx = null;
        try {
            openSession();
            tx = session.beginTransaction();
            session.save(cost);
            tx.commit();
        } catch (RuntimeException e) {
            logger.error("Failed to save entity " + cost + " with exception ", e);
            e.printStackTrace();
            if (tx != null) {
                tx.rollback();
            }
            throw new OihPersistenceException(e);
        } finally {
            closeSession();
        }
    }

    @Override
    public void save(List<InventorySourcingCost> costs) throws OihPersistenceException {
        Transaction tx = null;
        try {
            openSession();
            tx = session.beginTransaction();
            for (InventorySourcingCost o : costs) {
                session.save(o);
            }
            tx.commit();
        } catch (RuntimeException e) {
            logger.error("Failed to save entity " + logger + " with exception ", e);
            e.printStackTrace();
            if (tx != null) {
                tx.rollback();
            }
            throw new OihPersistenceException(e);
        } finally {
            closeSession();
        }
    }

    @Override
    public boolean exists(Long runId, String asin, String scopeId) throws OihPersistenceException {
        logger.debug("Query InventorySourcingCost by " + asin + "|" + scopeId + "|" + runId);
        try {
            openSession();
            Criteria cri = session.createCriteria(InventorySourcingCost.class);
            cri.add(Restrictions.eq("asin", asin));
            cri.add(Restrictions.eq("scopeId", scopeId));
            cri.add(Restrictions.eq("runID", runId));
            return cri.uniqueResult() != null;
        } catch (HibernateException e) {
            e.printStackTrace();
            logger.error("Fail to query InventorySourcingCost " + e);
            throw new OihPersistenceException(e);
        } finally {
            closeSession();
        }

    }

    @Override
    public InventorySourcingCost findOne(Long runId, String asin, String scopeId) throws OihPersistenceException {
        logger.debug("Query InventorySourcingCost by " + asin + "|" + scopeId + "|" + runId);
        try {
            openSession();
            Criteria cri = session.createCriteria(InventorySourcingCost.class);
            cri.add(Restrictions.eq("asin", asin));
            cri.add(Restrictions.eq("scopeId", scopeId));
            cri.add(Restrictions.eq("runID", runId));
            return (InventorySourcingCost) cri.uniqueResult();
        } catch (HibernateException e) {
            e.printStackTrace();
            logger.error("Fail to query InventorySourcingCost " + e);
            throw new OihPersistenceException(e);
        } finally {
            closeSession();
        }
    }

    @Override
    public void delete(InventorySourcingCost cost) throws OihPersistenceException {
        Transaction tx = null;
        try {
            openSession();
            tx = session.beginTransaction();
            session.delete(cost);
            tx.commit();
        } catch (RuntimeException e) {
            logger.error("Failed to delete entity " + cost + " with exception ", e);
            e.printStackTrace();
            if (tx != null) {
                tx.rollback();
            }
            throw new OihPersistenceException(e);
        } finally {
            closeSession();
        }
    }

    @Override
    public void delete(List<InventorySourcingCost> costs) throws OihPersistenceException {
        logger.debug("Trying to delete all the InventorySourcingCost instances");
        Transaction tx = null;
        try {
            openSession();
            tx = session.beginTransaction();
            for (InventorySourcingCost object : costs) {
                session.delete(object);
            }
            tx.commit();
        } catch (HibernateException e) {
            e.printStackTrace();
            logger.error("Fail to query InventorySourcingCost " + e);
            throw new OihPersistenceException(e);
        } finally {
            closeSession();
        }
    }

    @Override
    public void deleteAll() throws OihPersistenceException {
        logger.debug("Trying to delete all the InventorySourcingCost reccords from the db");
        Transaction tx = null;
        try {
            openSession();
            tx = session.beginTransaction();
            Criteria cri = session.createCriteria(InventorySourcingCost.class);
            @SuppressWarnings("unchecked")
            List<InventorySourcingCost> costs = cri.list();
            for (InventorySourcingCost cost : costs) {
                session.delete(cost);
            }
            tx.commit();
        } catch (HibernateException e) {
            e.printStackTrace();
            logger.error("Fail to query InventorySourcingCost " + e);
            throw new OihPersistenceException(e);
        } finally {
            closeSession();
        }
    }

    private void openSession() {
        session = MySQLSessionFactoryUtil.getSessionFactory().openSession();
    }

    private void closeSession() {
        if (session != null) {
            session.close();
        }
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<InventorySourcingCost> findList(Long runId, Collection<String> asins, Collection<String> scopeIds)
            throws OihPersistenceException {
        logger.info("Batch Query InventorySourcingCost for a batchList");
        try {
            openSession();
            Criteria cri = session.createCriteria(InventorySourcingCost.class);
            cri.add(Restrictions.in("asin", asins));
            cri.add(Restrictions.in("scopeId", scopeIds));
            cri.add(Restrictions.eq("runID", runId));
            return (List<InventorySourcingCost>) cri.list();
        } catch (HibernateException e) {
            e.printStackTrace();
            logger.error("Fail to query InventorySourcingCost " + e);
            throw new OihPersistenceException(e);
        } finally {
            closeSession();
        }
    }
}
