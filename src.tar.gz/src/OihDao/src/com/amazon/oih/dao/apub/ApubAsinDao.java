package com.amazon.oih.dao.apub;

import java.util.List;

import com.amazon.oih.dao.exception.OihPersistenceException;

public interface ApubAsinDao {
    
    public List<ApubAsin> getApubAsins(Long runId) throws OihPersistenceException;
    
    public void save(ApubAsin asin) throws OihPersistenceException;
}
