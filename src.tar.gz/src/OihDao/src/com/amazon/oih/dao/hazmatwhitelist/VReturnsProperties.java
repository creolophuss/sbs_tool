package com.amazon.oih.dao.hazmatwhitelist;

import java.io.Serializable;
import java.util.Date;

public class VReturnsProperties implements Serializable {
    private static final long serialVersionUID = -8175001521331970084L;
    private static final String PIPE = "|";
    private static final String OPEN_PAREN = "(";
    private static final String CLOSE_PAREN = ")";

    private Long id;

    private String propertyCategoryName;

    private String propertyTypeName;

    private String propertyValue;

    private String lastUpdatedBy;

    private Date lastUpdatedDate;
    
    private String lastActedUponBy;
    
    public VReturnsProperties() {
       // empty contructor required by hibernate 
    }

    public VReturnsProperties(VReturnsProperties p) {
        this.id = p.getId();
        this.propertyCategoryName = p.getPropertyCategoryName();
        this.propertyTypeName = p.getPropertyTypeName();
        this.propertyValue = p.getPropertyValue();
        this.lastUpdatedBy = p.getLastUpdatedBy();
        this.lastUpdatedDate = p.getLastUpdatedDate();
        this.lastActedUponBy = p.getLastActedUponBy(); 
    }
    
    public void setId(Long id) {
        this.id = id;
    }

    public Long getId() {
        return this.id;
    }

    public void setPropertyCategoryName(String category) {
        this.propertyCategoryName = category;
    }

    public String getPropertyCategoryName() {
        return this.propertyCategoryName;
    }

    public void setPropertyTypeName(String type) {
        this.propertyTypeName = type;
    }

    public String getPropertyTypeName() {
        return this.propertyTypeName;
    }

    public void setPropertyValue(String value) {
        this.propertyValue = value;
    }

    public String getPropertyValue() {
        return this.propertyValue;
    }

    public void setLastUpdatedBy(String user) {
        this.lastUpdatedBy = user;
    }

    public String getLastUpdatedBy() {
        return this.lastUpdatedBy;
    }

    public void setLastUpdatedDate(Date date) {
        this.lastUpdatedDate = date;
    }

    public Date getLastUpdatedDate() {
        return this.lastUpdatedDate;
    }
    
    public void setLastActedUponBy(String userId) {
        this.lastActedUponBy = userId;
    }
    
    public String getLastActedUponBy() {
        return this.lastActedUponBy;
    }
    
    @Override
    public String toString() {
        return new StringBuffer(OPEN_PAREN)
        .append("id[").append(this.id).append("]").append(PIPE)
        .append("category[").append(this.propertyCategoryName).append("]").append(PIPE)
        .append("type[").append(this.propertyTypeName).append("]").append(PIPE)
        .append("value[").append(this.propertyValue).append("]").append(PIPE)
        .append("lastUpdatedBy[").append(this.lastUpdatedBy).append("]").append(PIPE)
        .append("lastUpdatedDate[").append(this.lastUpdatedDate).append("]").append(PIPE)
        .append("lastActedUponBy[").append(this.lastActedUponBy).append("]").append(PIPE)
        .append(CLOSE_PAREN).toString();
    }
}
