/**
 * An enum representing the types of Forcast data the dao can store.
 */
package com.amazon.oih.dao.forecast;

public enum ForecastType
{
	PNT,
	OV,
	P10,
	P20,
	P30,
	P40,
	P50,
	P60,
	P65,
	P70,
	P80,
	P90,
	MEAN,
	OIH;
	
	public static final ForecastType DEFAULT_TYPE = P50;
}
