package com.amazon.oih.dao.hbase.vrds;

import java.io.Serializable;
import java.util.Date;

import com.amazon.oih.common.RowKeyBuildType;
import com.amazon.oih.common.RowKeyType;
import com.amazon.oih.dao.hbase.base.CommonKVHBaseDao.HTable;
import com.amazon.oih.dao.hbase.converter.Column;
import com.amazon.oih.dao.hbase.converter.RowKey;
import com.amazon.oih.dao.hbase.converter.SubKey;

@RowKey({"asin", "iog"})
@RowKeyBuildType(RowKeyType.ASIN_IOG)
@SubKey({"dsiId"})
@HTable(value = "DorcInfo", columFamilyName = "DorcInfo")
public class VRDSHBaseDorcInfo implements Serializable {
    private static final long serialVersionUID = -6214836106586808776L;
    private String asin;
    private String iog;
    private long dsiId;
    
    @Column(name="Dorc",index=0)
    private String marketplace = "";
    
    @Column(name="Dorc",index=1)
    private int gl = 0;
    
    @Column(name="Dorc",index=2)
    private String vendor = "";
    
    @Column(name="Dorc",index=3)
    private String disposition = "";
    
    @Column(name="Dorc",index=4)
    private String warehouse = "";
    
    @Column(name="Dorc",index=5)
    private int qtyAssigned = 0;
    
    @Column(name="Dorc",index=6)
    private long orderType = 0;
    
    @Column(name="Dorc",index=7)
    private long dorcId = 0;
    
    @Column(name="Dorc",index=8)
    private int qtyReceived = 0;
    
    @Column(name="Dorc",index=9)
    private int qtyReturned = 0;
    
    @Column(name="Dorc",index=10)
    private int qtyInUse = 0;
        
    @Column(name="Dorc",index=11)
    private double distributorCost = 0;
    
    @Column(name="Dorc",index=12)
    private String baseCurrencyCode = "";
    
    @Column(name="Dorc",index=13)
    private double distributorListPrice = 0;
    
    @Column(name="Dorc",index=14)
    private String distributorOrderId = "";
    
    @Column(name="Dorc",index=15)
    private Date distributorOrderDate = null;
    
    @Column(name="Dorc",index=16)
    private Date shipmentReceivedDate = null;
    
    @Column(name="Dorc",index=17)
    private String distributorId = "";
    
    @Column(name="Dorc",index=18)
    private String distributorShipmentId = "";
    
    @Column(name="Dorc",index=19)
    private double cost = 0;
    
    @Column(name="Dorc",index=20)
    private double refundAmount = 0;
    
    @Column(name="Dorc",index=21)
    private String foreignCurrencyCode = "";
    
    @Column(name="Dorc",index=22)
    private double costForeignCurrency = 0;
    
    @Column(name="Dorc",index=23)
    private double refundAmountForeignCurrency = 0;
    
    @Column(name="Dorc",index=24)
    private double distributorCostForeignCurrency = 0;
    
    @Column(name="Dorc",index=25)
    private double distributorListPriceForeignCurrency = 0;
    
    @Column(name="Dorc",index=26)
    private String liquidationType = "";
        
    @Column(name="Dorc",index=27)
    private String destinationVendor = "";
    
    @Column(name="Dorc",index=28)
    private String costSourceType = "";

    @Column(name="Dorc",index=29)
    private String costSourceId = "";

    public VRDSHBaseDorcInfo(){}
    
    public String getAsin() {
        return asin;
    }

    public void setAsin(String asin) {
        this.asin = asin;
    }

    public String getIog() {
        return iog;
    }

    public void setIog(String iog) {
        this.iog = iog;
    }

    public String getMarketplace() {
        return marketplace;
    }

    public void setMarketplace(String marketplace) {
        this.marketplace = marketplace;
    }

    public int getGl() {
        return gl;
    }

    public void setGl(int gl) {
        this.gl = gl;
    }

    public String getVendor() {
        return vendor;
    }

    public void setVendor(String vendor) {
        this.vendor = vendor;
    }

    public String getDisposition() {
        return disposition;
    }

    public void setDisposition(String disposition) {
        this.disposition = disposition;
    }

    public String getWarehouse() {
        return warehouse;
    }

    public void setWarehouse(String warehouse) {
        this.warehouse = warehouse;
    }

    public int getQtyAssigned() {
        return qtyAssigned;
    }

    public void setQtyAssigned(int qtyAssigned) {
        this.qtyAssigned = qtyAssigned;
    }

    public long getOrderType() {
        return orderType;
    }

    public void setOrderType(long orderType) {
        this.orderType = orderType;
    }

    public long getDorcId() {
        return dorcId;
    }

    public void setDorcId(long dorcId) {
        this.dorcId = dorcId;
    }

    public int getQtyReceived() {
        return qtyReceived;
    }

    public void setQtyReceived(int qtyReceived) {
        this.qtyReceived = qtyReceived;
    }

    public int getQtyReturned() {
        return qtyReturned;
    }

    public void setQtyReturned(int qtyReturned) {
        this.qtyReturned = qtyReturned;
    }

    public int getQtyInUse() {
        return qtyInUse;
    }

    public void setQtyInUse(int qtyInUse) {
        this.qtyInUse = qtyInUse;
    }

    public long getDsiId() {
        return dsiId;
    }

    public void setDsiId(long dsiId) {
        this.dsiId = dsiId;
    }

    public double getDistributorCost() {
        return distributorCost;
    }

    public void setDistributorCost(double distributorCost) {
        this.distributorCost = distributorCost;
    }

    public String getBaseCurrencyCode() {
        return baseCurrencyCode;
    }

    public void setBaseCurrencyCode(String baseCurrencyCode) {
        this.baseCurrencyCode = baseCurrencyCode;
    }

    public double getDistributorListPrice() {
        return distributorListPrice;
    }

    public void setDistributorListPrice(double distributorListPrice) {
        this.distributorListPrice = distributorListPrice;
    }

    public String getDistributorOrderId() {
        return distributorOrderId;
    }

    public void setDistributorOrderId(String distributorOrderId) {
        this.distributorOrderId = distributorOrderId;
    }

    public Date getDistributorOrderDate() {
        return distributorOrderDate;
    }

    public void setDistributorOrderDate(Date distributorOrderDate) {
        this.distributorOrderDate = distributorOrderDate;
    }

    public Date getShipmentReceivedDate() {
        return shipmentReceivedDate;
    }

    public void setShipmentReceivedDate(Date shipmentReceivedDate) {
        this.shipmentReceivedDate = shipmentReceivedDate;
    }

    public String getDistributorId() {
        return distributorId;
    }

    public void setDistributorId(String distributorId) {
        this.distributorId = distributorId;
    }

    public String getDistributorShipmentId() {
        return distributorShipmentId;
    }

    public void setDistributorShipmentId(String distributorShipmentId) {
        this.distributorShipmentId = distributorShipmentId;
    }

    public double getCost() {
        return cost;
    }

    public void setCost(double cost) {
        this.cost = cost;
    }

    public double getRefundAmount() {
        return refundAmount;
    }

    public void setRefundAmount(double refundAmount) {
        this.refundAmount = refundAmount;
    }

    public String getForeignCurrencyCode() {
        return foreignCurrencyCode;
    }

    public void setForeignCurrencyCode(String foreignCurrencyCode) {
        this.foreignCurrencyCode = foreignCurrencyCode;
    }

    public double getCostForeignCurrency() {
        return costForeignCurrency;
    }

    public void setCostForeignCurrency(double costForeignCurrency) {
        this.costForeignCurrency = costForeignCurrency;
    }

    public double getRefundAmountForeignCurrency() {
        return refundAmountForeignCurrency;
    }

    public void setRefundAmountForeignCurrency(double refundAmountForeignCurrency) {
        this.refundAmountForeignCurrency = refundAmountForeignCurrency;
    }

    public double getDistributorCostForeignCurrency() {
        return distributorCostForeignCurrency;
    }

    public void setDistributorCostForeignCurrency(
            double distributorCostForeignCurrency) {
        this.distributorCostForeignCurrency = distributorCostForeignCurrency;
    }

    public double getDistributorListPriceForeignCurrency() {
        return distributorListPriceForeignCurrency;
    }

    public void setDistributorListPriceForeignCurrency(
            double distributorListPriceForeignCurrency) {
        this.distributorListPriceForeignCurrency = distributorListPriceForeignCurrency;
    }

    public String getLiquidationType() {
        return liquidationType;
    }

    public void setLiquidationType(String liquidationType) {
        this.liquidationType = liquidationType;
    }
    
    public String getDestinationVendor() {
        return destinationVendor;
    }

    public void setDestinationVendor(String destinationVendor) {
        this.destinationVendor = destinationVendor;
    }

    public String getCostSourceType() {
        return costSourceType;
    }

    public void setCostSourceType(String costSourceType) {
        this.costSourceType = costSourceType;
    }

    public String getCostSourceId() {
        return costSourceId;
    }

    public void setCostSourceId(String costSourceId) {
        this.costSourceId = costSourceId;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((asin == null) ? 0 : asin.hashCode());
        result = prime * result + (int) (dsiId ^ (dsiId >>> 32));
        result = prime * result + ((iog == null) ? 0 : iog.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        VRDSHBaseDorcInfo other = (VRDSHBaseDorcInfo) obj;
        if (asin == null) {
            if (other.asin != null)
                return false;
        } else if (!asin.equals(other.asin))
            return false;
        if (dsiId != other.dsiId)
            return false;
        if (iog == null) {
            if (other.iog != null)
                return false;
        } else if (!iog.equals(other.iog))
            return false;
        return true;
    }

    @Override
    public String toString() {
        return "VRDSHBaseDorcInfo [asin=" + asin + ", iog=" + iog + ", marketplace=" + marketplace + ", gl=" + gl
                + ", vendor=" + vendor + ", disposition=" + disposition + ", liquidationType=" + liquidationType 
                + ", warehouse=" + warehouse + ", qtyAssigned="+ qtyAssigned + ", orderType=" + orderType 
                + ", dorcId=" + dorcId + ", qtyReceived=" + qtyReceived
                + ", qtyReturned=" + qtyReturned + ", qtyInUse=" + qtyInUse + ", dsiId=" + dsiId + ", distributorCost="
                + distributorCost + ", baseCurrencyCode=" + baseCurrencyCode + ", distributorListPrice="
                + distributorListPrice + ", distributorOrderId=" + distributorOrderId + ", distributorOrderDate="
                + distributorOrderDate + ", shipmentReceivedDate=" + shipmentReceivedDate + ", distributorId="
                + distributorId + ", distributorShipmentId=" + distributorShipmentId + ", cost=" + cost
                + ", costSourceType=" + costSourceType + ", costSourceId=" + costSourceId
                + ", refundAmount=" + refundAmount + ", foreignCurrencyCode=" + foreignCurrencyCode
                + ", costForeignCurrency=" + costForeignCurrency + ", refundAmountForeignCurrency="
                + refundAmountForeignCurrency + ", distributorCostForeignCurrency=" + distributorCostForeignCurrency
                + ", distributorListPriceForeignCurrency=" + distributorListPriceForeignCurrency + "]";
    }
    
    
    
}
