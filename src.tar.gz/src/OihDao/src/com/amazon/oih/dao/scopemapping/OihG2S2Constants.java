package com.amazon.oih.dao.scopemapping;

public interface OihG2S2Constants {

    public static final String SCOPEMAPPING_TABLE = "ScopeMapping";
    
    public static final String REALM_TO_SCOPE_MAP_FOR_CALC = "RealmToScopeMapForCalc";

    public static final String MARKETPLACEATTR_TABLE = "MarketplaceAttr";
    
    public static final String MERCHANT_TABLE = "MerchantAttr"; 

    public static final String IOG_TABLE = "IOGAttr";
    
    public static final String DAMAGE_BUILD_IOGS = "IhrMetrics.Extract.DamagedILBOQuantity.Iogs";
    
    public static final String SCOPE_TO_COUNTRY = "Scope2CountryMapping";
    
    public static final String COUNTRY_TO_REALM = "Country2RealmMapping";
    
}
