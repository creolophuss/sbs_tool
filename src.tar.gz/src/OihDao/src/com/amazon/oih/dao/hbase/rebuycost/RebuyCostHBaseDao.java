 /**
  * Copyright (c) 2014 Amazon.com, Inc.  All rights reserved.
  * 
  * Owner: oih-cn@
  */
package com.amazon.oih.dao.hbase.rebuycost;

import java.util.Date;

import com.amazon.oih.dao.hbase.base.CommonKVHBaseDao;
import com.amazon.oih.dao.rebuycost.RebuyCost;

/**
 * @author gaoxing
 * @param <T>
 *
 */
public class RebuyCostHBaseDao extends CommonKVHBaseDao<RebuyCost> {

    public RebuyCostHBaseDao() {
        super(RebuyCost.class);
    }

    public RebuyCostHBaseDao(String additionalId, String realm, Date rundate) {
        super(RebuyCost.class, additionalId, realm, rundate);
    }

}
