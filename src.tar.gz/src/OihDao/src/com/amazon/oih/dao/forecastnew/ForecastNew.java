package com.amazon.oih.dao.forecastnew;

import com.amazon.oih.dao.forecast.ForecastType;

public interface ForecastNew {
    public abstract long getRunID();
    public abstract void setRunID(long runid);

    public abstract String getAsin();
    public abstract void setAsin(String asin);

    public abstract int getIog();
    public abstract void setIog(int iog);

    public abstract String getType();
    public abstract void setType(String type);

    public abstract ForecastType getForecastType();
    
    public void setForecastType(ForecastType t);

    public abstract double getProbability();

    public abstract void setProbability(double probability);

    public abstract double getWeek1();

    public abstract void setWeek1(double week);
    
    public abstract double getWeek2();

    public abstract void setWeek2(double week);
    
    public abstract double getWeek3();

    public abstract void setWeek3(double week);
    
    public abstract double getWeek4();
    
    public abstract void setWeek4(double week);
    
    public abstract double getWeek5();

    public abstract void setWeek5(double week);
    
    public abstract double getWeek6();

    public abstract void setWeek6(double week);
    
    public abstract double getWeek7();

    public abstract void setWeek7(double week);
    
    public abstract double getWeek8();

    public abstract void setWeek8(double week);
    
    public abstract double getWeek9();

    public abstract void setWeek9(double week);
    
    public abstract double getWeek10();

    public abstract void setWeek10(double week);
    
    public abstract double getWeek11();

    public abstract void setWeek11(double week);
    
    public abstract double getWeek12();
    
    public abstract void setWeek12(double week);
    
    public abstract double getWeek13();

    public abstract void setWeek13(double week);
    
    public abstract double getWeek14();

    public abstract void setWeek14(double week);
    
    public abstract double getWeek15();

    public abstract void setWeek15(double week);
    
    public abstract double getWeek16();

    public abstract void setWeek16(double week);
      
    public abstract double getWeek17();

    public abstract void setWeek17(double week);
    
    public abstract double getWeek18();

    public abstract void setWeek18(double week);
    
    public abstract double getWeek19();

    public abstract void setWeek19(double week);
    
    public abstract double getWeek20();

    public abstract void setWeek20(double week);
    
    public abstract double getWeek21();

    public abstract void setWeek21(double week);
    
    public abstract double getWeek22();

    public abstract void setWeek22(double week);
    
    public abstract double getWeek23();

    public abstract void setWeek23(double week);
    
    public abstract double getWeek24();
    
    public abstract void setWeek24(double week);
    
    public abstract double getWeek25();

    public abstract void setWeek25(double week);
    
    public abstract double getWeek26();

    public abstract void setWeek26(double week);
    
    public abstract double getWeek27();

    public abstract void setWeek27(double week);
    
    public abstract double getWeek28();

    public abstract void setWeek28(double week);
    
    public abstract double getWeek29();

    public abstract void setWeek29(double week);
    
    public abstract double getWeek30();

    public abstract void setWeek30(double week);
    
    public abstract double getWeek31();

    public abstract void setWeek31(double week);
    
    public abstract double getWeek32();

    public abstract void setWeek32(double week);
    
    public abstract double getWeek33();

    public abstract void setWeek33(double week);   
}
