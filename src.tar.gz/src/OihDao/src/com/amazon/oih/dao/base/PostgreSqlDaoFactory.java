package com.amazon.oih.dao.base;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

import com.amazon.oih.dao.hazmatwhitelist.VReturnsPropertiesDao;

public class PostgreSqlDaoFactory {    
    
    private static ApplicationContext ppContext = null;
    
    public static VReturnsPropertiesDao getVReturnsPropertiesDao() {
        return (VReturnsPropertiesDao) getAppContext().getBean("VReturnsPropertiesDao");
    }  

    private synchronized static ApplicationContext getAppContext() {
        if (null != ppContext) {
            return ppContext;
        }
        System.getProperties().put("domain", "prod");// replace the place holder in the hibernate.xml
        ppContext = new FileSystemXmlApplicationContext(new String[] {
                "classpath:spring-configuration/VRetPostgreDb/hibernate.cfg.xml"
        });

        return ppContext;
    }

    // unit test can set its own appContext
    public static void setAppContext(ApplicationContext appCtx) {
        ppContext = appCtx;
    }
}
