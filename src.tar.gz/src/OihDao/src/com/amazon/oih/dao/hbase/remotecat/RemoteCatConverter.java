package com.amazon.oih.dao.hbase.remotecat;

import java.io.IOException;
import java.util.List;

import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.util.Bytes;

import amazon.platform.config.AppConfig;

import com.amazon.oih.dao.DaoConstants;
import com.amazon.oih.dao.hbase.base.Converter;
import com.amazon.oih.dao.hbase.converter.HBaseConverterFactory;
import com.amazon.oih.dao.hbase.converter.IHBaseObjectConverter;
import com.amazon.oih.dao.remotecat.RemoteCat;

@Deprecated
public class RemoteCatConverter implements Converter<RemoteCat> {
    private IHBaseObjectConverter<RemoteCat> convertor = HBaseConverterFactory.getDefaultConverter();
    private final static String REMOTECAT_COLUMNFAMILY = AppConfig.findString(DaoConstants.REMOTECAT_COLUMNFAMILY);
    
    @Override
    public RemoteCat convert(String rowKey, Result rs) throws IOException {
        return convertor.convert(RemoteCat.class, rowKey, rs);
    }

    @Override
    public RemoteCat convert(Result rs) throws IOException {
        return convertor.convert(RemoteCat.class, Bytes.toString(rs.getRow()), rs);
    }

    @Override
    public List<Put> convert(RemoteCat object) throws IOException {
        return convertor.convert(REMOTECAT_COLUMNFAMILY, object);
    }

    @Override
    public String getRowKey(RemoteCat object) {
        return convertor.getRowKey(object);
    }
}
