package com.amazon.oih.dao.historicdemand;

import java.util.Collection;

import javax.naming.NamingException;

import com.amazon.carbonado.PersistException;
import com.amazon.carbonado.RepositoryException;
import com.amazon.carbonado.SupportException;

public interface HistoricDemandDao {
    void save(HistoricDemand o) throws PersistException;

    void save(Collection<HistoricDemand> o) throws PersistException;

    boolean exists(String asin, Long marketplace) throws NamingException, RepositoryException, ClassNotFoundException;

    HistoricDemand find(String asin, Long marketplace) throws NamingException, RepositoryException, ClassNotFoundException;

    HistoricDemand createHistoricDemand(String asin, Long marketplace, int one_week, int two_week, int three_week,
            int four_week, int three_month, int one_year) throws SupportException, RepositoryException;
}
