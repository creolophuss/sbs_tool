package com.amazon.oih.dao.hbase.base;

import com.amazon.oih.common.RowKeyBuildType;
import com.amazon.oih.common.RowKeyType;
import com.amazon.oih.common.KeyValueBase.NamedValue;
import com.amazon.oih.dao.hbase.converter.Column;
import com.amazon.oih.dao.hbase.converter.RowKey;

@RowKey({"asin", "scopeId"})
@RowKeyBuildType(RowKeyType.ASIN_SCOPE)
public abstract class AsinScopeValueHBaseObject<T> {
    
    @NamedValue("asin")
    public String asin;
    
    @NamedValue("scopeId")
    public String scopeId;
    
    @Column(name="value",index=0)
    @NamedValue("value")
    public String value;
    
    public abstract T toApplicationObject();

    public String getAsin() {
        return asin;
    }

    public void setAsin(String asin) {
        this.asin = asin;
    }

    public String getScopeId() {
        return scopeId;
    }

    public void setScopeId(String scopeId) {
        this.scopeId = scopeId;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
