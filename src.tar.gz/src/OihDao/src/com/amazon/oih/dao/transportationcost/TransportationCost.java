package com.amazon.oih.dao.transportationcost;

import java.io.Serializable;

public class TransportationCost implements Serializable {

    private static final long serialVersionUID = -164898557891093872L;

    private String id;
    private String realm;
    private String warehouseLocation;
    private String vendorLocation;
    private Integer gl;
    private Double outCost;    
    
    public void setId(String id) {
        this.id = id;
    }
    
    public String getId() {
        return this.id;
    }
    
    public void setRealm(String realm) {
        this.realm = realm;
    }
    
    public String getRealm() {
        return this.realm;
    }
    
    public void setWarehouseLocation(String whseLoc) {
        this.warehouseLocation = whseLoc;
    }
    
    public String getWarehouseLocation() {
        return this.warehouseLocation;
    }
    
    public void setVendorLocation(String vcLoc) {
        this.vendorLocation = vcLoc;
    }
    
    public String getVendorLocation() {
        return this.vendorLocation;
    }
    
    public void setGl(Integer gl) {
        this.gl = gl;
    }
    
    public Integer getGl() {
        return this.gl;
    }
    
    public void setOutCost(Double outCost) {
        this.outCost = outCost;
    }
    
    public double getOutCost() {
        return this.outCost;
    }
    
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(id).append("|");
        sb.append(realm).append("|");
        sb.append(warehouseLocation).append("|");
        sb.append(vendorLocation).append("|");
        sb.append(gl).append("|");
        sb.append(outCost);
        return sb.toString();
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (obj instanceof TransportationCost) {
            TransportationCost other = (TransportationCost) obj;
            if (!this.id.equals(other.id)) {
                return false;
            }
        }
        return true;
    }
}
