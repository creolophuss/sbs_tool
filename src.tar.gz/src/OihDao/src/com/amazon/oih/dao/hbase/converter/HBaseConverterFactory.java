package com.amazon.oih.dao.hbase.converter;

public class HBaseConverterFactory {
    public static <T extends Object> IHBaseObjectConverter<T> getDefaultConverter(){
        IHBaseObjectConverter<T> dao = new HBaseObjectDefaultConverter<T>();
        return (IHBaseObjectConverter<T>)dao;
    }
}
