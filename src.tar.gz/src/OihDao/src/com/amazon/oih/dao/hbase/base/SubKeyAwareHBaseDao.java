package com.amazon.oih.dao.hbase.base;

import java.io.IOException;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.hadoop.hbase.client.Result;

import com.amazon.oih.dao.hbase.converter.Column;
import com.amazon.oih.dao.hbase.converter.HBaseObjectDefaultConverter;
import com.amazon.oih.dao.hbase.converter.SubKey;
import com.google.common.annotations.VisibleForTesting;

/**
 * Dao for HBase table use subkey as the columnName, and ignore the columnName definition. So that we could store
 * multiple T for one rowKey. It has 2 models:
 * [1] MultiColumnName, see @SubKeyAwareHBaseDaoTest.MultiColumnClass for how to define it.
 * Suppose we have an ASIN(B000000001) in marketplace(1), has 2 Vendors(VendorA&VendorB) provide inventory for this ASIN, and the 
 * (payOnSale, ReachCap) attributes for those 2 vendors are: VendorA(true, false), VendorB(false, true), when use vendor field as subkey,
 * it will store in HBase like:
 *    RowKey            VendorA.payOnSale     VendorA.ReachCap      VendorB.payOnSale     VendorB.ReachCap
 *  B000000001:1        true                  false                 false                 true
 * 
 * [2] Single LogicColumnName, see @SubKeyAwareHBaseDaoTest.SingleColumnClass for how to define it
 * For above example, , it will store in HBase like:  
 *    RowKey            VendorA           VendorB
 *  B000000001:1        true,False        false,true
 * 
 * Use MultiColumnClass, different columns come from different data source has no dependency, and you can query for single field, 
 * but it cost more storage space and have lower performance.
 * Use Single LogicColumnName, your data all coupled together, but it have lower storage space and better performance.
 * 
 *  
 * !!!Notice!!! 
 * [1] This class use HBaseObjectDefaultConverter, who use BeanUtilsBean to set Obj's fields, and it set "" when it encounter a null. 
 *     so your null will become "" or a default value when convert "" to your type, e.g. Boolean would become false.
 * [2] When use MultiColumnClass, every field will have one column, in HBase, this means for every field, you duplicate 
 *     rowkey, subkey, columnName with the field's value in that single line, which wastes store space! use with care!!
 * 
 * @author jialei
 * 
 * @param <T>
 */
public class SubKeyAwareHBaseDao<T> extends HBaseDaoImplAdaptor<List<T>> {
    private static final String SUBKEY_SPLIT = ":";
    private static final String SUBKEY_LOGICCOLUMN_NAME_SPLIT = ".";
    protected Class<T> classObj;
    private String logicColumnName;
    private HBaseObjectDefaultConverter<T> converter;
    private static Map<Class<? extends Object>, List<String>> subKeyFields = new ConcurrentHashMap<Class<? extends Object>, List<String>>();

    @VisibleForTesting
    public SubKeyAwareHBaseDao(Class<T> classObj) {
        super();
        this.classObj = classObj;
        this.logicColumnName = getLogicColumnName(classObj);
        this.converter = CommonKVHBaseDao.getConverter(classObj);
    }

    public SubKeyAwareHBaseDao(Class<T> classObj, String additionalId, String realm, Date rundate) {
        this(classObj, null, additionalId, realm, rundate, false);
    }

    public SubKeyAwareHBaseDao(Class<T> classObj, String additionalId, String realm, Date rundate, boolean skipRundateChecking) {
        this(classObj, null, additionalId, realm, rundate, skipRundateChecking);
    }
    
    @SuppressWarnings("unchecked")
    public SubKeyAwareHBaseDao(String classDesc) throws ClassNotFoundException {
    	this((Class<T>)Class.forName(classDesc));
    }

    public List<T> convert(Result res) throws IOException {
        return (List<T>)this.convert(new String(res.getRow()), res);
    }

    public SubKeyAwareHBaseDao(Class<T> classObj, String columnFamily, String additionalId, String realm, Date rundate,
            boolean skipRundateChecking) {
        super(CommonKVHBaseDao.obtainTableName(classObj, additionalId), CommonKVHBaseDao
                .obtainColumnFamilyName(classObj), realm, rundate, skipRundateChecking);
        this.classObj = classObj;
        this.logicColumnName = getLogicColumnName(classObj);
        this.converter = CommonKVHBaseDao.getConverter(classObj);
    }

    private static <T> String getLogicColumnName(Class<T> classObj) {
        Field[] fs = classObj.getDeclaredFields();
        String logicColumnName = null;
        for (Field f : fs) {
            if (f.isAnnotationPresent(Column.class)) {
                Column col = (Column) f.getAnnotation(Column.class);
                if (logicColumnName == null) {
                    logicColumnName = col.name();
                } else if (!logicColumnName.equals(col.name())) {
                    //do not need remember logicColumnName in case we have multiple ColumnNames
                    return null;
                }
            }
        }
        return logicColumnName;
    }

    @Override
    public String generateRowKey(List<T> bObjects) {
        String rowkey = null;
        for (T obj : bObjects) {
            if (rowkey == null) {
                rowkey = converter.getRowKey(obj);
                continue;
            }
            if (!rowkey.equals(converter.getRowKey(obj))) {
                throw new RuntimeException("the saving list do not have same rowkey, should be a bug for Dao of "
                        + obj.getClass().getCanonicalName());
            }
        }
        return rowkey;
    }

    @Override
    protected Map<String, String> generateColumnValueMap(List<T> bObjects) {
        Map<String, String> finalMap = new HashMap<String, String>();
        T hBaseObj = bObjects.get(0);
        List<String> subKeyFields = getSubKeyFieldsByObj(hBaseObj.getClass());
        for (T obj : bObjects) {
            String subKey = converter.getFieldValues(obj, subKeyFields, SUBKEY_SPLIT);
            Map<String, String> fieldMap = converter.getValues(obj);
            if (fieldMap.size() != 1 && !isMultiColumnNames()) {
                throw new RuntimeException("Impossible to come here...fieldMap could only be 1, but it's " + fieldMap.size() + " for Class:"
                        + classObj.getCanonicalName());
            }

            if (isMultiColumnNames()){
                for (Map.Entry<String, String> entry : fieldMap.entrySet()){
                    String logicColumnName = entry.getKey();
                    String valueStr = entry.getValue();
                    finalMap.put(subKey + SUBKEY_LOGICCOLUMN_NAME_SPLIT + logicColumnName, valueStr);
                }
            } else {
                String valueStr = fieldMap.values().iterator().next();
                finalMap.put(subKey, valueStr);
            }
        }
        return finalMap;
    }

    /**
     * columnMap comes from HBase, the key is the HBase column, the the value is HBase"Value" stored in that column.
     * For one rowKey, we may have multiple columns, and one "Value" for one column.
     * 
     * columnMap to POJO Mapping:
     * [1] when using single logicalColumnName:
     *    The column(Key) in columnMap is the values of fields who marked as @SubKey in POJO, separate by SUBKEY_SPLIT, and the "Value" 
     *    is a composite String, build by each field(which is marked as @Column) in POJO. As @HBaseObjectDefaultConverter use @Column.name 
     *    and @Column.index to construct the POJO, we need to remember @Column.name into logicalColumnName, then provide it to 
     *    @HBaseObjectDefaultConverter during construct POJO.
     * [2] when using multiple column: 
     *    The column(Key) in columnMap has 2 parts, separate by SUBKEY_LOGICCOLUMN_NAME_SPLIT, the first part is the values of fields
     *    who marked as @SubKey in POJO, the second part is one field's @Column.name in the POJO, the "Value" is the value for that 
     *    field. As we record @Column.name with @SubKey in HBase as HBase's column, so we don't need to remember them in logicalColumnName.
     *    e.g. For an POJO has 5 field marked as @Column, there will be 5 Hbase Columns for one single rowKey's one single subkey.  
     */
    @Override
    protected List<T> construct(String rowKey, Map<String, String> columnMap) {
        List<T> resultList = new ArrayList<T>();
        Map<String, Map<String, String>> subKey2columnName2ValueMap = groupColumnMapAccordingSubKey(columnMap);
        for (Map.Entry<String, Map<String, String>> entry : subKey2columnName2ValueMap.entrySet()) {
            String subKey = entry.getKey();
            Map<String, String> column2Value = entry.getValue();
            T result = converter.convert(classObj, rowKey, column2Value);
            converter.setFieldValue(result, subKey, getSubKeyFieldsByObj(classObj), SUBKEY_SPLIT);
            resultList.add(result);
        }
        return resultList;
    }
    
    /**
     * Return @SubKey -> @Column.name -> values of fields who marked as @Column
     * @param columnMap
     * @return 
     */
    private Map<String, Map<String, String>> groupColumnMapAccordingSubKey(Map<String, String> columnMap){
        Map<String, Map<String, String>> result = new HashMap<String, Map<String, String>>();
        for (Map.Entry<String, String> subKey2Value : columnMap.entrySet()){
            String subKey;
            String columnName;
            if (isMultiColumnNames()){
                String[] subKeyAndColumn = subKey2Value.getKey().split("\\" + SUBKEY_LOGICCOLUMN_NAME_SPLIT);
                if (subKeyAndColumn.length != 2){
                    throw new RuntimeException("For class:" + classObj.getCanonicalName() + " who use multi-logicColumnName, but do not store" +
                            " the logicColumnName with subKey, subkey is " + subKey2Value.getKey());
                }
                subKey = subKeyAndColumn[0];
                columnName = subKeyAndColumn[1];
            } else {
                subKey = subKey2Value.getKey();
                columnName = logicColumnName;
            }
            Map<String, String> columnName2Value = result.get(subKey);
            if (columnName2Value == null){
                columnName2Value = new HashMap<String, String>();
            }
            columnName2Value.put(columnName, subKey2Value.getValue());
            result.put(subKey, columnName2Value);
        }  
        return result;
    }
    
    private boolean isMultiColumnNames(){
        return logicColumnName == null;
    }
    
    @Override
    protected String getPOJOColumnName(String hbaseColumnName){
        if (isMultiColumnNames()){
            String[] subKeyAndColumn = hbaseColumnName.split("\\" + SUBKEY_LOGICCOLUMN_NAME_SPLIT);
            return subKeyAndColumn[1];
        } else {
            return logicColumnName;
        }
    }

    private static List<String> getSubKeyFieldsByObj(Class<? extends Object> clazz) {
        if (!subKeyFields.containsKey(clazz)) {
            if (clazz.isAnnotationPresent(SubKey.class)) {
                SubKey rk = (SubKey) clazz.getAnnotation(SubKey.class);
                subKeyFields.put(clazz, Arrays.asList(rk.value()));
            } else {
                List<String> empty = Collections.emptyList();
                subKeyFields.put(clazz, empty);
            }
        }

        return subKeyFields.get(clazz);
    }
}
