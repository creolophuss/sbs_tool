package com.amazon.oih.dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.Hashtable;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.CacheMode;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.ScrollMode;
import org.hibernate.ScrollableResults;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import amazon.platform.config.AppConfig;

import com.amazon.oih.dao.exception.DaoRuntimeException;
import com.amazon.oih.dao.exception.OihPersistenceException;

/**
 * Common DAO implementation
 * 
 * @author river
 * 
 */
public abstract class OihDao<T extends OihObject> {

    final static Logger log = Logger.getLogger(OihDao.class);
    final static Class[] PARAMETERS_EMPTY = new Class[]{};

    protected String source = null;
    protected Session session = null;
    final int maxRetryTimes = 3;

    public OihDao(String source) {
        this.source = source;
    }

    /**
     * Insert collection into DB with OIH rules by batch
     * @param objs
     * @throws OihPersistenceException
     * @throws DaoRuntimeException
     */
    public void oihInsert(Collection<T> objs) throws OihPersistenceException, DaoRuntimeException {
        int retryTimes = 0;
        
        while (retryTimes < maxRetryTimes){
            long start = System.currentTimeMillis();
            ScrollableResults rs = null;
            Hashtable<String, T> oldVObjs = null;
            Transaction tx = null;
            try {
                openSession();
                tx = session.beginTransaction();
                tx.setTimeout(30);

                oldVObjs = findCurrent(objs);
                for (T newObj : objs) {
                    T oldObj = oldVObjs.get(newObj.getKey());
                    oihInsert(newObj, oldObj);
                }

                session.flush();
                session.clear();
                tx.commit();

                System.out.println("total submit time" + (System.currentTimeMillis() - start) + " sumbit times =" + (++submitNum));
                return;
            } catch (RuntimeException e) {
                //e.printStackTrace();
                if (++retryTimes == maxRetryTimes){
                    log.error("Failed to save entity with exception ", e);
                    e.printStackTrace();
                    if (tx != null) {
                        tx.rollback(); 
                    }
                    throw new OihPersistenceException(e);
                } else {
                    log.info("Retry failed batch insert.");
                }
            } catch (Exception e) {      
                //e.printStackTrace();
                if (++retryTimes == maxRetryTimes){
                    log.error("Failed to save entity with exception ", e);
                    e.printStackTrace();
                    if (tx != null) {
                        tx.rollback(); 
                    }
                    throw new OihPersistenceException(e);
                } else {
                    log.info("Retry failed batch insert.");
                }
            } finally {
                closeSession();
            }
        }
    }

    /**
     * Common oih insert logic
     * @param newObj
     * @param oldObj
     * @param session
     */
    private void oihInsert(T newObj, T oldObj){
        if (oldObj != null) {
            if (newObj.equals(oldObj)) {
                oldObj.setLastLoadDate(newObj.getLastLoadDate());
                oldObj.setExpiredDate(newObj.getExpiredDate());
            } else {
                //System.out.println(oldObj.getKey() + " " + oldObj.getValues() + "   vs    " + newObj.getKey() + " " + newObj.getValues());
                oldObj.setIsCurrent(DaoConstants.IS_CURRENT_N);
                oldObj.setExpiredDate(newObj.getFirstLoadDate());
                session.save(newObj);
            }
        } else {
            session.save(newObj);
        }
    }

    /**
     * find current collection mainly by asin, subclass can overwrite it if need.
     * @param objs
     * @return
     * @throws OihPersistenceException
     * @throws DaoRuntimeException
     */
    public Hashtable<String, T>  findCurrent(Collection<T> objs) throws OihPersistenceException, DaoRuntimeException{
        ScrollableResults rs = null;
        Hashtable<String, T> oldVObjs = new Hashtable<String, T>();
        try {
            if (session == null || !session.isOpen()) {
                session = HibernateUtil.getSessionFactory().openSession();
            } 
            Criteria cri = session.createCriteria(getType());
            cri.add(Restrictions.in("asin", getAsinArray(objs)));
            for (T t : objs){
            	try{
            		if (t.getClass().getMethod("getRealm", PARAMETERS_EMPTY) != null){
            			cri.add(Restrictions.eq("realm", AppConfig.getRealm().name()));
            		}
            	}catch(Exception ex){
            		//Do nothing
            	}
            	break;
            }
            cri.add(Restrictions.eq("source", source));
            cri.add(Restrictions.eq("isCurrent", DaoConstants.IS_CURRENT_Y));
            cri.addOrder(Order.asc("sequenceId"));
            rs = cri.setCacheMode(CacheMode.IGNORE).scroll(ScrollMode.FORWARD_ONLY);
            while (rs.next()) {
                T oldObj = (T) rs.get(0);
                oldVObjs.put(oldObj.getKey(), oldObj);
            }
            return oldVObjs;
        } catch ( HibernateException e ) {
            log.error("Fail to query " + getType() + e);
            e.printStackTrace();
            throw new OihPersistenceException(e);
        } finally {
            if (rs != null) {
                rs.close();
            }
        }
    }

    /**
     * After data file load, run this function to update the rows that has not been updated to deleted status.
     * @param startDate
     * @param iogs
     * @return
     * @throws OihPersistenceException
     * @throws DaoRuntimeException
     */
    public int updateToDeleted(Date startDate, List<String> iogs) throws OihPersistenceException, DaoRuntimeException {
        String sql = "update " + getType()
                + " t set t.isCurrent = 'N', t.expiredDate = :expriedDate where t.isCurrent = 'Y' and t.lastLoadDate < :lastDate and t.source = :source and" 
                + " t.iog in " + buildInString(iogs);

        int updatedCount;
        Transaction tx = null;
        try {
            openSession();
            tx = session.beginTransaction();
            tx.setTimeout(30);
            updatedCount = session.createQuery(sql)
                          .setDate("expriedDate", startDate).setDate("lastDate", startDate).setString("source", source)
                          .setComment("+ parallel(t,2)")
                          .executeUpdate();
            tx.commit();
            log.info(getType() + ": rows are out of current : " + updatedCount);
            return updatedCount;
        } catch (RuntimeException e) {
            e.printStackTrace();
            log.error("Failed to update to deleted with exception ", e);
            if (tx != null) {
                tx.rollback();
            }
            throw new OihPersistenceException(e);
        } finally {
            closeSession();
        }
    }
    
    protected String buildInString(List<String> values) {
        if (values == null || values.size() == 0 ){
            return null;
        }
        StringBuilder sb = new StringBuilder();
        sb.append("(");
        for (String val : values){
            sb.append(val);
            sb.append(",");
        }
        sb.deleteCharAt(sb.length()-1);
        sb.append(")");
        return sb.toString();
    }
 
    protected String[] getAsinArray(Collection<T> objs) {
        if (objs == null || objs.size() == 0) {
            return null;
        }
        ArrayList<String> al = new ArrayList<String>();
        String currentAsin = "";
        for (T o : objs) {
            if (!currentAsin.equals(o.getAsin())) {
                currentAsin = o.getAsin();
                al.add(o.getAsin());
            }

        }
        String[] ret = new String[al.size()];
        al.toArray(ret);
        return ret;
    }


    // Handle session  
    protected void openSession() {
        session = HibernateUtil.getSessionFactory().openSession();
        /*
        if (session == null || !session.isOpen()) {
            session = HibernateUtil.getSessionFactory().openSession();
        }
        */
    }

    public void closeSession() {
        if (session != null) {
            session.close();
        }
    }

  
    /**
     * retrieve the classname for the entity that is managed by this dao
     * 
     * @return
     */
    abstract public String getType();

    /*
     * ***************************************************************************
     * The following code are some common dao code.
     * Currently are not used. Should be used in future for events
     * ***************************************************************************
     */
    /**
     * 
     * @param obj
     * @return
     * @throws OihPersistenceException
     * @throws DaoRuntimeException
     */
    public T insert(T obj) throws OihPersistenceException, DaoRuntimeException {
        Transaction tx = null;
        try {
            openSession();
            tx = session.beginTransaction();
            session.save(obj);
            tx.commit();
            return obj;
        } catch (RuntimeException e) {
            log.error("Failed to save entity " + obj + " with exception ", e);
            e.printStackTrace();
            if (tx != null) {
                tx.rollback();
            }
            throw new OihPersistenceException(e);
        } finally {
            closeSession();
        }
    }


    /**
     * 
     * @param obj
     * @return
     * @throws OihPersistenceException
     * @throws DaoRuntimeException
     */
    public T update(T obj) throws OihPersistenceException, DaoRuntimeException {
        Transaction tx = null;
        try {
            openSession();
            tx = session.beginTransaction();
            session.update(obj);
            tx.commit();
            return obj;
        } catch (RuntimeException e) {
            e.printStackTrace();
            log.error("Failed to save entity " + obj + " with exception ", e);
            if (tx != null) {
                tx.rollback();
            }
            throw new OihPersistenceException(e);
        } finally {
            closeSession();
        }
    }
    
    /**
     * 
     * @param obj
     * @return
     * @throws OihPersistenceException
     * @throws DaoRuntimeException
     */
    public T delete(T obj) throws OihPersistenceException, DaoRuntimeException {
        Transaction tx = null;
        try {
            openSession();
            tx = session.beginTransaction();
            session.delete(obj);
            tx.commit();
            return obj;
        } catch (RuntimeException e) {
            log.error("Failed to remove entity " + obj + " with exception ", e);
            e.printStackTrace();
            if (tx != null) {
                tx.rollback();
            }
            throw new OihPersistenceException(e);
        } finally {
            closeSession();
        }
    }
    /**
     * Insert T into DB with OIH rules
     * @param newObj
     * @throws OihPersistenceException
     * @throws DaoRuntimeException
     */
    public void oihInsert(T newObj) throws OihPersistenceException, DaoRuntimeException {
        int retryTimes = 0;
        while (retryTimes < maxRetryTimes){
             Hashtable<String, T> oldVObjs = null;
             Transaction tx = null;
             try {
                 openSession();
                 tx = session.beginTransaction();
                 tx.setTimeout(30);
  
                 T oldObj = findCurrent(newObj);
                 oihInsert(newObj, oldObj);
                 
                 session.flush();
                 session.clear();
                 tx.commit();
                 return;
             } catch (RuntimeException e) {
                 if (++retryTimes == maxRetryTimes){
                     log.error("Failed to save entity with exception ", e);
                     e.printStackTrace();
                     if (tx != null) {
                         tx.rollback(); 
                     }
                     throw new OihPersistenceException(e);
                 } else {
                     log.info("Retry failed insert.");
                 }
             } catch (Exception e) {           
                 if (++retryTimes == maxRetryTimes){
                     log.error("Failed to save entity with exception ", e);
                     e.printStackTrace();
                     if (tx != null) {
                         tx.rollback(); 
                     }
                     throw new OihPersistenceException(e);
                 } else {
                     log.info("Retry failed insert.");
                 } 
             } finally {
                 closeSession();
             }
         }
     }
    
    /**
     * 
     * @param obj
     * @return
     * @throws OihPersistenceException
     * @throws DaoRuntimeException
     */
    abstract public T findCurrent(T obj) throws OihPersistenceException, DaoRuntimeException;
    
    /*
     * ***************************************************************************
     * The following code are wrote for loading data by action kinds.
     * The functions are deprecated now, but are not delete in case use in future.
     * ***************************************************************************
     */
    public static long submitNum = 0;

    /**
     * Insert collection values to db by batch
     * @param objs
     * @throws OihPersistenceException
     * @throws DaoRuntimeException
     */
    public void insert(Collection<T> objs) throws OihPersistenceException, DaoRuntimeException {
        Transaction tx = null;
        try {
            openSession();
            tx = session.beginTransaction();
            tx.setTimeout(30);
            for (T o : objs) {
                try {
                    session.save(o);
                } catch (Exception e) {
                    log.error("Fail to create :" + o + "\n" + e);
                    e.printStackTrace();
                }
            }
            // session.flush();
            tx.commit();
        } catch (RuntimeException e) {
            log.error("Failed to save entity with exception ", e);
            e.printStackTrace();
            if (tx != null) {
                tx.rollback();
            }
            throw new OihPersistenceException(e);
        } finally {
            closeSession();
        }
    }
    
    /**
     * Update collection values to db by batch
     * @param objs
     * @throws OihPersistenceException
     * @throws DaoRuntimeException
     */
    public void updateValues(Collection<T> objs) throws OihPersistenceException, DaoRuntimeException {
        // put new value into a hashmap
        Hashtable<Long, T> newValues = new Hashtable<Long, T>();
        for (T obj : objs) {
            newValues.put(obj.getSequenceId(), obj);
        }

        Transaction tx = null;
        ScrollableResults rs = null;
        try {
            openSession();
            tx = session.beginTransaction();
            tx.setTimeout(30);
 
            Criteria cri = session.createCriteria(getType());
            cri.add(Restrictions.in("sequenceId", getIdArray(objs)));
            rs = cri.setCacheMode(CacheMode.IGNORE).scroll(ScrollMode.FORWARD_ONLY);
            while (rs.next()) {
                T o = (T) rs.get(0);
                T newObj = newValues.get(o.getSequenceId());
                o.setIsCurrent(DaoConstants.IS_CURRENT_N);
                o.setExpiredDate(newObj.getFirstLoadDate());
                session.save(newObj);
                //o.copyValues(new);
                // o.cleanValues();
            }

            session.flush();
            session.clear();
            tx.commit();
        } catch (RuntimeException e) {
            log.error("Failed to save entity with exception ", e);
            e.printStackTrace();
            if (tx != null) {
                tx.rollback();
            }
            throw new OihPersistenceException(e);
        } catch (Exception e) {
            log.error("Fail to update :" + "\n" + e);
            e.printStackTrace();
            if (tx != null) {
                tx.rollback();
            }
        } finally {
            if (rs != null) {
                rs.close();
            }
            closeSession();
        }
    }
    
    /**
     * Update rows to deleted status
     * 
     * @param objs
     * @throws OihPersistenceException
     * @throws DaoRuntimeException
     */
    public void updateToDeleted(Collection<T> objs) throws OihPersistenceException, DaoRuntimeException {
        long start = System.currentTimeMillis();

        Transaction tx = null;
        ScrollableResults rs = null;
        try {
            openSession();
            tx = session.beginTransaction();
            tx.setTimeout(30);

            Criteria cri = session.createCriteria(getType());
            cri.add(Restrictions.in("sequenceId", getIdArray(objs)));
            rs = cri.setCacheMode(CacheMode.IGNORE).scroll(ScrollMode.FORWARD_ONLY);
            while (rs.next()) {
                T o = (T) rs.get(0);
                //o.cleanValues();
                o.setIsCurrent(null);
            }
            session.flush();
            session.clear();
            tx.commit();
        } catch (RuntimeException e) {
            log.error("Failed to save entity with exception ", e);
            e.printStackTrace();
            if (tx != null) {
                tx.rollback();
            }
            throw new OihPersistenceException(e);
        } catch (Exception e) {
            log.error("Fail to update :" + "\n" + e);
            e.printStackTrace();
            if (tx != null) {
                tx.rollback();
            }
        } finally {
            if (rs != null) {
                rs.close();
            }
            closeSession();
        }
    }

    
    /**
     * Update all the current row to current time
     * 
     * @return
     * @throws OihPersistenceException
     * @throws DaoRuntimeException
     */
    public int updateTimeForCurrent(Date date) throws OihPersistenceException, DaoRuntimeException {
        long start = System.currentTimeMillis();
        String sql = "update " + getType()
                + " t set t.lastLoadDate = :lastDate, t.expiredDate= :expiredDate where t.isCurrent = :isCurrent";

        int updatedCount;
        Transaction tx = null;
        try {
            openSession();
            tx = session.beginTransaction();
            updatedCount = session.createQuery(sql).setDate("lastDate", date).setDate("expiredDate", date).setString("isCurrent",
                    DaoConstants.IS_CURRENT_Y).executeUpdate();
            System.out.println("Update cost " + (System.currentTimeMillis() - start));
            tx.commit();
            log.info(getType() + ": CURRENT_AS_OF is updated : " + updatedCount);
            return updatedCount;
        } catch (RuntimeException e) {
            e.printStackTrace();
            log.error("Failed to update CURRENT_AS_OF with exception ", e);
            if (tx != null) {
                tx.rollback();
            }
            throw new OihPersistenceException(e);
        } finally {
            closeSession();
        }
    }

    /**
     * Get ID array for Cretrias
     * 
     * @param objs
     * @return
     */
    private Long[] getIdArray(Collection<T> objs) {
        if (objs == null || objs.size() == 0) {
            return null;
        }
        Long ret[] = new Long[objs.size()];
        int i = 0;
        for (T o : objs) {
            ret[i++] = o.getSequenceId();
        }
        return ret;
    }
}
