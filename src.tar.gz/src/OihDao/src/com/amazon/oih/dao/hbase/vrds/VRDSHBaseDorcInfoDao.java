package com.amazon.oih.dao.hbase.vrds;

import java.io.IOException;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.client.Result;

import amazon.platform.config.AppConfig;

import com.amazon.oih.dao.DaoConstants;
import com.amazon.oih.dao.hbase.base.AbstractHBaseDaoImpl;
import com.amazon.oih.dao.hbase.converter.HBaseObjectDefaultConverter;
import com.amazon.oih.dao.hbase.schema.HTableNameCFGeneratorImpl;
import com.amazon.oih.utils.TimerHelper;
import com.google.common.base.Function;
import java.util.concurrent.atomic.AtomicInteger;

@Deprecated
public class VRDSHBaseDorcInfoDao extends AbstractHBaseDaoImpl<VRDSHBaseDorcInfo> {
    final static String DORC_INFO_INPUTNAME = AppConfig.findString(DaoConstants.VRDS_DORC_INFO_INPUTNAME);
    final static String DORC_INFO_COLUMNFAMILY = AppConfig.findString(DaoConstants.VRDS_DORC_INFO_COLUMNFAMILY);

    VRDSHBaseDorcInfoConverter vrdsHBaseDorcInfoConverter = new VRDSHBaseDorcInfoConverter();

    public VRDSHBaseDorcInfoDao(Date rundate, String realm) {
        super(new HTableNameCFGeneratorImpl(DORC_INFO_INPUTNAME, DORC_INFO_COLUMNFAMILY, realm, rundate), realm);
    }

    @Override
    protected VRDSHBaseDorcInfo convert(String rowKey, Result rs) throws IOException {
        return vrdsHBaseDorcInfoConverter.convert(rowKey, rs);
    }

    @Override
    protected List<Put> convert(VRDSHBaseDorcInfo bObject) throws IOException {
        return vrdsHBaseDorcInfoConverter.convert(bObject);
    }
    
    public Set<String> findExistAsinIogs(final List<String> asinIogs) throws IOException{
        final Set<String> asinIogSet = new HashSet<String>();
        long start = System.currentTimeMillis();
        String startAsinIog = asinIogs.get(0);
        String stopAsinIog = asinIogs.get(asinIogs.size()-1);
        byte[] stopKeyBytes = stopAsinIog.getBytes();
        stopKeyBytes[stopKeyBytes.length-1] = (byte) (stopKeyBytes[stopKeyBytes.length-1] + 1);
        String stopKey = new String(stopKeyBytes);
        final AtomicInteger count = new AtomicInteger(0);
        this.scanRowKeys(startAsinIog, stopKey, new Function<String, Void>(){
            @Override
            public Void apply(String asinIogDsiidKey) {
                count.incrementAndGet();
                String asinIog = getAsinIogFromRowKey(asinIogDsiidKey);
                if(asinIogs.contains(asinIog)){
                    asinIogSet.add(asinIog);
                }
                return null;
            };
        });
        if(count.intValue() > 1024 && count.intValue() > asinIogs.size() * 2){
            System.out.println("BigScan: "+ count.intValue() + ", start: "+ startAsinIog + ", stop: "+ stopAsinIog);
        }
        TimerHelper.getInstance().addPhase(this.getClass().getSimpleName() + "#scanRowKeys", start);
        return asinIogSet;
    }
    
    public String getRowKey(VRDSHBaseDorcInfo bObject) {
        return vrdsHBaseDorcInfoConverter.getRowKey(bObject);
    }
    
    private String getAsinIogFromRowKey(String rowKey){
        return rowKey.substring(0, rowKey.lastIndexOf(HBaseObjectDefaultConverter.getRowKeySplit()));
    }
}
