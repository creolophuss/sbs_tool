package com.amazon.oih.dao.hbase.schema;

import java.io.IOException;
import java.util.List;

import org.apache.hadoop.hbase.client.HTableInterface;

public interface HBaseSchemaDao {
    
    public HTableInterface getHtable(String tableName);

    public void createHTable(String tableName, String[] columnFamilies) throws IOException;

    public boolean tableExists(String tableName) throws IOException;

    public void deleteHTable(String tableName) throws IOException;

    void recreateHTable(String tableName, String[] columnFamilies) throws IOException;

    public void createHTableIfNotExisted(String tableName, String columnFamily) throws IOException;

    List<String> getHtableColumnFamilies(String tableName) throws IOException;    

    List<String> getHtableRegionSplitKeys(String tableName) throws IOException;    

    List<String> listHtableNames() throws IOException;

}
