package com.amazon.oih.dao.hbase.vrds;

import java.util.Date;

import com.amazon.oih.dao.hbase.base.SubKeyAwareHBaseDao;

public class VRDSFcskuInfoHbaseDao extends SubKeyAwareHBaseDao<VRDSFcskuInfo>{

    public VRDSFcskuInfoHbaseDao() {
        super(VRDSFcskuInfo.class);
    }
    
    public VRDSFcskuInfoHbaseDao(String additionalId, String realm, Date rundate) {
        super(VRDSFcskuInfo.class, additionalId, realm, rundate);
    }
}
