package com.amazon.oih.dao.procurability;

import java.io.Serializable;

import com.amazon.oih.common.RowKeyBuildType;
import com.amazon.oih.common.RowKeyType;
import com.amazon.oih.dao.hbase.base.CommonKVHBaseDao.HTable;
import com.amazon.oih.dao.hbase.converter.Column;
import com.amazon.oih.dao.hbase.converter.RowKey;

@RowKey({"asin", "scopeId"})
@RowKeyBuildType(RowKeyType.ASIN_SCOPE)
@HTable(value = "Procurability", columFamilyName = "pc")
public class Procurability implements Serializable {
    private static final long serialVersionUID = -4058499167432238753L;

    String asin;
    
    String scopeId;
    
    @Column(name="rc",index=0)
    Boolean procurable;
    
    //for reconstruction from serialization
    public Procurability(){} 
    
    public Procurability(String asin, String scopeId, Boolean procurable) {
        this.asin = asin;
        this.scopeId = scopeId;
        this.procurable = procurable;
    }


    public String getAsin() {
        return asin;
    }

    public void setAsin(String asin) {
        this.asin = asin;
    }

    public String getScopeId() {
        return scopeId;
    }

    public void setScopeId(String scopeId) {
        this.scopeId = scopeId;
    }

    public Boolean getProcurable() {
        return procurable;
    }

    public void setProcurable(Boolean procurable) {
        this.procurable = procurable;
    }    

}
