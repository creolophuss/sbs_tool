package com.amazon.oih.dao.shipcosts;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.log4j.Logger;

import com.amazon.oih.utils.SerializationUtil;
import com.google.common.collect.Table;

public class AsinShipoutCostInfoEncoder {

    private static Logger log = Logger.getLogger(AsinShipoutCostInfoEncoder.class);
    
    public static AsinShipoutCostInfoHBaseObject asinShipCostInfotoHBaseObject(AsinShipoutCostInfo info) {
        
        Table<Double, String, Double> costTable = info.getCostTable();
        
        Set<Double> weights = costTable.rowKeySet();
        Map<Double, Map<String, Double>> costDesc = new HashMap<Double, Map<String, Double>>();
        
        for(Double weight : weights) {
            Map<String, Double> costDetail = costTable.row(weight);
            costDesc.put(weight, costDetail);
        }
        
        try {
            String costDetailsDesc = SerializationUtil.toJsonString(costDesc);
            costDetailsDesc = costDetailsDesc.replace(",", "#");
            AsinShipoutCostInfoHBaseObject ret = new AsinShipoutCostInfoHBaseObject();
            ret.setAsin(info.getAsin());
            ret.setScopeId(info.getScopeId());
            ret.setValue(costDetailsDesc);
            
            return ret;
        } catch (Exception e) {
            log.error("Exception when encode AsinShipoutCostInfo to HBaseObj", e);
            return null;
        }
    }
    
    public static AsinShipoutCostInfo hBaseObjectToAsinShipoutCostInfo(AsinShipoutCostInfoHBaseObject hbaseObj) {
        AsinShipoutCostInfo info = new AsinShipoutCostInfo();
        info.setAsin(hbaseObj.getAsin());
        info.setScopeId(hbaseObj.getScopeId());
        
        String costDetailsDesc = hbaseObj.getValue();
       
        try {
            costDetailsDesc = costDetailsDesc.replace("#", ",");
            Map<String, Map<String, Double>> rows = (Map<String, Map<String, Double>>)SerializationUtil.readJsonObject(
                    costDetailsDesc, Map.class);
            
            for(Entry<String, Map<String, Double>> row : rows.entrySet()) {
                
                Double weight = Double.valueOf(row.getKey());
                for(Entry<String, Double> cell : row.getValue().entrySet()) {
                    String warehouse = cell.getKey();
                    Double value = (Double)cell.getValue();
                    
                    info.addCost(weight, warehouse, value);
                }
            }
            
            return info;
            
        } catch (Exception e) {
            log.error("Exception when parse cost details table from underlyin string " + costDetailsDesc + "," + info.getAsin(), e);
            throw new RuntimeException(costDetailsDesc + "," + info.getAsin(), e);
        }
    }
   
}
