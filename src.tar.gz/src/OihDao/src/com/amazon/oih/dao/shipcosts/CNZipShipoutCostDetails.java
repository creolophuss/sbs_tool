package com.amazon.oih.dao.shipcosts;

import com.amazon.oih.common.KVFormater.FileColumnNames;
import com.amazon.oih.common.KeyValueBase.NamedValue;
import com.google.common.primitives.Doubles;

@FileColumnNames({"source", "dest", "kG100UnitCost", "kG300UnitCost", "kG500UnitCost", "moreUnitCost", "startWeight", "startCost"})
public class CNZipShipoutCostDetails {

    @NamedValue("source")
    private String source;
    
    @NamedValue("dest")
    private String dest;
    
    @NamedValue("kG100UnitCost")
    private String kG100UnitCost;
    
    @NamedValue("kG300UnitCost")
    private String kG300UnitCost;
    
    @NamedValue("kG500UnitCost")
    private String kG500UnitCost;
    
    @NamedValue("moreUnitCost")
    private String moreUnitCost;
    
    @NamedValue("startWeight")
    private String startWeight;
    
    @NamedValue("startCost")
    private String startCost;

    public CNZipShipoutCostDetails() {
        
    }
    
    public CNZipShipoutCostDetails(String record) {
        
        String[] fields = record.split(",");
        
        setSource(fields[0]);
        setDest(fields[1]);
        
        setkG100UnitCost(fields[2]);
        setkG300UnitCost(fields[3]);
        setkG500UnitCost(fields[4]);
        setMoreUnitCost(fields[5]);
        
        setStartWeight(fields[6]);
        setStartCost(fields[7]);
    }
    
    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getDest() {
        return dest;
    }

    public void setDest(String dest) {
        this.dest = dest;
    }

    public String getkG100UnitCost() {
        return kG100UnitCost;
    }

    public void setkG100UnitCost(String kG100UnitCost) {
        this.kG100UnitCost = kG100UnitCost;
    }

    public String getkG300UnitCost() {
        return kG300UnitCost;
    }

    public void setkG300UnitCost(String kG300UnitCost) {
        this.kG300UnitCost = kG300UnitCost;
    }

    public String getkG500UnitCost() {
        return kG500UnitCost;
    }

    public void setkG500UnitCost(String kG500UnitCost) {
        this.kG500UnitCost = kG500UnitCost;
    }

    public String getMoreUnitCost() {
        return moreUnitCost;
    }

    public void setMoreUnitCost(String moreUnitCost) {
        this.moreUnitCost = moreUnitCost;
    }

    public String getStartWeight() {
        return startWeight;
    }

    public void setStartWeight(String startWeight) {
        this.startWeight = startWeight;
    }

    public String getStartCost() {
        return startCost;
    }

    public void setStartCost(String startCost) {
        this.startCost = startCost;
    }
    
    @Override
    public String toString() {
        StringBuffer sb = new StringBuffer();
        sb.append(source).append(",")
          .append(dest).append(",")
          .append(kG100UnitCost).append(",")
          .append(kG300UnitCost).append(",")
          .append(kG500UnitCost).append(",")
          .append(moreUnitCost).append(",")
          .append(startWeight).append(",")
          .append(startCost);
        
        return sb.toString();
    }
}
