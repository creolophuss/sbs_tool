package com.amazon.oih.dao.vrdsDisposition;

public class ReturnTermInfo {

	String asin;
	int iog;
	int marketplaceId;
	String vendor;
	double refundPercentage;
	String refundBasisCode;
	boolean isReturnAllowed;
	boolean isAsinReturnAllowed;
	boolean isAuthRequired;
	int returnByMinDays;
	int returnByMaxDays;
	double perUnitRestockingValue;
	String perUnitRestockingBasis;
	ReturnCapInfo returnCap;
	String openAuthorizationNumber;
	
	public String getAsin() {
		return asin;
	}
	public void setAsin(String asin) {
		this.asin = asin;
	}
	public int getIog() {
		return iog;
	}
	public void setIog(int iog) {
		this.iog = iog;
	}
	public int getMarketplaceId() {
		return marketplaceId;
	}
	public void setMarketplaceId(int marketplaceId) {
		this.marketplaceId = marketplaceId;
	}
	public String getVendor() {
		return vendor;
	}
	public void setVendor(String vendor) {
		this.vendor = vendor;
	}
	public double getRefundPercentage() {
		return refundPercentage;
	}
	public void setRefundPercentage(double refundPercentage) {
		this.refundPercentage = refundPercentage;
	}
	public String getRefundBasisCode() {
		return refundBasisCode;
	}
	public void setRefundBasisCode(String refundBasisCode) {
		this.refundBasisCode = refundBasisCode;
	}
	public boolean isReturnAllowed() {
		return isReturnAllowed;
	}
	public void setReturnAllowed(boolean isReturnAllowed) {
		this.isReturnAllowed = isReturnAllowed;
	}
	public boolean isAuthRequired() {
		return isAuthRequired;
	}
	public void setAuthRequired(boolean isAuthRequired) {
		this.isAuthRequired = isAuthRequired;
	}
	public int getReturnByMinDays() {
		return returnByMinDays;
	}
	public void setReturnByMinDays(int returnByMinDays) {
		this.returnByMinDays = returnByMinDays;
	}
	public int getReturnByMaxDays() {
		return returnByMaxDays;
	}
	public void setReturnByMaxDays(int returnByMaxDays) {
		this.returnByMaxDays = returnByMaxDays;
	}
	public double getPerUnitRestockingValue() {
		return perUnitRestockingValue;
	}
	public void setPerUnitRestockingValue(double perUnitRestockingValue) {
		this.perUnitRestockingValue = perUnitRestockingValue;
	}
	public String getPerUnitRestockingBasis() {
		return perUnitRestockingBasis;
	}
	public void setPerUnitRestockingBasis(String perUnitRestockingBasis) {
		this.perUnitRestockingBasis = perUnitRestockingBasis;
	}

	public String toString() {
		
		StringBuffer str = new StringBuffer();
		str.append("asin: ");
		str.append(asin);
		str.append(" iog: ");
		str.append(iog);
		str.append(" marketplace: ");
		str.append(marketplaceId);
		str.append(" vendor: ");
		str.append(vendor);
		str.append(" refund percentage: ");
		str.append(refundPercentage);
		str.append(" isReturnAllowed: ");
		str.append(isReturnAllowed);
		str.append(" isAsinReturnAllowed: ");
		str.append(isAsinReturnAllowed);
		str.append(" isAuthRequired: ");
		str.append(isAuthRequired);
		str.append(" returnCap: ");
		str.append(returnCap);
		return str.toString();
	}
	public void setAsinReturnAllowed(boolean isAsinReturnAllowed) {
		this.isAsinReturnAllowed = isAsinReturnAllowed;
	}
	public boolean isAsinReturnAllowed() {
		return isAsinReturnAllowed;
	}
	
	public ReturnCapInfo getReturnCap() {
		return returnCap;
	}
	public void setReturnCap(ReturnCapInfo returnCap) {
		this.returnCap = returnCap;
	}
	
	public String getOpenAuthorizationNumber() {
        return openAuthorizationNumber;
    }
    public void setOpenAuthorizationNumber(String openAuthorizationNumber) {
        this.openAuthorizationNumber = openAuthorizationNumber;
    }	

}
