package com.amazon.oih.dao.transportationcost;

import java.util.List;

public interface TransportationCostDao {
    public List<TransportationCost> getTransportationCosts(String realm);
    public void save(TransportationCost transportationCost) throws Exception;
}
