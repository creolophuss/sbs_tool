package com.amazon.oih.dao.forecast34to52;

import java.util.Collection;
import java.util.List;

import org.apache.log4j.Logger;

import com.amazon.carbonado.IsolationLevel;
import com.amazon.carbonado.PersistException;
import com.amazon.carbonado.Repository;
import com.amazon.carbonado.RepositoryException;
import com.amazon.carbonado.Storage;
import com.amazon.carbonado.SupportException;
import com.amazon.carbonado.Transaction;
import com.amazon.oih.dao.forecast.ForecastType;

public class Forecast34To52DaoImpl implements Forecast34To52Dao{

    final static Logger log = Logger.getLogger(Forecast34To52DaoImpl.class);

    protected String domain = null;

    protected Repository repository = null;

    public Forecast34To52DaoImpl(String domain) {
        this.domain = domain;
    }

    public void setRepository(Repository repository) {
        if (null == repository) {
            throw new IllegalArgumentException("repository cannot be null.");
        }
        this.repository = repository;
    }
    
	@Override
	public Forecast34To52 createForecast34To52(String asin, Integer marketplaceId,
			ForecastType type, List<Double> forecasts) throws SupportException,
			RepositoryException {
        Storage<Forecast34To52> sf = repository.storageFor(Forecast34To52.class);
        Forecast34To52 f = sf.prepare();

        f.setAsin(asin);
        f.setForecastType(type);
        f.setMarketplaceId(marketplaceId);
        f.setWeek34(forecasts.get(0));
        f.setWeek35(forecasts.get(1));
        f.setWeek36(forecasts.get(2));
        f.setWeek37(forecasts.get(3));
        f.setWeek38(forecasts.get(4));
        f.setWeek39(forecasts.get(5));
        f.setWeek40(forecasts.get(6));
        f.setWeek41(forecasts.get(7));
        f.setWeek42(forecasts.get(8));
        f.setWeek43(forecasts.get(9));
        f.setWeek44(forecasts.get(10));
        f.setWeek45(forecasts.get(11));
        f.setWeek46(forecasts.get(12));
        f.setWeek47(forecasts.get(13));
        f.setWeek48(forecasts.get(14));
        f.setWeek49(forecasts.get(15));
        f.setWeek50(forecasts.get(16));
        f.setWeek51(forecasts.get(17));
        f.setWeek52(forecasts.get(18));
        return f;
	}

	@Override
	public boolean exists(String asin, Integer marketplaceId) throws RepositoryException {
        boolean retVal = false;
        Storage<Forecast34To52> sf = repository.storageFor(Forecast34To52.class);
        retVal = sf.query("asin = ? & marketplaceId = ?").with(asin).with(marketplaceId).exists();
        return retVal;
	}

	@Override
	public boolean exists(String asin, Integer marketplaceId, ForecastType type)throws RepositoryException {
        boolean retVal = false;

        Storage<Forecast34To52> sf = repository.storageFor(Forecast34To52.class);
        retVal = sf.query("asin = ? & marketplaceId = ? & type = ?").with(asin).with(marketplaceId).with(type.name()).exists();

        return retVal;
	}
	
	@Override
	public Forecast34To52 find(String asin, Integer marketplaceId, ForecastType type)
			throws RepositoryException {
        Storage<Forecast34To52> sf = repository.storageFor(Forecast34To52.class);
        Forecast34To52 data = sf.query("asin = ? & marketplaceId = ? & type = ?").with(asin).with(marketplaceId).with(type.name())
                .loadOne();

        return data;
	}
	
	@Override
	public List<Forecast34To52> find(String asin, Integer marketplaceId) throws RepositoryException {
        Storage<Forecast34To52> sf = repository.storageFor(Forecast34To52.class);
        List<Forecast34To52> data = sf.query("asin = ? & marketplaceId = ?").with(asin).with(marketplaceId).fetch().toList();

        return data;
	}

	@Override
	public void save(Forecast34To52 o) throws PersistException {
        o.insert();
	}

	@Override
	public void save(Collection<Forecast34To52> o) throws PersistException {
        Transaction txn = repository.enterTransaction(IsolationLevel.READ_UNCOMMITTED);

        try {
            for (Forecast34To52 f : o) {
                f.insert();
            }

            txn.commit();
        } catch (PersistException e) {
            throw e;
        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
            txn.exit();
        }
	}

}
