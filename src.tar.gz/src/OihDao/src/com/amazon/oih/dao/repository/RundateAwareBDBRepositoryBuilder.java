package com.amazon.oih.dao.repository;

import java.io.File;
import java.util.concurrent.atomic.AtomicReference;

import amazon.platform.config.AppConfig;

import com.amazon.carbonado.ConfigurationException;
import com.amazon.carbonado.Repository;
import com.amazon.carbonado.RepositoryBuilder;
import com.amazon.carbonado.RepositoryException;
import com.amazon.carbonado.TriggerFactory;
import com.amazon.carbonado.repo.sleepycat.BDBRepositoryBuilder;

/**
 * Accepts an additional rundate for environment home. Rundate must be in a format we can use for directory name
 */
public class RundateAwareBDBRepositoryBuilder implements RepositoryBuilder {
    protected final BDBRepositoryBuilder bdbRepositoryBuilder = new BDBRepositoryBuilder();
    private String rundate;
    private String tempFileHome;

    @Override
    public boolean addTriggerFactory(TriggerFactory tf) {
        return bdbRepositoryBuilder.addTriggerFactory(tf);
    }

    @Override
    public Repository build() throws ConfigurationException, RepositoryException {
        return bdbRepositoryBuilder.build();
    }

    @Override
    public Repository build(AtomicReference<Repository> rootRef) throws ConfigurationException, RepositoryException {
        return bdbRepositoryBuilder.build(rootRef);
    }

    @Override
    public String getName() {
        return bdbRepositoryBuilder.getName();
    }

    @Override
    public Iterable<TriggerFactory> getTriggerFactories() {
        return bdbRepositoryBuilder.getTriggerFactories();
    }

    @Override
    public boolean isMaster() {
        return bdbRepositoryBuilder.isMaster();
    }

    @Override
    public boolean removeTriggerFactory(TriggerFactory tf) {
        return bdbRepositoryBuilder.removeTriggerFactory(tf);
    }

    @Override
    public void setMaster(boolean master) {
        bdbRepositoryBuilder.setMaster(master);
    }

    @Override
    public void setName(String name) {
        bdbRepositoryBuilder.setName(name);
    }

    public void setTransactionWriteNoSync(boolean noSync) {
        bdbRepositoryBuilder.setTransactionWriteNoSync(noSync);
    }

    public boolean getTransactionWriteNoSync() {
        return bdbRepositoryBuilder.getTransactionWriteNoSync();
    }

    public void setProduct(String product) {
        bdbRepositoryBuilder.setProduct(product);
    }

    public String getProduct() {
        return bdbRepositoryBuilder.getProduct();
    }

    public void setEnvironmentHome(String envHome) throws RepositoryException {
        if (rundate == null)
            tempFileHome = envHome;
        else
            setEnvironmentHomeFile(new File(envHome));
    }

    public String getEnvironmentHome() {
        return bdbRepositoryBuilder.getEnvironmentHome();
    }

    public void setEnvironmentHomeFile(File envHome) throws RepositoryException {
        if (rundate == null) {
            throw new RepositoryException(
                    "Undefined rundate. Rundate is required and must be specified prior to environment home");
        }

        bdbRepositoryBuilder.setEnvironmentHomeFile(new File(envHome.getPath() + File.separator + rundate));
    }
    
    public void buildEnvironmentHomeFile(String realm) throws RepositoryException {
    	tempFileHome = tempFileHome.replaceAll(AppConfig.getRealm().name(), realm);
    	System.out.println("replace realm :" + AppConfig.getRealm().name() + " with:" + realm + " and got:" + tempFileHome );
        bdbRepositoryBuilder.setEnvironmentHomeFile(new File(tempFileHome + File.separator + rundate));
    }

    public File getEnvironmentHomeFile() {
        return bdbRepositoryBuilder.getEnvironmentHomeFile();
    }

    public void setRundate(String rundate) {
        this.rundate = rundate;
    }

    public String getRundate() {
        return rundate;
    }

    public void setCachePercent(int percent) {
        bdbRepositoryBuilder.setCachePercent(percent);
    }

    public int getCachePercent() {
        return bdbRepositoryBuilder.getCachePercent();
    }
}
