package com.amazon.oih.dao.hbase.base;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import org.apache.hadoop.hbase.client.Delete;
import org.apache.hadoop.hbase.client.Get;
import org.apache.hadoop.hbase.client.HTable;
import org.apache.hadoop.hbase.client.HTableInterface;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.client.ResultScanner;
import org.apache.hadoop.hbase.client.Scan;
import org.apache.hadoop.hbase.filter.FilterList;
import org.apache.hadoop.hbase.filter.FirstKeyOnlyFilter;
import org.apache.hadoop.hbase.filter.KeyOnlyFilter;
import org.apache.hadoop.hbase.util.Bytes;
import org.apache.log4j.Logger;

import com.amazon.oih.dao.hbase.schema.HBaseSchemaDao;
import com.amazon.oih.dao.hbase.schema.HBaseSchemaDaoImpl;
import com.amazon.oih.dao.hbase.schema.HTableNameCFGenerator;
import com.amazon.oih.utils.HTableUtil;
import com.amazon.oih.utils.TimerHelper;
import com.google.common.base.Function;

public abstract class AbstractHBaseDaoImpl<T> implements HBaseDao<T> {

    private static Logger log = Logger.getLogger(AbstractHBaseDaoImpl.class);
    
    private static final int DEFAULT_SMALL_SCAN_CACHING_SIZE = 128;
    private static final int DEFAULT_FULL_SCAN_CACHING_SIZE = 1024;

    protected HBaseSchemaDao hbaseSchemaDao = null;
    protected HTableInterface hTable = null;
    protected String tableName = null;
    protected String columnFamily = null;

    protected static final int MARK_OF_TUESDAY = 3;
    protected static final int MARK_OF_SATURDAY = 7;
    protected static final String TABLENAME_SPLIT = "_";

    public AbstractHBaseDaoImpl(HTableNameCFGenerator generator, String realm) {
        try {
            tableName = generator.getTableName();
            columnFamily = generator.getColumnFamily();
            hbaseSchemaDao = HBaseSchemaDaoImpl.getInstance(realm, null);
            log.info("Creating HBase Schema for table " + tableName + ",realm " + realm + ", source identity="
                    + HBaseSchemaDaoImpl.DEFAULT_SOURCE_IDENTITY);
            hbaseSchemaDao.createHTableIfNotExisted(tableName, columnFamily);
        } catch (IOException e) {
            e.printStackTrace();
            throw new RuntimeException("Can NOT create new HBase Table: " + tableName);
        }
        hTable = hbaseSchemaDao.getHtable(tableName);
    }

    public AbstractHBaseDaoImpl(String tableName, String columnFamily, String realm, String sourceIdentity) {
        log.info("Creating HBase Schema for table " + tableName + ",realm " + realm + ", source identity="
                + sourceIdentity);
        hbaseSchemaDao = HBaseSchemaDaoImpl.getInstance(realm, sourceIdentity);
        this.tableName = tableName;
        this.columnFamily = columnFamily;
        hTable = hbaseSchemaDao.getHtable(tableName);
    }

    public AbstractHBaseDaoImpl() {

    }

    String daoClassName = this.getClass().getSimpleName();

    @Override
    public void putSingleElement(T bObject) throws IOException {
        long start = System.currentTimeMillis();
        List<Put> puts = convert(bObject);
        put(hTable, puts);
        TimerHelper.getInstance().addPhase(daoClassName + "#put", start);
    }

    @Override
    public void put(List<T> bObjects) throws IOException {
        if (bObjects == null) {
            return;
        }
        long start = System.currentTimeMillis();
        List<Put> puts = new ArrayList<Put>(bObjects.size());
        for (T bObject : bObjects) {
            puts.addAll(convert(bObject));
        }
        put(hTable, puts);
        TimerHelper.getInstance().addPhase(daoClassName + "#batchPut", start);
    }
    
    private void put(HTableInterface hTable, List<Put> puts) throws IOException{
        if (hTable instanceof HTable){
            HTableUtil.bucketRsPut((HTable)hTable, puts);
        } else {
            hTable.put(puts);
            hTable.flushCommits();
        }
    }

    @Override
    public T get(String rowKey) throws IOException {
        long start = System.currentTimeMillis();
        Get get = new Get(rowKey.getBytes());
        Result rs = hTable.get(get);
        T result = convert(rowKey, rs);
        TimerHelper.getInstance().addPhase(daoClassName + "#get", start);
        return result;
    }

    @Override
    public List<T> get(Collection<String> rowKeys) throws IOException {
        long start = System.currentTimeMillis();
        List<Get> gets = new ArrayList<Get>(rowKeys.size());
        for (String rowKey : rowKeys) {
            gets.add(new Get(rowKey.getBytes()));
        }
        List<T> objects = new ArrayList<T>(rowKeys.size());
        Result[] results = hTable.get(gets);
        int i = 0;
        for (String rowKey : rowKeys) {
            objects.add(convert(rowKey, results[i]));
            i++;
        }
        TimerHelper.getInstance().addPhase(daoClassName + "#batchGet", start);
        return objects;
    }

    @Override
    public boolean exist(String rowKey) throws IOException {
        long start = System.currentTimeMillis();
        Get get = new Get(rowKey.getBytes());
        boolean isExisted = hTable.exists(get);
        TimerHelper.getInstance().addPhase(daoClassName + "#exist", start);
        return isExisted;
    }

    @Override
    public boolean exist(String rowKey, String qualifier) throws IOException {
        long start = System.currentTimeMillis();
        Get get = new Get(rowKey.getBytes());
        get.addColumn(columnFamily.getBytes(), qualifier.getBytes());
        boolean isExisted = hTable.exists(get);
        TimerHelper.getInstance().addPhase(daoClassName + "#existQualifier", start);
        return isExisted;
    }

    @Override
    public void deleteRow(String rowKey) throws IOException {
        long start = System.currentTimeMillis();
        Delete delete = new Delete(rowKey.getBytes());
        hTable.delete(delete);
        TimerHelper.getInstance().addPhase(daoClassName + "#delete", start);
    }

    @Override
    public void deleteRows(List<String> rowKeys) throws IOException {
        long start = System.currentTimeMillis();
        List<Delete> deletes = new ArrayList<Delete>(rowKeys.size());
        for (String rowKey : rowKeys) {
            deletes.add(new Delete(rowKey.getBytes()));
        }
        hTable.delete(deletes);
        TimerHelper.getInstance().addPhase(daoClassName + "#batchDelete", start);
    }

    @Override
    public void close() throws IOException {
        hTable.close();
    }

    public List<T> scanBatch(LinkedList<String> rowKeys) {
        long start = System.currentTimeMillis();
        List<T> objects = new ArrayList<T>(rowKeys.size());

        Scan scan = new Scan();
        String startRow = generateStartRow(rowKeys);
        String stopRow = generateStopRow(rowKeys);
        scan.setStartRow(Bytes.toBytes(startRow));
        scan.setStopRow(Bytes.toBytes(stopRow));
        scan.setCaching(DEFAULT_SMALL_SCAN_CACHING_SIZE);
        ResultScanner results = null;
        try {
            results = hTable.getScanner(scan);
            for (Result result : results) {
                if (rowKeys.isEmpty()) {
                    break;
                }
                addOrFilter(result, objects, rowKeys);
            }
        } catch (IOException e) {
            e.printStackTrace();
            return objects;
        } finally {
            results.close();
        }
        TimerHelper.getInstance().addPhase(daoClassName + "#scan", start);
        return objects;
    }
    
    public void scanRowKeys(String startKey, String stopKey, Function<String, Void> callback) throws IOException{
        Scan scan = new Scan(startKey.getBytes(), stopKey.getBytes());
        scan.setCaching(DEFAULT_SMALL_SCAN_CACHING_SIZE);
        scan.setFilter(new FilterList(FilterList.Operator.MUST_PASS_ALL, new KeyOnlyFilter(), new FirstKeyOnlyFilter()));
        ResultScanner results = null;
        try {
            results = hTable.getScanner(scan);
            Iterator<Result> it = results.iterator();
            while(it.hasNext()){
                Result result = it.next();
                String rowKey = new String(result.getRow());
                callback.apply(rowKey);
            }
        } finally{
            if(results != null){
                results.close();
            }
        }    
    }    
    
    
    public void scanAll(Function<T,Void> callback) throws IOException{
        Scan scan = new Scan();
        scan.setCacheBlocks(true);
        scan.setCaching(DEFAULT_FULL_SCAN_CACHING_SIZE);
        ResultScanner results = null;
        try {
            results = hTable.getScanner(scan);
            Iterator<Result> it = results.iterator();
            while(it.hasNext()){
                Result result = it.next();
                T obj = convert(new String(result.getRow()), result);
                callback.apply(obj);
            }
        } finally{
            if(results != null){
                results.close();
            }
        }
    }

    private String generateStopRow(LinkedList<String> rowKeys) {
        char[] lastRowKey = rowKeys.getLast().toCharArray();
        lastRowKey[lastRowKey.length - 1] = (char) (lastRowKey[lastRowKey.length - 1] + 1);
        return new String(lastRowKey);
    }

    private String generateStartRow(LinkedList<String> rowKeys) {
        return rowKeys.getFirst();
    }

    private void addOrFilter(Result result, List<T> objects, LinkedList<String> rowKeys) throws IOException {
        String row = new String(result.getRow());
        while (!rowKeys.isEmpty()) {
            String currentRowKey = rowKeys.getFirst();
            if (row.startsWith(currentRowKey)) {
                objects.add(convert(row, result));
                break;
            } else {
                if (row.compareTo(currentRowKey) < 0) {
                    break;
                } else {
                    rowKeys.removeFirst();
                }
            }
        }
    }

    protected abstract T convert(String rowKey, Result rs) throws IOException;

    protected abstract List<Put> convert(T bObject) throws IOException;

}
