package com.amazon.oih.dao.forecast34to52;

import com.amazon.carbonado.Alias;
import com.amazon.carbonado.Derived;
import com.amazon.carbonado.PrimaryKey;
import com.amazon.carbonado.Storable;
import com.amazon.carbonado.constraint.FloatConstraint;
import com.amazon.carbonado.constraint.LengthConstraint;
import com.amazon.carbonado.constraint.TextConstraint;
import com.amazon.oih.dao.forecast.ForecastType;

/**
 * Forecast 34 to 52 bean with annotations for Carbonado ORM. Simple constraints added for data verification.
 */
@Alias("data_Forecast34To52")
@PrimaryKey( {
        "asin", "marketplaceId", "type"
})
public abstract class Forecast34To52  implements Storable<Forecast34To52> {

    public abstract String getAsin();

    @LengthConstraint(min = 10, max = 10)
    public abstract void setAsin(String asin);

    @Alias("marketplaceId")
    public abstract int getMarketplaceId();
    public abstract void setMarketplaceId(int marketplaceId);
    
    public abstract String getType();
    @TextConstraint(allowed = {"PNT", "OV", "P50", "MEAN", "OIH", "pnt", "ov", "p50", "mean", "oih"})
    public abstract void setType(String type);

    /**
     * Return the type as a ForecastType enum instead of as a string.
     * 
     * @return ForecastType enum
     */
    @Derived
    public ForecastType getForecastType() {
        return ForecastType.valueOf(getType());
    }

    /**
     * Set type type using the ForecastType enum instead of a String.
     * 
     * @param t type as a ForecastType enum
     */
    public void setForecastType(ForecastType t) {
        setType(t.name());
    }

    @Alias("week34")
    public abstract double getWeek34();
    @FloatConstraint(min = 0, max = Float.MAX_VALUE)
    public abstract void setWeek34(double week);   
    
    @Alias("week35")
    public abstract double getWeek35();
    @FloatConstraint(min = 0, max = Float.MAX_VALUE)
    public abstract void setWeek35(double week);   

    @Alias("week36")
    public abstract double getWeek36();
    @FloatConstraint(min = 0, max = Float.MAX_VALUE)
    public abstract void setWeek36(double week);   

    @Alias("week37")
    public abstract double getWeek37();
    @FloatConstraint(min = 0, max = Float.MAX_VALUE)
    public abstract void setWeek37(double week);   

    @Alias("week38")
    public abstract double getWeek38();
    @FloatConstraint(min = 0, max = Float.MAX_VALUE)
    public abstract void setWeek38(double week);   

    @Alias("week39")
    public abstract double getWeek39();
    @FloatConstraint(min = 0, max = Float.MAX_VALUE)
    public abstract void setWeek39(double week);   

    @Alias("week40")
    public abstract double getWeek40();
    @FloatConstraint(min = 0, max = Float.MAX_VALUE)
    public abstract void setWeek40(double week);   

    @Alias("week41")
    public abstract double getWeek41();
    @FloatConstraint(min = 0, max = Float.MAX_VALUE)
    public abstract void setWeek41(double week);   

    @Alias("week42")
    public abstract double getWeek42();
    @FloatConstraint(min = 0, max = Float.MAX_VALUE)
    public abstract void setWeek42(double week);   

    @Alias("week43")
    public abstract double getWeek43();
    @FloatConstraint(min = 0, max = Float.MAX_VALUE)
    public abstract void setWeek43(double week);   

    @Alias("week44")
    public abstract double getWeek44();
    @FloatConstraint(min = 0, max = Float.MAX_VALUE)
    public abstract void setWeek44(double week);   

    @Alias("week45")
    public abstract double getWeek45();
    @FloatConstraint(min = 0, max = Float.MAX_VALUE)
    public abstract void setWeek45(double week);   

    @Alias("week46")
    public abstract double getWeek46();
    @FloatConstraint(min = 0, max = Float.MAX_VALUE)
    public abstract void setWeek46(double week);   

    @Alias("week47")
    public abstract double getWeek47();
    @FloatConstraint(min = 0, max = Float.MAX_VALUE)
    public abstract void setWeek47(double week);   

    @Alias("week48")
    public abstract double getWeek48();
    @FloatConstraint(min = 0, max = Float.MAX_VALUE)
    public abstract void setWeek48(double week);   

    @Alias("week49")
    public abstract double getWeek49();
    @FloatConstraint(min = 0, max = Float.MAX_VALUE)
    public abstract void setWeek49(double week);   

    @Alias("week50")
    public abstract double getWeek50();
    @FloatConstraint(min = 0, max = Float.MAX_VALUE)
    public abstract void setWeek50(double week);   

    @Alias("week51")
    public abstract double getWeek51();
    @FloatConstraint(min = 0, max = Float.MAX_VALUE)
    public abstract void setWeek51(double week);   

    @Alias("week52")
    public abstract double getWeek52();
    @FloatConstraint(min = 0, max = Float.MAX_VALUE)
    public abstract void setWeek52(double week);   
}
