package com.amazon.oih.dao.hbase.sokoban;

import com.amazon.oih.dao.hbase.base.SubKeyAwareHBaseDao;

public class SokobanHBaseobjectConverter extends SubKeyAwareHBaseDao<SokobanFasFactor>{

    public SokobanHBaseobjectConverter() {
        super(SokobanFasFactor.class);
       
    }

}
