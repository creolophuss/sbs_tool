package com.amazon.oih.dao.hbase.adjustedrol;

import com.amazon.oih.common.RowKeyBuildType;
import com.amazon.oih.common.RowKeyType;
import com.amazon.oih.dao.hbase.base.CommonKVHBaseDao.HTable;
import com.amazon.oih.dao.hbase.converter.Column;
import com.amazon.oih.dao.hbase.converter.RowKey;

@RowKey({
        "asin", "scopeId"
})
@RowKeyBuildType(RowKeyType.ASIN_SCOPE)
@HTable(value = "AdjustedMaxROL", columFamilyName = "ROL", separator = ":")
public class AdjustedMaxROL {

    private String asin;

    private String scopeId;

    @Column(name = "adjustedMaxROL", index = 0)
    private Integer adjustedMaxRol;

    public String getAsin() {
        return asin;
    }

    public void setAsin(String asin) {
        this.asin = asin;
    }

    public String getScopeId() {
        return scopeId;
    }

    public void setScopeId(String scopeId) {
        this.scopeId = scopeId;
    }

    public Integer getAdjustedMaxRol() {
        return adjustedMaxRol;
    }

    public void setAdjustedMaxRol(Integer adjustedMaxRol) {
        this.adjustedMaxRol = adjustedMaxRol;
    }

}
