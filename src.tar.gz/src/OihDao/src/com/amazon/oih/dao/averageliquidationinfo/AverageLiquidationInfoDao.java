package com.amazon.oih.dao.averageliquidationinfo;

import java.util.List;
import java.util.Set;

import com.amazon.oih.dao.exception.OihPersistenceException;

public interface AverageLiquidationInfoDao {
    public abstract void save(AverageLiquidationInfo o) throws OihPersistenceException;

    public abstract boolean exists(Long runId, Integer iog, String country, String gl, String category,
            String subCategory) throws OihPersistenceException;

    public abstract AverageLiquidationInfo find(Long runId, Integer iog, String country, String gl, String category,
            String subCategory) throws OihPersistenceException;

    public abstract AverageLiquidationInfo createAverageLiquidationInfo(Long runId, Integer iog, String country,
            String gl, String category, String subCategory, double rate, String type, String layer, boolean rate_found);

    public abstract void delete(AverageLiquidationInfo o) throws OihPersistenceException;

    public abstract void deleteAll() throws OihPersistenceException;

    public abstract AverageLiquidationInfo find(Integer iog, String country, String gl, String category, String subCategory)
            throws OihPersistenceException;
    
    public List<AverageLiquidationInfo> find(String country, Long runId) throws OihPersistenceException;
    
    public List<AverageLiquidationInfo> find(Set<Long> runIds) throws OihPersistenceException;
}
