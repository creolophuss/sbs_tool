package com.amazon.oih.dao.quantitymarkdowninfo;

import java.util.List;

import com.amazon.oih.dao.exception.OihPersistenceException;

/**
 * @author gaoxing
 *
 */
public interface IQuantityBasedMarkdownInfoDao {

    /**
     * Save mark down Info list to the database
     * @param infos
     * @throws OihPersistenceException
     */
    public abstract void save(List<QuantityBasedMarkdownInfo> infos) throws OihPersistenceException;

    /**
     *  Save mark down Info to the database
     * @param info
     * @throws OihPersistenceException
     */
    public abstract void save(QuantityBasedMarkdownInfo info) throws OihPersistenceException;

    /**
     * Check whether the data exist in the database.
     * @param runId
     * @param asin
     * @param marketplaceId
     * @return
     * @throws OihPersistenceException
     */
    public abstract boolean exists(Long runId, String asin, long marketplaceId) throws OihPersistenceException;

    /**
     * find the mark down info by run id, ASIN, marketplace id
     * @param runId
     * @param asin
     * @param marketplaceId
     * @return
     * @throws OihPersistenceException
     */
    public abstract QuantityBasedMarkdownInfo find(Long runId, String asin, long marketplaceId) throws OihPersistenceException;
}
