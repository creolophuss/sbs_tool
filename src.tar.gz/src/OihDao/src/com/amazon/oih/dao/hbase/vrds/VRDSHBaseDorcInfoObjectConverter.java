package com.amazon.oih.dao.hbase.vrds;

import com.amazon.oih.dao.hbase.base.SubKeyAwareHBaseDao;

public class VRDSHBaseDorcInfoObjectConverter extends SubKeyAwareHBaseDao<VRDSHBaseDorcInfo>{

	public VRDSHBaseDorcInfoObjectConverter() {
		super(VRDSHBaseDorcInfo.class);
	}

}
