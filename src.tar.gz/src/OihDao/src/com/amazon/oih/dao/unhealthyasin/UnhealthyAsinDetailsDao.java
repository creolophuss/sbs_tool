package com.amazon.oih.dao.unhealthyasin;

import java.util.List;

import com.amazon.oih.dao.exception.OihPersistenceException;

public interface UnhealthyAsinDetailsDao {
    public abstract void save(UnhealthyAsinDetails o) throws OihPersistenceException;

    public abstract void save(List<UnhealthyAsinDetails> UnhealthyAsinDetailsList) throws OihPersistenceException;
}
