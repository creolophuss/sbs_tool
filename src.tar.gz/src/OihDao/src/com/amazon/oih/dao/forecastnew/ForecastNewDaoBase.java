package com.amazon.oih.dao.forecastnew;

import java.util.Collection;
import java.util.List;

import javax.naming.NamingException;

import org.apache.log4j.Logger;

import com.amazon.carbonado.IsolationLevel;
import com.amazon.carbonado.PersistException;
import com.amazon.carbonado.Repository;
import com.amazon.carbonado.RepositoryException;
import com.amazon.carbonado.Storage;
import com.amazon.carbonado.Transaction;

import com.amazon.oih.dao.forecast.ForecastType;

public class ForecastNewDaoBase implements ForecastNewDao {
    final static Logger _log = Logger.getLogger(ForecastNewDaoBase.class);

    protected String _domain = null;

    protected Repository repository = null;

    public ForecastNewDaoBase(String domain) {
        _domain = domain;
    }

    public void setRepository(Repository repository) {
        if (null == repository) {
            throw new IllegalArgumentException("repository cannot be null.");
        }
        this.repository = repository;
    }

    @Override
    public boolean exists(Long runId, String asin, Integer iog, String realm) throws NamingException, RepositoryException,
            ClassNotFoundException {
        boolean retVal = false;

        Storage<ForecastNewBDBObject> sf = repository.storageFor(ForecastNewBDBObject.class);
        retVal = sf.query("asin = ? & iog = ? & runID = ?").with(asin).with(iog).with(runId).exists();

        return retVal;
    }

    @Override
    public Collection<? extends ForecastNew> find(Long runId, String asin, Integer iog, String realm) throws NamingException, RepositoryException,
            ClassNotFoundException {
        Storage<ForecastNewBDBObject> sf = repository.storageFor(ForecastNewBDBObject.class);
        List<ForecastNewBDBObject> data = sf.query("asin = ? & iog = ? & runID = ?").with(asin).with(iog).with(runId).fetch().toList();

        return data;
    }

    @Override
    public Collection<? extends ForecastNew> find(Long runId, String asin, Integer iog, ForecastType type, String realm) throws NamingException,
            RepositoryException, ClassNotFoundException {
        Storage<ForecastNewBDBObject> sf = repository.storageFor(ForecastNewBDBObject.class);
        List<ForecastNewBDBObject> data = sf.query("asin = ? & iog = ? & runID = ? & type = ?").with(asin).with(iog).with(runId).with(type.name())
                .fetch().toList();

        return data;
    }

    @Override
    public List<? extends ForecastNew> findOrderedByProbability(Long runId, String asin, Integer iog, ForecastType type, String realm)
            throws NamingException, RepositoryException, ClassNotFoundException {
        Storage<ForecastNewBDBObject> sf = repository.storageFor(ForecastNewBDBObject.class);
        
        
        List<ForecastNewBDBObject> data = sf.query("asin = ? & iog = ? & runID = ? & type = ?").with(asin).with(iog).with(runId).with(type.name())
                .orderBy("probability").fetch().toList();
        return data;
    }


    @Override
    public ForecastNew createForecast(Long runId, String asin, Integer iog, ForecastType type, Double probability, List<Double> forecasts, String realm)
            throws NamingException, RepositoryException, ClassNotFoundException {
        Storage<ForecastNewBDBObject> sf = repository.storageFor(ForecastNewBDBObject.class);
        ForecastNewBDBObject f = sf.prepare();

        f.setRunID(runId);
        f.setAsin(asin);
        f.setIog(iog);
        f.setForecastType(type);
        f.setProbability(probability);
        f.setWeek1(forecasts.get(0));
        f.setWeek2(forecasts.get(1));
        f.setWeek3(forecasts.get(2));
        f.setWeek4(forecasts.get(3));
        f.setWeek5(forecasts.get(4));
        f.setWeek6(forecasts.get(5));
        f.setWeek7(forecasts.get(6));
        f.setWeek8(forecasts.get(7));
        f.setWeek9(forecasts.get(8));
        f.setWeek10(forecasts.get(9));
        f.setWeek11(forecasts.get(10));
        f.setWeek12(forecasts.get(11));
        f.setWeek13(forecasts.get(12));
        f.setWeek14(forecasts.get(13));
        f.setWeek15(forecasts.get(14));
        f.setWeek16(forecasts.get(15));
        f.setWeek17(forecasts.get(16));
        f.setWeek18(forecasts.get(17));
        f.setWeek19(forecasts.get(18));
        f.setWeek20(forecasts.get(19));
        f.setWeek21(forecasts.get(20));
        f.setWeek22(forecasts.get(21));
        f.setWeek23(forecasts.get(22));
        f.setWeek24(forecasts.get(23));
        f.setWeek25(forecasts.get(24));
        f.setWeek26(forecasts.get(25));
        f.setWeek27(forecasts.get(26));
        f.setWeek28(forecasts.get(27));
        f.setWeek29(forecasts.get(28));
        f.setWeek30(forecasts.get(29));
        f.setWeek31(forecasts.get(30));
        f.setWeek32(forecasts.get(31));
        f.setWeek33(forecasts.get(32));
        return f;
    }

    @Override
    public void save(ForecastNew o) throws PersistException {
    	if (o instanceof ForecastNewBDBObject){
            ((ForecastNewBDBObject)o).insert();
    	}
    }

    @Override
    public void save(Collection<ForecastNew> o) throws PersistException {
        Transaction txn = repository.enterTransaction(IsolationLevel.READ_UNCOMMITTED);
        try {
            for (ForecastNew f : o) {
            	if (f instanceof ForecastNewBDBObject){
                    ((ForecastNewBDBObject)f).insert();
            	}
            }

            txn.commit();
        } catch (PersistException e) {
            throw e;
        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
            txn.exit();
        }
    }

    @Override
    public String toString() {
        StringBuilder r = new StringBuilder();

        r.append(this.getClass().getSimpleName()).append(": ").append("domain = ").append(_domain);

        return r.toString();
    }
}
