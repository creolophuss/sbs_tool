package com.amazon.oih.dao.hbase.cbm;

import static com.amazon.oih.dao.hbase.cbm.CalendarMarkdownHistoricDemandHBaseDao.COLUMN_DEMAND_BYTES;
import static com.amazon.oih.dao.hbase.cbm.CalendarMarkdownHistoricDemandHBaseDao.COLUMN_FAMILY_BYTES;

import java.io.IOException;
import java.util.Collections;
import java.util.List;

import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.util.Bytes;


import com.amazon.oih.cbm.model.CalendarMarkdownHistoricDemand;
import com.amazon.oih.dao.hbase.base.Converter;
import com.amazon.oih.utils.HBaseRowkeyUtil;
import com.google.common.base.Joiner;


public class CalendarMarkdownHistoricDemandConverter implements Converter<CalendarMarkdownHistoricDemand> {

	@Override
	public CalendarMarkdownHistoricDemand convert(String rowKey, Result rs) throws IOException {
		CalendarMarkdownHistoricDemand historicDemand = parseRowkey(rowKey);
        if (rs != null && !rs.isEmpty()) {
            if (rowKey == null) {
                rowKey = Bytes.toString(rs.getRow());
            }
            
            String demand = Bytes.toString(rs.getValue(COLUMN_FAMILY_BYTES, COLUMN_DEMAND_BYTES));
            historicDemand.setDemands(CalendarMarkdownHistoricDemand.parseDemands(demand));
            return historicDemand;
        }
        return historicDemand;
	}
	
    static public CalendarMarkdownHistoricDemand parseRowkey(String rowkey) {
        String[] rowKey = rowkey.split(":");
        String asin = rowKey[0];
        long marketplace = Long.valueOf(rowKey[1]);
        return new CalendarMarkdownHistoricDemand(asin, marketplace, Collections.EMPTY_LIST);
    }

	@Override
	public List<Put> convert(CalendarMarkdownHistoricDemand demand)
			throws IOException {
		 byte[] rowKey = Bytes.toBytes(getRowKey(demand));

	        Put put = new Put(rowKey);
	        put.add(COLUMN_FAMILY_BYTES, COLUMN_DEMAND_BYTES,
	                Bytes.toBytes(Joiner.on(CalendarMarkdownHistoricDemand.DEMAND_SEPARATOR).join(demand.getDemands())));
	        return Collections.nCopies(1, put);
	}

	@Override
	public String getRowKey(CalendarMarkdownHistoricDemand demand) {
		return HBaseRowkeyUtil.getRowKeyBasedAsinMarketplace(demand.getAsin(), demand.getMarketplaceId());
	}

	@Override
	public CalendarMarkdownHistoricDemand convert(Result rs) throws IOException {
		return convert(null, rs);
	}

}
