package com.amazon.oih.dao.markdowninfo;

import java.io.Serializable;

import com.amazon.oih.common.RowKeyBuildType;
import com.amazon.oih.common.RowKeyType;
import com.amazon.oih.dao.hbase.base.CommonKVHBaseDao.HTable;
import com.amazon.oih.dao.hbase.converter.Column;
import com.amazon.oih.dao.hbase.converter.RowKey;

@RowKey({"asin", "marketplaceId"})
@RowKeyBuildType(RowKeyType.ASIN_MARKETPLACE)
@HTable(value = "MarkdownInfo")
public class MarkdownInfo implements Serializable {
    public static final MarkdownInfo NO_MARKDOWN = new MarkdownInfo(0.0, 1.0, 0.0);
    public static String DATA_LEVEL_ASIN = "mkdPredictedASIN";    
    private static final long serialVersionUID = 1L;
    public static final String DATA_LEVEL_PRICE_MODEL = "priceModel";
    private static final double MAX_VALID_RECOVERY_RATE = 0.95;
    private long runID;
    private String asin;
    private int marketplaceId;
    
    @Column(name="mk",index=0)
    private double demandIncrease;
    @Column(name="mk",index=1)
    private double demandIncreaseRate;
    @Column(name="mk",index=2)
    private double recoveryRate;
    @Column(name="mk",index=3)
    private String dataVersion;
    @Column(name="mk",index=4)
    private String dataLevel;

    public MarkdownInfo(long runID, String asin, int marketplaceId, double demandIncrease, double demandIncreaseRate,
    		double recoveryRate, String dataVersion, String dataLevel) {
        this.runID = runID;
        this.asin = asin;
        this.marketplaceId = marketplaceId;
        this.demandIncrease = demandIncrease;
        this.demandIncreaseRate = demandIncreaseRate;
        this.recoveryRate = recoveryRate;
        this.dataVersion = dataVersion;
        this.dataLevel = dataLevel;
    }

    public MarkdownInfo() {

    }
    
    public MarkdownInfo( double priceFactor, double demandFactor, double demandIncrease) {
        this.recoveryRate = priceFactor + 1.0;
        this.demandIncreaseRate = demandFactor;
        this.demandIncrease = demandIncrease;
    }

    public MarkdownInfo( double priceFactor, double demandFactor ) {
        this.recoveryRate = priceFactor + 1.0;
        this.demandIncreaseRate = demandFactor;
        this.dataLevel = DATA_LEVEL_ASIN;
      }

    public MarkdownInfo( double priceFactor, double demandFactor, double demandIncrease, String dataLevel) {
        this.recoveryRate = priceFactor + 1.0;
        this.demandIncreaseRate = demandFactor;
        this.demandIncrease = demandIncrease;
        this.dataLevel = dataLevel;
    }

    public void setRunID(long runID) {
        this.runID = runID;
    }

    public long getRunID() {
        return runID;
    }

    public void setAsin(String asin) {
        this.asin = asin;
    }

    public String getAsin() {
        return asin;
    }

    public double getPrice( double ourPrice ) {
        return ourPrice * (1.0 + getPriceFactor());
      }

    public int getMarketplaceId() {
		return marketplaceId;
	}

	public void setMarketplaceId(int marketplaceId) {
		this.marketplaceId = marketplaceId;
	}

	public double getDemandIncrease() {
		return demandIncrease;
	}
	
	public double getDemandFactor() {
	    return demandIncreaseRate;
	}
	
	public double getDemandIncreasePerWeek() {
	    return demandIncrease;
	}

	public void setDemandIncrease(double demandIncrease) {
		this.demandIncrease = demandIncrease;
	}

	public double getDemandIncreaseRate() {
		return demandIncreaseRate;
	}

	public void setDemandIncreaseRate(double demandIncreaseRate) {
		this.demandIncreaseRate = demandIncreaseRate;
	}

	public double getRecoveryRate() {
		return recoveryRate;
	}

	public void setRecoveryRate(double recoveryRate) {
		this.recoveryRate = recoveryRate;
	}

	public String getDataVersion() {
		return dataVersion;
	}

	public void setDataVersion(String dataVersion) {
		this.dataVersion = dataVersion;
	}

	public String getDataLevel() {
		return dataLevel;
	}

	public void setDataLevel(String dataLevel) {
		this.dataLevel = dataLevel;
	}

	@Override
    public String toString() {
        return "MarkdownInfo [runID=" + runID + ", asin=" + asin + ", marketplaceId=" + marketplaceId
                + ", demandIncrease=" + demandIncrease + ", demandIncreaseRate=" + demandIncreaseRate
                + ", recoveryRate=" + recoveryRate + ", dataVersion=" + dataVersion + ", dataLevel=" + dataLevel + "]";
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof MarkdownInfo == false) {
            return false;
        }
        if (this == obj) {
            return true;
        }

        MarkdownInfo other = (MarkdownInfo) obj;
        return this.asin.equals(other.getAsin()) && this.marketplaceId == other.getMarketplaceId() && 
        		Math.abs(this.demandIncrease - other.getDemandIncrease()) < 1e-6 && 
        		Math.abs(this.demandIncreaseRate - other.getDemandIncreaseRate()) < 1e-6 &&
        		Math.abs(this.recoveryRate - other.getRecoveryRate()) <  1e-6 &&
        		this.dataVersion.equals(other.getDataVersion()) && this.dataLevel.equals(other.getDataLevel());
    }


    @Override
    public int hashCode() {
        final int prime = 127; // changed from default - 31 is a lame prime #
        int result = 1;
        result = prime * result + ((asin == null) ? 0 : asin.hashCode());
        result = prime * result + marketplaceId;
        result = prime * result + (int) runID;
        return result;
    }

    public Double getPriceFactor() {
        return recoveryRate - 1;
    }

    public boolean isValid() {
        return (Math.abs(getDemandIncreaseRate()) > 10e-6 || Math.abs(getDemandIncrease()) > 10e-6) &&  recoveryRate <= MAX_VALID_RECOVERY_RATE;
    }
}
