package com.amazon.oih.dao.recall;

import java.util.List;

import com.amazon.carbonado.Repository;
import com.amazon.oih.dao.exception.OihPersistenceException;

/**
 * 
 * @author zhongwei
 *
 */
public interface IRecallDao {
    public void setRepository(Repository repository);

    public RecallObject createRecall(RecallInfo valueObject) throws OihPersistenceException;

    public void save(RecallObject recall) throws OihPersistenceException;

    public void save(List<RecallObject> recalls) throws OihPersistenceException;

    public RecallObject find(String asin, int iog) throws OihPersistenceException;

    public boolean exists(String asin, int iog) throws OihPersistenceException;
}
