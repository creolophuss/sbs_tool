package com.amazon.oih.dao.hbase.forecast;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import com.amazon.oih.common.RowKeyBuildType;
import com.amazon.oih.common.RowKeyType;
import com.amazon.oih.dao.hbase.base.CommonKVHBaseDao.HTable;
import com.amazon.oih.dao.hbase.converter.Column;
import com.amazon.oih.dao.hbase.converter.RowKey;
import com.amazon.oih.dao.hbase.converter.SubKey;
import com.google.common.base.Joiner;

@RowKey({"asin", "marketplace"})
@RowKeyBuildType(RowKeyType.ASIN_MARKETPLACE)
@SubKey({"probability"})
/**
 * A trick here is: as ForecastSeq is using ',' as separator, which conflict with HBaseDao's default separator for different columns.
 * so we override HBase's separator as ':' to make things work.
 */
@HTable(value = "ForecastDistribution", columFamilyName = "Forecast", separator = ":")
public class AnnoForecastHBaseObj implements Serializable {  
    private static final long serialVersionUID = -8738993209957914964L;
    private static final String SEPARATOR = ",";
    private String asin;
    private long marketplace;
    private String probability;
   
    @Column(name="forecastSeq",index=0)
    private String forecastSeq;
    
    public AnnoForecastHBaseObj(){}
    
    public String getAsin() {
        return asin;
    }
    public void setAsin(String asin) {
        this.asin = asin;
    }
    public long getMarketplace() {
        return marketplace;
    }
    public void setMarketplace(long marketplace) {
        this.marketplace = marketplace;
    }
    public String getProbability() {
        return probability;
    }
    public void setProbability(String probability) {
        this.probability = probability;
    }
    public String getForecastSeq() {
        return forecastSeq;
    }
    public void setForecastSeq(String forecastSeq) {
        this.forecastSeq = forecastSeq;
    }  
    public void setForecastSeq(List<Double> forecastList) {
        this.forecastSeq = Joiner.on(SEPARATOR).join(forecastList);
    } 
    
    @Override
    public String toString(){
        StringBuilder builder = new StringBuilder();
        builder.append(asin).append("|").append(marketplace).append("|").append(probability).append(forecastSeq);
        return asin + "|" + marketplace + "|" + probability + ":" + forecastSeq;
    }
    
    public static ForecastHBaseObject toForecastHBaseObject(List<AnnoForecastHBaseObj> forecastList){
        if (forecastList == null || forecastList.size() == 0){
            return null;
        }
        ForecastHBaseObject obj = new ForecastHBaseObject();
        obj.setAsin(forecastList.get(0).getAsin());
        obj.setMarketplace(forecastList.get(0).getMarketplace());
        Map<String, List<Double>> forecastMap = obj.getForecastMap();
        for (AnnoForecastHBaseObj annoObj : forecastList){
            if (!annoObj.getAsin().equals(obj.getAsin()) || annoObj.getMarketplace() != obj.getMarketplace()){
                throw new RuntimeException("The forecastList do not contain forecast of same ASIN|Marketplace!" + forecastList);
            }
           
            String forecastSeq = annoObj.getForecastSeq();
            List<Double> forecastDetail = null;
            if (StringUtils.isBlank(forecastSeq)) {
            	forecastDetail = Collections.<Double>emptyList();
            } else {
            	forecastDetail = new ArrayList<Double>();
                for (String forecast : annoObj.getForecastSeq().split(SEPARATOR)){
                    forecastDetail.add(Double.valueOf(forecast));
                }
            }

            forecastMap.put(annoObj.probability, forecastDetail);
        }
        return obj;
    }
}
