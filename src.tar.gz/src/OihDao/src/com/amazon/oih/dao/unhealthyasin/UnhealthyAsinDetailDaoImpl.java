package com.amazon.oih.dao.unhealthyasin;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.amazon.oih.dao.SessionFactoryManager;
import com.amazon.oih.dao.exception.OihPersistenceException;


public class UnhealthyAsinDetailDaoImpl implements UnhealthyAsinDetailsDao {
    private final static Logger logger = Logger.getLogger(UnhealthyAsinDetailDaoImpl.class);
    
    @Override
    public void save(UnhealthyAsinDetails o) throws OihPersistenceException {
        Transaction tx = null;
        Session session = null;
        try {
            session = openSession();
            tx = session.beginTransaction();
            session.save(o);
            tx.commit();
        } catch (RuntimeException e) {
            logger.error("Failed to save entity " + o + " with exception ", e);
            e.printStackTrace();
            if (tx != null) {
                tx.rollback();
            }
            throw new OihPersistenceException(e);
        } finally {
            closeSession(session);
        }
    }

    @Override
    public void save(List<UnhealthyAsinDetails> UnhealthyAsinDetailsList) throws OihPersistenceException {
        Transaction tx = null;
        Session session = null;
        try {
            session = openSession();
            tx = session.beginTransaction();
            for (UnhealthyAsinDetails o : UnhealthyAsinDetailsList) {
                session.saveOrUpdate(o);
            }
            tx.commit();
        } catch (RuntimeException e) {
            logger.error("Failed to save entity " + logger + " with exception ", e);
            if (tx != null) {
                tx.rollback();
            }
            throw new OihPersistenceException(e);
        } finally {
            closeSession(session);
        }
    }

    private Session openSession() {
        return SessionFactoryManager.getScosmetSessionFactoryInstance().openSession();
    }

    private void closeSession(Session session) {
        if (session != null) {
            session.close();
        }
    }
}
