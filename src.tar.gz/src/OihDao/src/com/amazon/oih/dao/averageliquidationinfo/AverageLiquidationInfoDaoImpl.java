package com.amazon.oih.dao.averageliquidationinfo;

import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import com.amazon.oih.dao.MySQLSessionFactoryUtil;
import com.amazon.oih.dao.exception.OihPersistenceException;

public class AverageLiquidationInfoDaoImpl implements AverageLiquidationInfoDao {
    private final static Logger logger = Logger.getLogger(AverageLiquidationInfoDaoImpl.class);

    public AverageLiquidationInfoDaoImpl(String domain) {
    }

    @Override
    public void save(AverageLiquidationInfo o) throws OihPersistenceException {
        Transaction tx = null;
        Session session = null;
        try {
            session = openSession();
            tx = session.beginTransaction();
            session.save(o);
            tx.commit();
        } catch (RuntimeException e) {
            logger.error("Failed to save entity " + o + " with exception ", e);
            e.printStackTrace();
            if (tx != null) {
                tx.rollback();
            }
            throw new OihPersistenceException(e);
        } finally {
            closeSession(session);
        }
    }

    @Override
    public boolean exists(Long runId, Integer iog, String country, String gl, String category, String subCategory)
            throws OihPersistenceException {
        logger.debug("Query AverageLiquidationInfo by " + runId + "|" + iog + "|" + country + "|" + gl + "|" + category
                + "|" + subCategory);
        Session session = null;
        try {
            session = openSession();
            Criteria cri = session.createCriteria(AverageLiquidationInfo.class);
            cri.add(Restrictions.eq("runID", runId));
            cri.add(Restrictions.eq("iog", iog));
            cri.add(Restrictions.eq("country", country));
            cri.add(Restrictions.eq("gl", gl));
            cri.add(Restrictions.eq("category", category));
            cri.add(Restrictions.eq("subCategory", subCategory));
            return cri.uniqueResult() != null;
        } catch (HibernateException e) {
            e.printStackTrace();
            logger.error("Fail to query AverageLiquidationInfo " + e);
            throw new OihPersistenceException(e);
        } finally {
            closeSession(session);
        }

    }

    @Override
    public AverageLiquidationInfo find(Long runId, Integer iog, String country, String gl, String category,
            String subCategory) throws OihPersistenceException {
        logger.debug("Query AverageLiquidationInfo by " + runId + "|" + iog + "|" + country + "|" + gl + "|" + category
                + "|" + subCategory);
        Session session = null;
        try {
            session = openSession();
            Criteria cri = session.createCriteria(AverageLiquidationInfo.class);
            cri.add(Restrictions.eq("runID", runId));
            cri.add(Restrictions.eq("iog", iog));
            cri.add(Restrictions.eq("country", country));
            cri.add(Restrictions.eq("gl", gl));
            cri.add(Restrictions.eq("category", category));
            cri.add(Restrictions.eq("subCategory", subCategory));
            return (AverageLiquidationInfo) cri.uniqueResult();
        } catch (HibernateException e) {
            e.printStackTrace();
            logger.error("Fail to query AverageLiquidationInfo " + e);
            throw new OihPersistenceException(e);
        } finally {
            closeSession(session);
        }

    }
    
    public AverageLiquidationInfo find(Integer iog, String country, String gl, String category,
            String subCategory) throws OihPersistenceException {
        logger.debug("Query AverageLiquidationInfo by 'NO runID' " + iog + "|" + country + "|" + gl + "|" + category
                + "|" + subCategory);
        Session session = null;
        try {
            session = openSession();
            Criteria cri = session.createCriteria(AverageLiquidationInfo.class);
            cri.add(Restrictions.eq("iog", iog));
            cri.add(Restrictions.eq("country", country));
            cri.add(Restrictions.eq("gl", gl));
            cri.add(Restrictions.eq("category", category));
            cri.add(Restrictions.eq("subCategory", subCategory));
            cri.addOrder(Order.desc("runID"));
            cri.setMaxResults(1);
            return (AverageLiquidationInfo) cri.uniqueResult();
        } catch (HibernateException e) {
            e.printStackTrace();
            logger.error("Fail to query AverageLiquidationInfo " + e);
            throw new OihPersistenceException(e);
        } finally {
            closeSession(session);
        }
    }
    
    @Override
    public AverageLiquidationInfo createAverageLiquidationInfo(Long runId, Integer iog, String country, String gl,
            String category, String subCategory, double rate, String type, String layer, boolean rate_found) {
        AverageLiquidationInfo result = new AverageLiquidationInfo();
        result.setRunID(runId);
        result.setRate(rate);
        result.setIog(iog);
        result.setCountry(country);
        result.setGl(gl);
        result.setCategory(category);
        result.setSubCategory(subCategory);

        result.setType(type);
        result.setLayer(layer);
        result.setRate(rate);
        result.setRateFound(rate_found ? "Y" : "N");

        return result;
    }

    @Override
    public void delete(AverageLiquidationInfo o) throws OihPersistenceException {
        Transaction tx = null;
        Session session = null;
        try {
            session = openSession();
            tx = session.beginTransaction();
            session.delete(o);
            tx.commit();
        } catch (RuntimeException e) {
            logger.error("Failed to save entity " + o + " with exception ", e);
            e.printStackTrace();
            if (tx != null) {
                tx.rollback();
            }
            throw new OihPersistenceException(e);
        } finally {
            closeSession(session);
        }
    }

    @SuppressWarnings("unchecked")
    @Override
    public void deleteAll() throws OihPersistenceException {
        logger.debug("Trying to delete all the elements from the db");
        Session session = null;
        Transaction tx = null;        
        try {
            session = openSession();
            tx = session.beginTransaction();
            Criteria cri = session.createCriteria(AverageLiquidationInfo.class);
            List<AverageLiquidationInfo> alis = cri.list();
            for (AverageLiquidationInfo object : alis) {
                session.delete(object);
            }
            tx.commit();
        } catch (HibernateException e) {
            e.printStackTrace();
            logger.error("Fail to query AverageLiquidationInfo " + e);
            throw new OihPersistenceException(e);
        } finally {
            closeSession(session);
        }

    }

    private Session openSession() {
        return MySQLSessionFactoryUtil.getSessionFactory().openSession();
    }

    private void closeSession(Session session) {
        if (session != null) {
            session.close();
        }
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<AverageLiquidationInfo> find(String country, Long runId) throws OihPersistenceException{
        if (logger.isDebugEnabled()) {
            logger.debug("Get average liquidation info from " + country + " by runid " + runId);
        }
        
        Session session = null;
        try {
            session = openSession();
            Criteria cri = session.createCriteria(AverageLiquidationInfo.class);
            cri.add(Restrictions.eq("country", country));
            cri.add(Restrictions.eq("runID", runId));
            
            return (List<AverageLiquidationInfo>)cri.list();
        } catch (HibernateException e) {
            e.printStackTrace();
            logger.error("Fail to query AverageLiquidationInfo " + e);
            throw new OihPersistenceException(e);
        } finally {
            closeSession(session);
        }

    }
    
    @SuppressWarnings("unchecked")
    @Override
    public List<AverageLiquidationInfo> find(Set<Long> runIds) throws OihPersistenceException{
        if (logger.isDebugEnabled()) {
            logger.debug("Get average liquidation info by runids: " + runIds);
        }
        
        Session session = null;
        try {
            session = openSession();
            Criteria cri = session.createCriteria(AverageLiquidationInfo.class);
            cri.add(Restrictions.in("runID", runIds));            
            return (List<AverageLiquidationInfo>)cri.list();
        } catch (HibernateException e) {
            e.printStackTrace();
            logger.error("Fail to query AverageLiquidationInfo " + e);
            throw new OihPersistenceException(e);
        } finally {
            closeSession(session);
        }

    }
}
