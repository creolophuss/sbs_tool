package com.amazon.oih.dao.g2s2;

class G2S2ClientConfigs {

    private String domain;
    private String realm;
    private String g2s2ReadEndpoint;
    private String g2s2WriteEndpoint;
    private String g2s2StageVersionLabel;
    private boolean hasReadCache;
    private boolean hasWriteCache;

    public G2S2ClientConfigs() {
    }

    public G2S2ClientConfigs(String domain, String realm, String g2s2ReadEndpoint, String g2s2WriteEndpoint,
            String g2s2StageVersionLabel, boolean hasReadCache, boolean hasWriteCache) {
        this.domain = domain;
        this.realm = realm;
        this.g2s2ReadEndpoint = g2s2ReadEndpoint;
        this.g2s2WriteEndpoint = g2s2WriteEndpoint;
        this.g2s2StageVersionLabel = g2s2StageVersionLabel;
        this.hasReadCache = hasReadCache;
        this.hasWriteCache = hasWriteCache;
    }

    @Override
    public String toString() {
        return new StringBuilder("G2S2AppConfigDao [domain=").append( domain )
                .append( ", realm=" ).append( realm )
                .append( ", g2S2ReadEndpoint=" ).append( g2s2ReadEndpoint )
                .append( ", g2S2WriteEndpoint=" ).append( g2s2WriteEndpoint )
                .append( ", g2S2StageVersionLabel=" ).append( g2s2StageVersionLabel)
                .append( ", hasReadCache=" ).append( hasReadCache )
                .append( ", hasWriteCache=" ).append( hasWriteCache )
                .append( ", g2S2RefreshCacheInterval=").append( "]")
                .toString();
    }

    public String getDomain() {
        return domain;
    }

    public void setDomain(String domain) {
        this.domain = domain;
    }

    public String getRealm() {
        return realm;
    }

    public void setRealm(String realm) {
        this.realm = realm;
    }

    public String getG2s2ReadEndpoint() {
        return g2s2ReadEndpoint;
    }

    public void setG2s2ReadEndpoint(String g2s2ReadEndpoint) {
        this.g2s2ReadEndpoint = g2s2ReadEndpoint;
    }

    public String getG2s2WriteEndpoint() {
        return g2s2WriteEndpoint;
    }

    public void setG2s2WriteEndpoint(String g2s2WriteEndpoint) {
        this.g2s2WriteEndpoint = g2s2WriteEndpoint;
    }

    public String getG2s2StageVersionLabel() {
        return g2s2StageVersionLabel;
    }

    public void setG2s2StageVersionLabel(String g2s2StageVersionLabel) {
        this.g2s2StageVersionLabel = g2s2StageVersionLabel;
    }

    public boolean isHasReadCache() {
        return hasReadCache;
    }

    public void setHasReadCache(boolean hasReadCache) {
        this.hasReadCache = hasReadCache;
    }

    public boolean isHasWriteCache() {
        return hasWriteCache;
    }

    public void setHasWriteCache(boolean hasWriteCache) {
        this.hasWriteCache = hasWriteCache;
    }

}
