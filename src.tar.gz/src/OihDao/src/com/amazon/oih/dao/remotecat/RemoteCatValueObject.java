package com.amazon.oih.dao.remotecat;

import java.util.Date;

/**
 * This is the value object for the RemoteCat
 * 
 * @author zhongwei
 * 
 */
public class RemoteCatValueObject {
    private String asin = "0000000000";
    private int iog = 1;
    private long marketplace = 1;
    private long merchant = 1;
    private int gl = 0;
    private String title = "";
    private double ourPrice = 0.0;
    private double basePrice = 0.0;
    private double listPriceWithTax = 0.0;
    
    private boolean isHidden = false;
    
    // Shelf Life
    protected int fcShelfLife = -1;
    protected int fcShelfLifePadTime = -1;
    protected int fcShelfLifePadTime2Q = -1; //for warehouse deal
    
    
    public double getBasePrice() {
		return basePrice;
	}

	public void setBasePrice(double basePrice) {
		this.basePrice = basePrice;
	}

	public String getSeasonStart() {
		return seasonStart;
	}

	public void setSeasonStart(String seasonStart) {
		this.seasonStart = seasonStart;
	}
	
	public String getSeasonStartYear() {
        return seasonStartYear;
    }

    public void setSeasonStartYear(String seasonStartYear) {
        this.seasonStartYear = seasonStartYear;
    }

	public String getFullPriceEnd() {
		return fullPriceEnd;
	}

	public void setFullPriceEnd(String fullPriceEnd) {
		this.fullPriceEnd = fullPriceEnd;
	}

	public String getLiquidateDate() {
		return liquidateDate;
	}

	public void setLiquidateDate(String liquidateDate) {
		this.liquidateDate = liquidateDate;
	}

	public String getSupplyType() {
		return supplyType;
	}

	public void setSupplyType(String supplyType) {
		this.supplyType = supplyType;
	}

	public String getDemandType() {
		return demandType;
	}

	public void setDemandType(String demandType) {
		this.demandType = demandType;
	}

	private Date publicationDate = null;
    private Date releaseDate = null;
    private String upc = "";
    private boolean isUnPrepRequired = false;
    private int category = 0;
    private int subCategory = 0;
    private String ean = "";
    private String publisherCode = "null";
    private double mapPrice = 0.0;
    private String mapRequired = "N";
    private double listPrice = 0.0;
    private String parentAsin = "unknown";
    private String replenishmentCategory = "Unknown";
    private String hazmatTransportationRegularClass = "";
    private String hazmatException = "";
    private String isHazmatItem = "";
    private String textbookType = "";
    private String mapStrict = "N";
    private Date mapEndDate = null;
    private Date siteLaunchDate = null;
    private String brandCode = "";
    private String brandName = "";
    private String binding = "";
    private String seasons = "";
    private String model = "";
    private String sourceCountryCode = "";
    private double mapStrictPrice = 0.0;
    private int modelYear = 0;
    private String format = "";
    private String restrictedPriceDiscountCountry = "";
    private String availability = "";
    private String retailOffer = "N";
    private String seasonStart = null;
    private String seasonStartYear = null;
    private String fullPriceEnd = null;
    private String liquidateDate = null;
    private String supplyType = null;
    private String demandType = null;
    // lpn
    private String provenanceTracking;
    // Used only by OIH Workflow
    private String manufacturer;
    
    // Used by CBM
    private String color = null;
    
    public String getAsin() {
        return asin;
    }

    public void setAsin(String asin) {
        this.asin = asin;
    }

    public int getIog() {
        return iog;
    }

    public void setIog(int iog) {
        this.iog = iog;
    }

    public int getGl() {
        return gl;
    }

    public void setGl(int gl) {
        this.gl = gl;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public double getOurPrice() {
        return ourPrice;
    }

    public void setOurPrice(double ourPrice) {
        this.ourPrice = ourPrice;
    }

    public Date getPublicationDate() {
        return publicationDate;
    }

    public void setPublicationDate(Date publicationDate) {
        this.publicationDate = publicationDate;
    }

    public Date getReleaseDate() {
        return releaseDate;
    }

    public void setReleaseDate(Date releaseDate) {
        this.releaseDate = releaseDate;
    }

    public String getUpc() {
        return upc;
    }

    public void setUpc(String upc) {
        this.upc = upc;
    }

    public boolean isUnPrepRequired() {
        return isUnPrepRequired;
    }

    public void setUnPrepRequired(boolean isUnPrepRequired) {
        this.isUnPrepRequired = isUnPrepRequired;
    }

    public int getCategory() {
        return category;
    }

    public void setCategory(int category) {
        this.category = category;
    }

    public int getSubCategory() {
        return subCategory;
    }

    public void setSubCategory(int subCategory) {
        this.subCategory = subCategory;
    }

    public String getEan() {
        return ean;
    }

    public void setEan(String ean) {
        this.ean = ean;
    }

    public String getPublisherCode() {
        return publisherCode;
    }

    public void setPublisherCode(String publisherCode) {
        this.publisherCode = publisherCode;
    }

    public double getMapPrice() {
        return mapPrice;
    }

    public void setMapPrice(double mapPrice) {
        this.mapPrice = mapPrice;
    }

    public String getMapRequired() {
        return mapRequired;
    }

    public void setMapRequired(String mapRequired) {
        this.mapRequired = mapRequired;
    }

    public double getListPrice() {
        return listPrice;
    }

    public void setListPrice(double listPrice) {
        this.listPrice = listPrice;
    }

    public void setListPriceWithTax(double listPriceWithTax){
        this.listPriceWithTax = listPriceWithTax;
    }
    
    public double getListPriceWithTax(){
        return this.listPriceWithTax;
    }
    
    public String getParentAsin() {
        return parentAsin;
    }

    public void setParentAsin(String parentAsin) {
        this.parentAsin = parentAsin;
    }

    public String getReplenishmentCategory() {
        return replenishmentCategory;
    }

    public void setReplenishmentCategory(String replenishmentCategory) {
        this.replenishmentCategory = replenishmentCategory;
    }

    public String getHazmatTransportationRegularClass() {
        return hazmatTransportationRegularClass;
    }

    public void setHazmatTransportationRegularClass(String hazmatTransportationRegularClass) {
        this.hazmatTransportationRegularClass = hazmatTransportationRegularClass;
    }

    public String getHazmatException() {
        return hazmatException;
    }

    public void setHazmatException(String hazmatException) {
        this.hazmatException = hazmatException;
    }

    public String isHazmatItem() {
        return isHazmatItem;
    }

    public void setHazmatItem(String isHazmatItem) {
        this.isHazmatItem = isHazmatItem;
    }

    public String getTextbookType() {
        return textbookType;
    }

    public void setTextbookType(String textbookType) {
        this.textbookType = textbookType;
    }

    public String getMapStrict() {
        return mapStrict;
    }

    public void setMapStrict(String mapStrict) {
        this.mapStrict = mapStrict;
    }

    public Date getMapEndDate() {
        return mapEndDate;
    }

    public void setMapEndDate(Date mapEndDate) {
        this.mapEndDate = mapEndDate;
    }

    public Date getSiteLaunchDate() {
        return siteLaunchDate;
    }

    public void setSiteLaunchDate(Date siteLaunchDate) {
        this.siteLaunchDate = siteLaunchDate;
    }

    public String getBrandCode() {
        return brandCode;
    }

    public void setBrandCode(String brandCode) {
        this.brandCode = brandCode;
    }

    public String getBrandName() {
        return brandName;
    }

    public void setBrandName(String brandName) {
        this.brandName = brandName;
    }

    public String getBinding() {
        return binding;
    }

    public void setBinding(String binding) {
        this.binding = binding;
    }

    public String getSeasons() {
        return seasons;
    }

    public void setSeasons(String seasons) {
        this.seasons = seasons;
    }

    public String getModelNumber() {
        return model;
    }

    public void setModelNumber(String modelNumber) {
        this.model = modelNumber;
    }

    public String getSourceCountryCode() {
        return sourceCountryCode;
    }

    public void setSourceCountryCode(String sourceCountryCode) {
        this.sourceCountryCode = sourceCountryCode;
    }

    public double getMapStrictPrice() {
        return mapStrictPrice;
    }

    public void setMapStrictPrice(double mapStrictPrice) {
        this.mapStrictPrice = mapStrictPrice;
    }

	public int getModelYear() {
		return modelYear;
	}

	public void setModelYear(int modelYear) {
		this.modelYear = modelYear;
	}

	public String getFormat() {
		return format;
	}

	public void setFormat(String format) {
		this.format = format;
	}

	public String getRestrictedPriceDiscountCountry() {
		return restrictedPriceDiscountCountry;
	}

	public void setRestrictedPriceDiscountCountry(
			String restrictedPriceDiscountCountry) {
		this.restrictedPriceDiscountCountry = restrictedPriceDiscountCountry;
	}

	public String getAvailability() {
		return availability;
	}

	public void setAvailability(String availability) {
		this.availability = availability;
	}

	public String getRetailOffer() {
		return retailOffer;
	}

	public void setRetailOffer(String retailOffer) {
		this.retailOffer = retailOffer;
	}

	public long getMarketplace() {
		return marketplace;
	}

	public void setMarketplace(long marketplace) {
		this.marketplace = marketplace;
	}

	public long getMerchant() {
		return merchant;
	}

	public void setMerchant(long merchant) {
		this.merchant = merchant;
	}

    public boolean isHidden() {
        return isHidden;
    }

    public void setHidden(boolean isHidden) {
        this.isHidden = isHidden;
    }

    //Shelf Life
    public int getFcShelfLife() {
        return fcShelfLife;
    }

    public void setFcShelfLife(int fcShelfLife) {
        this.fcShelfLife = fcShelfLife;
    }

    public int getFcShelfLifePadTime() {
        return fcShelfLifePadTime;
    }

    public void setFcShelfLifePadTime(int fcShelfLifePadTime) {
        this.fcShelfLifePadTime = fcShelfLifePadTime;
    }

    public int getFcShelfLifePadTime2Q() {
        return fcShelfLifePadTime2Q;
    }

    public void setFcShelfLifePadTime2Q(int fcShelfLifePadTime2Q) {
        this.fcShelfLifePadTime2Q = fcShelfLifePadTime2Q;
    }
    
    public String getProvenanceTracking(){
        return this.provenanceTracking;
    }

    public void setProvenanceTracking(String provenanceTracking) {
        this.provenanceTracking = provenanceTracking;
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

}
