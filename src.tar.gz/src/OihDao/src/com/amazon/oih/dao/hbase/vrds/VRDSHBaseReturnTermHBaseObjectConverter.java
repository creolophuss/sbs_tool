package com.amazon.oih.dao.hbase.vrds;

import com.amazon.oih.dao.hbase.base.SubKeyAwareHBaseDao;

public class VRDSHBaseReturnTermHBaseObjectConverter extends SubKeyAwareHBaseDao<VRDSHBaseReturnTerm>{

	public VRDSHBaseReturnTermHBaseObjectConverter() {
		super(VRDSHBaseReturnTerm.class);
	}

}
