package com.amazon.oih.dao.hbase.revenue.dataprocess;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.util.Bytes;

import com.amazon.oih.dao.hbase.revenue.AsinRevenueData;
import com.amazon.oih.dao.hbase.revenue.RevenueHBaseDao;
import com.google.common.collect.Maps;

public class AsinRevenueDataConvertor {

    public static RevenueSBSData convert2SBSData(Result result) {
        RevenueSBSData ret = new RevenueSBSData();
        String key = Bytes.toString(result.getRow());
        AsinRevenueData asinRevenueData = RevenueHBaseDao.convertResult2AsinRevenue(key, result);

        ret.asin = asinRevenueData.getAsin();

        ret.ourprice = asinRevenueData.getOurPrice();

        Map<Integer, List<Double>> revenueMap = asinRevenueData.getInventory2RevenueMap();

        Integer maxInventory = Collections.max(revenueMap.keySet());

        double totalRevenueOfWeek0 = revenueMap.get(maxInventory).get(0);

        double avgRevenue = totalRevenueOfWeek0 / maxInventory;

        ret.revenue = avgRevenue;
        ret.maxInventory = maxInventory;

        return ret;

    }

    public static RevenueVerifyData convert2VerifyData(Result result) {
        RevenueVerifyData ret = new RevenueVerifyData();
        String key = Bytes.toString(result.getRow());
        AsinRevenueData asinRevenueData = RevenueHBaseDao.convertResult2AsinRevenue(key, result);

        ret.asin = asinRevenueData.getAsin();

        double[] preInventoryRevenue = null;
        double[] preRevenuePerDeltaInventory = null;

        Map<Integer, List<Double>> sortedMap = Maps.newTreeMap();
        sortedMap.putAll(asinRevenueData.getInventory2RevenueMap());

        int[] inventoryValues = new int[sortedMap.size()];
        int inventoryStep = 0;
        for (Entry<Integer, List<Double>> data : sortedMap.entrySet()) {
            List<Double> inventRevenueN = data.getValue();
            inventoryValues[inventoryStep] = data.getKey();
            int weekCount = inventRevenueN.size();
            // init weeks revenue
            if (preInventoryRevenue == null) {
                preInventoryRevenue = new double[weekCount];
                for (int week = 0; week < weekCount; week++) {
                    preInventoryRevenue[week] = inventRevenueN.get(week);
                }
                inventoryStep++;
                continue;
            }
            // init weeks delta revenue
            if (preRevenuePerDeltaInventory == null) {
                preRevenuePerDeltaInventory = new double[weekCount];
                for (int week = 0; week < weekCount; week++) {
                    double preRevenue = preInventoryRevenue[week];
                    double revenue = inventRevenueN.get(week);
                    double delta = revenue - preRevenue;
                    preRevenuePerDeltaInventory[week] = delta
                            / (inventoryValues[inventoryStep] - inventoryValues[inventoryStep - 1]);
                    preInventoryRevenue[week] = revenue;
                }
                inventoryStep++;
                continue;
            }
            for (int week = 0; week < weekCount; week++) {
                double preWeekRevenuePerDeltaInventory = (preRevenuePerDeltaInventory[week]);

                double preRevenue = preInventoryRevenue[week];
                double revenue = inventRevenueN.get(week);

                int deltaInventory = inventoryValues[inventoryStep] - inventoryValues[inventoryStep - 1];

                double currWeekRevenuePerDeltaInventory = (revenue - preRevenue) / deltaInventory;

                if (currWeekRevenuePerDeltaInventory - preWeekRevenuePerDeltaInventory >= 0.02) {
                    String report = String.format("Week %s. Inventory %s to %s. " + "Revenue %s to %s. P=%s C=%s",
                            week, inventoryValues[inventoryStep - 1],
                            inventoryValues[inventoryStep], preWeekRevenuePerDeltaInventory,
                            currWeekRevenuePerDeltaInventory, preRevenue, revenue);
                    ret.setExceptionDetails(report);
                    return ret;
                }

                preRevenuePerDeltaInventory[week] = currWeekRevenuePerDeltaInventory;
                preInventoryRevenue[week] = revenue;
            }
            inventoryStep++;
        }

        return ret;

    }
}
