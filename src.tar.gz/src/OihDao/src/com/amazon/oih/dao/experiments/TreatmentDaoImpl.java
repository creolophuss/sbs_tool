package com.amazon.oih.dao.experiments;

import com.amazon.carbonado.ConfigurationException;
import com.amazon.carbonado.PersistException;
import com.amazon.carbonado.Repository;
import com.amazon.carbonado.RepositoryException;
import com.amazon.carbonado.Storage;
import com.amazon.oih.dao.exception.DaoRuntimeException;
import com.amazon.oih.dao.exception.OihPersistenceException;

public class TreatmentDaoImpl implements TreatmentDao {

    protected String _domain = null;
    protected Repository repository = null;

    public TreatmentDaoImpl(String domain) {
        _domain = domain;
    }

    public void setRepository(Repository repository) {
        if (null == repository) {
            throw new IllegalArgumentException("repository is null");
        }
        this.repository = repository;
    }

    @Override
    public Treatment createTreatment(long runId, int experimentId, int iog, String asin) throws OihPersistenceException {
        try {
            Storage<Treatment> sf = repository.storageFor(Treatment.class);
            Treatment t = sf.prepare();
            t.setRunID(runId);
            t.setExperimentId(experimentId);
            t.setIog(iog);
            t.setAsin(asin);
            return t;
        } catch (ConfigurationException e) {
            throw new DaoRuntimeException(e);
        } catch (RepositoryException e) {
            throw new OihPersistenceException(e);
        }
    }

    @Override
    public void save(Treatment treatment) throws OihPersistenceException {
        try {
            treatment.insert();
        } catch (PersistException e) {
            throw new OihPersistenceException(e);
        }
    }

    @Override
    public boolean exists(long runID, int experimentId, int iog, String asin) throws OihPersistenceException {

        try {
            Storage<Treatment> sf = repository.storageFor(Treatment.class);
            return sf.query("runID = ? & experimentId = ? & asin = ? & iog = ?").with(runID).with(experimentId)
                    .with(asin).with(iog).exists();
        } catch (ConfigurationException e) {
            throw new DaoRuntimeException(e);
        } catch (RepositoryException e) {
            throw new OihPersistenceException(e);
        }
    }

}
