package com.amazon.oih.dao.transportationcost;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;

import com.amazon.oih.dao.SessionFactoryManager;
import com.amazon.oih.dao.exception.OihPersistenceException;

public class TransportationCostDaoImpl implements TransportationCostDao {
    private final static Logger logger = Logger.getLogger(TransportationCostDaoImpl.class);
    
    @SuppressWarnings("unchecked")
    @Override
    public List<TransportationCost> getTransportationCosts(String realm) {
        Session session = null;
        try {
            session = openSession();
            Criteria cri = session.createCriteria(TransportationCost.class);
            cri.add(Restrictions.eq("realm", realm));
            return (List<TransportationCost>) cri.list();
        } catch (HibernateException e) {
            logger.error("Failed to get transportation costs of realm " + realm + ". " + e);
            throw (e);
        } finally {
            closeSession(session);
        }
    }
    
    @Override
    public void save(TransportationCost transportationCost) throws Exception {
        Session session = null;
        Transaction tx = null;
        try {
            session = openSession();
            tx = session.beginTransaction();
            session.save(transportationCost);
            tx.commit();
        } catch (HibernateException e) {
            if (tx != null) {
                tx.rollback();
            }
            logger.error("Fail to save transportation cost: " + transportationCost + ". " + e);
            throw new OihPersistenceException(e);
        } finally {
            closeSession(session);
        }
    }
    
    private Session openSession() {
        return SessionFactoryManager.getVendorFlexSessionFactoryInstance().openSession();
    }

    private void closeSession(Session session) {
        if (session != null) {
            session.close();
        }
    }

}
