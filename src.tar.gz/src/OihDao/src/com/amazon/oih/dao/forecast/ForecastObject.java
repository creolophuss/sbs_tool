package com.amazon.oih.dao.forecast;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import amazon.platform.config.AppConfig;

import com.amazon.oih.dao.OihObject;

/**
 * This is the forecast object for Hibernate.
 * The code seems very ugly, but I can't find a good way to map many columns of one table to a list
 * If you have some other better solution, please substitute it without any doubt.
 * 
 * @author zhongwei
 * 
 */
public class ForecastObject extends OihObject {
    private double forecast1;
    private double forecast2;
    private double forecast3;
    private double forecast4;
    private double forecast5;
    private double forecast6;
    private double forecast7;
    private double forecast8;
    private double forecast9;
    private double forecast10;
    private double forecast11;
    private double forecast12;
    private double forecast13;
    private double forecast14;
    private double forecast15;
    private double forecast16;
    private double forecast17;
    private double forecast18;
    private double forecast19;
    private double forecast20;
    private double forecast21;
    private double forecast22;
    private double forecast23;
    private double forecast24;
    private double forecast25;
    private double forecast26;
    private double forecast27;
    private double forecast28;
    private double forecast29;
    private double forecast30;
    private double forecast31;
    private double forecast32;
    private double forecast33;
    private double forecast34;
    private double forecast35;
    private double forecast36;
    private double forecast37;
    private double forecast38;
    private double forecast39;
    private double forecast40;
    private double forecast41;
    private double forecast42;
    private double forecast43;
    private double forecast44;
    private double forecast45;
    private double forecast46;
    private double forecast47;
    private double forecast48;
    private double forecast49;
    private double forecast50;
    private double forecast51;
    private double forecast52;
    private String realm;
    private ForecastType type;

    private final static int NUM_OF_WEEK = 52;
    private static final List<Double> zeroForecasts = new ArrayList<Double>(NUM_OF_WEEK);
    static {
        for (int i = 0; i < NUM_OF_WEEK; i++) {
            zeroForecasts.add(0.0);
        }
    }

    public ForecastObject() {
    }

    public ForecastObject(String asin, int iog) {
        this.setAsin(asin);
        this.setIog(iog);
        setRealm(AppConfig.getRealm().name());
    }

    public static ForecastObject createNullForecastObject(String asin, int iog) {
        ForecastObject nullForecast = new ForecastObject(asin, iog);
        nullForecast.setForecasts(zeroForecasts);
        return nullForecast;
    }

    public ForecastObject(String asin, int iog, String source, Date runDate, List<Double> forecasts) {
        super(asin, iog, source, runDate);
        InitWithType(asin, iog, source, runDate, ForecastType.DEFAULT_TYPE, forecasts);
    }

	public ForecastObject(String asin, int iog, String source, Date runDate, ForecastType type, List<Double> forecasts) {
        super(asin, iog, source, runDate);
        InitWithType(asin, iog, source, runDate, type, forecasts);
    }
	
	private void InitWithType(String asin, int iog, String source,
			Date runDate, ForecastType type, List<Double> forecasts) {
        assert (forecasts != null && forecasts.size() == NUM_OF_WEEK);
        setForecasts(forecasts);
        setRealm(AppConfig.getRealm().name());
        setType(type);
	}
	
    public double getForecast1() {
        return forecast1;
    }

    public void setForecast1(double forecast1) {
        this.forecast1 = forecast1;
    }

    public double getForecast2() {
        return forecast2;
    }

    public void setForecast2(double forecast2) {
        this.forecast2 = forecast2;
    }

    public double getForecast3() {
        return forecast3;
    }

    public void setForecast3(double forecast3) {
        this.forecast3 = forecast3;
    }

    public double getForecast4() {
        return forecast4;
    }

    public void setForecast4(double forecast4) {
        this.forecast4 = forecast4;
    }

    public double getForecast5() {
        return forecast5;
    }

    public void setForecast5(double forecast5) {
        this.forecast5 = forecast5;
    }

    public double getForecast6() {
        return forecast6;
    }

    public void setForecast6(double forecast6) {
        this.forecast6 = forecast6;
    }

    public double getForecast7() {
        return forecast7;
    }

    public void setForecast7(double forecast7) {
        this.forecast7 = forecast7;
    }

    public double getForecast8() {
        return forecast8;
    }

    public void setForecast8(double forecast8) {
        this.forecast8 = forecast8;
    }

    public double getForecast9() {
        return forecast9;
    }

    public void setForecast9(double forecast9) {
        this.forecast9 = forecast9;
    }

    public double getForecast10() {
        return forecast10;
    }

    public void setForecast10(double forecast10) {
        this.forecast10 = forecast10;
    }

    public double getForecast11() {
        return forecast11;
    }

    public void setForecast11(double forecast11) {
        this.forecast11 = forecast11;
    }

    public double getForecast12() {
        return forecast12;
    }

    public void setForecast12(double forecast12) {
        this.forecast12 = forecast12;
    }

    public double getForecast13() {
        return forecast13;
    }

    public void setForecast13(double forecast13) {
        this.forecast13 = forecast13;
    }

    public double getForecast14() {
        return forecast14;
    }

    public void setForecast14(double forecast14) {
        this.forecast14 = forecast14;
    }

    public double getForecast15() {
        return forecast15;
    }

    public void setForecast15(double forecast15) {
        this.forecast15 = forecast15;
    }

    public double getForecast16() {
        return forecast16;
    }

    public void setForecast16(double forecast16) {
        this.forecast16 = forecast16;
    }

    public double getForecast17() {
        return forecast17;
    }

    public void setForecast17(double forecast17) {
        this.forecast17 = forecast17;
    }

    public double getForecast18() {
        return forecast18;
    }

    public void setForecast18(double forecast18) {
        this.forecast18 = forecast18;
    }

    public double getForecast19() {
        return forecast19;
    }

    public void setForecast19(double forecast19) {
        this.forecast19 = forecast19;
    }

    public double getForecast20() {
        return forecast20;
    }

    public void setForecast20(double forecast20) {
        this.forecast20 = forecast20;
    }

    public double getForecast21() {
        return forecast21;
    }

    public void setForecast21(double forecast21) {
        this.forecast21 = forecast21;
    }

    public double getForecast22() {
        return forecast22;
    }

    public void setForecast22(double forecast22) {
        this.forecast22 = forecast22;
    }

    public double getForecast23() {
        return forecast23;
    }

    public void setForecast23(double forecast23) {
        this.forecast23 = forecast23;
    }

    public double getForecast24() {
        return forecast24;
    }

    public void setForecast24(double forecast24) {
        this.forecast24 = forecast24;
    }

    public double getForecast25() {
        return forecast25;
    }

    public void setForecast25(double forecast25) {
        this.forecast25 = forecast25;
    }

    public double getForecast26() {
        return forecast26;
    }

    public void setForecast26(double forecast26) {
        this.forecast26 = forecast26;
    }

    public double getForecast27() {
        return forecast27;
    }

    public void setForecast27(double forecast27) {
        this.forecast27 = forecast27;
    }

    public double getForecast28() {
        return forecast28;
    }

    public void setForecast28(double forecast28) {
        this.forecast28 = forecast28;
    }

    public double getForecast29() {
        return forecast29;
    }

    public void setForecast29(double forecast29) {
        this.forecast29 = forecast29;
    }

    public double getForecast30() {
        return forecast30;
    }

    public void setForecast30(double forecast30) {
        this.forecast30 = forecast30;
    }

    public double getForecast31() {
        return forecast31;
    }

    public void setForecast31(double forecast31) {
        this.forecast31 = forecast31;
    }

    public double getForecast32() {
        return forecast32;
    }

    public void setForecast32(double forecast32) {
        this.forecast32 = forecast32;
    }

    public double getForecast33() {
        return forecast33;
    }

    public void setForecast33(double forecast33) {
        this.forecast33 = forecast33;
    }

    public double getForecast34() {
		return forecast34;
	}

	public void setForecast34(double forecast34) {
		this.forecast34 = forecast34;
	}

	public double getForecast35() {
		return forecast35;
	}

	public void setForecast35(double forecast35) {
		this.forecast35 = forecast35;
	}

	public double getForecast36() {
		return forecast36;
	}

	public void setForecast36(double forecast36) {
		this.forecast36 = forecast36;
	}

	public double getForecast37() {
		return forecast37;
	}

	public void setForecast37(double forecast37) {
		this.forecast37 = forecast37;
	}

	public double getForecast38() {
		return forecast38;
	}

	public void setForecast38(double forecast38) {
		this.forecast38 = forecast38;
	}

	public double getForecast39() {
		return forecast39;
	}

	public void setForecast39(double forecast39) {
		this.forecast39 = forecast39;
	}

	public double getForecast40() {
		return forecast40;
	}

	public void setForecast40(double forecast40) {
		this.forecast40 = forecast40;
	}

	public double getForecast41() {
		return forecast41;
	}

	public void setForecast41(double forecast41) {
		this.forecast41 = forecast41;
	}

	public double getForecast42() {
		return forecast42;
	}

	public void setForecast42(double forecast42) {
		this.forecast42 = forecast42;
	}

	public double getForecast43() {
		return forecast43;
	}

	public void setForecast43(double forecast43) {
		this.forecast43 = forecast43;
	}

	public double getForecast44() {
		return forecast44;
	}

	public void setForecast44(double forecast44) {
		this.forecast44 = forecast44;
	}

	public double getForecast45() {
		return forecast45;
	}

	public void setForecast45(double forecast45) {
		this.forecast45 = forecast45;
	}

	public double getForecast46() {
		return forecast46;
	}

	public void setForecast46(double forecast46) {
		this.forecast46 = forecast46;
	}

	public double getForecast47() {
		return forecast47;
	}

	public void setForecast47(double forecast47) {
		this.forecast47 = forecast47;
	}

	public double getForecast48() {
		return forecast48;
	}

	public void setForecast48(double forecast48) {
		this.forecast48 = forecast48;
	}

	public double getForecast49() {
		return forecast49;
	}

	public void setForecast49(double forecast49) {
		this.forecast49 = forecast49;
	}

	public double getForecast50() {
		return forecast50;
	}

	public void setForecast50(double forecast50) {
		this.forecast50 = forecast50;
	}

	public double getForecast51() {
		return forecast51;
	}

	public void setForecast51(double forecast51) {
		this.forecast51 = forecast51;
	}

	public double getForecast52() {
		return forecast52;
	}

	public void setForecast52(double forecast52) {
		this.forecast52 = forecast52;
	}

	public ForecastType getType() {
		return type;
	}

	public void setType(ForecastType type) {
		this.type = type;
	}

	public void setForecasts(List<Double> forecasts) {
        for (int i = 0; i < forecasts.size(); i++) {
            if (Double.isNaN(forecasts.get(i)) || Double.isInfinite(forecasts.get(i))) {
                forecasts.set(i, 0.0);// transfer NaN to 0.0
            }
        }

        setForecast1(forecasts.get(0));
        setForecast2(forecasts.get(1));
        setForecast3(forecasts.get(2));
        setForecast4(forecasts.get(3));
        setForecast5(forecasts.get(4));
        setForecast6(forecasts.get(5));
        setForecast7(forecasts.get(6));
        setForecast8(forecasts.get(7));
        setForecast9(forecasts.get(8));
        setForecast10(forecasts.get(9));
        setForecast11(forecasts.get(10));
        setForecast12(forecasts.get(11));
        setForecast13(forecasts.get(12));
        setForecast14(forecasts.get(13));
        setForecast15(forecasts.get(14));
        setForecast16(forecasts.get(15));
        setForecast17(forecasts.get(16));
        setForecast18(forecasts.get(17));
        setForecast19(forecasts.get(18));
        setForecast20(forecasts.get(19));
        setForecast21(forecasts.get(20));
        setForecast22(forecasts.get(21));
        setForecast23(forecasts.get(22));
        setForecast24(forecasts.get(23));
        setForecast25(forecasts.get(24));
        setForecast26(forecasts.get(25));
        setForecast27(forecasts.get(26));
        setForecast28(forecasts.get(27));
        setForecast29(forecasts.get(28));
        setForecast30(forecasts.get(29));
        setForecast31(forecasts.get(30));
        setForecast32(forecasts.get(31));
        setForecast33(forecasts.get(32));
        setForecast34(forecasts.get(33));
        setForecast35(forecasts.get(34));
        setForecast36(forecasts.get(35));
        setForecast37(forecasts.get(36));
        setForecast38(forecasts.get(37));
        setForecast39(forecasts.get(38));
        setForecast40(forecasts.get(39));
        setForecast41(forecasts.get(40));
        setForecast42(forecasts.get(41));
        setForecast43(forecasts.get(42));
        setForecast44(forecasts.get(43));
        setForecast45(forecasts.get(44));
        setForecast46(forecasts.get(45));
        setForecast47(forecasts.get(46));
        setForecast48(forecasts.get(47));
        setForecast49(forecasts.get(48));
        setForecast50(forecasts.get(49));
        setForecast51(forecasts.get(50));
        setForecast52(forecasts.get(51));
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof ForecastObject == false) {
            return false;
        }
        if (this == obj) {
            return true;
        }

        ForecastObject other = (ForecastObject) obj;
        return super.equals(obj) 
        		&& (getRealm() != null && getRealm().equals(other.getRealm()))
        		&& (getType() != null && getType().equals(other.getType()))
                && Math.abs(this.forecast1 - other.getForecast1()) < 1e-6
                && Math.abs(this.forecast2 - other.getForecast2()) < 1e-6
                && Math.abs(this.forecast3 - other.getForecast3()) < 1e-6
                && Math.abs(this.forecast4 - other.getForecast4()) < 1e-6
                && Math.abs(this.forecast5 - other.getForecast5()) < 1e-6
                && Math.abs(this.forecast6 - other.getForecast6()) < 1e-6
                && Math.abs(this.forecast7 - other.getForecast7()) < 1e-6
                && Math.abs(this.forecast8 - other.getForecast8()) < 1e-6
                && Math.abs(this.forecast9 - other.getForecast9()) < 1e-6
                && Math.abs(this.forecast10 - other.getForecast10()) < 1e-6
                && Math.abs(this.forecast11 - other.getForecast11()) < 1e-6
                && Math.abs(this.forecast12 - other.getForecast12()) < 1e-6
                && Math.abs(this.forecast13 - other.getForecast13()) < 1e-6
                && Math.abs(this.forecast14 - other.getForecast14()) < 1e-6
                && Math.abs(this.forecast15 - other.getForecast15()) < 1e-6
                && Math.abs(this.forecast16 - other.getForecast16()) < 1e-6
                && Math.abs(this.forecast17 - other.getForecast17()) < 1e-6
                && Math.abs(this.forecast18 - other.getForecast18()) < 1e-6
                && Math.abs(this.forecast19 - other.getForecast19()) < 1e-6
                && Math.abs(this.forecast20 - other.getForecast20()) < 1e-6
                && Math.abs(this.forecast21 - other.getForecast21()) < 1e-6
                && Math.abs(this.forecast22 - other.getForecast22()) < 1e-6
                && Math.abs(this.forecast23 - other.getForecast23()) < 1e-6
                && Math.abs(this.forecast24 - other.getForecast24()) < 1e-6
                && Math.abs(this.forecast25 - other.getForecast25()) < 1e-6
                && Math.abs(this.forecast26 - other.getForecast26()) < 1e-6
                && Math.abs(this.forecast27 - other.getForecast27()) < 1e-6
                && Math.abs(this.forecast28 - other.getForecast28()) < 1e-6
                && Math.abs(this.forecast29 - other.getForecast29()) < 1e-6
                && Math.abs(this.forecast30 - other.getForecast30()) < 1e-6
                && Math.abs(this.forecast31 - other.getForecast31()) < 1e-6
                && Math.abs(this.forecast32 - other.getForecast32()) < 1e-6
                && Math.abs(this.forecast33 - other.getForecast33()) < 1e-6
                && Math.abs(this.forecast34 - other.getForecast34()) < 1e-6
                && Math.abs(this.forecast35 - other.getForecast35()) < 1e-6
                && Math.abs(this.forecast36 - other.getForecast36()) < 1e-6
                && Math.abs(this.forecast37 - other.getForecast37()) < 1e-6
                && Math.abs(this.forecast38 - other.getForecast38()) < 1e-6
                && Math.abs(this.forecast39 - other.getForecast39()) < 1e-6
                && Math.abs(this.forecast40 - other.getForecast40()) < 1e-6
                && Math.abs(this.forecast41 - other.getForecast41()) < 1e-6
                && Math.abs(this.forecast42 - other.getForecast42()) < 1e-6
                && Math.abs(this.forecast43 - other.getForecast43()) < 1e-6
                && Math.abs(this.forecast44 - other.getForecast44()) < 1e-6
                && Math.abs(this.forecast45 - other.getForecast45()) < 1e-6
                && Math.abs(this.forecast46 - other.getForecast46()) < 1e-6
                && Math.abs(this.forecast47 - other.getForecast47()) < 1e-6
                && Math.abs(this.forecast48 - other.getForecast48()) < 1e-6
                && Math.abs(this.forecast49 - other.getForecast49()) < 1e-6
                && Math.abs(this.forecast50 - other.getForecast50()) < 1e-6
                && Math.abs(this.forecast51 - other.getForecast51()) < 1e-6
                && Math.abs(this.forecast52 - other.getForecast52()) < 1e-6;
    }

    @Override
    public void cleanValues() {
        forecast1 = 0.0;
        forecast2 = 0.0;
        forecast3 = 0.0;
        forecast4 = 0.0;
        forecast5 = 0.0;
        forecast6 = 0.0;
        forecast7 = 0.0;
        forecast8 = 0.0;
        forecast9 = 0.0;
        forecast10 = 0.0;
        forecast11 = 0.0;
        forecast12 = 0.0;
        forecast13 = 0.0;
        forecast14 = 0.0;
        forecast15 = 0.0;
        forecast16 = 0.0;
        forecast17 = 0.0;
        forecast18 = 0.0;
        forecast19 = 0.0;
        forecast20 = 0.0;
        forecast21 = 0.0;
        forecast22 = 0.0;
        forecast23 = 0.0;
        forecast24 = 0.0;
        forecast25 = 0.0;
        forecast26 = 0.0;
        forecast27 = 0.0;
        forecast28 = 0.0;
        forecast29 = 0.0;
        forecast30 = 0.0;
        forecast31 = 0.0;
        forecast32 = 0.0;
        forecast33 = 0.0;
        forecast34 = 0.0;
        forecast35 = 0.0;
        forecast36 = 0.0;
        forecast37 = 0.0;
        forecast38 = 0.0;
        forecast39 = 0.0;
        forecast40 = 0.0;
        forecast41 = 0.0;
        forecast42 = 0.0;
        forecast43 = 0.0;
        forecast44 = 0.0;
        forecast45 = 0.0;
        forecast46 = 0.0;
        forecast47 = 0.0;
        forecast48 = 0.0;
        forecast49 = 0.0;
        forecast50 = 0.0;
        forecast51 = 0.0;
        forecast52 = 0.0;
    }

    @Override
    public void copyValues(Object obj) {

        if (obj == null || obj instanceof ForecastObject == false) {
            throw new RuntimeException("Wrong instance type.");
        }
        ForecastObject other = (ForecastObject) obj;
        this.forecast1 = other.forecast1;
        this.forecast2 = other.forecast2;
        this.forecast3 = other.forecast3;
        this.forecast4 = other.forecast4;
        this.forecast5 = other.forecast5;
        this.forecast6 = other.forecast6;
        this.forecast7 = other.forecast7;
        this.forecast8 = other.forecast8;
        this.forecast9 = other.forecast9;
        this.forecast10 = other.forecast10;
        this.forecast11 = other.forecast11;
        this.forecast12 = other.forecast12;
        this.forecast13 = other.forecast13;
        this.forecast14 = other.forecast14;
        this.forecast15 = other.forecast15;
        this.forecast16 = other.forecast16;
        this.forecast17 = other.forecast17;
        this.forecast18 = other.forecast18;
        this.forecast19 = other.forecast19;
        this.forecast20 = other.forecast20;
        this.forecast21 = other.forecast21;
        this.forecast22 = other.forecast22;
        this.forecast23 = other.forecast23;
        this.forecast24 = other.forecast24;
        this.forecast25 = other.forecast25;
        this.forecast26 = other.forecast26;
        this.forecast27 = other.forecast27;
        this.forecast28 = other.forecast28;
        this.forecast29 = other.forecast29;
        this.forecast30 = other.forecast30;
        this.forecast31 = other.forecast31;
        this.forecast32 = other.forecast32;
        this.forecast33 = other.forecast33;
        this.forecast34 = other.forecast34;
        this.forecast35 = other.forecast35;
        this.forecast36 = other.forecast36;
        this.forecast37 = other.forecast37;
        this.forecast38 = other.forecast38;
        this.forecast39 = other.forecast39;
        this.forecast40 = other.forecast40;
        this.forecast41 = other.forecast41;
        this.forecast42 = other.forecast42;
        this.forecast43 = other.forecast43;
        this.forecast44 = other.forecast44;
        this.forecast45 = other.forecast45;
        this.forecast46 = other.forecast46;
        this.forecast47 = other.forecast47;
        this.forecast48 = other.forecast48;
        this.forecast49 = other.forecast49;
        this.forecast50 = other.forecast50;
        this.forecast51 = other.forecast51;
        this.forecast52 = other.forecast52;
    }

    @Override
    public String getKey() {
        return this.getAsin() + "|" + this.getIog() + "|" + getRealm() + "|" + getType();
    }

    @Override
    public String getValues() {
        return String.valueOf(forecast1) + String.valueOf(forecast2) + String.valueOf(forecast3)
                + String.valueOf(forecast4) + String.valueOf(forecast5) + String.valueOf(forecast6)
                + String.valueOf(forecast7) + String.valueOf(forecast8) + String.valueOf(forecast9)
                + String.valueOf(forecast10) + String.valueOf(forecast11) + String.valueOf(forecast12)
                + String.valueOf(forecast13) + String.valueOf(forecast14) + String.valueOf(forecast15)
                + String.valueOf(forecast16) + String.valueOf(forecast17) + String.valueOf(forecast18)
                + String.valueOf(forecast19) + String.valueOf(forecast20) + String.valueOf(forecast21)
                + String.valueOf(forecast22) + String.valueOf(forecast23) + String.valueOf(forecast24)
                + String.valueOf(forecast25) + String.valueOf(forecast26) + String.valueOf(forecast27)
                + String.valueOf(forecast28) + String.valueOf(forecast29) + String.valueOf(forecast30)
                + String.valueOf(forecast31) + String.valueOf(forecast32) + String.valueOf(forecast33)
                + String.valueOf(forecast34) + String.valueOf(forecast35) + String.valueOf(forecast36)
                + String.valueOf(forecast37) + String.valueOf(forecast38) + String.valueOf(forecast39)
                + String.valueOf(forecast40) + String.valueOf(forecast41) + String.valueOf(forecast42)
                + String.valueOf(forecast43) + String.valueOf(forecast44) + String.valueOf(forecast45)
                + String.valueOf(forecast46) + String.valueOf(forecast47) + String.valueOf(forecast48)
                + String.valueOf(forecast49) + String.valueOf(forecast50) + String.valueOf(forecast51)
                + String.valueOf(forecast52);
    }

    @Override
    public int hashCode() {
        int result;
        result = 17 + this.getAsin().hashCode();
        result = 17 * result + this.getIog() + this.getRealm().hashCode() + this.getType().hashCode();
        return result;
    }

    public List<Double> getForecasts() {
        List<Double> forecasts = new ArrayList<Double>(NUM_OF_WEEK);
        forecasts.add(forecast1);
        forecasts.add(forecast2);
        forecasts.add(forecast3);
        forecasts.add(forecast4);
        forecasts.add(forecast5);
        forecasts.add(forecast6);
        forecasts.add(forecast7);
        forecasts.add(forecast8);
        forecasts.add(forecast9);
        forecasts.add(forecast10);
        forecasts.add(forecast11);
        forecasts.add(forecast12);
        forecasts.add(forecast13);
        forecasts.add(forecast14);
        forecasts.add(forecast15);
        forecasts.add(forecast16);
        forecasts.add(forecast17);
        forecasts.add(forecast18);
        forecasts.add(forecast19);
        forecasts.add(forecast20);
        forecasts.add(forecast21);
        forecasts.add(forecast22);
        forecasts.add(forecast23);
        forecasts.add(forecast24);
        forecasts.add(forecast25);
        forecasts.add(forecast26);
        forecasts.add(forecast27);
        forecasts.add(forecast28);
        forecasts.add(forecast29);
        forecasts.add(forecast30);
        forecasts.add(forecast31);
        forecasts.add(forecast32);
        forecasts.add(forecast33);
        forecasts.add(forecast34);
        forecasts.add(forecast35);
        forecasts.add(forecast36);
        forecasts.add(forecast37);
        forecasts.add(forecast38);
        forecasts.add(forecast39);
        forecasts.add(forecast40);
        forecasts.add(forecast41);
        forecasts.add(forecast42);
        forecasts.add(forecast43);
        forecasts.add(forecast44);
        forecasts.add(forecast45);
        forecasts.add(forecast46);
        forecasts.add(forecast47);
        forecasts.add(forecast48);
        forecasts.add(forecast49);
        forecasts.add(forecast50);
        forecasts.add(forecast51);
        forecasts.add(forecast52);

        return forecasts;
    }

    public void setRealm(String realm) {
        this.realm = realm;
    }

    public String getRealm() {
        return realm;
    }

}