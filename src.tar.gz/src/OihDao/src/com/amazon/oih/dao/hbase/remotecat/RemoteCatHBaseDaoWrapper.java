package com.amazon.oih.dao.hbase.remotecat;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import com.amazon.carbonado.Repository;
import com.amazon.oih.dao.exception.OihPersistenceException;
import com.amazon.oih.dao.hbase.base.HBaseDao;
import com.amazon.oih.dao.hbase.base.HBaseDaoImplAdaptor;
import com.amazon.oih.dao.remotecat.IRemoteCatDao;
import com.amazon.oih.dao.remotecat.RemoteCat;
import com.amazon.oih.dao.remotecat.RemoteCatValueObject;
import com.amazon.oih.utils.Utils;

public class RemoteCatHBaseDaoWrapper implements HBaseDao<List<RemoteCat>>, IRemoteCatDao {

    private HBaseDaoImplAdaptor<List<RemoteCat>> dao = null;
    public RemoteCatHBaseDaoWrapper(HBaseDaoImplAdaptor<List<RemoteCat>> remoteCatHBaseDao){
        this.dao = remoteCatHBaseDao;
    }
    @Override
    public void setRepository(Repository repository) {
        // nothing
    }

    @Override
    public RemoteCat createRemoteCat(long runId, RemoteCatValueObject valueObject){
        return new RemoteCat(runId, valueObject);
    }

    @Override
    public void save(RemoteCat remoteCat) throws OihPersistenceException {
        try {
            putSingleElement(Arrays.asList(remoteCat));
        } catch (IOException e) {
            throw new OihPersistenceException(e);
        }
    }

    @Override
    public void save(List<RemoteCat> remoteCats) throws OihPersistenceException {
        try {
            put(Utils.toNestedList(remoteCats));
        } catch (IOException e) {
            throw new OihPersistenceException(e);
        }
    }

    @Override
    public RemoteCat find(Long runId, String asin, long marketplaceId, long merchantId) throws OihPersistenceException {
        try {
            List<RemoteCat> resultList = get(dao.generateRowKey(Arrays.asList(new RemoteCat(asin, marketplaceId, merchantId))));
            return findByMerchantId(resultList, merchantId);      
        } catch (IOException e) {
            throw new OihPersistenceException(e);
        }
    }
    
    @Override
    public List<RemoteCat> find(Long runId, List<String> asins, long marketplaceId, long merchantId) throws OihPersistenceException {
        try {
            Collection<String> rowKeys = new ArrayList<String>(asins.size());
            for (String asin : asins) {
                rowKeys.add(dao.generateRowKey(Arrays.asList(new RemoteCat(asin, marketplaceId, merchantId))));
            }
            List<List<RemoteCat>> resultList =  get(rowKeys);
            
            List<RemoteCat> finalResult = new ArrayList<RemoteCat>();
            for (int i=0; i<asins.size(); i++){
                RemoteCat found = findByMerchantId(resultList.get(i), merchantId);
                finalResult.add(found);
            }
            return finalResult;
        } catch (IOException e) {
            throw new OihPersistenceException(e);
        }        
    }
    
    private RemoteCat findByMerchantId(List<RemoteCat> remoteCatList, long merchantId){
        if (remoteCatList == null){
            return null;
        }
        for (RemoteCat remoteCat : remoteCatList){
            if (remoteCat != null && merchantId == remoteCat.getMerchant()){
                return remoteCat;
            }
        }
        return null;
    }

    @Override
    public boolean exists(Long runId, String asin, long marketplaceId, long merchantId) throws OihPersistenceException {
        try {
            return exist(dao.generateRowKey(Arrays.asList(new RemoteCat(asin, marketplaceId, merchantId))), "" + merchantId);
        } catch (IOException e) {
            throw new OihPersistenceException(e);
        }
    }

    @Override
    public void putSingleElement(List<RemoteCat> bObject) throws IOException {
        dao.putSingleElement(bObject);
    }

    @Override
    public void put(List<List<RemoteCat>> bObjects) throws IOException {
        dao.put(bObjects);
    }

    @Override
    public List<RemoteCat> get(String rowKey) throws IOException {
        return dao.get(rowKey);
    }

    @Override
    public List<List<RemoteCat>> get(Collection<String> rowKeys) throws IOException {
        return dao.get(rowKeys);
    }

    @Override
    public boolean exist(String rowKey) throws IOException {
        boolean ret = dao.exist(rowKey);
        return ret;
    }

    @Override
    public boolean exist(String rowKey, String qualifier) throws IOException {
        boolean ret = dao.exist(rowKey, qualifier);
        return ret;
    }

    @Override
    public void deleteRow(String rowKey) throws IOException {
        dao.deleteRow(rowKey);
    }

    @Override
    public void deleteRows(List<String> rowKeys) throws IOException {
        dao.deleteRows(rowKeys);
    }

    @Override
    public void close() throws IOException {
        dao.close();
    }

}
