package com.amazon.oih.dao.scopemapping;

import java.util.ArrayList;
import java.util.List;

import com.amazon.oih.dao.g2s2.ConfigKey;


@ConfigKey(value = "ScopeMapping")
public class OihScopeMapping  extends ConfigEntity {

    private String scope;
    private List<MarketplaceMerchantIdPair> marketplaceMerchantIdPairs;
    private List<Long> iogs;
    private List<Long> marketplaces;

    private Long primaryIogId;
    private Long primaryMarketplaceId;

    private List<Long> disabledIogs;
    private List<Long> disabledMarketplaces;

    private String forecastGroup;

    @ID
    public String getScope() {
        return scope;
    }

    public void setScope(String scope) {
        this.scope = scope;
    }
    
    /**
     * get enabled IOGs in this scope
     * @return enabled IOGs in this scope
     */
    public List<Long> getIogs() {
        return iogs;
    }

    public void setIogs(List<Long> iogs) {
        this.iogs = new ArrayList<Long>(iogs);
    }
    
    /**
     * get enabled Marketplaces in this scope
     * @return enabled Marketplaces in this scope
     */
    public List<Long> getMarketplaces() {
        return marketplaces;
    }

    public void setMarketplaces(List<Long> marketplaces) {
        this.marketplaces = new ArrayList<Long>(marketplaces);
    }

    public Long getPrimaryIogId() {
        return primaryIogId;
    }

    public void setPrimaryIogId(Long primaryIogId) {
        this.primaryIogId = primaryIogId;
    }

    public Long getPrimaryMarketplaceId() {
        return primaryMarketplaceId;
    }

    public void setPrimaryMarketplaceId(Long primaryMarketplaceId) {
        this.primaryMarketplaceId = primaryMarketplaceId;
    }

    public List<Long> getDisabledIogs() {
        return disabledIogs;
    }

    public void setDisabledIogs(List<Long> disabledIogs) {
        this.disabledIogs = new ArrayList<Long>(disabledIogs);
    }

    public List<Long> getDisabledMarketplaces() {
        return disabledMarketplaces;
    }

    public void setDisabledMarketplaces(List<Long> disabledMarketplaces) {
        this.disabledMarketplaces = new ArrayList<Long>(disabledMarketplaces);
    }

    public String getForecastGroup() {
        return forecastGroup;
    }

    public void setForecastGroup(String forecastGroup) {
        this.forecastGroup = forecastGroup;
    }
    

    public List<MarketplaceMerchantIdPair> getMarketplaceMerchantIdPairs() {
        return marketplaceMerchantIdPairs;
    }

    public void setMarketplaceMerchantIdPairs(List<MarketplaceMerchantIdPair> marketplaceMerchantIdPairs) {
        this.marketplaceMerchantIdPairs = marketplaceMerchantIdPairs;
    }
    
    @Override
    public boolean equals(Object other){
        if( this == other){
            return true;
        }else if( other instanceof OihScopeMapping ){
            return this.equalsById((OihScopeMapping)other);
        }
        return false;
    }
    
    public String toString(){
        return String.format("OihScopeMapping{id= %s,primaryIogId=%d,primaryMarketplaceId=%d}", this.scope, this.primaryIogId, this.primaryMarketplaceId );
    }
}
