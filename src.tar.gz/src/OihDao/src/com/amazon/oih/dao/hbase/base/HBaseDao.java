package com.amazon.oih.dao.hbase.base;

import java.io.IOException;
import java.util.Collection;
import java.util.List;

public interface HBaseDao<T> {
    public void putSingleElement(T bObject) throws IOException;

    public void put(List<T> bObjects) throws IOException;

    public T get(String rowKey) throws IOException;

    public List<T> get(Collection<String> rowKeys) throws IOException;

    public boolean exist(String rowKey) throws IOException;

    public boolean exist(String rowKey, String qualifier) throws IOException;

    public void deleteRow(String rowKey) throws IOException;

    public void deleteRows(List<String> rowKeys) throws IOException;

    public void close() throws IOException;
}
