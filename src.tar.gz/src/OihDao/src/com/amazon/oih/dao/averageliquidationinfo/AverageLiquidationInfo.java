package com.amazon.oih.dao.averageliquidationinfo;

import java.io.Serializable;

public class AverageLiquidationInfo implements Serializable {
    private static final long serialVersionUID = -7904900120601804643L;
    private long runID;
    private int iog;
    private String country;
    private String gl;
    private String category;
    private String subCategory;
    private double rate;
    private String type;
    private String layer;
    private String rateFound;
    
    public int getIog() {
        return iog;
    }

    public void setIog(int iog) {
        this.iog = iog;
    }

    public String getGl() {
        return gl;
    }

    public void setGl(String gl) {
        this.gl = gl;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getSubCategory() {
        return subCategory;
    }

    public void setSubCategory(String subCategory) {
        this.subCategory = subCategory;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public double getRate() {
        return rate;
    }

    public void setRate(double rate) {
        this.rate = rate;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getRateFound() {
        return rateFound;
    }

    public void setRateFound(String rateFound) {
        this.rateFound = rateFound;
    }

    public long getRunID() {
        return runID;
    }

    public void setRunID(long runID) {
        this.runID = runID;
    }

    public String getLayer() {
        return layer;
    }

    public void setLayer(String layer) {
        this.layer = layer;
    }

    public boolean isValid() {
        return "Y".equalsIgnoreCase(rateFound);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(gl).append("|");
        sb.append(category).append("|");
        sb.append(subCategory).append("|");
        sb.append(rateFound).append("|");
        sb.append(type).append("|");
        sb.append(layer).append("|");
        sb.append(rate);
        return sb.toString();
    }    
}