package com.amazon.oih.dao.hbase.converter;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.beanutils.BeanUtilsBean;
import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.util.Bytes;

import com.amazon.oih.common.BeanUtilsFactory;
import com.amazon.oih.dao.hbase.base.HBaseDaoImplAdaptor;
import com.google.common.base.Joiner;

public class HBaseObjectDefaultConverter <T> implements IHBaseObjectConverter <T>{

    private static final String ROWKEY_SPLIT = ":";
    private static final String VALUE_SPLIT = ",";
    private BeanUtilsBean beanUtils = null;
    private static Map<Class<? extends Object>, List<String>> rowKeyFields = 
            new ConcurrentHashMap<Class<? extends Object>, List<String>>();
    private static Map<Class<? extends Object>, Map<String, List<String>>> valueFields = 
            new ConcurrentHashMap<Class<? extends Object>, Map<String, List<String>>>();
    
    public HBaseObjectDefaultConverter(){
        beanUtils = BeanUtilsFactory.getBeanUtils();
    }
    /**
     * convert the hbase result to hbase object
     * @param clazz
     * @param rowKey
     * @param rs
     * @return
     */
    public T convert(Class<T> clazz, String rowKey, Result rs){
    	Map<String, String> valueMap = HBaseDaoImplAdaptor.convertResult2KVMap(rs);
    	return convert(clazz, rowKey, valueMap);
    }
    
    public T convert(Class<T> clazz, String rowKey, Map<String, String> valueMap){
        if (valueMap == null || valueMap.isEmpty()) {
            return null;
        }

        T hBaseObj = null;
        try {
            hBaseObj = (T)clazz.newInstance();
            setRowKey(hBaseObj, rowKey);
            setValues(hBaseObj, valueMap);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        
        return hBaseObj;
    }
        
    private void setRowKey(T hBaseObj, String rowKey){
        List<String> rowKeyNames = getRowKeyFieldsByObj(hBaseObj.getClass());        
        setFieldValue(hBaseObj, rowKey, rowKeyNames, getRowKeySplit());
    }
    
    /**
     * Set field value by fieldName and a String which contains related fieldValues, split according to
     *  spliter
     * @param hBaseObj
     * @param valueStr
     * @param fieldNames
     * @param spliter
     */
    public void setFieldValue(T hBaseObj, String valueStr, List<String> fieldNames, String spliter){
        String[] rks = valueStr.split(spliter);
        
        try {
            int i = 0;
            for (String rkName : fieldNames){
                beanUtils.setProperty(hBaseObj, rkName, rks[i++]);
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    
    private void setValues(T hBaseObj, Map<String, String> valueMap){
        Map<String, List<String>> colNames = getValueFieldsByObj(hBaseObj.getClass());
        
        for (Map.Entry<String, String> kv : valueMap.entrySet()) {
            String colName = kv.getKey();
            List<String> fieldNames = colNames.get(colName);
           
            try {
                int i = 0;
                String str = kv.getValue();
                String[] values = str.split(getValueSplit());
                for (String fieldName : fieldNames){
                    if (i >= values.length){
                        beanUtils.setProperty(hBaseObj, fieldName, "");
                    }
                    else{
                        if (values[i].length() == 0 || values[i] == null){
                            beanUtils.setProperty(hBaseObj, fieldName, "");
                        }
                        else{
                            beanUtils.setProperty(hBaseObj, fieldName, values[i]);   
                        }
                    }
                    i++;
                }
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
    }
    
    /**
     * Convert hbase object to Put list
     * @param columnFamily
     * @param hBaseObj
     * @return
     */
    public List<Put> convert(String columnFamily, T hBaseObj){
        Map<String, String> colValueMap = getValues(hBaseObj);
        Set<String> keySet = colValueMap.keySet();
        Iterator<String> it = keySet.iterator();
        List<Put> puts = new ArrayList<Put>();
        while (it.hasNext()) {
            String key = (String) it.next();
            String value = colValueMap.get(key);
            Put put = new Put(Bytes.toBytes(getRowKey(hBaseObj)));
            put.add(Bytes.toBytes(columnFamily), Bytes.toBytes(key), Bytes.toBytes(value));
            puts.add(put);
        }
        return puts;
    }

    /**
     * Get row key by a obj, make sure the rowkey fields of Ojbect has been assigned value
     * @param hBaseObj
     * @return
     */
    public String getRowKey(T hBaseObj){
        List<String> rowKeyNames = getRowKeyFieldsByObj(hBaseObj.getClass());
        return getFieldValues(hBaseObj, rowKeyNames, getRowKeySplit());
    }
    
    public String getFieldValues(T hBaseObj, List<String> rowKeyNames, String spliter){
        String[] rowKey = new String[rowKeyNames.size()]; 

        try {
            int i = 0;
            for (String rkName : rowKeyNames){
                String rk = beanUtils.getProperty(hBaseObj, rkName);
                if (rk == null){
                    throw new RuntimeException(String.format("the element %s of row key cann't be null in Object %s",rkName, ReflectionToStringBuilder.toString(hBaseObj)));
                }
                else{
                    rowKey[i++] = rk;
                }
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        
        return Joiner.on(spliter).join(rowKey);
    }

    /**
     * row key splitor
     * @return
     */
    public static String getRowKeySplit(){
        return ROWKEY_SPLIT;
    }

    /**
     * value splitor
     * @return
     */
    public String getValueSplit(){
        return VALUE_SPLIT;
    }
    
    public Map<String, String> getValues(T hBaseObj){
        Map<String, List<String>> colNames = getValueFieldsByObj(hBaseObj.getClass());
        
        Map<String, String> values = new HashMap<String, String>();

        Iterator<String> colIter = colNames.keySet().iterator();
        while(colIter.hasNext()){
            String colName = colIter.next();
            values.put(colName, getValue(hBaseObj, colNames.get(colName)));
        }
        
        return values;
    }
    
    protected void getFields(Map<String, Field> fields, Class<? extends Object> clazz) {
        if (clazz == null ) {
            return;
        }
        
        for(Field field : clazz.getDeclaredFields()) {
            if (fields.containsKey(field.getName()) == false) {
                fields.put(field.getName(),  field);
            }
        }
        
        getFields(fields, clazz.getSuperclass());
    }
    
    private String getValue(T hBaseObj, List<String> fieldNames){
        String[] value = new String[fieldNames.size()]; 
        try {
            int i = 0;
            for (String fName : fieldNames){
                String v = beanUtils.getProperty(hBaseObj, fName);
                if (v == null){
                    value[i++] = "";
                }
                else{
                    value[i++] = v;
                }
                
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return Joiner.on(getValueSplit()).join(value);
    }
    
    private static List<String> getRowKeyFieldsByObj(Class<? extends Object> clazz){
        if (!rowKeyFields.containsKey(clazz)){
            if (clazz.isAnnotationPresent(RowKey.class)){
                RowKey rk = (RowKey)clazz.getAnnotation(RowKey.class);
                rowKeyFields.put(clazz, Arrays.asList(rk.value()));
            }
            else{
                List<String> empty = Collections.emptyList();
                rowKeyFields.put(clazz, empty);
            }
        }
        
        return rowKeyFields.get(clazz);
    }
    
    private Map<String, List<String>> getValueFieldsByObj(Class<? extends Object> clazz){
        if (valueFields.containsKey(clazz)){
            return valueFields.get(clazz);
        }
        Map<String, List<String>> colMap = new HashMap<String, List<String>>();
        Map<String, TreeMap<Integer, String>> colSortedBySeq = new HashMap<String, TreeMap<Integer, String>>();
        
        Map<String, Field> fsMap = new HashMap<String, Field>();
        getFields(fsMap, clazz);
        Field[] fs = fsMap.values().toArray(new Field[0]);
        for (Field f : fs){
           
            if(f.isAnnotationPresent(Column.class)){
                Column col = (Column)f.getAnnotation(Column.class);
                TreeMap<Integer, String> seqMap = null;
                if (colSortedBySeq.containsKey(col.name())){
                    seqMap = colSortedBySeq.get(col.name());
                }
                else{
                    seqMap = new TreeMap<Integer, String>();
                }
                seqMap.put(col.index(), f.getName());
                colSortedBySeq.put(col.name(), seqMap);
            }
        }
        
        Iterator<String> colIter = colSortedBySeq.keySet().iterator();
        while(colIter.hasNext()){
            List<String> fieldNames = new ArrayList<String>();
            String colName = colIter.next();
            Iterator<Integer> seqIter = colSortedBySeq.get(colName).keySet().iterator();
            while(seqIter.hasNext()){
                Integer seq = seqIter.next();
                String fieldName = colSortedBySeq.get(colName).get(seq);
                fieldNames.add(fieldName);
            }
            colMap.put(colName, fieldNames);
        }
        
        valueFields.put(clazz, colMap);
        return colMap;
    }
}
