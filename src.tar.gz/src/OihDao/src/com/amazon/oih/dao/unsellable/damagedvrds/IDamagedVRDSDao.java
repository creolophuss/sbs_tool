package com.amazon.oih.dao.unsellable.damagedvrds;

import java.util.List;

import com.amazon.carbonado.Repository;
import com.amazon.oih.dao.exception.OihPersistenceException;

public interface IDamagedVRDSDao {
    public void setRepository(Repository repository);

    public abstract void save(List<DamagedVRDSItem> items) throws OihPersistenceException;

    public abstract void save(DamagedVRDSItem item) throws OihPersistenceException;

    public abstract boolean exists(String fnsku, Integer iog) throws OihPersistenceException;

    public abstract List<DamagedVRDSItem> find(String fnsku, Integer iog) throws OihPersistenceException;

    public abstract List<DamagedVRDSItem> find(String fnsku, String fcsku, Integer iog, String warehouse, String condition) throws OihPersistenceException;

    public abstract DamagedVRDSItem createDamagedVRDSItem(OihVRDSItem item) throws OihPersistenceException;
}
