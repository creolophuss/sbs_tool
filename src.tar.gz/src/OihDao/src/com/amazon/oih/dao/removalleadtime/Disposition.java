package com.amazon.oih.dao.removalleadtime;

/**
 * 
 *
 */
public  enum Disposition{
    
	RETURN("RI"), LIQUIDATION("LI"), DESTROY_RETURN("DR"), DESTROY_LIQUIDATION("DL");
	
	private String dispositionCode;
	
	private Disposition(String dispositionCode){
	    this.dispositionCode = dispositionCode;
	}
	
    /**
     * used by hibernate to reconstruct an Disposition from the db
     * 
     * @param disposition
     * @return
     */
    public static Disposition fromString(String disposition) {
    	if (disposition == null)
    		return null;
        for (Disposition o : Disposition.values()) {
            if (o.toString().equals(disposition.trim()))
                return o;
        }
        return null;
    }
    
    public String getString() {
        return this.toString();
    }
    
    public static Disposition fromCode(String dispositionCode){
        for (Disposition o : Disposition.values()) {
            if (o.getDispositionCode().equals(dispositionCode))
                return o;
        }
        throw new IllegalArgumentException("Unkown dispositionCode: " + dispositionCode);        
    }
    
    public String getDispositionCode(){
        return this.dispositionCode;
    }
}
