package com.amazon.oih.dao;

import org.apache.log4j.Logger;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

/**
 * A hibernate util to handle session factory
 * 
 * @author river
 * 
 */
public class HibernateUtil {

    final static Logger log = Logger.getLogger(HibernateUtil.class);

    private static SessionFactory sessionFactory = null;

    /**
     * Build session factory
     * 
     * @return
     */
    private static SessionFactory buildSessionFactory() {
        try {
            log.info("Constructiong a session factory.");
            Configuration cfg = new Configuration();
            cfg.configure("hibernate.oih.cfg.xml");
            return cfg.buildSessionFactory();
        } catch (Throwable ex) {
            // Make sure you log the exception, as it might be swallowed
            System.err.println("Initial SessionFactory creation failed." + ex);
            log.error("Initial SessionFactory creation failed." + ex);
            throw new ExceptionInInitializerError(ex);
        }
    }

    /**
     * Get session factory
     * 
     * @return
     */
    public static SessionFactory getSessionFactory() {
        if (sessionFactory == null) {
            sessionFactory = buildSessionFactory();
        }
        return sessionFactory;
    }

    /**
     * This function is only resvered used for UT
     * 
     * @param sf
     */
    public static void setSessionFactory(SessionFactory sf) {
        sessionFactory = sf;
    }
}
