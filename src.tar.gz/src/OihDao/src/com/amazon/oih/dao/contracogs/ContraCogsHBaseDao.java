package com.amazon.oih.dao.contracogs;

import java.util.Date;

import com.amazon.oih.dao.hbase.base.SubKeyAwareHBaseDao;

public class ContraCogsHBaseDao extends SubKeyAwareHBaseDao<ContraCogs> {
    public ContraCogsHBaseDao() {
        super(ContraCogs.class);
    }

    public ContraCogsHBaseDao(String additionalId, String realm, Date rundate) {
        super(ContraCogs.class, additionalId, realm, rundate);
    }
}
