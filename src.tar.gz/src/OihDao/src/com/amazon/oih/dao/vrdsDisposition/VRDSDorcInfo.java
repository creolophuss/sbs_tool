package com.amazon.oih.dao.vrdsDisposition;

import java.util.Date;
import com.amazon.carbonado.Alias;
import com.amazon.carbonado.AlternateKeys;
import com.amazon.carbonado.Key;
import com.amazon.carbonado.PrimaryKey;
import com.amazon.carbonado.Sequence;
import com.amazon.carbonado.Storable;
import com.amazon.carbonado.constraint.IntegerConstraint;
import com.amazon.carbonado.constraint.LengthConstraint;
import com.amazon.carbonado.Nullable;

@Alias("data_dorc_info")
@PrimaryKey("id")
@AlternateKeys({
    @Key({
            "runID", "asin", "iog", "dsiId"
    })
})
public abstract class VRDSDorcInfo implements Storable<VRDSDorcInfo> {
    @Sequence("id")
    public abstract long getId();

    public abstract void setId(long id);

    @Alias("run_id")
    public abstract long getRunID();

    public abstract void setRunID(long runid);

    public abstract String getAsin();

    @LengthConstraint(min = 10, max = 10)
    public abstract void setAsin(String asin);

    public abstract int getIog();

    @IntegerConstraint(min = 1, max = Integer.MAX_VALUE)
    public abstract void setIog(int iog);

    public abstract int getMarketplaceId();

    @IntegerConstraint(min = 1, max = Integer.MAX_VALUE)
    public abstract void setMarketplaceId(int marketplaceId);

    public abstract int getGl();

    @IntegerConstraint(min = 0, max = Integer.MAX_VALUE)
    public abstract void setGl(int gl);

    @Nullable
    public abstract String getVendor();

    @LengthConstraint(min = 0, max = 5)
    public abstract void setVendor(String vendor);

    @Nullable
    public abstract String getDisposition();

    public abstract void setDisposition(String dispositionType);

    @Nullable
    public abstract String getWarehouse();

    @LengthConstraint(min = 0, max = 4)
    public abstract void setWarehouse(String warehouse);

    public abstract int getQtyAssigned();

    @IntegerConstraint(min = 0, max = Integer.MAX_VALUE)
    public abstract void setQtyAssigned(int qtyAssigned);

    @Nullable
    public abstract Long getOrderType();

    public abstract void setOrderType(Long orderType);

    @Nullable
    public abstract Long getDorcId();

    public abstract void setDorcId(Long dorcId);

    public abstract int getQtyReceived();

    @IntegerConstraint(min = 0, max = Integer.MAX_VALUE)
    public abstract void setQtyReceived(int qtyReceived);

    @Nullable
    public abstract Integer getQtyReturned();

    @IntegerConstraint(min = 0, max = Integer.MAX_VALUE)
    public abstract void setQtyReturned(Integer qtyReturned);

    @Nullable
    public abstract Integer getQtyInUse();

    @IntegerConstraint(min = 0, max = Integer.MAX_VALUE)
    public abstract void setQtyInUse(Integer qtyInUse);

    @Nullable
    public abstract Long getDsiId();

    public abstract void setDsiId(Long dsiId);

    @Nullable
    public abstract Double getDistributorCost();

    public abstract void setDistributorCost(Double cost);

    @Nullable
    public abstract String getBaseCurrencyCode();

    public abstract void setBaseCurrencyCode(String currencyCode);

    @Nullable
    public abstract Double getDistributorListPrice();

    public abstract void setDistributorListPrice(Double price);

    @Nullable
    public abstract String getDistributorOrderId();

    public abstract void setDistributorOrderId(String doId);

    @Nullable
    public abstract Date getDistributorOrderDate();

    public abstract void setDistributorOrderDate(Date doDate);

    @Nullable
    public abstract Date getShipmentReceivedDate();

    public abstract void setShipmentReceivedDate(Date doDate);

    @Nullable
    public abstract String getDistributorId();

    public abstract void setDistributorId(String distributorId);

    @Nullable
    public abstract String getDistributorShipmentId();

    public abstract void setDistributorShipmentId(String dsId);

    public abstract double getCost();

    public abstract void setCost(double cost);

    public abstract double getRefundAmount();

    public abstract void setRefundAmount(double refundAmount);
    
    @Nullable
    public abstract String getForeignCurrencyCode();
    
    public abstract void setForeignCurrencyCode(String ForeignCurrencyCode);
    
    public abstract double getCostForeignCurrency();
    
    public abstract void setCostForeignCurrency(double costForeignCurrency);
    
    public abstract double getRefundAmountForeignCurrency();
    
    public abstract void setRefundAmountForeignCurrency(double refundAmountForeignCurrency);

    public abstract double getDistributorCostForeignCurrency();
    
    public abstract void setDistributorCostForeignCurrency(double distributorCostForeignCurrency);
    
    public abstract double getDistributorListPriceForeignCurrency();
    
    public abstract void setDistributorListPriceForeignCurrency(double distributorListPriceForeignCurrency);
    
}
