package com.amazon.oih.dao.hbase.markdowninfo;

import java.io.IOException;
import java.util.Date;
import java.util.List;

import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.util.Bytes;

import amazon.platform.config.AppConfig;

import com.amazon.oih.dao.DaoConstants;
import com.amazon.oih.dao.hbase.base.AbstractHBaseDaoImpl;
import com.amazon.oih.dao.hbase.base.Converter;
import com.amazon.oih.dao.hbase.schema.HTableNameCFGeneratorImpl;
import com.amazon.oih.dao.markdowninfo.MarkdownInfo;

/**
 * 
 * @author xlpeng
 * 
 */
@Deprecated
public class MarkdownInfoHBaseDao extends AbstractHBaseDaoImpl<MarkdownInfo> {
    static final String columnDemandIncrease = "demandIncrease";
    static final byte[] columnDemandIncreaseBytes = Bytes.toBytes(columnDemandIncrease);
    static final String columnDemandIncreaseRate = "demandIncreaseRate";
    static final byte[] columnDemandIncreaseRateBytes = Bytes.toBytes(columnDemandIncreaseRate);
    static final String columnRecoveryRate = "recoveryRate";
    static final byte[] columnRecoveryRateBytes = Bytes.toBytes(columnRecoveryRate);
    static final String columnDataVersion = "dataVersion";
    static final byte[] columnDataVersionBytes = Bytes.toBytes(columnDataVersion);
    static final String columnDataLevel = "dataLevel";
    static final byte[] columnDataLevelBytes = Bytes.toBytes(columnDataLevel);
   
    static final String tableName = AppConfig.findString(DaoConstants.MARKDOWN_INFO_TABLENAME);
    static final String columnFamily = AppConfig.findString(DaoConstants.MARKDOWN_INFO_COLUMNFAMILY);
    static final byte[] columnFamilyBytes = Bytes.toBytes(columnFamily);
    Converter<MarkdownInfo> converter;
    
    public MarkdownInfoHBaseDao(Date rundate, String realm) {
        super(new HTableNameCFGeneratorImpl(tableName, columnFamily, realm, rundate), realm);
        converter = new MarkdownInfoConverter();
    }

    @Override
    public MarkdownInfo convert(String rowKey, Result rs) throws IOException {
        return converter.convert(rowKey, rs);
    }
    
    @Override
    protected List<Put> convert(MarkdownInfo markdownInfoObject) throws IOException {
        return converter.convert(markdownInfoObject);
    }
}
