package com.amazon.oih.dao.hbase.tax;

import java.io.Serializable;

import com.amazon.oih.common.RowKeyBuildType;
import com.amazon.oih.common.RowKeyType;
import com.amazon.oih.dao.hbase.base.CommonKVHBaseDao.HTable;
import com.amazon.oih.dao.hbase.converter.Column;
import com.amazon.oih.dao.hbase.converter.RowKey;

@RowKey({"asin", "scope"})
@RowKeyBuildType(RowKeyType.ASIN_SCOPE)
@HTable(value = "Tax", columFamilyName = "Tax")
public class Tax implements Serializable {
    private static final long serialVersionUID = -3489652705500662471L;
    
    private String asin = "0000000000";
    private String scope = "FAKE_SCOPE";
    
    @Column(name="t",index=0)
    private double taxRate = 0.0;

    public Tax(){
    }

    public Tax(String asin, String scope) {
        super();
        this.asin = asin;
        this.scope = scope;
    }

    public Tax(String asin, String scope, double taxRate) {
        super();
        this.asin = asin;
        this.scope = scope;
        this.taxRate = taxRate;
    }

    public String getAsin() {
        return asin;
    }

    public void setAsin(String asin) {
        this.asin = asin;
    }

    public double getTaxRate() {
        return taxRate;
    }

    public void setTaxRate(double taxRate) {
        this.taxRate = taxRate;
    }

    public String getScope() {
        return scope;
    }

    public void setScope(String scope) {
        this.scope = scope;
    }
}
