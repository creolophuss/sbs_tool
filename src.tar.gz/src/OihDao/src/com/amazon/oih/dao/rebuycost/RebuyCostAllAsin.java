 /**
  * Copyright (c) 2014 Amazon.com, Inc.  All rights reserved.
  * 
  * Owner: oih-cn@
  */
package com.amazon.oih.dao.rebuycost;

import com.amazon.oih.common.RowKeyBuildType;
import com.amazon.oih.common.RowKeyType;
import com.amazon.oih.common.KVFormater.FileColumnNames;
import com.amazon.oih.common.KeyValueBase.NamedValue;
import com.amazon.oih.dao.hbase.base.CommonKVHBaseDao.HTable;
import com.amazon.oih.dao.hbase.converter.Column;
import com.amazon.oih.dao.hbase.converter.RowKey;

/**
 * @author gaoxing
 *
 */
@RowKey({"asin", "iog"})
@RowKeyBuildType(RowKeyType.ASIN_IOG)
@HTable("RebuyCostAllAsin")
@FileColumnNames({"ASIN", "unit_cost", "Inventory Owner Group Id"})
public class RebuyCostAllAsin extends RebuyCost {
    private static final long serialVersionUID = 6792374407613909759L;
    @NamedValue("ASIN")
    private String asin;
    @NamedValue("Inventory Owner Group Id")
    private int iog;
    
    @NamedValue("unit_cost")
    @Column(name="cost",index=1)
    private double cost;

    /**
     * Keep this for common DAO init instance.
     */
    public RebuyCostAllAsin(){
    }

    public RebuyCostAllAsin(String asin, int iog, double rebuyCost){
        super(asin, iog, rebuyCost);
    }

    public String getAsin() {
        return asin;
    }

    public void setAsin(String asin) {
        this.asin = asin;
    }

    public int getIog() {
        return iog;
    }

    public void setIog(int iog) {
        this.iog = iog;
    }

    public double getCost() {
        return cost;
    }

    public void setCost(double cost) {
        this.cost = cost;
    }
}
