package com.amazon.oih.dao.apub;

import java.util.Collections;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.amazon.oih.dao.MySQLSessionFactoryUtil;
import com.amazon.oih.dao.exception.OihPersistenceException;

public class ApubAsinDaoImpl implements ApubAsinDao {

    private static Logger log = Logger.getLogger(ApubAsinDaoImpl.class);
    
    @SuppressWarnings("unchecked")
    @Override
    public List<ApubAsin> getApubAsins(Long runId) throws OihPersistenceException {
        Session session = null;
        try {
            session = openSession();
            List<ApubAsin> result = (List<ApubAsin>)session.getNamedQuery("ApubAsin.FindApubAsinsByRunId")
                    .setParameter("runId", runId).list();
            
            return result == null ? Collections.<ApubAsin>emptyList() : result;
        } catch (Exception e){
            throw new OihPersistenceException("Exception when query apub asin with runid " + runId, e);
        } finally {
            session.close();
        }
    }
    
    public void save(ApubAsin apubAsin) throws OihPersistenceException {
        Transaction tx = null;
        Session session = null;
        try {
            session = openSession();
            tx = session.beginTransaction();
            session.save(apubAsin);
            tx.commit();
        } catch (RuntimeException e) {
            log.error("Failed to save apubAsin " + apubAsin.getAsin() + " with exception ", e);
            e.printStackTrace();
            if (tx != null) {
                tx.rollback();
            }
            throw new OihPersistenceException(e);
        } finally {
            closeSession(session);
        }
    }
    
    private Session openSession() {
        return MySQLSessionFactoryUtil.getSessionFactory().openSession();
    }

    private void closeSession(Session session) {
        if (session != null) {
            session.close();
        }
    }
}

