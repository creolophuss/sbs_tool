package com.amazon.oih.dao.historicdemand;

import java.io.Serializable;

import com.amazon.oih.common.RowKeyBuildType;
import com.amazon.oih.common.RowKeyType;
import com.amazon.oih.common.KVFormater.FileColumnNames;
import com.amazon.oih.common.KeyValueBase.NamedValue;
import com.amazon.oih.dao.hbase.base.CommonKVHBaseDao.HTable;
import com.amazon.oih.dao.hbase.converter.Column;
import com.amazon.oih.dao.hbase.converter.RowKey;
/**
 * 
 * @author xlpeng
 *
 */
@RowKey({"asin", "marketplace"})
@RowKeyBuildType(RowKeyType.ASIN_MARKETPLACE)
@HTable("HistoricDemand")
@FileColumnNames({"ASIN", "marketplace", "one_week", "two_weeks", "three_weeks", "four_weeks", "one_year", "three_months", "to33_week"})
public class HistoricDemandRawData implements Serializable {
    private static final long serialVersionUID = 3895269417732202135L;
    @NamedValue("ASIN")
    private String asin;
    
    @NamedValue("marketplace")
    private long marketplace;
    
    @NamedValue("one_week")
    @Column(name="HD",index=0)
    private int firstWeek;
    
    @NamedValue("two_weeks")
    @Column(name="HD",index=1)
    private int secondWeek;
    
    @NamedValue("three_weeks")
    @Column(name="HD",index=2)
    private int thirdWeek;
    
    @NamedValue("four_weeks")
    @Column(name="HD",index=3)
    private int fourthWeek;
    
    @NamedValue("three_months")
    @Column(name="HD",index=4)
    private int threeMonths;    
    
    @NamedValue("one_year")
    @Column(name="HD",index=5)
    private int oneYear;
    
    @NamedValue("to33_week")
    @Column(name="HD",index=6)    
    private int to33week;
    

    public String getAsin() {
        return asin;
    }
    public void setAsin(String asin) {
        this.asin = asin;
    }
    public long getMarketplace() {
        return marketplace;
    }
    public void setMarketplace(long marketplace) {
        this.marketplace = marketplace;
    }
    public int getFirstWeek() {
        return firstWeek;
    }
    public void setFirstWeek(int firstWeek) {
        this.firstWeek = firstWeek;
    }
    public int getSecondWeek() {
        return secondWeek;
    }
    public void setSecondWeek(int secondWeek) {
        this.secondWeek = secondWeek;
    }
    public int getThirdWeek() {
        return thirdWeek;
    }
    public void setThirdWeek(int thirdWeek) {
        this.thirdWeek = thirdWeek;
    }
    public int getFourthWeek() {
        return fourthWeek;
    }
    public void setFourthWeek(int fourthWeek) {
        this.fourthWeek = fourthWeek;
    }
    public int getThreeMonths() {
        return threeMonths;
    }
    public void setThreeMonths(int threeMonths) {
        this.threeMonths = threeMonths;
    }
    public int getOneYear() {
        return oneYear;
    }
    public void setOneYear(int oneYear) {
        this.oneYear = oneYear;
    }
    
    public int getTo33week() {
        return to33week;
    }
    public void setTo33week(int to33week) {
        this.to33week = to33week;
    }
    
    
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((asin == null) ? 0 : asin.hashCode());
        result = prime * result + (int) (marketplace ^ (marketplace >>> 32));
        return result;
    }
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        HistoricDemandRawData other = (HistoricDemandRawData) obj;
        if (asin == null) {
            if (other.asin != null)
                return false;
        } else if (!asin.equals(other.asin))
            return false;
        if (marketplace != other.marketplace)
            return false;
        return true;
    }
}
