package com.amazon.oih.dao.hbase.schema;

public interface HTableNameCFGenerator {
    public String getTableName();
    public String getColumnFamily();
}
