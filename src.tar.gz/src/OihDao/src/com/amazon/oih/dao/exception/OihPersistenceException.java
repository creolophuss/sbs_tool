package com.amazon.oih.dao.exception;

public class OihPersistenceException extends Exception {
	static final long serialVersionUID = 1L;

	public OihPersistenceException(String message) {
		super(message);
	}

	public OihPersistenceException(Throwable cause) {
		super(cause);
	}

	public OihPersistenceException(String message, Throwable cause) {
		super(message, cause);
	}
}
