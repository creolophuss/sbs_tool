package com.amazon.oih.dao.scopemapping;

import java.util.ArrayList;
import java.util.List;

/**
 * helper class for OihScopeMapping operations
 */
public class OihScopeHelper {
    
    public static List<Long> findEnabledMarketplaceIdsForScope(OihScopeMapping scope){
        return scope.getMarketplaces();
    }
    
    public static List<Long> findEnabledIogIdsForScope(OihScopeMapping scope){
        return scope.getIogs();
    }
    
    public static boolean isIogEnaledInScope(Long iogId, OihScopeMapping scope){
        return scope.getIogs().contains(iogId);
    }    
    
    public static boolean isMarketplaceEnabledInScope(Long marketplaceId, OihScopeMapping scope){
        return scope.getMarketplaces().contains(marketplaceId);
    }
    
    public static boolean isIogInScope(Long iogId, OihScopeMapping scope){
        return scope.getIogs().contains(iogId) || scope.getDisabledIogs().contains(iogId);
    }
    
    public static boolean isMarketplaceInScope(Long marketplaceId, OihScopeMapping scope){
        return scope.getMarketplaces().contains(marketplaceId) || scope.getDisabledMarketplaces().contains(marketplaceId);
    }
    
    public static List<Long> findMerchantIdByMarketplaceIdInScope(Long marketplaceId, OihScopeMapping scope){
        List<Long> merchantIds = new ArrayList<Long>();
        if(scope.getMarketplaceMerchantIdPairs() != null){
            for( MarketplaceMerchantIdPair  p :  scope.getMarketplaceMerchantIdPairs()){
                if(p.getMarketplaceId() == marketplaceId ){
                    merchantIds.add(p.getMerchantId());
                }
            }
        }
        return merchantIds;
    }
}
