package com.amazon.oih.dao.abasics;

import java.io.Serializable;

public class ABasicsAsin implements Serializable {
    
    private static final long serialVersionUID = 4870231641517852562L;
    
    private Long runId;
    private String asin;
    private String org;
    private String type;
    
    public Long getRunId() {
        return runId;
    }
    public void setRunId(Long runId) {
        this.runId = runId;
    }
    public String getAsin() {
        return asin;
    }
    public void setAsin(String asin) {
        this.asin = asin;
    }
    public String getOrg() {
        return org;
    }
    public void setOrg(String org) {
        this.org = org;
    }
    public String getType() {
        return type;
    }
    public void setType(String type) {
        this.type = type;
    }
    public static long getSerialversionuid() {
        return serialVersionUID;
    }
    
    
}
