package com.amazon.oih.dao.historicdemand;

import java.util.Collection;

import javax.naming.NamingException;

import org.apache.log4j.Logger;

import com.amazon.carbonado.IsolationLevel;
import com.amazon.carbonado.PersistException;
import com.amazon.carbonado.Repository;
import com.amazon.carbonado.RepositoryException;
import com.amazon.carbonado.Storage;
import com.amazon.carbonado.SupportException;
import com.amazon.carbonado.Transaction;

public class HistoricDemandDaoImpl implements HistoricDemandDao{
    final static Logger _log = Logger.getLogger(HistoricDemandDaoImpl.class);
    protected String _domain = null;
    protected Repository repository = null;

    public HistoricDemandDaoImpl(String domain) {
        _domain = domain;
    }

    public void setRepository(Repository repository) {
        if (null == repository) {
            throw new IllegalArgumentException("repository cannot be null.");
        }
        this.repository = repository;
    }

    @Override
    public HistoricDemand createHistoricDemand(String asin,Long marketplace ,int one_week, int two_week, int three_week, int four_week, int three_month, int one_year) throws SupportException, RepositoryException{
        Storage<HistoricDemand> sf = repository.storageFor(HistoricDemand.class);
        HistoricDemand f = sf.prepare();
        f.setAsin(asin);
        f.setMarketplace(marketplace);
        f.setOneWeek(one_week);
        f.setTwoWeek(two_week);
        f.setThreeWeek(three_week);
        f.setFourWeek(four_week);
        f.setThreeMonths(three_month);
        f.setOneYear(one_year);
        return f;
    }

    @Override
    public void save(HistoricDemand o) throws PersistException {
        o.insert();
    }

    @Override
    public void save(Collection<HistoricDemand> o) throws PersistException {
        Transaction txn = repository.enterTransaction(IsolationLevel.READ_UNCOMMITTED);
        try {
            for (HistoricDemand f : o) {
                f.insert();
            }
            txn.commit();
        } catch (PersistException e) {
            throw e;
        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
            txn.exit();
        }
    }

    @Override
    public String toString() {
        StringBuilder r = new StringBuilder();
        r.append(this.getClass().getSimpleName()).append(": ").append("domain = ").append(_domain);
        return r.toString();
    }


	@Override
    public HistoricDemand find(String asin, Long marketplace)throws NamingException, RepositoryException, ClassNotFoundException {
	    Storage<HistoricDemand> sf = repository.storageFor(HistoricDemand.class);
	    HistoricDemand data = sf.query("asin = ? & marketplace = ? ").with(asin).with(marketplace).loadOne();

	    return data;
	}

	@Override
	public boolean exists(String asin, Long marketplace)throws NamingException, RepositoryException, ClassNotFoundException {
        boolean retVal = false;

        Storage<HistoricDemand> sf = repository.storageFor(HistoricDemand.class);
        retVal = sf.query("asin = ? & marketplace = ? ").with(asin).with(marketplace).exists();

        return retVal;
	}
}
