package com.amazon.oih.dao.hbase.schema;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;

import org.apache.commons.lang.StringUtils;

import amazon.rest.collections.Triple;

public class HTableNamer {

    private static final String TABLENAME_SPLIT = "_";
    protected static final SimpleDateFormat SIMPLE_DATE_FORMAT = new SimpleDateFormat("yyyyMMdd");

    public String generateName(String inputName, String realm, Date rundate) {
        return StringUtils.join(Arrays.asList(inputName, realm, SIMPLE_DATE_FORMAT.format(rundate)), TABLENAME_SPLIT);
    }

    public Triple<String, String, Date> parseName(String tableName) throws ParseException {
        String[] tokens = StringUtils.split(tableName, TABLENAME_SPLIT);
        if (tokens.length < 3) {
            throw new ParseException("Irregular table name :" + tableName, 0);
        }
        String rundate = tokens[tokens.length - 1];
        String realm = tokens[tokens.length - 2];
        String inputName = tableName.substring(0, tableName.length() - rundate.length() - realm.length()
                - TABLENAME_SPLIT.length() * 2);
        return new Triple<String, String, Date>(inputName, realm, SIMPLE_DATE_FORMAT.parse(rundate));
    }
}