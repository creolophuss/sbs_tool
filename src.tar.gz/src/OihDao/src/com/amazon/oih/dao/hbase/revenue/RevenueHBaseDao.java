package com.amazon.oih.dao.hbase.revenue;

import java.io.IOException;
import java.util.Collections;
import java.util.List;

import org.apache.hadoop.hbase.KeyValue;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.util.Bytes;
import org.apache.log4j.Logger;

import com.amazon.oih.dao.hbase.base.AbstractHBaseDaoImpl;
import com.amazon.oih.utils.HBaseRowkeyUtil;
import com.amazon.oih.utils.RevenueHBaseTableUtil;

/**
 * 
 * @author mengzang
 * 
 */
public class RevenueHBaseDao extends AbstractHBaseDaoImpl<AsinRevenueData> {

    private static Logger logger = Logger.getLogger(RevenueHBaseDao.class);

    public final static String columnFamily = "Revenue";
    public final static byte[] columnFamilyBytes = Bytes.toBytes(columnFamily);

    public final static String columnData = "data";
    public final static byte[] columnDataBytes = Bytes.toBytes(columnData);
    public final static String columnCost = "cost";
    public final static byte[] columnCostBytes = Bytes.toBytes(columnCost);
    public final static String columnOurPrice = "ourPrice";
    public final static byte[] columnOurPriceBytes = Bytes.toBytes(columnOurPrice);

    public RevenueHBaseDao(String tableName, String realm) {
        super(tableName, columnFamily, realm, RevenueHBaseTableUtil.RevenueTableSourceIdentity);
    }

    public RevenueHBaseDao() {
    }

    @Override
    protected AsinRevenueData convert(String rowKey, Result rs) throws IOException {
        return convertResult2AsinRevenue(rowKey, rs);
    }

    public static AsinRevenueData convertResult2AsinRevenue(String rowKey, Result rs) {
        if (rs == null || rs.isEmpty()) {
            return null;
        }
        AsinRevenueData asinRevenueData = HBaseRowkeyUtil.parseAsinRevenueDatakey(rowKey);

        for (KeyValue kv : rs.raw()) {
            byte[] columnBytes = kv.getQualifier();
            String value = new String(kv.getValue());

            if (Bytes.compareTo(columnDataBytes, columnBytes) == 0) {
                asinRevenueData.setInventory2RevenueMapByString(value);
            } else if (Bytes.compareTo(columnCostBytes, columnBytes) == 0) {
                asinRevenueData.setCost(RevenueHBaseTableUtil.getDoubleValueFromString(value));
            } else if (Bytes.compareTo(columnOurPriceBytes, columnBytes) == 0) {
                asinRevenueData.setOurPrice(RevenueHBaseTableUtil.getDoubleValueFromString(value));
            } else {
                logger.error("Unkown HBase column:" + new String(columnBytes) + ", value is:" + value);
            }
        }
        return asinRevenueData;
    }

    @Override
    protected List<Put> convert(AsinRevenueData bObject) throws IOException {
        String rowKey = HBaseRowkeyUtil.getRowKeyForAsinRevenueData(bObject);

        String revenueData = bObject.getInventory2RevenueMapOfStringFormat();
        String costStr = bObject.getCost() == null ? "" : bObject.getCost().toString();
        String ourPriceStr = bObject.getOurPrice() == null ? "" : bObject.getOurPrice().toString();

        Put put = new Put(Bytes.toBytes(rowKey));
        put.add(columnFamilyBytes, columnDataBytes, Bytes.toBytes(revenueData));
        put.add(columnFamilyBytes, columnCostBytes, Bytes.toBytes(costStr));
        put.add(columnFamilyBytes, columnOurPriceBytes, Bytes.toBytes(ourPriceStr));
        return Collections.nCopies(1, put);
    }
}
