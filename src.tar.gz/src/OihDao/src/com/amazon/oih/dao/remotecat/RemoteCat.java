package com.amazon.oih.dao.remotecat;

import java.io.Serializable;
import java.util.Date;

import com.amazon.oih.common.RowKeyBuildType;
import com.amazon.oih.common.RowKeyType;

import com.amazon.oih.dao.hbase.base.CommonKVHBaseDao.HTable;
import com.amazon.oih.dao.hbase.converter.Column;
import com.amazon.oih.dao.hbase.converter.RowKey;
import com.amazon.oih.dao.hbase.converter.SubKey;

@RowKey({"asin", "marketplace"})
@RowKeyBuildType(RowKeyType.ASIN_MARKETPLACE)
@SubKey({"merchant"})
@HTable(value = "RemoteCat", columFamilyName = "RemoteCat")
public class RemoteCat implements Serializable {
    private static final long serialVersionUID = 947074284369862245L;
    private long runId = 0;
    private String asin = "0000000000";
    private int iog = 1;
    private long marketplace = 1;
    private long merchant = 1;
    
    @Column(name="rc",index=0)
    private int gl = 0;
    @Column(name="rc",index=1)
    private int category = 0;
    @Column(name="rc",index=2)
    private int subCategory = 0;
    @Column(name="rc",index=3)
    private String title = "";
    @Column(name="rc",index=4)
    private double ourPrice = 0.0;
    @Column(name="rc",index=5)
    private Date publicationDate = null;
    @Column(name="rc",index=6)
    private Date releaseDate = null;
    @Column(name="rc",index=7)
    private String upc = "";
    @Column(name="rc",index=8)
    private boolean unPrepRequired = false;
    @Column(name="rc",index=9)
    private String ean = "";
    @Column(name="rc",index=10)
    private String publisherCode = "null";
    @Column(name="rc",index=11)
    private double mapPrice = 0.0;
    @Column(name="rc",index=12)
    private String mapRequired = "N";
    @Column(name="rc",index=13)
    private double listPrice = 0.0;
    @Column(name="rc",index=14)
    private String parentAsin = "unknown";
    @Column(name="rc",index=15)
    private String replenishmentCategory = "Unknown";
    @Column(name="rc",index=16)
    private String hazmatTransportationRegularClass = "";
    @Column(name="rc",index=17)
    private String hazmatException = "";
    @Column(name="rc",index=18)
    private String hazmatItem = "";
    @Column(name="rc",index=19)
    private String textbookType = "";
    @Column(name="rc",index=20)
    private String mapStrict = "N";
    @Column(name="rc",index=21)
    private Date mapEndDate = null;
    @Column(name="rc",index=22)
    private Date siteLaunchDate = null;
    @Column(name="rc",index=23)
    private String brandCode = "";
    @Column(name="rc",index=24)
    private String brandName = "";
    @Column(name="rc",index=25)
    private String binding = "";
    @Column(name="rc",index=26)
    private String seasons = "";
    @Column(name="rc",index=27)
    private String modelNumber = "";
    @Column(name="rc",index=28)
    private String sourceCountryCode = "";
    @Column(name="rc",index=29)
    private double mapStrictPrice = 0.0;
    @Column(name="rc",index=30)
    private int modelYear = 0;
    @Column(name="rc",index=31)
    private String format = "";
    @Column(name="rc",index=32)
    private String restrictedPriceDiscountCountry = "";
    @Column(name="rc",index=33)
    private String availability = "";
    @Column(name="rc",index=34)
    private String retailOffer = "N";
    // Shelf Life
    @Column(name="rc",index=35)
    private int fcShelfLife = -1;
    @Column(name="rc",index=36)
    private int fcShelfLifePadTime = -1;
    @Column(name="rc",index=37)
    private int fcShelfLifePadTime2Q = -1; //for warehouse deal
    
    // Fields only used by OIH Workflow
    @Column(name="rc",index=38)
    private String manufacturer = "";
    
    public RemoteCat(){
    }
    
    public RemoteCat(String asin, long marketplace, long merchant){
        this.asin = asin;
        this.marketplace = marketplace;
        this.merchant = merchant;
    }

    public RemoteCat(long runId, RemoteCatValueObject valueObject){
        this.setRunId(runId);
        this.setAsin(valueObject.getAsin());
        this.setMarketplace(valueObject.getMarketplace());
        this.setMerchant(valueObject.getMerchant());
        this.setBinding(valueObject.getBinding());
        this.setBrandName(valueObject.getBrandName());
        this.setBrandCode(valueObject.getBrandCode());
        this.setCategory(valueObject.getCategory());
        this.setEan(valueObject.getEan());
        this.setGl(valueObject.getGl());
        this.setHazmatException(valueObject.getHazmatException());
        this.setHazmatItem(valueObject.isHazmatItem());
        this.setHazmatTransportationRegularClass(valueObject.getHazmatTransportationRegularClass());
        this.setMapRequired(valueObject.getMapRequired());
        this.setUnPrepRequired(valueObject.isUnPrepRequired());
        this.setListPrice(valueObject.getListPrice());
        this.setMapEndDate(valueObject.getMapEndDate());
        this.setMapPrice(valueObject.getMapPrice());
        this.setMapStrict(valueObject.getMapStrict());
        this.setMapStrictPrice(valueObject.getMapStrictPrice());
        this.setModelNumber(valueObject.getModelNumber());
        this.setOurPrice(valueObject.getOurPrice());
        this.setParentAsin(valueObject.getParentAsin());
        this.setPublicationDate(valueObject.getPublicationDate());
        this.setPublisherCode(valueObject.getPublisherCode());
        this.setReleaseDate(valueObject.getReleaseDate());
        this.setReplenishmentCategory(valueObject.getReplenishmentCategory());
        this.setSeasons(valueObject.getSeasons());
        this.setSiteLaunchDate(valueObject.getSiteLaunchDate());
        this.setSourceCountryCode(valueObject.getSourceCountryCode());
        this.setSubCategory(valueObject.getSubCategory());
        this.setTextbookType(valueObject.getTextbookType());
        this.setTitle(valueObject.getTitle());
        this.setUpc(valueObject.getUpc());
        this.setModelYear(valueObject.getModelYear());
        this.setFormat(valueObject.getFormat());
        this.setRestrictedPriceDiscountCountry(valueObject.getRestrictedPriceDiscountCountry());
        this.setAvailability(valueObject.getAvailability());
        this.setRetailOffer(valueObject.getRetailOffer());

        //don't like this way, should use bean copy
        this.setFcShelfLife(valueObject.getFcShelfLife());
        this.setFcShelfLifePadTime(valueObject.getFcShelfLifePadTime());
        this.setFcShelfLifePadTime2Q(valueObject.getFcShelfLifePadTime2Q());
        
        this.setManufacturer(valueObject.getManufacturer());
    }
    public long getRunId() {
        return runId;
    }
    public void setRunId(long runId) {
        this.runId = runId;
    }
    public String getAsin() {
        return asin;
    }
    public void setAsin(String asin) {
        this.asin = asin;
    }
    public int getIog() {
        return iog;
    }
    public void setIog(int iog) {
        this.iog = iog;
    }
    public long getMarketplace() {
        return marketplace;
    }
    public void setMarketplace(long marketplace) {
        this.marketplace = marketplace;
    }
    public long getMerchant() {
        return merchant;
    }
    public void setMerchant(long merchant) {
        this.merchant = merchant;
    }
    public int getGl() {
        return gl;
    }
    public void setGl(int gl) {
        this.gl = gl;
    }
    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    public double getOurPrice() {
        return ourPrice;
    }
    public void setOurPrice(double ourPrice) {
        this.ourPrice = ourPrice;
    }
    public Date getPublicationDate() {
        return publicationDate;
    }
    public void setPublicationDate(Date publicationDate) {
        this.publicationDate = publicationDate;
    }
    public Date getReleaseDate() {
        return releaseDate;
    }
    public void setReleaseDate(Date releaseDate) {
        this.releaseDate = releaseDate;
    }
    public String getUpc() {
        return upc;
    }
    public void setUpc(String upc) {
        this.upc = upc;
    }
    public boolean isUnPrepRequired() {
        return unPrepRequired;
    }
    public void setUnPrepRequired(boolean unPrepRequired) {
        this.unPrepRequired = unPrepRequired;
    }
    public int getCategory() {
        return category;
    }
    public void setCategory(int category) {
        this.category = category;
    }
    public int getSubCategory() {
        return subCategory;
    }
    public void setSubCategory(int subCategory) {
        this.subCategory = subCategory;
    }
    public String getEan() {
        return ean;
    }
    public void setEan(String ean) {
        this.ean = ean;
    }
    public String getPublisherCode() {
        return publisherCode;
    }
    public void setPublisherCode(String publisherCode) {
        this.publisherCode = publisherCode;
    }
    public double getMapPrice() {
        return mapPrice;
    }
    public void setMapPrice(double mapPrice) {
        this.mapPrice = mapPrice;
    }
    public String getMapRequired() {
        return mapRequired;
    }
    public void setMapRequired(String mapRequired) {
        this.mapRequired = mapRequired;
    }
    public double getListPrice() {
        return listPrice;
    }
    public void setListPrice(double listPrice) {
        this.listPrice = listPrice;
    }
    public String getParentAsin() {
        return parentAsin;
    }
    public void setParentAsin(String parentAsin) {
        this.parentAsin = parentAsin;
    }
    public String getReplenishmentCategory() {
        return replenishmentCategory;
    }
    public void setReplenishmentCategory(String replenishmentCategory) {
        this.replenishmentCategory = replenishmentCategory;
    }
    public String getHazmatTransportationRegularClass() {
        return hazmatTransportationRegularClass;
    }
    public void setHazmatTransportationRegularClass(String hazmatTransportationRegularClass) {
        this.hazmatTransportationRegularClass = hazmatTransportationRegularClass;
    }
    public String getHazmatException() {
        return hazmatException;
    }
    public void setHazmatException(String hazmatException) {
        this.hazmatException = hazmatException;
    }
    public String getHazmatItem() {
        return hazmatItem;
    }
    public void setHazmatItem(String hazmatItem) {
        this.hazmatItem = hazmatItem;
    }
    public String getTextbookType() {
        return textbookType;
    }
    public void setTextbookType(String textbookType) {
        this.textbookType = textbookType;
    }
    public String getMapStrict() {
        return mapStrict;
    }
    public void setMapStrict(String mapStrict) {
        this.mapStrict = mapStrict;
    }
    public Date getMapEndDate() {
        return mapEndDate;
    }
    public void setMapEndDate(Date mapEndDate) {
        this.mapEndDate = mapEndDate;
    }
    public Date getSiteLaunchDate() {
        return siteLaunchDate;
    }
    public void setSiteLaunchDate(Date siteLaunchDate) {
        this.siteLaunchDate = siteLaunchDate;
    }
    public String getBrandCode() {
        return brandCode;
    }
    public void setBrandCode(String brandCode) {
        this.brandCode = brandCode;
    }
    public String getBrandName() {
        return brandName;
    }
    public void setBrandName(String brandName) {
        this.brandName = brandName;
    }
    public String getBinding() {
        return binding;
    }
    public void setBinding(String binding) {
        this.binding = binding;
    }
    public String getSeasons() {
        return seasons;
    }
    public void setSeasons(String seasons) {
        this.seasons = seasons;
    }
    public String getModelNumber() {
        return modelNumber;
    }
    public void setModelNumber(String modelNumber) {
        this.modelNumber = modelNumber;
    }
    public String getSourceCountryCode() {
        return sourceCountryCode;
    }
    public void setSourceCountryCode(String sourceCountryCode) {
        this.sourceCountryCode = sourceCountryCode;
    }
    public double getMapStrictPrice() {
        return mapStrictPrice;
    }
    public void setMapStrictPrice(double mapStrictPrice) {
        this.mapStrictPrice = mapStrictPrice;
    }
    public int getModelYear() {
        return modelYear;
    }
    public void setModelYear(int modelYear) {
        this.modelYear = modelYear;
    }
    public String getFormat() {
        return format;
    }
    public void setFormat(String format) {
        this.format = format;
    }
    public String getRestrictedPriceDiscountCountry() {
        return restrictedPriceDiscountCountry;
    }
    public void setRestrictedPriceDiscountCountry(String restrictedPriceDiscountCountry) {
        this.restrictedPriceDiscountCountry = restrictedPriceDiscountCountry;
    }
    public String getAvailability() {
        return availability;
    }
    public void setAvailability(String availability) {
        this.availability = availability;
    }
    public String getRetailOffer() {
        return retailOffer;
    }
    public void setRetailOffer(String retailOffer) {
        this.retailOffer = retailOffer;
    }

    //Shelf Life
    public int getFcShelfLife() {
        return fcShelfLife;
    }

    public void setFcShelfLife(int fcShelfLife) {
        this.fcShelfLife = fcShelfLife;
    }

    public int getFcShelfLifePadTime() {
        return fcShelfLifePadTime;
    }

    public void setFcShelfLifePadTime(int fcShelfLifePadTime) {
        this.fcShelfLifePadTime = fcShelfLifePadTime;
    }

    public int getFcShelfLifePadTime2Q() {
        return fcShelfLifePadTime2Q;
    }

    public void setFcShelfLifePadTime2Q(int fcShelfLifePadTime2Q) {
        this.fcShelfLifePadTime2Q = fcShelfLifePadTime2Q;
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }

}
