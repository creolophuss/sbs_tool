package com.amazon.oih.dao.g2s2;

import java.util.List;

import org.codehaus.jackson.type.TypeReference;

import amazon.iop.metadata.g2s2.client.G2S2Exception;

public interface G2S2AppConfigsReadonlyDao {
    /**
     * Retrieve app config from g2s2, will ignore cache, and use defalut relam and domain that found in AppConfig.
     * @param key
     *            the key for app config item
     * @param clazz
     *            Class that app config will be convert to.
     * @return app config stored in g2s2 with parameter key
     */
    <T> T getAppConfig(String key, Class<? extends T> clazz);

    /**
     * 
     * Retrieve app config from g2s2, will ignore cache, and use defalut domain that found in AppConfig.
     * 
     * @param key
     *            the key for app config item
     * @param clazz
     *            Class that app config will be convert to.
     * @param realm
     *            realm that the app config is bound to.
     * @return app config stored in g2s2 with parameter key
     */
    <T> T getAppConfig(String key, Class<? extends T> clazz, String realm);

    /**
     * 
     * Retrieve app config from g2s2, ignore cache.
     * 
     * @param key
     *            the key for app config item
     * @param clazz
     *            Class that app config will be convert to.
     * @param realm
     *            realm that the app config is bound to.
     * @param domain
     *            domain that the app config is bound to.
     * @return the app config stored in g2s2 with provided key
     */
    <T> T getAppConfig(String key, Class<? extends T> clazz, String realm, String domain);

    /**
     * 
     * Retrieve app config from g2s2.
     * @param key
     *            the key for app config item
     * @param clazz
     *            Class that app config will be convert to.
     * @param realm
     *            realm that the app config is bound to.
     * @param domain
     *            realm that the app config is bound to.
     * @param ignoreCache
     *            will ignore cache if assigned as true
     * @return the app config content stored in g2s2 with provided key.
     */
    <T> T getAppConfig(String key, Class<? extends T> clazz, String realm, String domain, boolean ignoreCache);

    /**
     * Retrieve app config from g2s2. Config key must be assigned by annotation ConfigKey on class.
     * 
     * @param clazz
     *            type of app config with ConfigKey annotation
     * @param realm
     *            realm that the app config is bound to.
     * @param domain
     *            domain that the app config is bound to.
     * @param ignoreCache
     *            will ignore cache if assigned as true
     * @return the app config stored in g2s2 with provided key
     */
    <T> T getAppConfig(Class<? extends T> clazz, String realm, String domain, boolean ignoreCache);

    /**
     * get app config as List, if app config content is not list type, will return a list containing the app config
     * content as only one element. if app config content is list type, the method will map the app config content to
     * List directly. realm and domain for the app config both use default value that stored in g2s2Configurations.
     * 
     * @param key
     *            the key for app config.
     * @param clazz
     *            type for elements of result list.
     * @return app config stored in g2s2 with provided key
     */
    <T> List<T> getAppConfigList(String key, Class<? extends T> clazz);

    /**
     * get app config as List, if app config content is not list type, will return a list containing the app config
     * content as only one element. if app config content is list type, the method will map the app config content to
     * List directly. realm for the app config use default value that stored in g2s2Configurations.
     * 
     * @param key
     *            the key for app config.
     * @param clazz
     *            clazz type for elements of result list.
     * @param realm
     *            realm that the app config is bound to.
     * @return app config stored in g2s2 with provided key
     */
    <T> List<T> getAppConfigList(String key, Class<? extends T> clazz, String realm);

    /**
     * get app config as List, if app config content is not list type, will return a list containing the app config
     * content as only one element. if app config content is list type, the method will map the app config content to
     * List directly.
     * 
     * @param key
     *            the key for app config.
     * @param clazz
     *            clazz type for elements of result list.
     * @param realm
     *            realm that the app config is bound to.
     * @param domain
     *            domain that the app config is bound to.
     * @return app config stored in g2s2 with provided key
     */
    <T> List<T> getAppConfigList(String key, Class<? extends T> clazz, String realm, String domain);

    /**
     * get app config as List, if app config content is not list type, will return a list containing the app config
     * content as only one element. if app config content is list type, the method will map the app config content to
     * List directly.
     * 
     * @param key
     *            the key for app config.
     * @param clazz
     *            class type for elements of result list.
     * @param realm
     *            realm that the app config is bound to.
     * @param domain
     *            domain that the app config is bound to.
     * @param ignoreCache
     *            will ignore cache if assigned as true
     * @return app config stored in g2s2 with provided key
     */
    <T> List<T> getAppConfigList(String key, Class<? extends T> clazz, String realm, String domain, boolean ignoreCache);

    /**
     * get app config as List, if app config content is not list type, will return a list containing the app config
     * content as only one element. if app config content is list type, the method will map the app config content to
     * List directly.
     * 
     * @param clazz
     *            class type with ConfigKey annotation for elements of result list.
     * @param realm
     *            realm that the app config is bound to.
     * @param domain
     *            domain that the app config is bound to.
     * @param ignoreCache
     *            will ignore cache if assigned as true
     * @return app config as List
     */
    <T> List<T> getAppConfigList(Class<? extends T> clazz, String realm, String domain, boolean ignoreCache);

    /**
     * find latest stage version
     * 
     * @param ignoreCache
     *            will ignore cache if assigned as true
     * @return the latest stage version
     */
    String findLatestStageVersionFromG2S2(boolean ignoreCache);

    /**
     * query all app configs related to the given app config key. including the app config content bounded to every
     * domain and realm
     * 
     * @param appConfigKey
     *            app config key that you want to query
     * @param clazz
     *            type for the app config content
     * @return all app configs related to appConfigKey as List
     */
    <T> List<AppConfigInfo<T>> queryAppConfig(String appConfigKey, Class<? extends T> clazz);

    /**
     * query all app configs related to the given app config key. including the app config content bounded to every
     * domain and realm
     * 
     * @param appConfigKey
     *            app config key that you want to query
     * @param typeReference
     *            type reference for the app config content that can contain generic type as new TypeReference&lt;List&lt;OihScopeMapping&gt;&gt;
     * @return all app configs related to appConfigKey as List
     */
    <T> List<AppConfigInfo<T>> queryAppConfig(String key, TypeReference<T> typeReference);

    /**
     * Flush the g2s2 client's cache.
     */
    public void flushCache() throws G2S2Exception;

}
