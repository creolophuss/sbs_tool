package com.amazon.oih.dao.shipcosts;

import com.amazon.oih.dao.hbase.base.HBaseSaveableObject;
import com.google.common.collect.HashBasedTable;
import com.google.common.collect.Table;


public class AsinShipoutCostInfo extends HBaseSaveableObject<AsinShipoutCostInfoHBaseObject>{

    private String asin;
    private String scopeId;
    
    private Table<Double, String, Double> costTable;
    
    public AsinShipoutCostInfo() {
        costTable = HashBasedTable.<Double, String, Double>create();
    }
    
    public void addCost(Double weight, String warehouse, Double cost) {
        costTable.put(weight, warehouse, cost);
    }

    public String getAsin() {
        return asin;
    }

    public void setAsin(String asin) {
        this.asin = asin;
    }

    public String getScopeId() {
        return scopeId;
    }

    public void setScopeId(String scopeId) {
        this.scopeId = scopeId;
    }
    
    public  Table<Double, String, Double> getCostTable() {
        return costTable;
    }

    @Override
    public AsinShipoutCostInfoHBaseObject toHBaseObject() {
        return AsinShipoutCostInfoEncoder.asinShipCostInfotoHBaseObject(this);
    }
}
