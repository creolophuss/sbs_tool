package com.amazon.oih.dao.hbase.cbm;

import java.io.IOException;
import java.util.Collection;
import java.util.List;

import com.amazon.oih.cbm.model.AsinMarketplace;
import com.amazon.oih.cbm.model.CalendarMarkdownHistoricDemand;




public interface ICalendarMarkdownHistoricDemandDao{
	public List<CalendarMarkdownHistoricDemand> getHistormicDemand(List<? extends AsinMarketplace> items)  throws IOException ;
	public void save(List<CalendarMarkdownHistoricDemand> demands) throws IOException;
}
