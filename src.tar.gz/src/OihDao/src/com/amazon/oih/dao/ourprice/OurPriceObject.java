package com.amazon.oih.dao.ourprice;

import java.util.Date;

import amazon.platform.config.AppConfig;

import com.amazon.oih.dao.OihObject;
import com.amazon.oih.dao.hbase.ourprice.OurpriceHbaseObject;

/**
 * This is the our price object for Hibernate
 * 
 * @author zhongwei
 * 
 */
public class OurPriceObject extends OihObject {
	private double ourPrice;
    private String realm;

	public double getOurPrice() {
		return ourPrice;
	}

	public void setOurPrice(double ourPrice) {
		this.ourPrice = ourPrice;
	}

	public OurPriceObject() {
	}

	public OurPriceObject(String asin, int iog, String source, double ourPrice,
			Date runDate) {
		super(asin, iog, source, runDate);
		this.ourPrice = ourPrice;
        setRealm(AppConfig.getRealm().name());
	}

	public OurpriceHbaseObject toHBaseFormat(){
		OurpriceHbaseObject result = new OurpriceHbaseObject(getAsin(), getIog(), ourPrice);
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (obj instanceof OurPriceObject == false) {
			return false;
		}
		if (this == obj) {
			return true;
		}

		OurPriceObject other = (OurPriceObject) obj;
		return super.equals(obj) && this.getRealm().equals(other.getRealm())
		        && Math.abs(this.ourPrice - other.getOurPrice()) < 1e-6;
	}

	@Override
	public void cleanValues() {
		this.ourPrice = 0;
	}

	@Override
	public void copyValues(Object obj) {
		if (obj == null || obj instanceof OurPriceObject == false) {
			throw new RuntimeException("Wrong instance type.");
		}
		OurPriceObject other = (OurPriceObject) obj;
		this.ourPrice = other.getOurPrice();
	}

	@Override
	public String getKey() {
		return this.getAsin() + "|" + this.getIog() + "|" + this.getRealm();
	}

	@Override
	public String getValues() {
		return String.valueOf(ourPrice);
	}

	@Override
	public int hashCode() {
		return getKey().hashCode();
	}

    public void setRealm(String realm) {
        this.realm = realm;
    }

    public String getRealm() {
        return realm;
    }
}
