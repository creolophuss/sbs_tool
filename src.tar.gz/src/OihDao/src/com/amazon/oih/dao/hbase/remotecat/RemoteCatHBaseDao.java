package com.amazon.oih.dao.hbase.remotecat;

import java.io.IOException;
import java.util.Date;
import java.util.List;

import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.client.Result;

import amazon.platform.config.AppConfig;

import com.amazon.oih.dao.DaoConstants;
import com.amazon.oih.dao.hbase.base.AbstractHBaseDaoImpl;
import com.amazon.oih.dao.hbase.base.Converter;
import com.amazon.oih.dao.hbase.schema.HTableNameCFGeneratorImpl;
import com.amazon.oih.dao.remotecat.RemoteCat;
import com.amazon.oih.utils.TimerHelper;

@Deprecated
public class RemoteCatHBaseDao extends AbstractHBaseDaoImpl<RemoteCat> {

    private Converter<RemoteCat> converter = new RemoteCatConverter();
    private final static String REMOTECAT_TABLENAME = AppConfig.findString(DaoConstants.REMOTECAT_TABLENAME);
    private final static String REMOTECAT_COLUMNFAMILY = AppConfig.findString(DaoConstants.REMOTECAT_COLUMNFAMILY);
    
    public RemoteCatHBaseDao(Date rundate, String realm) {
        super(new HTableNameCFGeneratorImpl(REMOTECAT_TABLENAME, REMOTECAT_COLUMNFAMILY, realm, rundate), realm);
    }

    @Override
    protected RemoteCat convert(String rowKey, Result rs) throws IOException {
        long start = System.currentTimeMillis();
        RemoteCat ret = converter.convert(rowKey, rs);
        TimerHelper.getInstance().addPhase("RemoteCatHBaseDao#convertToRemoteCat", start);
        return ret;
    }

    @Override
    protected List<Put> convert(RemoteCat bObject) throws IOException {
        long start = System.currentTimeMillis();
        List<Put> ret = converter.convert(bObject);
        TimerHelper.getInstance().addPhase("RemoteCatHBaseDao#convertToPut", start);
        return ret;
    }
}
