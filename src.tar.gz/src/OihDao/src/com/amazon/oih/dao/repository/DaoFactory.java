package com.amazon.oih.dao.repository;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import amazon.platform.config.AppConfig;

import com.amazon.carbonado.Repository;
import com.amazon.oih.cbm.model.CalendarMarkdownRemoteCat;
import com.amazon.oih.common.Identifiable;
import com.amazon.oih.common.KVDao;
import com.amazon.oih.costs.VendorFCs;
import com.amazon.oih.costs.VendorFCsDaoImpl;
import com.amazon.oih.dao.DaoConstants;
import com.amazon.oih.dao.OihDao;
import com.amazon.oih.dao.OihObject;
import com.amazon.oih.dao.SessionFactoryManager;
import com.amazon.oih.dao.apub.ApubAsinDao;
import com.amazon.oih.dao.apub.ApubAsinDaoImpl;
import com.amazon.oih.dao.averageliquidationinfo.AverageLiquidationInfoDao;
import com.amazon.oih.dao.averageliquidationinfo.AverageLiquidationInfoDaoImpl;
import com.amazon.oih.dao.contracogs.ContraCogsHBaseDao;
import com.amazon.oih.dao.experiments.Experiment;
import com.amazon.oih.dao.experiments.ExperimentDao;
import com.amazon.oih.dao.experiments.ExperimentDaoImpl;
import com.amazon.oih.dao.experiments.Treatment;
import com.amazon.oih.dao.experiments.TreatmentDao;
import com.amazon.oih.dao.experiments.TreatmentDaoImpl;
import com.amazon.oih.dao.forecast.ForecastDao;
import com.amazon.oih.dao.forecast.ForecastObject;
import com.amazon.oih.dao.forecast34to52.Forecast34To52;
import com.amazon.oih.dao.forecast34to52.Forecast34To52Dao;
import com.amazon.oih.dao.forecast34to52.Forecast34To52DaoImpl;
import com.amazon.oih.dao.forecastnew.ForecastNewBDBObject;
import com.amazon.oih.dao.forecastnew.ForecastNewDao;
import com.amazon.oih.dao.forecastnew.ForecastNewDaoBase;
import com.amazon.oih.dao.forecastnew.ForecastNewDaoOracleImp;
import com.amazon.oih.dao.hbase.adjustedrol.AdjustedMaxROL;
import com.amazon.oih.dao.hbase.axforecast.AxForecastObject;
import com.amazon.oih.dao.hbase.base.CommonKVHBaseDao;
import com.amazon.oih.dao.hbase.base.HBaseDaoImplAdaptor;
import com.amazon.oih.dao.hbase.base.SubKeyAwareHBaseDao;
import com.amazon.oih.dao.hbase.cbm.CalendarMarkdownHistoricDemandHBaseDao;
import com.amazon.oih.dao.hbase.cbm.ICalendarMarkdownHistoricDemandDao;
import com.amazon.oih.dao.hbase.civ.CIVInfoHbaseDao;
import com.amazon.oih.dao.hbase.forecast.AnnoForecastHBaseObj;
import com.amazon.oih.dao.hbase.markdownhitfloor.MarkdownHitFloorInfo;
import com.amazon.oih.dao.hbase.markdowninfo.MarkdownInfoHBaseDaoWrapper;
import com.amazon.oih.dao.hbase.ourprice.OurpriceHbaseObject;
import com.amazon.oih.dao.hbase.procurability.ProcurabilityHbaseDao;
import com.amazon.oih.dao.hbase.quantitybasedmarkdowninfo.QuantityBasedMarkdownInfoHBaseDao;
import com.amazon.oih.dao.hbase.quantitybasedmarkdowninfo.QuantityBasedMarkdownInfoHBaseDaoWrapper;
import com.amazon.oih.dao.hbase.remotecat.RemoteCatHBaseDaoWrapper;
import com.amazon.oih.dao.hbase.revenue.RevenueHBaseDao;
import com.amazon.oih.dao.hbase.sokoban.SokobanFasFactor;
import com.amazon.oih.dao.hbase.tax.Tax;
import com.amazon.oih.dao.hbase.vendor.Vendor;
import com.amazon.oih.dao.hbase.vendor.VendorRejection;
import com.amazon.oih.dao.hbase.vrds.VRDSFcskuInfo;
import com.amazon.oih.dao.hbase.vrds.VRDSFcskuInfoHbaseDao;
import com.amazon.oih.dao.hbase.vrds.VRDSHBaseDorcInfo;
import com.amazon.oih.dao.hbase.vrds.VRDSHBaseReturnTerm;
import com.amazon.oih.dao.historicdemand.HistoricDemandHbaseDao;
import com.amazon.oih.dao.holdingcost.HoldingCost;
import com.amazon.oih.dao.holdingcost.HoldingCostDao;
import com.amazon.oih.dao.holdingcost.HoldingCostDaoImpl;
import com.amazon.oih.dao.ilbo.IlboObject;
import com.amazon.oih.dao.inventorysourcingcost.InventorySourcingCostDao;
import com.amazon.oih.dao.inventorysourcingcost.InventorySourcingCostDaoImpl;
import com.amazon.oih.dao.markdowninfo.IMarkdownInfoDao;
import com.amazon.oih.dao.markdowninfo.MarkdownForecastDao;
import com.amazon.oih.dao.markdowninfo.MarkdownForecastDaoImpl;
import com.amazon.oih.dao.markdowninfo.MarkdownInfo;
import com.amazon.oih.dao.markdowninfo.MarkdownInfoBDBObject;
import com.amazon.oih.dao.markdowninfo.MarkdownInfoDao;
import com.amazon.oih.dao.miscAsin.MiscAsinDao;
import com.amazon.oih.dao.miscAsin.MiscAsinDaoImpl;
import com.amazon.oih.dao.ourprice.OurPriceDao;
import com.amazon.oih.dao.ourprice.OurPriceObject;
import com.amazon.oih.dao.quantitymarkdowninfo.IQuantityBasedMarkdownInfoDao;
import com.amazon.oih.dao.rebuycost.RebuyCost;
import com.amazon.oih.dao.recall.IRecallDao;
import com.amazon.oih.dao.recall.RecallDao;
import com.amazon.oih.dao.recall.RecallObject;
import com.amazon.oih.dao.remotecat.IRemoteCatDao;
import com.amazon.oih.dao.remotecat.RemoteCat;
import com.amazon.oih.dao.removalleadtime.RemoveLeadTimeDao;
import com.amazon.oih.dao.removalleadtime.RemoveLeadTimeDaoImpl;
import com.amazon.oih.dao.run.Run;
import com.amazon.oih.dao.run.RunDao;
import com.amazon.oih.dao.run.RunDaoBase;
import com.amazon.oih.dao.targetInvLevel.TargetInventoryLevelDao;
import com.amazon.oih.dao.targetInvLevel.TargetInventoryLevelDaoImpl;
import com.amazon.oih.dao.targetInvLevel.TargetInventoryLevelMaxOverPeriodDao;
import com.amazon.oih.dao.targetInvLevel.TargetInventoryLevelMaxOverPeriodDaoImpl;
import com.amazon.oih.dao.targetInvLevel.TargetInventoryLevelScope;
import com.amazon.oih.dao.targetInvLevel.TargetInventoryLevelScopeDao;
import com.amazon.oih.dao.targetInvLevel.TargetInventoryLevelScopeDaoImpl;
import com.amazon.oih.dao.transportationcost.TransportationCostDao;
import com.amazon.oih.dao.transportationcost.TransportationCostDaoImpl;
import com.amazon.oih.dao.unhealthyasin.UnhealthyAsinDetailDaoImpl;
import com.amazon.oih.dao.unhealthyasin.UnhealthyAsinDetailsDao;
import com.amazon.oih.dao.unsellable.damagedremotecat.DamagedRemoteCatDao;
import com.amazon.oih.dao.unsellable.damagedremotecat.DamagedRemoteCatObject;
import com.amazon.oih.dao.unsellable.damagedremotecat.IDamagedRemoteCatDao;
import com.amazon.oih.dao.unsellable.damagedvrds.DamagedVRDSDao;
import com.amazon.oih.dao.unsellable.damagedvrds.DamagedVRDSItem;
import com.amazon.oih.dao.unsellable.damagedvrds.IDamagedVRDSDao;
import com.amazon.oih.dao.unsellable.inventorycandidate.InventoryCandidateComposite;
import com.amazon.oih.dao.unsellable.inventorycandidate.InventoryCandidateCompositeDao;
import com.amazon.oih.dao.unsellable.inventorycandidate.InventoryCandidateCompositeDaoImpl;
import com.amazon.oih.dao.vendorleadtime.VendorLeadTimeDao;
import com.amazon.oih.dao.vendorleadtime.VendorLeadTimeDaoImpl;
import com.amazon.oih.dao.vrdsDisposition.VRDSDorcInfo;
import com.amazon.oih.dao.vrdsDisposition.VRDSDorcInfoDao;
import com.amazon.oih.dao.vrdsDisposition.VRDSDorcInfoDaoImpl;
import com.amazon.oih.dao.vrdsDisposition.VRDSReturnTerms;
import com.amazon.oih.dao.vrdsDisposition.VRDSReturnTermsDao;
import com.amazon.oih.dao.vrdsDisposition.VRDSReturnTermsDaoImpl;
import com.amazon.oih.utils.DaoUtil;
import com.amazon.oih.utils.HBaseUtil;
import com.amazon.oih.utils.RevenueHBaseTableUtil;
import com.google.common.collect.HashBiMap;

public class DaoFactory {
    private final static Map<Class<? extends OihObject>, DaoType> CLASS_TO_ENUM = new HashMap<Class<? extends OihObject>, DaoType>();
    private final static HashBiMap<Class<? extends Identifiable>, KVDaoProvider> CLASS_TO_PROVIDER = HashBiMap.create();;
    static {
        CLASS_TO_ENUM.put(OurPriceObject.class, DaoType.OUR_PRICE_DAO);
        CLASS_TO_ENUM.put(ForecastObject.class, DaoType.FORECAST_DAO);
        CLASS_TO_ENUM.put(IlboObject.class, DaoType.ILBO_DAO);

        CLASS_TO_PROVIDER.put(VendorFCs.class, KVDaoProvider.VENDOR_FCS);
        CLASS_TO_PROVIDER.put(HoldingCost.class, KVDaoProvider.MONTHLY_HOLDINGCOST);
    }

    private DaoFactory() {

    }

    @SuppressWarnings("unchecked")
    public static <T extends OihObject> OihDao<T> getDao(Class<T> objectType, String domain) {
        return (OihDao<T>) CLASS_TO_ENUM.get(objectType).getDao(domain);
    }

    public static OurPriceDao getOurPriceDao(String domain) {
        return new OurPriceDao(domain);
    }

    public static ForecastDao getForecast(String domain) {
        return new ForecastDao(domain);
    }

    public static ForecastNewDao getForecastNewOracleDao(String domain) {
        if (RepositoryFactory.UNIT_TEST.equalsIgnoreCase(domain)) {
            return DaoUtil.getForecastNewDao4UnitTest();
        }
        return new ForecastNewDaoOracleImp(domain);
    }

    public static RunDao getRunDao(String domain) {
        Repository p = RepositoryFactory.getInst().getRepository(Run.class, domain);
        RunDaoBase dao = new RunDaoBase(domain);
        dao.setRepository(p);
        return dao;
    }

    public static ForecastNewDao getForecastNewBDBDao(String domain) {
        Repository p = RepositoryFactory.getInst().getRepository(ForecastNewBDBObject.class, domain);
        ForecastNewDaoBase dao = new ForecastNewDaoBase(domain);
        dao.setRepository(p);
        return dao;
    }

    public static Forecast34To52Dao getForecast34To52Dao(String domain) {
        Repository p = RepositoryFactory.getInst().getRepository(Forecast34To52.class, domain);
        Forecast34To52DaoImpl dao = new Forecast34To52DaoImpl(domain);
        dao.setRepository(p);
        return dao;
    }

    public static AverageLiquidationInfoDao getAverageLiquidationInfoDao(String domain) {
        if (RepositoryFactory.UNIT_TEST.equalsIgnoreCase(domain)) {
            return DaoUtil.getAverageLiquidationInfoDao4UnitTest();
        }
        return new AverageLiquidationInfoDaoImpl(domain);
    }

    public static ApubAsinDao getApubAsinDao(String domain) {
        if (RepositoryFactory.UNIT_TEST.equalsIgnoreCase(domain)) {
            DaoUtil.getApubAsinDao4UnitTest();
        }

        return new ApubAsinDaoImpl();
    }

    public static MiscAsinDao getMiscAsinDao(String domain) {
        if (RepositoryFactory.UNIT_TEST.equalsIgnoreCase(domain)) {
            return DaoUtil.getMiscAsinDao4UnitTest();
        }
        return new MiscAsinDaoImpl(domain);
    }

    public static MarkdownForecastDao getMarkdownForecastDao(String domain) {
        if (RepositoryFactory.UNIT_TEST.equalsIgnoreCase(domain)) {
            return DaoUtil.getMarkdownForecast4UnitTest();
        }
        return new MarkdownForecastDaoImpl(domain);
    }

    public static VendorLeadTimeDao getVendorLeadTimeDao(String domain) {
        if (RepositoryFactory.UNIT_TEST.equalsIgnoreCase(domain)) {
            return DaoUtil.getVendorLeadTime4UnitTest();
        }
        return new VendorLeadTimeDaoImpl(domain);
    }

    public static RemoveLeadTimeDao getRemoveLeadTimeDao(String domain) {
        if (RepositoryFactory.UNIT_TEST.equalsIgnoreCase(domain)) {
            return DaoUtil.getRemovalLeadTime4UnitTest();
        }
        return new RemoveLeadTimeDaoImpl(domain);
    }

    public static TargetInventoryLevelDao getTargetInventoryLevelDao(String domain) {
        if (RepositoryFactory.UNIT_TEST.equalsIgnoreCase(domain)) {
            return DaoUtil.getTargetInventoryLevelDao4UnitTest();
        }
        return new TargetInventoryLevelDaoImpl(domain);
    }

    public static TargetInventoryLevelScopeDao getTargetInventoryLevelScopeDao(String domain) {
        if (RepositoryFactory.UNIT_TEST.equalsIgnoreCase(domain)) {
            return DaoUtil.getTargetInventoryLevelScopeDao4UnitTest();
        }
        return new TargetInventoryLevelScopeDaoImpl(domain);
    }

    public static TargetInventoryLevelMaxOverPeriodDao getTargetInventoryLevelMaxOverPeriodDao(String domain) {
        if (RepositoryFactory.UNIT_TEST.equalsIgnoreCase(domain)) {
            return DaoUtil.getLegacyTargetInventoryLevelDao4UnitTest();
        }
        return new TargetInventoryLevelMaxOverPeriodDaoImpl(domain);
    }

    public static ExperimentDao getExperimentDao(String domain) {
        Repository p = RepositoryFactory.getInst().getRepository(Experiment.class, domain);
        ExperimentDaoImpl dao = new ExperimentDaoImpl(domain);
        dao.setRepository(p);
        return dao;
    }

    public static TreatmentDao getTreatmentDao(String domain) {
        Repository p = RepositoryFactory.getInst().getRepository(Treatment.class, domain);
        TreatmentDaoImpl dao = new TreatmentDaoImpl(domain);
        dao.setRepository(p);
        return dao;
    }

    public static VRDSDorcInfoDao getVRDSDorcInfoDao(String domain) {
        Repository p = RepositoryFactory.getInst().getRepository(VRDSDorcInfo.class, domain);
        VRDSDorcInfoDaoImpl dao = new VRDSDorcInfoDaoImpl(domain);
        dao.setRepository(p);
        return dao;
    }

    public static VRDSReturnTermsDao getVRDSReturnTermsDao(String domain) {
        Repository p = RepositoryFactory.getInst().getRepository(VRDSReturnTerms.class, domain);
        VRDSReturnTermsDaoImpl dao = new VRDSReturnTermsDaoImpl(domain);
        dao.setRepository(p);
        return dao;
    }

    public static InventoryCandidateCompositeDao getInventoryCandidateCompositeDao(String domain) {
        Repository p = RepositoryFactory.getInst().getRepository(InventoryCandidateComposite.class, domain);
        InventoryCandidateCompositeDao dao = new InventoryCandidateCompositeDaoImpl(domain);
        dao.setRepository(p);
        return dao;
    }

    public static IDamagedVRDSDao getDamagedVRDSDao(String domain) {
        Repository p = RepositoryFactory.getInst().getRepository(DamagedVRDSItem.class, domain);
        IDamagedVRDSDao dao = new DamagedVRDSDao(domain);
        dao.setRepository(p);
        return dao;
    }

    public static HistoricDemandHbaseDao getHistoricDemandDao(Date runDate, String realm) {
        return new HistoricDemandHbaseDao("", realm, runDate);
    }
    
    public static CIVInfoHbaseDao getCIVInfoHbaseDao(Date runDate, String realm){
        return new CIVInfoHbaseDao("", realm, runDate);
    }

    public static IMarkdownInfoDao getMarkdownInfoDao(Run run, String domain) {
        return getMarkdownInfoDao(run.getRunDate().toDate(), domain);
    }

    public static IMarkdownInfoDao getMarkdownInfoDao(Date offsetRundate, String domain) {
        if (HBaseUtil.isUseHBase(DaoConstants.MARKDOWN_INFO)) {
            HBaseDaoImplAdaptor<MarkdownInfo> markdownInfoHBaseDao = new CommonKVHBaseDao<MarkdownInfo>(
                    MarkdownInfo.class, "", AppConfig.getRealm().name(), offsetRundate);
            return new MarkdownInfoHBaseDaoWrapper(markdownInfoHBaseDao);
        } else {
            Repository p = RepositoryFactory.getInst().getRepository(MarkdownInfoBDBObject.class, domain);
            IMarkdownInfoDao dao = new MarkdownInfoDao(domain);
            dao.setRepository(p);
            return dao;
        }
    }
    
    public static IQuantityBasedMarkdownInfoDao getQuantityBasedMarkdownInfoDao(Run run, String domain) {
        return getQuantityBasedMarkdownInfoDao(run.getRunDate().toDate(), domain);
    }
    
    public static IQuantityBasedMarkdownInfoDao getQuantityBasedMarkdownInfoDao(Date offsetRundate, String domain) {
    	QuantityBasedMarkdownInfoHBaseDao markdownInfoHBaseDao = new QuantityBasedMarkdownInfoHBaseDao(offsetRundate, AppConfig.getRealm().name());
        return new QuantityBasedMarkdownInfoHBaseDaoWrapper(markdownInfoHBaseDao);
    }

    public static IRemoteCatDao getRemoteCatDao(Date runDate, String domain) {
        HBaseDaoImplAdaptor<List<RemoteCat>> remoteCatHBaseDao = new SubKeyAwareHBaseDao<RemoteCat>(RemoteCat.class,
                "", AppConfig.getRealm().name(), runDate);
        return new RemoteCatHBaseDaoWrapper(remoteCatHBaseDao);
    }

    public static CommonKVHBaseDao<CalendarMarkdownRemoteCat> getCalendarMarkdownRemoteCatDao(Date runDate,
            String domain) {
        return new CommonKVHBaseDao<CalendarMarkdownRemoteCat>(CalendarMarkdownRemoteCat.class, "", AppConfig
                .getRealm().name(), runDate, true);
    }

    public static ICalendarMarkdownHistoricDemandDao getCalendarMarkdownHistoricDemandDao(Date runDate, String domain) {
    	return new CalendarMarkdownHistoricDemandHBaseDao(runDate, AppConfig.getRealm().name());
    }

    public static IDamagedRemoteCatDao getDamagedRemoteCatDao(String domain) {
        Repository p = RepositoryFactory.getInst().getRepository(DamagedRemoteCatObject.class, domain);
        IDamagedRemoteCatDao dao = new DamagedRemoteCatDao(domain);
        dao.setRepository(p);
        return dao;
    }

    public static IRecallDao getRecallDao(String domain) {
        Repository p = RepositoryFactory.getInst().getRepository(RecallObject.class, domain);
        IRecallDao dao = new RecallDao();
        dao.setRepository(p);
        return dao;
    }
    
    public static HBaseDaoImplAdaptor<AdjustedMaxROL> getAdjustedMaxROLHBaseDao(Date rundate, String realm) {
        return new CommonKVHBaseDao<AdjustedMaxROL>(AdjustedMaxROL.class, "", realm, rundate);
    }
    
    public static HBaseDaoImplAdaptor<AxForecastObject> getAxForecastHBaseDao(Date rundate, String realm) {
        return new CommonKVHBaseDao<AxForecastObject>(AxForecastObject.class, "", realm, rundate);
    }

    public static SubKeyAwareHBaseDao<AnnoForecastHBaseObj> getForecastHBaseDao(Date rundate, String realm) {
        return new SubKeyAwareHBaseDao<AnnoForecastHBaseObj>(AnnoForecastHBaseObj.class, "", realm, rundate);
    }

    public static HBaseDaoImplAdaptor<OurpriceHbaseObject> getOurpriceHBaseDao(String realm, Date runDate) {
        return new CommonKVHBaseDao<OurpriceHbaseObject>(OurpriceHbaseObject.class, "", realm, runDate);
    }

    public static HBaseDaoImplAdaptor<List<VRDSHBaseDorcInfo>> getVRDSHBaseDorcInfoDao(Date rundate, String realm) {
        return new SubKeyAwareHBaseDao<VRDSHBaseDorcInfo>(VRDSHBaseDorcInfo.class, "", realm, rundate);
    }

    public static HBaseDaoImplAdaptor<List<VRDSHBaseReturnTerm>> getVRDSHBaseReturnTermDao(Date rundate, String realm) {
        return new SubKeyAwareHBaseDao<VRDSHBaseReturnTerm>(VRDSHBaseReturnTerm.class, "", realm, rundate);
    }
    
    public static HBaseDaoImplAdaptor<List<VRDSFcskuInfo>> getVRDSHBaseFcskuInfoDao(Date rundate, String realm) {
        return new VRDSFcskuInfoHbaseDao("", realm, rundate);
    }
        
    public static HBaseDaoImplAdaptor<List<Vendor>> getVendorDao(Date rundate, String realm) {
        return new SubKeyAwareHBaseDao<Vendor>(Vendor.class, "", realm, rundate);
    }
    
    public static HBaseDaoImplAdaptor<List<SokobanFasFactor>> getSokobanFasFactorDao(Date rundate, String realm) {
        return new SubKeyAwareHBaseDao<SokobanFasFactor>(SokobanFasFactor.class, "", realm, rundate);
    }
    
    public static HBaseDaoImplAdaptor<VendorRejection> getVendorRejectedDao(Date rundate, String realm) {
        return new CommonKVHBaseDao<VendorRejection>(VendorRejection.class, "", realm, rundate);
    }
    
    public static HBaseDaoImplAdaptor<TargetInventoryLevelScope> getTargetInventoryLevelInfoHBaseDao(Date rundate, String realm) {
        return new CommonKVHBaseDao<TargetInventoryLevelScope>(TargetInventoryLevelScope.class, "", realm, rundate);
    }
    
    public static HBaseDaoImplAdaptor<MarkdownHitFloorInfo> getMarkdownHitFloorInfoHBaseDao(Date rundate, String realm){
        return new CommonKVHBaseDao<MarkdownHitFloorInfo>(MarkdownHitFloorInfo.class, "", realm, rundate);
    }

    public static ProcurabilityHbaseDao getProcurabilityHbaseDao(Date rundate, String realm) {
        return new ProcurabilityHbaseDao("", realm, rundate);
    }    

    public static RevenueHBaseDao getAsinRevenueDataHBaseDao(String realm, Date runDate) {
        RevenueHBaseDao dao = new RevenueHBaseDao(RevenueHBaseTableUtil.getAsinRevenueTableNameForDate(realm, runDate),
                realm);
        return dao;
    }
    
    public static ContraCogsHBaseDao getContraCogsDao(Date rundate, String realm) {
        return new ContraCogsHBaseDao("", realm, rundate);
    }

    public static InventorySourcingCostDao getInventorySourcingCostDao(String domain) {
        if (RepositoryFactory.UNIT_TEST.equalsIgnoreCase(domain)) {
            return DaoUtil.getInventorySourcingCostDao4UnitTest();
        }
        return new InventorySourcingCostDaoImpl(domain);
    }

    public static HBaseDaoImplAdaptor<Tax>  getTaxDao(Date runDate, String realm) {
        return new CommonKVHBaseDao<Tax>(Tax.class, "", realm, runDate);
    }

    public static UnhealthyAsinDetailsDao getUnhealthyAsinDetailsDao() {
        return new UnhealthyAsinDetailDaoImpl();
    }

    public static HoldingCostDao getHoldingCostDao() {
        return new HoldingCostDaoImpl();
    }

    public static TransportationCostDao getTransportationCostDao() {
        return new TransportationCostDaoImpl();
    }

    public static HBaseDaoImplAdaptor<RebuyCost> getRebuyCostHbaseDao(Date rundate, String realm) {
        return new CommonKVHBaseDao<RebuyCost>(RebuyCost.class, "", realm, rundate);
    }

    @SuppressWarnings("unchecked")
    public static <T extends Identifiable> KVDao<T> getKVDao(Class<T> classObj) {
        KVDao<T> dao = (KVDao<T>) CLASS_TO_PROVIDER.get(classObj).getDao();
        return dao;
    }

    public static Class<? extends Identifiable> getBeanClass(String name) {
        KVDaoProvider provider = null;
        try {
            provider = KVDaoProvider.valueOf(name);
        } catch (Exception e) {
            return null;
        }
        return CLASS_TO_PROVIDER.inverse().get(provider);
    }

    /**
     * Use this builder to make indirect creation of KVDao, so that to realize lazy init.
     * 
     * @author jialei
     * 
     */
    private static enum KVDaoProvider {
        MONTHLY_HOLDINGCOST {
            @Override
            KVDao<?> initDao() {
                return new HoldingCostDaoImpl();
            }
        },
        VENDOR_FCS {
            @Override
            KVDao<?> initDao() {
                return new VendorFCsDaoImpl(SessionFactoryManager.getVendorFlexSessionFactoryInstance());
            }
        };

        private KVDao<?> dao = null;

        synchronized public KVDao<?> getDao() {
            if (dao == null) {
                dao = initDao();
            }
            return dao;
        }

        abstract KVDao<?> initDao();
    }
}
