package com.amazon.oih.dao.vendorleadtime;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;

import com.amazon.oih.dao.MySQLSessionFactoryUtil;
import com.amazon.oih.dao.exception.OihPersistenceException;

public class VendorLeadTimeDaoImpl implements VendorLeadTimeDao {
    private final static Logger logger = Logger.getLogger(VendorLeadTimeDaoImpl.class);
    protected Session session = null;
    private static double DEFAULT_VENDOR_LEAD_TIME = 7;

    public VendorLeadTimeDaoImpl(String domain) {
    }

    @Override
    public VendorLeadTime createInstance(long runID, String vendor, long merchantId, int gl , double averageVlt) {
        return new VendorLeadTime(runID, vendor, merchantId, gl, averageVlt);
    }

    @Override
    public boolean exists(Long runId, String vendor, long merchantId, int gl) throws OihPersistenceException {
        logger.debug("Query VendorLeadTime by " + vendor + "|" + merchantId + "|" + runId);
        try {
            openSession();
            Criteria cri = session.createCriteria(VendorLeadTime.class);
            cri.add(Restrictions.eq("vendor", vendor));
            cri.add(Restrictions.eq("merchantId", merchantId));
            cri.add(Restrictions.eq("runID", runId));
            cri.add(Restrictions.eq("gl", gl));
            return cri.uniqueResult() != null;
        } catch (HibernateException e) {
            e.printStackTrace();
            logger.error("Fail to query TargetInventoryLevel " + e);
            throw new OihPersistenceException(e);
        }
    }

    @Override
    public VendorLeadTime find(Long runId, String vendor, long merchantId, int gl) throws OihPersistenceException {
        logger.debug("Query VendorLeadTime by " + vendor + "|" + merchantId + "|" + runId);
        try {
            openSession();
            Criteria cri = session.createCriteria(VendorLeadTime.class);
            cri.add(Restrictions.eq("vendor", vendor));
            cri.add(Restrictions.eq("merchantId", merchantId));
            cri.add(Restrictions.eq("runID", runId));
            cri.add(Restrictions.eq("gl", gl));
            if (cri.uniqueResult()!= null)
                return (VendorLeadTime) cri.uniqueResult();
            else
            	return createInstance( runId, vendor, merchantId,  gl, DEFAULT_VENDOR_LEAD_TIME); 
        } catch (HibernateException e) {
            e.printStackTrace();
            logger.error("Fail to query TargetInventoryLevel " + e);
            throw new OihPersistenceException(e);
        }
    }

    @Override
    public void save(List<VendorLeadTime> tils) throws OihPersistenceException {
        Transaction tx = null;
        try {
            openSession();
            tx = session.beginTransaction();
            for (VendorLeadTime o : tils) {
                session.save(o);
            }
            tx.commit();
        } catch (RuntimeException e) {
            logger.error("Failed to save entity " + logger + " with exception ", e);
            e.printStackTrace();
            if (tx != null) {
                tx.rollback();
            }
            throw new OihPersistenceException(e);
        } finally {
            closeSession();
        }
    }

    @Override
    public void save(VendorLeadTime o) throws OihPersistenceException {
        Transaction tx = null;
        try {
            openSession();
            tx = session.beginTransaction();
            session.save(o);
            tx.commit();
        } catch (RuntimeException e) {
            logger.error("Failed to save entity " + o + " with exception ", e);
            e.printStackTrace();
            if (tx != null) {
                tx.rollback();
            }
            throw new OihPersistenceException(e);
        } finally {
            closeSession();
        }
    }

    /**
     * Delete all the elements from the database
     * 
     * @throws OihPersistenceException
     */
    @SuppressWarnings("unchecked")
    @Override
    public void deleteAll() throws OihPersistenceException {
        logger.debug("Trying to delete all the elements from the db");
        Transaction tx = null;
        try {
            openSession();
            tx = session.beginTransaction();
            Criteria cri = session.createCriteria(VendorLeadTime.class);
            List<VendorLeadTime> targetInventoryLevels = cri.list();
            for (VendorLeadTime object : targetInventoryLevels) {
                session.delete(object);
            }
            tx.commit();
        } catch (HibernateException e) {
            e.printStackTrace();
            logger.error("Fail to query TargetInventoryLevel " + e);
            throw new OihPersistenceException(e);
        }
    }

    /**
     * Delete the object from the database
     * 
     * @param o
     * @throws OihPersistenceException
     */
    @Override
    public void delete(VendorLeadTime o) throws OihPersistenceException {
        Transaction tx = null;
        try {
            openSession();
            tx = session.beginTransaction();
            session.delete(o);
            tx.commit();
        } catch (RuntimeException e) {
            logger.error("Failed to save entity " + o + " with exception ", e);
            e.printStackTrace();
            if (tx != null) {
                tx.rollback();
            }
            throw new OihPersistenceException(e);
        } finally {
            closeSession();
        }
    }

    private void openSession() {
        session = MySQLSessionFactoryUtil.getSessionFactoryForInspector().openSession();
    }

    private void closeSession() {
        if (session != null) {
            session.close();
        }
    }
}