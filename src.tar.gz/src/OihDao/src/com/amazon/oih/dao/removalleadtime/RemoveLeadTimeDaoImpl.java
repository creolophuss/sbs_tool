package com.amazon.oih.dao.removalleadtime;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;

import com.amazon.oih.dao.MySQLSessionFactoryUtil;
import com.amazon.oih.dao.exception.OihPersistenceException;

public class RemoveLeadTimeDaoImpl implements RemoveLeadTimeDao {
    private final static Logger logger = Logger.getLogger(RemoveLeadTimeDaoImpl.class);
    protected Session session = null;

    public RemoveLeadTimeDaoImpl(String domain) {
    }

    @Override
    public RemoveLeadTime createInstance(Long runId, String asin, Integer iog, Integer gl, Disposition disposition, Double removalLeadTime) {
        return new RemoveLeadTime(runId, asin, iog, gl, disposition, removalLeadTime);
    }

    @Override
    public boolean exists(Long runId, String asin, Integer iog, Integer gl, Disposition disposition) throws OihPersistenceException {
        logger.debug("Query RemoveLeadTime by " + asin + "|" + iog + "|" + runId + "|" + gl + "|" + disposition);
        try {
            openSession();
            Criteria cri = session.createCriteria(RemoveLeadTime.class);
            cri.add(Restrictions.eq("asin", asin));
            cri.add(Restrictions.eq("iog", iog));
            cri.add(Restrictions.eq("runID", runId));
            cri.add(Restrictions.eq("gl", gl));
            cri.add(Restrictions.eq("disposition", disposition));
            return cri.uniqueResult() != null;
        } catch (HibernateException e) {
            e.printStackTrace();
            logger.error("Fail to query TargetInventoryLevel " + e);
            throw new OihPersistenceException(e);
        }
    }

    @Override
    public RemoveLeadTime find(Long runId, String asin, Integer iog, Integer gl, Disposition disposition) throws OihPersistenceException {
    	logger.debug("Query RemoveLeadTime by " + asin + "|" + iog + "|" + runId + "|" + gl + "|" + disposition);
        try {
            openSession();
            Criteria cri = session.createCriteria(RemoveLeadTime.class);
            cri.add(Restrictions.eq("asin", asin));
            cri.add(Restrictions.eq("iog", iog));
            cri.add(Restrictions.eq("runID", runId));
            cri.add(Restrictions.eq("gl", gl));
            cri.add(Restrictions.eq("disposition", disposition));
            return (RemoveLeadTime) cri.uniqueResult();
        } catch (HibernateException e) {
            e.printStackTrace();
            logger.error("Fail to query TargetInventoryLevel " + e);
            throw new OihPersistenceException(e);
        }
    }
    

	@Override
	public RemoveLeadTime findAsinLevelData(Long runId, String asin, Integer iog, Disposition disposition) throws OihPersistenceException {
		return find(runId, asin, iog, RemoveLeadTime.NULL_GL, disposition);
	}

	@Override
	public RemoveLeadTime findGLLevelData(Long runId, Integer iog, Integer gl, Disposition disposition) throws OihPersistenceException {
        return find(runId, RemoveLeadTime.NULL_ASIN, iog, gl, disposition);
	}

    @Override
    public void save(List<RemoveLeadTime> tils) throws OihPersistenceException {
        Transaction tx = null;
        try {
            openSession();
            tx = session.beginTransaction();
            for (RemoveLeadTime o : tils) {
                session.save(o);
            }
            tx.commit();
        } catch (RuntimeException e) {
            logger.error("Failed to save entity " + logger + " with exception ", e);
            e.printStackTrace();
            if (tx != null) {
                tx.rollback();
            }
            throw new OihPersistenceException(e);
        } finally {
            closeSession();
        }
    }

    @Override
    public void save(RemoveLeadTime o) throws OihPersistenceException {
        Transaction tx = null;
        try {
            openSession();
            tx = session.beginTransaction();
            session.save(o);
            tx.commit();
        } catch (RuntimeException e) {
            logger.error("Failed to save entity " + o + " with exception ", e);
            e.printStackTrace();
            if (tx != null) {
                tx.rollback();
            }
            throw new OihPersistenceException(e);
        } finally {
            closeSession();
        }
    }

    /**
     * Delete all the elements from the database
     * 
     * @throws OihPersistenceException
     */
    @SuppressWarnings("unchecked")
    @Override
    public void deleteAll() throws OihPersistenceException {
        logger.debug("Trying to delete all the elements from the db");
        Transaction tx = null;
        try {
            openSession();
            tx = session.beginTransaction();
            Criteria cri = session.createCriteria(RemoveLeadTime.class);
            List<RemoveLeadTime> targetInventoryLevels = cri.list();
            for (RemoveLeadTime object : targetInventoryLevels) {
                session.delete(object);
            }
            tx.commit();
        } catch (HibernateException e) {
            e.printStackTrace();
            logger.error("Fail to query TargetInventoryLevel " + e);
            throw new OihPersistenceException(e);
        }
    }

    /**
     * Delete the object from the database
     * 
     * @param o
     * @throws OihPersistenceException
     */
    @Override
    public void delete(RemoveLeadTime o) throws OihPersistenceException {
        Transaction tx = null;
        try {
            openSession();
            tx = session.beginTransaction();
            session.delete(o);
            tx.commit();
        } catch (RuntimeException e) {
            logger.error("Failed to save entity " + o + " with exception ", e);
            e.printStackTrace();
            if (tx != null) {
                tx.rollback();
            }
            throw new OihPersistenceException(e);
        } finally {
            closeSession();
        }
    }

    private void openSession() {
        session = MySQLSessionFactoryUtil.getSessionFactoryForInspector().openSession();
    }

    private void closeSession() {
        if (session != null) {
            session.close();
        }
    }
}