package com.amazon.oih.dao.g2s2;

import java.io.Serializable;

public class AppConfigInfo<T> implements Serializable{
    private static final long serialVersionUID = 4184999805870057690L;
    private String realm;
    private String domain;
    private String key;
    private T configContent;
    
    public AppConfigInfo() {
        super();
    }


    public AppConfigInfo(String realm, String domain, String key, T configContent) {
        super();
        this.realm = realm;
        this.domain = domain;
        this.key = key;
        this.configContent = configContent;
    }



    /**
     * @return the realm
     */
    public String getRealm() {
        return realm;
    }

    /**
     * @param realm the realm to set
     */
    public void setRealm(String realm) {
        this.realm = realm;
    }

    /**
     * @return the domain
     */
    public String getDomain() {
        return domain;
    }

    /**
     * @param domain the domain to set
     */
    public void setDomain(String domain) {
        this.domain = domain;
    }

    /**
     * @return the configContent
     */
    public T getConfigContent() {
        return configContent;
    }

    /**
     * @param configContent the configContent to set
     */
    public void setConfigContent(T configContent) {
        this.configContent = configContent;
    }


    /**
     * @return the key
     */
    public String getKey() {
        return key;
    }


    /**
     * @param key the key to set
     */
    public void setKey(String key) {
        this.key = key;
    }
    
    

}
