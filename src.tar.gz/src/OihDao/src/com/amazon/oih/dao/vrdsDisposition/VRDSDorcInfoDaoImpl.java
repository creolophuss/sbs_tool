package com.amazon.oih.dao.vrdsDisposition;

import java.util.List;

import amazon.platform.profiler.Profiler;
import amazon.platform.profiler.ProfilerScope;

import com.amazon.carbonado.ConfigurationException;
import com.amazon.carbonado.Cursor;
import com.amazon.carbonado.IsolationLevel;
import com.amazon.carbonado.PersistException;
import com.amazon.carbonado.Query;
import com.amazon.carbonado.Repository;
import com.amazon.carbonado.RepositoryException;
import com.amazon.carbonado.Storage;
import com.amazon.carbonado.Transaction;
import com.amazon.oih.dao.exception.DaoRuntimeException;
import com.amazon.oih.dao.exception.OihPersistenceException;

public class VRDSDorcInfoDaoImpl implements VRDSDorcInfoDao {

    protected String _domain = null;
    protected Repository repository = null;

    public VRDSDorcInfoDaoImpl(String domain) {
        _domain = domain;
    }

    public void setRepository(Repository repository) {
        if (null == repository) {
            throw new IllegalArgumentException("repository is null");
        }
        this.repository = repository;
    }

    @Override
    public VRDSDorcInfo createVRDSDorcInfo(Long runid, OIHDorcInfo info) throws DaoRuntimeException,
            OihPersistenceException {
        ProfilerScope scope = Profiler.scopeStart(this.getClass().getName() + "::create");
        try {
            Storage<VRDSDorcInfo> sDorcInfo = repository.storageFor(VRDSDorcInfo.class);
            VRDSDorcInfo myDorcInfo = sDorcInfo.prepare();
            myDorcInfo.setRunID(runid);

            setValues(myDorcInfo, info);

            return myDorcInfo;

        } catch (ConfigurationException e) {
            throw new DaoRuntimeException(e);
        } catch (RepositoryException e) {
            throw new OihPersistenceException(e);
        } finally {
            Profiler.scopeEnd(scope);
        }

    }

    private void setValues(VRDSDorcInfo myDorcInfo, OIHDorcInfo info) {

        myDorcInfo.setAsin(info.asin);
        myDorcInfo.setIog(info.iog);
        myDorcInfo.setMarketplaceId(info.marketplaceId);
        myDorcInfo.setGl(info.gl);
        myDorcInfo.setVendor(info.vendor);
        myDorcInfo.setDisposition(info.dispositionType);
        myDorcInfo.setWarehouse(info.warehouse);
        myDorcInfo.setQtyAssigned((int) info.qtyAssigned);
        myDorcInfo.setOrderType(info.orderType);
        myDorcInfo.setDorcId(info.dorcId);
        myDorcInfo.setQtyReceived(info.qtyReceived);
        myDorcInfo.setQtyReturned(new Integer(info.qtyReturned));
        myDorcInfo.setQtyInUse(new Integer(info.qtyInUse));
        myDorcInfo.setDsiId(new Long(info.dsiId));
        myDorcInfo.setDistributorCost(new Double(info.distributorCost));
        myDorcInfo.setBaseCurrencyCode(info.baseCurrencyCode);
        myDorcInfo.setDistributorListPrice(new Double(info.distributorListPrice));
        myDorcInfo.setDistributorOrderId(info.distributorOrderId);
        myDorcInfo.setDistributorOrderDate(info.distributorOrderDate);
        myDorcInfo.setShipmentReceivedDate(info.shipmentReceivedDate);
        myDorcInfo.setDistributorId(info.distributorId);
        myDorcInfo.setDistributorShipmentId(info.distributorShipmentId);
        myDorcInfo.setCost(info.cost);
        myDorcInfo.setRefundAmount(info.refundAmount);
        myDorcInfo.setForeignCurrencyCode(info.foreignCurrencyCode);
        myDorcInfo.setCostForeignCurrency(info.costForeignCurrency);
        myDorcInfo.setRefundAmountForeignCurrency(info.refundAmountForeignCurrency);
        myDorcInfo.setDistributorCostForeignCurrency(info.getDistributorCostForeignCurrency());
        myDorcInfo.setDistributorListPriceForeignCurrency(info.getDistributorListPriceForeignCurrency());
    }

    @Override
    public List<VRDSDorcInfo> find(Long runId, String asin, Integer iog) throws DaoRuntimeException,
            OihPersistenceException {
        ProfilerScope scope = Profiler.scopeStart(this.getClass().getName() + "::find");

        try {
            Storage<VRDSDorcInfo> sf = repository.storageFor(VRDSDorcInfo.class);

            return sf.query("runID = ? & iog = ? & asin = ?").with(runId).with(iog).with(asin)
                    .orderBy("-shipmentReceivedDate").fetch().toList();

        } catch (ConfigurationException e) {
            throw new DaoRuntimeException(e);
        } catch (RepositoryException e) {
            throw new OihPersistenceException(e);
        } finally {
            Profiler.scopeEnd(scope);
        }

    }
    
    @Override
    public List<VRDSDorcInfo> find(Long runId, String asin) throws DaoRuntimeException,
            OihPersistenceException {
        ProfilerScope scope = Profiler.scopeStart(this.getClass().getName() + "::find");

        try {
            Storage<VRDSDorcInfo> sf = repository.storageFor(VRDSDorcInfo.class);

            return sf.query("runID = ? & asin = ?").with(runId).with(asin)
                    .orderBy("-shipmentReceivedDate").fetch().toList();

        } catch (ConfigurationException e) {
            throw new DaoRuntimeException(e);
        } catch (RepositoryException e) {
            throw new OihPersistenceException(e);
        } finally {
            Profiler.scopeEnd(scope);
        }

    }
    
    public VRDSDorcInfo findByDsiId(Long runId, Integer iog, String asin, long dsiId) throws OihPersistenceException{
        ProfilerScope scope = Profiler.scopeStart(this.getClass().getName() + "::findByDsiId");
        try {
            Storage<VRDSDorcInfo> sf = repository.storageFor(VRDSDorcInfo.class);

            Cursor<VRDSDorcInfo> returnInfos = sf.query("runID = ? & iog = ? & asin = ? & dsiId = ?").with(runId).with(iog).with(asin).with(dsiId)
                    .fetch();
            VRDSDorcInfo info = null;
            if (returnInfos.hasNext())
                info = returnInfos.next();
            return info;
        } catch (ConfigurationException e) {
            throw new DaoRuntimeException(e);
        } catch (RepositoryException e) {
            throw new OihPersistenceException(e);
        } finally {
            Profiler.scopeEnd(scope);
        }
    }

    @Override
    public void save(VRDSDorcInfo info) throws OihPersistenceException {
        ProfilerScope scope = Profiler.scopeStart(this.getClass().getName() + "::save");
        try {
            info.insert();
        } catch (PersistException e) {
            throw new OihPersistenceException(e);
        } finally {
            Profiler.scopeEnd(scope);
        }

    }

    @Override
    public boolean exists(Long runId, String asin, Integer iog) throws DaoRuntimeException, OihPersistenceException {
        ProfilerScope scope = Profiler.scopeStart(this.getClass().getName() + "::exists");
        try {
            Storage<VRDSDorcInfo> sf = repository.storageFor(VRDSDorcInfo.class);
            boolean retVal = sf.query("runID = ? & iog = ? & asin = ?").with(runId).with(iog).with(asin).exists();

            return retVal;
        } catch (ConfigurationException e) {
            throw new DaoRuntimeException(e);
        } catch (RepositoryException e) {
            throw new OihPersistenceException(e);
        } finally {
            Profiler.scopeEnd(scope);
        }
    }

    @Override
    public void save(List<VRDSDorcInfo> info) throws OihPersistenceException {
        Transaction txn = repository.enterTransaction(IsolationLevel.READ_UNCOMMITTED);

        try {
            for (VRDSDorcInfo di : info) {
                if (!di.tryLoad())
                    di.insert();
            }
            txn.commit();
        } catch (PersistException e) {
            throw new OihPersistenceException(e);
        } catch (Exception e) {
            throw new DaoRuntimeException(e);
        } finally {
            exitTransaction(txn);
        }
    }

    private void exitTransaction(Transaction txn) throws OihPersistenceException {
        try {
            txn.exit();
        } catch (PersistException e) {
            throw new OihPersistenceException(e);
        }
    }
    
    @Override
    public void delete(Long runId, String asin, Integer iog) throws OihPersistenceException {
        ProfilerScope scope = Profiler.scopeStart(this.getClass().getName() + "::delete");
        try {
            Storage<VRDSDorcInfo> sf = repository.storageFor(VRDSDorcInfo.class);
            Query<VRDSDorcInfo> q=sf.query("runID = ? & iog = ? & asin = ?").with(runId).with(iog).with(asin);
            q.deleteAll();
        } catch (ConfigurationException e) {
            throw new DaoRuntimeException(e);
        } catch (RepositoryException e) {
            throw new OihPersistenceException(e);
        } finally {
            Profiler.scopeEnd(scope);
        }
    }
}
