package com.amazon.oih.dao.remotecat;

import java.util.Date;

import com.amazon.carbonado.Alias;
import com.amazon.carbonado.Nullable;
import com.amazon.carbonado.PrimaryKey;
import com.amazon.carbonado.Storable;
import com.amazon.carbonado.constraint.FloatConstraint;
import com.amazon.carbonado.constraint.IntegerConstraint;
import com.amazon.carbonado.constraint.LengthConstraint;

/**
 * This is no longer used, know we are reading the HBase even for single machine version.
 *
 */
@Alias("data_remote_cat")
@PrimaryKey( {
        "runID", "asin", "marketplace", "merchant"
})
@Deprecated
public abstract class RemoteCatBDB implements Storable<RemoteCatBDB> {
    @Alias("run_id")
    public abstract long getRunID();

    public abstract void setRunID(long runId);

    public abstract String getAsin();

    @LengthConstraint(min = 10, max = 10)
    public abstract void setAsin(String asin);

    public abstract long getMarketplace();

    @IntegerConstraint(min = 1, max = Long.MAX_VALUE)
    public abstract void setMarketplace(long marketplace);

    public abstract long getMerchant();
    
    @IntegerConstraint(min = 1, max = Long.MAX_VALUE)
    public abstract void setMerchant(long merchant);
    
    public abstract int getGl();

    @IntegerConstraint(min = 0, max = Integer.MAX_VALUE)
    public abstract void setGl(int gl);

    public abstract String getTitle();

    public abstract void setTitle(String title);

    public abstract double getOurPrice();

    @FloatConstraint(min = 0, max = Double.MAX_VALUE)
    public abstract void setOurPrice(double ourprice);

    @Nullable
    public abstract Date getPublicationDate();

    public abstract void setPublicationDate(Date date);

    @Nullable
    public abstract Date getReleaseDate();

    public abstract void setReleaseDate(Date date);

    public abstract String getUpc();

    public abstract void setUpc(String upc);

    public abstract boolean isUnPrepRequired();

    public abstract void setUnPrepRequired(boolean isUnPrepRequired);

    public abstract int getCategory();

    @IntegerConstraint(min = 0, max = Integer.MAX_VALUE)
    public abstract void setCategory(int category);

    public abstract int getSubCategory();

    @IntegerConstraint(min = 0, max = Integer.MAX_VALUE)
    public abstract void setSubCategory(int subCategory);

    public abstract String getEan();

    public abstract void setEan(String ean);

    public abstract String getPublisherCode();

    public abstract void setPublisherCode(String publisherCode);

    public abstract double getMapPrice();

    @FloatConstraint(min = 0, max = Double.MAX_VALUE)
    public abstract void setMapPrice(double mapPrice);

    public abstract String getMapRequired();

    public abstract void setMapRequired(String isMapRequired);

    public abstract String getParentAsin();

    public abstract void setParentAsin(String parentAsin);

    public abstract double getListPrice();

    @FloatConstraint(min = 0, max = Double.MAX_VALUE)
    public abstract void setListPrice(double listPrice);

    public abstract String getReplenishmentCategory();

    public abstract void setReplenishmentCategory(String replenishmentCategory);

    public abstract String getHazmatTransportationRegularClass();

    public abstract void setHazmatTransportationRegularClass(String hazmatTransportationRegularClass);

    public abstract String getHazmatException();

    public abstract void setHazmatException(String hazmatException);

    public abstract String getHazmatItem();

    public abstract void setHazmatItem(String isHazmatItem);

    public abstract String getTextbookType();

    public abstract void setTextbookType(String textbookType);

    public abstract String getMapStrict();

    public abstract void setMapStrict(String isMapStrict);

    @Nullable
    public abstract Date getMapEndDate();

    public abstract void setMapEndDate(Date mapEndDate);

    @Nullable
    public abstract Date getSiteLaunchDate();

    public abstract void setSiteLaunchDate(Date siteLaunchDate);

    public abstract String getBrandName();

    public abstract void setBrandName(String brandCode);

    public abstract String getBrandCode();

    public abstract void setBrandCode(String brandCode);

    public abstract String getBinding();

    public abstract void setBinding(String binding);

    public abstract String getSeasons();

    public abstract void setSeasons(String seasons);

    public abstract String getModelNumber();

    public abstract void setModelNumber(String modelNumber);

    public abstract String getSourceCountryCode();

    public abstract void setSourceCountryCode(String sourceCountryCode);

    public abstract double getMapStrictPrice();

    @FloatConstraint(min = 0, max = Double.MAX_VALUE)
    public abstract void setMapStrictPrice(double mapStrictPrice);
    
    public abstract int getModelYear();
    
    @IntegerConstraint(min = 0, max = Integer.MAX_VALUE)
    public abstract void setModelYear(int modelYear);
    
    public abstract String getFormat();
    
    public abstract void setFormat(String format);
    
    public abstract String getRestrictedPriceDiscountCountry();
    
    public abstract void setRestrictedPriceDiscountCountry(String rpdc);
    
    public abstract String getAvailability();
    
    public abstract void setAvailability(String availability);

    public abstract String getRetailOffer();

    public abstract void setRetailOffer(String isRetailOffer);
    
}
