package com.amazon.oih.dao.removalleadtime;

import java.io.Serializable;

public class RemoveLeadTime implements Serializable {
    private static final long serialVersionUID = 1L;
	public static int NULL_GL = -1;
	public static String NULL_ASIN = "null";
	
    private long runID;
    private String asin;
    private int iog;
    private int gl;
    private Disposition disposition;
    private double removalLeadTime;


    public RemoveLeadTime(long runID, String asin, int iog, int gl , Disposition disposition, double removalLeadTime) {
        this.runID = runID;
        this.asin = asin;
        this.iog = iog;
        this.gl = gl;
        this.disposition = disposition;
        this.removalLeadTime = removalLeadTime;
    }

    public RemoveLeadTime() {

    }

    public void setRunID(long runID) {
        this.runID = runID;
    }

    public long getRunID() {
        return runID;
    }

	public int getGl() {
		return gl;
	}

	public void setGl(int gl) {
		this.gl = gl;
	}

	public String getAsin() {
		return asin;
	}

	public void setAsin(String asin) {
		this.asin = asin;
	}

	public int getIog() {
		return iog;
	}

	public void setIog(int iog) {
		this.iog = iog;
	}

	public Disposition getDisposition() {
		return disposition;
	}

	public void setDisposition(Disposition disposition) {
		this.disposition = disposition;
	}

	public double getRemovalLeadTime() {
		return removalLeadTime;
	}

	public void setRemovalLeadTime(double removalLeadTime) {
		this.removalLeadTime = removalLeadTime;
	}

	@Override
	public String toString(){
		return "asin:" + asin + " iog:" + iog + " runID:" + runID + " gl:" + gl + " Disposition:" + disposition + " removalLeadTime:" + removalLeadTime;
	}
	
	@Override
    public boolean equals(Object obj) {
        if (obj instanceof RemoveLeadTime == false) {
            return false;
        }
        if (this == obj) {
            return true;
        }

        RemoveLeadTime other = (RemoveLeadTime) obj;

        return this.runID == other.getRunID()  && this.asin.equals(other.getAsin()) && this.iog == other.getIog()  
        		&& this.gl == other.getGl() && Math.abs(this.removalLeadTime - other.getRemovalLeadTime()) < 1e-6
        		&& this.disposition.equals(other.getDisposition());
    }


    @Override
    public int hashCode() {
        final int prime = 127; // changed from default - 31 is a lame prime #
        int result = 1;
        result = prime * result + ((asin == null) ? 0 : asin.hashCode());
        result = prime * result + (int) iog;
        result = prime * result + (int) runID;
        result = prime * result + gl;
        result = prime * result + ((disposition == null) ? 0 : disposition.toString().hashCode());
        return result;
    }
}
