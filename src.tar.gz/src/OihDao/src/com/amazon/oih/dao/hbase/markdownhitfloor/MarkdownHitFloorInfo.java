package com.amazon.oih.dao.hbase.markdownhitfloor;

import java.io.Serializable;
import com.amazon.oih.common.RowKeyBuildType;
import com.amazon.oih.common.RowKeyType;
import com.amazon.oih.dao.hbase.base.CommonKVHBaseDao.HTable;
import com.amazon.oih.dao.hbase.converter.Column;
import com.amazon.oih.dao.hbase.converter.RowKey;

@RowKey({"asin", "marketplaceId"})
@RowKeyBuildType(RowKeyType.ASIN_MARKETPLACE)
@HTable(value = "MarkdownHitFloorDuration")
public class MarkdownHitFloorInfo implements Serializable {

    private static final long serialVersionUID = 4809097877846933851L;
    private String asin;
    private String marketplaceId;
    
    @Column(name="MHFloor",index=0)
    private int activeDuration;
    @Column(name="MHFloor",index=1)
    private int inactiveDuration;
    
    private String inactive;
    
    public String getAsin() {
        return asin;
    }
    public void setAsin(String asin) {
        this.asin = asin;
    }
    public String getMarketplaceId() {
        return marketplaceId;
    }
    public void setMarketplaceId(String marketplaceId) {
        this.marketplaceId = marketplaceId;
    }
    public int getActiveDuration() {
        return activeDuration;
    }
    public void setActiveDuration(int activeDuration) {
        this.activeDuration = activeDuration;
    }

    public int getInactiveDuration() {
        return inactiveDuration;
    }
    public void setInactiveDuration(int inactiveDuration) {
        this.inactiveDuration = inactiveDuration;
    }
    public String getInactive() {
        return inactive;
    }
    public void setInactive(String inactive) {
        this.inactive = inactive;
    }
    


}
