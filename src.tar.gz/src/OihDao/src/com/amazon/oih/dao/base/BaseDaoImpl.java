package com.amazon.oih.dao.base;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionTemplate;

@Transactional(propagation = Propagation.SUPPORTS)
public class BaseDaoImpl<T> implements BaseDao<T> {
    private SessionFactory sessionFactory;
    private TransactionTemplate transactionTemplate;

    @SuppressWarnings("unchecked")
    @Override
    public List<T> findAll(Class<T> clazz) {
        return (List<T>) getSessionFactory().getCurrentSession().createQuery("from " + clazz.getName()).list();
    }

    @Override
    public void delete(T object) {
        getSessionFactory().getCurrentSession().delete(object);
    }

    @Override
    public void saveOrUpdate(T object) {
        getSessionFactory().getCurrentSession().saveOrUpdate(object);
    }

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    public SessionFactory getSessionFactory() {
        return sessionFactory;
    }

    public void setTransactionTemplate(TransactionTemplate transactionTemplate) {
        this.transactionTemplate = transactionTemplate;
    }

    public TransactionTemplate getTransactionTemplate() {
        return transactionTemplate;
    }

    @Override
    @Transactional(propagation = Propagation.SUPPORTS, readOnly = false, rollbackFor = Exception.class)
    public void saveOrUpdate(List<T> objects) {
        for (T object : objects) {
            saveOrUpdate(object);
        }
    }
}
