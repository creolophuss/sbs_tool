package com.amazon.oih.dao.g2s2.exceptions;

public class IonMappingException extends RuntimeException {

    private static final long serialVersionUID = -6781015702662313018L;

    public IonMappingException() {
        super();
    }

    public IonMappingException(String message, Throwable cause) {
        super(message, cause);
    }

    public IonMappingException(String message) {
        super(message);
    }

    public IonMappingException(Throwable cause) {
        super(cause);
    }
}
