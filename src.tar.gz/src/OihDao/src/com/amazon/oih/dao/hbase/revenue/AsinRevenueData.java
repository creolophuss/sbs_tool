package com.amazon.oih.dao.hbase.revenue;

import java.util.List;
import java.util.Map;

import com.amazon.oih.utils.RevenueHBaseTableUtil;

/**
 * 
 * @author mengzang
 * 
 */
public class AsinRevenueData {

    public AsinRevenueData(String asin, String scopeId) {
        this.asin = asin;
        this.scopeId = scopeId;
    }

    private String asin;
    private String scopeId;
    private Map<Integer, List<Double>> inventory2RevenueMap = RevenueHBaseTableUtil.EMPTY_REVENUE_MAP;;
    private Double ourPrice;
    private Double cost;

    public Double getOurPrice() {
        return ourPrice;
    }

    public void setOurPrice(Double ourPrice) {
        this.ourPrice = ourPrice;
    }

    public Double getCost() {
        return cost;
    }

    public void setCost(Double cost) {
        this.cost = cost;
    }

    public String getAsin() {
        return asin;
    }

    public void setAsin(String asin) {
        this.asin = asin;
    }

    public Map<Integer, List<Double>> getInventory2RevenueMap() {
        return inventory2RevenueMap;
    }

    public void setInventory2RevenueMap(Map<Integer, List<Double>> inventory2RevenueMap) {
        if (inventory2RevenueMap == null) {
            this.inventory2RevenueMap = RevenueHBaseTableUtil.EMPTY_REVENUE_MAP;
        } else {
            this.inventory2RevenueMap = inventory2RevenueMap;
        }
    }

    public String getScopeId() {
        return scopeId;
    }

    public void setScopeId(String scopeId) {
        this.scopeId = scopeId;
    }

    public void setInventory2RevenueMapByString(String value) {
        this.inventory2RevenueMap = RevenueHBaseTableUtil.convertString2InventoryRevenueMap(value);
    }

    public String getInventory2RevenueMapOfStringFormat() {
        return RevenueHBaseTableUtil.convertInventoryRevenueMap2String(this.inventory2RevenueMap);
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((asin == null) ? 0 : asin.hashCode());
        result = prime * result + ((cost == null) ? 0 : cost.hashCode());
        result = prime * result + ((inventory2RevenueMap == null) ? 0 : inventory2RevenueMap.hashCode());
        result = prime * result + ((ourPrice == null) ? 0 : ourPrice.hashCode());
        result = prime * result + ((scopeId == null) ? 0 : scopeId.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        AsinRevenueData other = (AsinRevenueData) obj;
        if (asin == null) {
            if (other.asin != null)
                return false;
        } else if (!asin.equals(other.asin))
            return false;
        if (cost == null) {
            if (other.cost != null)
                return false;
        } else if (!cost.equals(other.cost))
            return false;
        if (inventory2RevenueMap == null) {
            if (other.inventory2RevenueMap != null)
                return false;
        } else if (!RevenueHBaseTableUtil.compareInventory2RevenueMap(inventory2RevenueMap, other.inventory2RevenueMap))
            return false;
        if (ourPrice == null) {
            if (other.ourPrice != null)
                return false;
        } else if (!ourPrice.equals(other.ourPrice))
            return false;
        if (scopeId == null) {
            if (other.scopeId != null)
                return false;
        } else if (!scopeId.equals(other.scopeId))
            return false;
        return true;
    }

    @Override
    public String toString() {
        return "AsinRevenueData [asin=" + asin + ", scopeId=" + scopeId + ", inventory2RevenueMap="
                + RevenueHBaseTableUtil.convertInventoryRevenueMap2String(inventory2RevenueMap) + ", ourPrice="
                + ourPrice + ", cost=" + cost + "]";
    }

}
