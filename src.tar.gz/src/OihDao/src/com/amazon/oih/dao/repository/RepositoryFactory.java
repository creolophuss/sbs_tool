package com.amazon.oih.dao.repository;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;

import javax.naming.Context;
import javax.naming.NamingException;

import org.apache.log4j.Logger;

import com.amazon.carbonado.ConfigurationException;
import com.amazon.carbonado.Repository;
import com.amazon.carbonado.RepositoryBuilder;
import com.amazon.carbonado.RepositoryException;
import com.amazon.carbonado.Storable;
import com.amazon.carbonado.repo.map.MapRepositoryBuilder;
import com.amazon.carbonado.repo.replicated.ReplicatedRepositoryBuilder;
import com.amazon.oih.dao.OdinizedAppConfigInitCtxFactory;
import com.amazon.oih.dao.exception.DaoRuntimeException;
import com.amazon.oih.dao.experiments.Experiment;
import com.amazon.oih.dao.experiments.Treatment;
import com.amazon.oih.dao.forecast34to52.Forecast34To52;
import com.amazon.oih.dao.forecastnew.ForecastNew;
import com.amazon.oih.dao.forecastnew.ForecastNewBDBObject;
import com.amazon.oih.dao.historicdemand.HistoricDemand;
import com.amazon.oih.dao.markdowninfo.MarkdownInfoBDBObject;
import com.amazon.oih.dao.recall.RecallObject;
import com.amazon.oih.dao.remotecat.RemoteCatBDB;
import com.amazon.oih.dao.run.Run;
import com.amazon.oih.dao.unsellable.damagedremotecat.DamagedRemoteCatObject;
import com.amazon.oih.dao.unsellable.damagedvrds.DamagedVRDSItem;
import com.amazon.oih.dao.unsellable.inventorycandidate.InventoryCandidateComposite;
import com.amazon.oih.dao.vrdsDisposition.VRDSDorcInfo;
import com.amazon.oih.dao.vrdsDisposition.VRDSReturnTerms;

/**
 * The factory class for Carbonado repositories.
 */
public class RepositoryFactory {
    private static final Logger log = Logger.getLogger(RepositoryFactory.class);

    public static final String UNIT_TEST = "UNIT_TEST";

    private static final RepositoryFactory instance = new RepositoryFactory();
    private Repository inMemoryRepository = null;
    private Map<String, Repository> inDbRepositoryPool = new ConcurrentHashMap<String, Repository>();

    private final static Map<Class<? extends Storable<?>>, String> classToSourceMap = new HashMap<Class<? extends Storable<?>>, String>();

    static {
        final String vrdsDbSource = "/dataSource/OihVrdsDb";
        final String inputsDbSource = "/dataSource/OihInputsDb";
        final String experimentsDbSource = "/dataSource/OihIpcExperimentsDb";
        final String forecastNewDbSource = "/dataSource/OihForecastNewDb";
        final String forecast34To52DbSource = "/dataSource/OihForecast34To52Db";
        final String historicDemandDbSource = "/dataSource/OihHistoricDemandDb";
        final String markdownInfoDbSource = "/dataSource/OihMarkdownInfoDb";
        final String remoteCatDbSource = "/dataSource/OihRemoteCatDb";
        final String recallSource = "/dataSource/DamagedRecallDb";
        final String damagedRemoteCatSource = "/dataSource/DamagedRemoteCatDb";
        final String damagedVRDSSource = "/dataSource/DamagedVRDSDb";
        final String icCompositeSource = "/dataSource/InventoryCandidateComposite";

        classToSourceMap.put(ForecastNewBDBObject.class, forecastNewDbSource);
        classToSourceMap.put(Forecast34To52.class, forecast34To52DbSource);
        classToSourceMap.put(Run.class, inputsDbSource);
        classToSourceMap.put(VRDSDorcInfo.class, vrdsDbSource);
        classToSourceMap.put(VRDSReturnTerms.class, vrdsDbSource);
        classToSourceMap.put(Experiment.class, experimentsDbSource);
        classToSourceMap.put(Treatment.class, experimentsDbSource);
        classToSourceMap.put(HistoricDemand.class, historicDemandDbSource);
        classToSourceMap.put(MarkdownInfoBDBObject.class, markdownInfoDbSource);
        classToSourceMap.put(RemoteCatBDB.class, remoteCatDbSource);
        classToSourceMap.put(RecallObject.class, recallSource);
        classToSourceMap.put(DamagedRemoteCatObject.class, damagedRemoteCatSource);
        classToSourceMap.put(DamagedVRDSItem.class, damagedVRDSSource);
        classToSourceMap.put(InventoryCandidateComposite.class, icCompositeSource);
    }

    private RepositoryFactory() {
        // build in-memory repository for test purpose
        inMemoryRepository = buildInMemoryRepository();
    }

    public static RepositoryFactory getInst() {
        return instance;
    }

    public final Repository getRepository(Class<? extends Storable<?>> cls, String domain) {
        return getRepository(cls, domain, null, null);
    }
    
    public final Repository getRepository(Class<? extends Storable<?>> cls, String domain, String rundate, String realm) {
        if (null == cls) {
            throw new IllegalArgumentException("cls is null");
        }
        if (null == domain || domain.trim().length() == 0) {
            throw new IllegalArgumentException("doamin is not specified");
        }

        if (UNIT_TEST.equalsIgnoreCase(domain)) {
            return inMemoryRepository;
        } else {
            return getDatabaseRepository(cls, rundate, realm);
        }
    }
    
    public final Repository getRepositoryNoCache(Class<? extends Storable<?>> cls, String domain, String rundate, String realm) {
        if (null == cls) {
            throw new IllegalArgumentException("cls is null");
        }
        if (null == domain || domain.trim().length() == 0) {
            throw new IllegalArgumentException("doamin is not specified");
        }

        if (UNIT_TEST.equalsIgnoreCase(domain)) {
            return inMemoryRepository;
        } else {
            return getDatabaseRepositoryNoCache(cls, rundate, realm);
        }
    }

    private final Repository getDatabaseRepository(Class<? extends Storable<?>> cls, String rundate, String realm) {

        String source = classToSourceMap.get(cls);
        if (null == source) {
            throw new IllegalStateException("cannot find db repository for " + cls.getClass().getName());
        }

        Repository r = inDbRepositoryPool.get(source);
        if (r == null) {
            r = createRepository(cls, source, rundate, realm, true);
        }

        return r;
    }
    
    private final Repository getDatabaseRepositoryNoCache(Class<? extends Storable<?>> cls, String rundate, String realm) {

        String source = classToSourceMap.get(cls);
        if (null == source) {
            throw new IllegalStateException("cannot find db repository for " + cls.getClass().getName());
        }

        return createRepository(cls, source, rundate, realm, false);
    }

    private synchronized Repository createRepository(Class<? extends Storable<?>> cls, String source, String rundate, String realm
    		, boolean useCache) {
        Repository r = null;
        if (useCache){
            r = inDbRepositoryPool.get(source);
        }
        
        if (r == null) {
            try {
                RepositoryBuilder master = createMasterRepositoryBuilder(source, rundate, realm);
                RepositoryBuilder replica = createReplicaRepositoryBuider(source);
                if (replica != null) {
                    log.info("A replicated repository is being used for storable " + cls.getName());
                    ReplicatedRepositoryBuilder rrb = new ReplicatedRepositoryBuilder();
                    rrb.setMasterRepositoryBuilder(master);
                    rrb.setReplicaRepositoryBuilder(replica);
                    r = rrb.build();
                } else {
                    log.warn("No replicated repository is being used for storable " + cls.getName());
                    r = master.build();
                }

                inDbRepositoryPool.put(source, r);
                log.debug("Returning repository for class: " + cls.getName());
            } catch (RepositoryException ex) {
                throw new DaoRuntimeException(ex);
            }
        }
        return r;
    }

    private synchronized RepositoryBuilder createReplicaRepositoryBuider(String datasource) throws DaoRuntimeException {
        log.info("building replicated repository for data source: " + datasource);

        try {
        	OdinizedAppConfigInitCtxFactory contextFactory = new OdinizedAppConfigInitCtxFactory();
            RepositoryBuilder replica = (RepositoryBuilder) contextFactory.getInitialContext(null).lookup(
                    datasource + "/Replication");
            return replica;
        } catch (NamingException ex) {
            log.info("replicated repository for data source " + datasource + " is not  available.");
        } catch (Exception ex) {
            log.info("replicated repository for data source " + datasource + " is not  available.");
        }
        return null;
    }

    private synchronized RepositoryBuilder createMasterRepositoryBuilder(String datasource, String rundate, String realm) throws DaoRuntimeException {
        log.info("building master repository for data source: " + datasource);

        try {
        	OdinizedAppConfigInitCtxFactory contextFactory = new OdinizedAppConfigInitCtxFactory();

            Context context = contextFactory.getInitialContext(null);
            RepositoryBuilder master = (RepositoryBuilder) context.lookup(datasource + "/Master");

            if (master == null)
                throw new DaoRuntimeException("Master repository for data source \'" + datasource
                        + "' is not  available.");

            if (rundate != null && realm != null && master instanceof RundateAwareBDBRepositoryBuilder){
                ((RundateAwareBDBRepositoryBuilder) master).setRundate(rundate);
                ((RundateAwareBDBRepositoryBuilder) master).buildEnvironmentHomeFile(realm);   
            }
            
            return master;

        } catch (NamingException e) {
            throw new DaoRuntimeException(e); 
        } catch (RepositoryException e) {
            throw new DaoRuntimeException(e);
        }
    }

    private Repository buildInMemoryRepository() throws DaoRuntimeException {
        try {
            MapRepositoryBuilder b = new MapRepositoryBuilder();
            b.setName("InMemoryRepository");
            b.setLockTimeout(60, TimeUnit.SECONDS);
            return b.build();
        } catch (ConfigurationException e) {
            throw new DaoRuntimeException(e);
        } catch (RepositoryException e) {
            throw new DaoRuntimeException(e);
        }
    }
}
