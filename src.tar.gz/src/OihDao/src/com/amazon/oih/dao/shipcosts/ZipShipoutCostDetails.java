package com.amazon.oih.dao.shipcosts;

import java.util.Arrays;

import com.google.common.base.Preconditions;
import com.google.common.collect.Range;
import com.google.common.collect.Ranges;
import com.google.common.primitives.Doubles;

public class ZipShipoutCostDetails implements Cloneable {
    private String source;
    private String dest;
    
    private double [] unitCosts;
    private double [] weightPoints;
    
    private Range<Double> [] weightRanges;
    
    private double startWeight;
    private double startCost;
    
    public ZipShipoutCostDetails() {
        
    }
    
    public ZipShipoutCostDetails(String source, String dest, double[] unitCosts, double[] weightPoints, double startWeight, double startCost) {
        this.source = source;
        this.dest = dest;
        this.unitCosts = unitCosts;
        this.startWeight = startWeight;
        this.startCost = startCost;
        this.weightPoints = weightPoints;
        this.weightRanges = buildWeightRanges(weightPoints);
    }
    
    public ZipShipoutCostDetails(CNZipShipoutCostDetails cnDetail) {
        this.source = cnDetail.getSource();
        this.dest = cnDetail.getDest();
        this.startCost = Double.parseDouble(cnDetail.getStartCost());
        this.startWeight = Double.parseDouble(cnDetail.getStartWeight());
        
        this.unitCosts = new double[] {
                Double.parseDouble(cnDetail.getkG100UnitCost()),
                Double.parseDouble(cnDetail.getkG300UnitCost()),
                Double.parseDouble(cnDetail.getkG500UnitCost()),
                Double.parseDouble(cnDetail.getMoreUnitCost())
                };
        
        this.weightPoints = new double[] {100.0, 300.0, 500.0};
        
        this.weightRanges = buildWeightRanges(weightPoints);
    }
    
    public String getSource() {
        return source;
    }
    public void setSource(String source) {
        this.source = source;
    }
    
    public String getDest() {
        return dest;
    }
    public void setDest(String dest) {
        this.dest = dest;
    }
  
    public double[] getUnitCosts() {
        return unitCosts;
    }
   
    public double getStartWeight() {
        return startWeight;
    }
    
    public double getStartCost() {
        return startCost;
    }
  
    public boolean costEquals(ZipShipoutCostDetails anotherCost) {
       
        return Arrays.equals(unitCosts, anotherCost.unitCosts) &&  Arrays.equals(weightRanges, anotherCost.weightRanges) 
                && startWeight == anotherCost.startWeight && startCost == anotherCost.startCost;
    }
    
    public String getCostDescription() {
        String costs = Doubles.join(",", unitCosts);
        StringBuffer desc = new StringBuffer(costs);
        
        desc.append("#");
        for(Range<Double> range : weightRanges) {
            desc.append(range.toString());
        }
        
        return desc.toString();
    }
    
    public Double getCost(double weight) {
        for(int i = 0; i < unitCosts.length; i++) {
            double unitCost = unitCosts[i];
            if (weightRanges[i].contains(weight)) {
                double cost = unitCost * weight;
                return cost > startCost ? cost : startCost;
            }
        }
        
        return null;
    }
    
    public double[] getWeightPoints() {
        return weightPoints.clone();
    }
    
    @Override
    public ZipShipoutCostDetails clone() {
        return new ZipShipoutCostDetails(
                this.source,
                this.dest,
                this.getUnitCosts(),
                this.weightPoints,
                this.startWeight,
                this.startCost
                );
    }
    
    @Override
    public String toString() {
        return "ZipShipoutCostDetails [source=" + source + ", dest=" + dest + ", unitCosts="
                + Arrays.toString(unitCosts) + ", weightPoints=" + Arrays.toString(weightPoints) + ", weightRanges="
                + Arrays.toString(weightRanges) + ", startWeight=" + startWeight + ", startCost=" + startCost + "]";
    }

    private Range<Double>[] buildWeightRanges(double[] weights) {
        
        Preconditions.checkArgument(weights.length == unitCosts.length - 1, "unit costs size doesn't equal weight ranges!");
        
        @SuppressWarnings("unchecked")
        Range<Double>[] ranges = new Range[weights.length + 1];
        
        ranges[0] = Ranges.atMost(weights[0]);
        
        int index = 0;
        for(;index < weights.length - 1; index++) {
            ranges[index + 1] = Ranges.closedOpen(weights[index], weights[index + 1]);
        }
        
        ranges[index + 1] = Ranges.atLeast(weights[index]);
        
        return ranges;
    }
}
