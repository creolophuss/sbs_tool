package com.amazon.oih.dao.targetInvLevel;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import com.amazon.oih.dao.MySQLSessionFactoryUtil;
import com.amazon.oih.dao.exception.OihPersistenceException;
import com.amazon.oih.utils.AsinIogPair;
import com.amazon.oih.utils.Utils;

public class TargetInventoryLevelDaoImpl implements TargetInventoryLevelDao {
    private final static Logger logger = Logger.getLogger(TargetInventoryLevelDaoImpl.class);
    protected Session session = null;

    public TargetInventoryLevelDaoImpl(String domain) {
    }

    @Override
    public TargetInventoryLevel createTargetInventoryLevel(Long runid, String asin, Integer iog, Integer til,
            Integer cartonQty) {
        return new TargetInventoryLevel(runid, asin, iog, til, cartonQty);
    }

    @Override
    public boolean exists(Long runId, String asin, Integer iog) throws OihPersistenceException {
        logger.debug("Query TargetInventoryLevel by " + asin + "|" + iog + "|" + runId);
        try {
            openSession();
            Criteria cri = session.createCriteria(TargetInventoryLevel.class);
            cri.add(Restrictions.eq("asin", asin));
            cri.add(Restrictions.eq("iog", iog));
            cri.add(Restrictions.eq("runID", runId));
            return cri.uniqueResult() != null;
        } catch (HibernateException e) {
            e.printStackTrace();
            logger.error("Fail to query TargetInventoryLevel " + e);
            throw new OihPersistenceException(e);
        }
    }

    @Override
    public TargetInventoryLevel find(Long runId, String asin, Integer iog) throws OihPersistenceException {
        logger.debug("Query TargetInventoryLevel by " + asin + "|" + iog + "|" + runId);
        try {
            openSession();
            Criteria cri = session.createCriteria(TargetInventoryLevel.class);
            cri.add(Restrictions.eq("asin", asin));
            cri.add(Restrictions.eq("iog", iog));
            cri.add(Restrictions.eq("runID", runId));
            return (TargetInventoryLevel) cri.uniqueResult();
        } catch (HibernateException e) {
            e.printStackTrace();
            logger.error("Fail to query TargetInventoryLevel " + e);
            throw new OihPersistenceException(e);
        }
    }

    @SuppressWarnings("unchecked")
    private List<TargetInventoryLevel> find(Long runId, List<String> asins, int iog) throws OihPersistenceException {
        logger.info("Batch Query TargetInventoryLevel for a batchList, the first asin is " + asins.get(0) + "|" + iog);
        try {
            openSession();
            Criteria cri = session.createCriteria(TargetInventoryLevel.class);
            cri.add(Restrictions.in("asin", asins));
            cri.add(Restrictions.eq("iog", iog));
            cri.add(Restrictions.eq("runID", runId));
            return (List<TargetInventoryLevel>) cri.list();
        } catch (HibernateException e) {
            e.printStackTrace();
            logger.error("Fail to query TargetInventoryLevel " + e);
            throw new OihPersistenceException(e);
        }
    }

    @Override
    public List<TargetInventoryLevel> find(Long runId, List<AsinIogPair> asinIogPairs) throws OihPersistenceException {
        List<TargetInventoryLevel> results = new ArrayList<TargetInventoryLevel>();

        Map<Integer, List<String>> iog2AsinsMap = Utils.splitAsinIogList2AsinsMap(asinIogPairs);
        Iterator<Integer> iterator = iog2AsinsMap.keySet().iterator();

        try {
            while (iterator.hasNext()) {
                Integer iog = iterator.next();
                List<TargetInventoryLevel> opObjects = find(runId, iog2AsinsMap.get(iog), iog);
                for (TargetInventoryLevel object : opObjects) {
                    results.add(object);
                }
            }
            return results;
        } catch (HibernateException e) {
            logger.error("Fail to query TargetInventoryLevel " + e);
            throw new OihPersistenceException(e);
        }
    }

    @Override
    public void save(List<TargetInventoryLevel> tils) throws OihPersistenceException {
        Transaction tx = null;
        try {
            openSession();
            tx = session.beginTransaction();
            for (TargetInventoryLevel o : tils) {
                session.save(o);
            }
            tx.commit();
        } catch (RuntimeException e) {
            logger.error("Failed to save entity " + logger + " with exception ", e);
            e.printStackTrace();
            if (tx != null) {
                tx.rollback();
            }
            throw new OihPersistenceException(e);
        } finally {
            closeSession();
        }
    }

    @Override
    public void save(TargetInventoryLevel o) throws OihPersistenceException {
        Transaction tx = null;
        try {
            openSession();
            tx = session.beginTransaction();
            session.save(o);
            tx.commit();
        } catch (RuntimeException e) {
            logger.error("Failed to save entity " + o + " with exception ", e);
            e.printStackTrace();
            if (tx != null) {
                tx.rollback();
            }
            throw new OihPersistenceException(e);
        } finally {
            closeSession();
        }
    }

    /**
     * Delete all the elements from the database
     * 
     * @throws OihPersistenceException
     */
    @SuppressWarnings("unchecked")
    @Override
    public void deleteAll() throws OihPersistenceException {
        logger.debug("Trying to delete all the elements from the db");
        Transaction tx = null;
        try {
            openSession();
            tx = session.beginTransaction();
            Criteria cri = session.createCriteria(TargetInventoryLevel.class);
            List<TargetInventoryLevel> targetInventoryLevels = cri.list();
            for (TargetInventoryLevel object : targetInventoryLevels) {
                session.delete(object);
            }
            tx.commit();
        } catch (HibernateException e) {
            e.printStackTrace();
            logger.error("Fail to query TargetInventoryLevel " + e);
            throw new OihPersistenceException(e);
        }
    }

    /**
     * Delete the object from the database
     * 
     * @param o
     * @throws OihPersistenceException
     */
    @Override
    public void delete(TargetInventoryLevel o) throws OihPersistenceException {
        Transaction tx = null;
        try {
            openSession();
            tx = session.beginTransaction();
            session.delete(o);
            tx.commit();
        } catch (RuntimeException e) {
            logger.error("Failed to save entity " + o + " with exception ", e);
            e.printStackTrace();
            if (tx != null) {
                tx.rollback();
            }
            throw new OihPersistenceException(e);
        } finally {
            closeSession();
        }
    }

    private void openSession() {
        session = MySQLSessionFactoryUtil.getSessionFactory().openSession();
    }

    private void closeSession() {
        if (session != null) {
            session.close();
        }
    }

    @Override
    public Integer getTotalCountByRunId(Long runId) throws OihPersistenceException {
        logger.debug("Trying to get count from the db");
        Integer totalCount = null;
        Transaction tx = null;
        try {
            openSession();
            tx = session.beginTransaction();
            Criteria cri = session.createCriteria(TargetInventoryLevel.class);
            cri.setProjection(Projections.rowCount());
            cri.add(Restrictions.eq("runID", runId));
            totalCount = (Integer) cri.list().get(0);
            tx.commit();
        } catch (HibernateException e) {
            e.printStackTrace();
            logger.error("Fail to query TargetInventoryLevel " + e);
            throw new OihPersistenceException(e);
        }
        return totalCount;
    }

    @Override
    public Integer getInvalidTILCountByRunId(Long runId) throws OihPersistenceException {
        logger.debug("Trying to get invalid data count from the db");
        Integer invalidDataCount = null;
        Transaction tx = null;
        try {
            openSession();
            tx = session.beginTransaction();
            Criteria cri = session.createCriteria(TargetInventoryLevel.class);
            cri.setProjection(Projections.rowCount());
            cri.add(Restrictions.eq("til", -1));
            cri.add(Restrictions.eq("runID", runId));
            invalidDataCount = (Integer) cri.list().get(0);
            tx.commit();
        } catch (HibernateException e) {
            e.printStackTrace();
            logger.error("Fail to query TargetInventoryLevel " + e);
            throw new OihPersistenceException(e);
        }
        return invalidDataCount;
    }

}