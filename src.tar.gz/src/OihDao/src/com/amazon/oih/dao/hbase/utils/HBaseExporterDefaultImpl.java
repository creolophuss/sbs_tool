 /**
  * Copyright (c) 2014 Amazon.com, Inc.  All rights reserved.
  * 
  * Owner: oih-cn@
  */
package com.amazon.oih.dao.hbase.utils;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import oih.config.ConfigFactory;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.GnuParser;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.hadoop.hbase.KeyValue;
import org.apache.hadoop.hbase.client.HTableInterface;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.client.ResultScanner;
import org.apache.hadoop.hbase.client.Scan;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import amazon.platform.config.AppConfig;
import amazon.platform.logging.AppConfigLog4jConfigurator;
import amazon.rest.collections.Iterables;

import com.amazon.oih.dao.hbase.schema.HBaseSchemaDao;
import com.amazon.oih.dao.hbase.schema.HBaseSchemaDaoImpl;
import com.amazon.oih.utils.GenericLineProcessor;
import com.amazon.oih.utils.IExporter;
import com.amazon.oih.utils.ILineProcessor;
import com.amazon.oih.utils.RevenueHBaseTableUtil;
import com.google.common.base.Splitter;
import com.google.common.collect.Lists;

/**
 * TODO: Right now it just support the Rowkey is also a column name case, and we do not parse the OIH HBase annotation 
 * yet. We'll need add this support later. 
 * @author gaoxing
 *
 */
public class HBaseExporterDefaultImpl implements IExporter<String> {
    protected static final String ROOT = "root";
    protected static final String DOMAIN = "domain";
    protected static final String OVERRIDE = "override";
    protected static final String REALM = "realm";
    protected static final String APPGROUP = "appgroup";
    protected static final String APP = "app";
    protected static final String TABLE = "table";
    protected static final String SPLITER = "spliter";
    protected static final String OUTPUT = "output";
    protected static final String UTF_8 = "UTF-8";
    protected static final String NEW_LINE = "\n";
    protected static final String EXCLUDED_COLS = "excluded_cols";
    protected static final String COMMA = ",";
    protected static Logger log = Logger.getLogger(HBaseSchemaDaoImpl.class);
    private List<String> excludedColList = null;

    @Override
    public void export(String entityName, String outputFilePath, ILineProcessor<String> lineProcessor) throws IOException {
        String tableName = entityName;
        HBaseSchemaDaoImpl.getInstance(ConfigFactory.getRealm(), RevenueHBaseTableUtil.RevenueTableSourceIdentity);
        HBaseSchemaDao schemaDao = HBaseSchemaDaoImpl.getInstance(ConfigFactory.getRealm(), null);
        if (schemaDao.tableExists(tableName) == false) {
            log("Table doesn't exist. Please double check your spell of table name " + tableName);
            return;
        }

        OutputStream outputStream = new FileOutputStream(new File(outputFilePath));
        OutputStreamWriter outputStreamWriter = new OutputStreamWriter(outputStream);
        BufferedWriter bufferedWriter = new BufferedWriter(outputStreamWriter);

        HTableInterface htable = schemaDao.getHtable(tableName);
        Scan paramScan = new Scan();
        ResultScanner resultScanner = htable.getScanner(paramScan);

        List<HBaseCol> columns = new ArrayList<HBaseCol>();
        List<String> rawDataList = new ArrayList<String>();
        excludedColList = getExcludedColList();

        int counter = 0;
        Result result = null;
        try {
            while ((result = resultScanner.next()) != null) {
                rawDataList.clear();
                if (columns.size() > 0) {
                    for (HBaseCol hbaseCol : columns) {
                        byte[] qualifier = hbaseCol.qualifier.getBytes("UTF-8");
                        byte[] val = result.getValue(hbaseCol.colFamily.getBytes("UTF-8"), qualifier);
                        rawDataList.add(buildDataLine(val));
                    }
                } else {
                    List<KeyValue> kvList = result.list();
                    for (KeyValue keyValue : kvList) {
                        String colFamily = new String(keyValue.getFamily(), UTF_8);
                        String qualifier = new String(keyValue.getQualifier(), UTF_8);
                        if (!excludedColList.contains(qualifier.toLowerCase())) {
                            columns.add(new HBaseCol(colFamily, qualifier));
                            rawDataList.add(buildFileHeader(colFamily, qualifier));
                            System.out.println(String.format("Column %s is included in export as the exclude col list is %s", qualifier, excludedColList));
                        } else {
                            System.out.println(String.format("Column %s is excluded from export", qualifier));
                        }
                    }
                }

                // Write each line
                bufferedWriter.write(lineProcessor.buildLine(rawDataList) + NEW_LINE);

                // Print progress in console
                if (++counter % 10000 == 0) {
                    System.out.println(String.format("Exported %d rows", counter));
                }
            }
            bufferedWriter.flush();
            System.out.println(String.format("Totally export %d rows", counter));
        } finally {
            IOUtils.closeQuietly(bufferedWriter);
        }

    }

    protected List<String> getExcludedColList() {
        if (excludedColList == null) {
            excludedColList = Lists.newArrayList();
        }
        return excludedColList;
    }

    protected String buildDataLine(byte[] val) throws UnsupportedEncodingException {
        String dataLine = "";
        if (val != null) {
            dataLine = new String(val, "UTF-8");
        }
        return dataLine;
    }

    protected String buildFileHeader(String colFamily, String qualifier) {
        return qualifier;
    }

    private void log(Object obj) {
        System.out.println(obj);
        log.info(obj);
    }

    class HBaseCol {
        String colFamily = null;
        String qualifier = null;

        public HBaseCol(String colFamily, String qualifier) {
            this.colFamily = colFamily;
            this.qualifier = qualifier;
        }
    }

    /**
     * @param args
     */
    public static void main(String[] args) {
        try {
            AppConfigLog4jConfigurator.configureForBootstrap();

            HBaseExporterDefaultImpl exporter = new HBaseExporterDefaultImpl();
            exporter.doMain(args);
        } catch (Exception e) {
            log.error("Exception", e);
            LogManager.shutdown();
            System.exit(1);
        }

        log.info("Finished export successfully");
        LogManager.shutdown();
        System.exit(0);
    }

    protected void doMain(String[] args) throws IOException {
        Options options = new Options();
        options.addOption("a", APP, true, "the App name");
        options.addOption("g", APPGROUP, true, "the AppGroup name");

        options.addOption("r", ROOT, true, "Path to brazil-config");
        options.addOption("d", DOMAIN, true, "test, prod...");
        options.addOption("l", REALM, true, "USAmazon, JPAmazon...");
        options.addOption("o", OVERRIDE, true, "Priority.cfg(complete path)");

        options.addOption("t", TABLE, true, "the target export table name");
        options.addOption("s", SPLITER, true, "the delimiter/spliter between columns");
        options.addOption("f", OUTPUT, true, "output file path");
        options.addOption("e", EXCLUDED_COLS, true, "excluded columns, split with comma, like \"seasons,brand_code\"");

        CommandLine cmd = null;
        try {
            CommandLineParser parser = new GnuParser();
            cmd = parser.parse(options, args);
        } catch (ParseException e) {
            e.printStackTrace();
            log.error("Failed to parse the command line", e);
            throw new RuntimeException("Failed to parse the command line", e);
        }

        validateInputOptions(cmd);
        if (StringUtils.isNotBlank(cmd.getOptionValue(EXCLUDED_COLS))) {
            Iterable<String> iterable = Splitter.on(COMMA).omitEmptyStrings().trimResults()
                    .split(cmd.getOptionValue(EXCLUDED_COLS).toLowerCase());
            excludedColList = Iterables.toList(iterable);
            System.out.println("excluded columns are " + excludedColList);
        }

        AppConfig.initialize(cmd.getOptionValue(APP), cmd.getOptionValue(APPGROUP), args);

        ILineProcessor<String> lineBuilder = new GenericLineProcessor(cmd.getOptionValue(SPLITER));
        this.export(cmd.getOptionValue(TABLE), cmd.getOptionValue(OUTPUT), lineBuilder);
    }

    protected void validateInputOptions(CommandLine cmd) {
        System.out.println("Target export table is " + cmd.getOptionValue("t"));
        System.out.println("Output file path is " + cmd.getOptionValue("f"));
        System.out.println("The delimiter between columns is " + cmd.getOptionValue("s"));
        
        if (StringUtils.isEmpty(cmd.getOptionValue(REALM))) {
            throw new IllegalArgumentException("realm can not be empty");
        } else {
            System.out.println("realm is " + cmd.getOptionValue(REALM));
        }

        if (StringUtils.isEmpty(cmd.getOptionValue(OVERRIDE))) {
            throw new IllegalArgumentException("Brazil override config file can not be empty");
        } else {
            System.out.println("Brazil override config file is " + cmd.getOptionValue(OVERRIDE));
        }

        if (StringUtils.isEmpty(cmd.getOptionValue(OUTPUT))) {
            throw new IllegalArgumentException("Output file path can not be empty");
        } else {
            System.out.println("Output file path is " + cmd.getOptionValue(OUTPUT));
        }

    }

}
