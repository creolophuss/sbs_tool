package com.amazon.oih.dao.hbase.markdowninfo;

import java.io.IOException;
import java.util.Collection;
import java.util.List;

import com.amazon.carbonado.Repository;
import com.amazon.oih.dao.exception.OihPersistenceException;
import com.amazon.oih.dao.hbase.base.HBaseDao;
import com.amazon.oih.dao.hbase.base.HBaseDaoImplAdaptor;
import com.amazon.oih.dao.markdowninfo.IMarkdownInfoDao;
import com.amazon.oih.dao.markdowninfo.MarkdownInfo;
import com.amazon.oih.utils.HBaseRowkeyUtil;

/**
 * Adapter wrapper for MarkdownInfoHBaseDao that let client access MarkdownInfoHBaseDao as IMarkdownInfoDao
 * 
 * @author xlpeng
 * 
 */
public class MarkdownInfoHBaseDaoWrapper implements HBaseDao<MarkdownInfo>, IMarkdownInfoDao {
    private HBaseDaoImplAdaptor<MarkdownInfo> markdownInfoHBaseDao;

    public MarkdownInfoHBaseDaoWrapper(HBaseDaoImplAdaptor<MarkdownInfo> markdownInfoHBaseDao) {
        this.markdownInfoHBaseDao = markdownInfoHBaseDao;
    }

    @Override
    public void save(List<MarkdownInfo> infos) throws OihPersistenceException {
        try {
            put(infos);
        } catch (IOException e) {
            throw new OihPersistenceException(e);
        }
    }

    @Override
    public void save(MarkdownInfo info) throws OihPersistenceException {
        try {
            putSingleElement(info);
        } catch (IOException e) {
            throw new OihPersistenceException(e);
        }
    }

    @Override
    public boolean exists(Long runId, String asin, long marketplaceId) throws OihPersistenceException {
        try {
            return exist(HBaseRowkeyUtil.getRowKeyBasedAsinMarketplace(asin, marketplaceId));
        } catch (IOException e) {
            throw new OihPersistenceException(e);
        }
    }

    @Override
    public MarkdownInfo find(Long runId, String asin, long marketplaceId) throws OihPersistenceException {
        try {
            return get(HBaseRowkeyUtil.getRowKeyBasedAsinMarketplace(asin, marketplaceId));
        } catch (IOException e) {
            throw new OihPersistenceException(e);
        }
    }

    @Override
    public MarkdownInfo createMarkdownInfo(Long runId, String asin, long marketplaceId, double recoveryRate,
            double demandIncrease, double demandIncreaseRate, String dataLevel, String dataVersion)
            throws OihPersistenceException {
        return new MarkdownInfo(runId, asin, (int) marketplaceId, demandIncrease, demandIncreaseRate, recoveryRate,
                dataVersion, dataLevel);
    }

    @Override
    public void setRepository(Repository repository) {
        // do nothing
    }

    public void putSingleElement(MarkdownInfo markdownInfo) throws IOException {
        markdownInfoHBaseDao.putSingleElement(markdownInfo);
    }

    public void put(List<MarkdownInfo> markdownInfos) throws IOException {
        markdownInfoHBaseDao.put(markdownInfos);
    }

    public MarkdownInfo get(String rowKey) throws IOException {
        return markdownInfoHBaseDao.get(rowKey);
    }

    public List<MarkdownInfo> get(Collection<String> rowKeys) throws IOException {
        return markdownInfoHBaseDao.get(rowKeys);
    }

    public boolean exist(String rowKey) throws IOException {
        return markdownInfoHBaseDao.exist(rowKey);
    }

    public boolean exist(String rowKey, String qualifier) throws IOException {
        return markdownInfoHBaseDao.exist(rowKey, qualifier);
    }

    public void deleteRow(String rowKey) throws IOException {
        markdownInfoHBaseDao.deleteRow(rowKey);
    }

    public void deleteRows(List<String> rowKeys) throws IOException {
        markdownInfoHBaseDao.deleteRows(rowKeys);
    }

    public void close() throws IOException {
        markdownInfoHBaseDao.close();
    }
}
