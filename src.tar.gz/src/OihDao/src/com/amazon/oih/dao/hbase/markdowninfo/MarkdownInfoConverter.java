package com.amazon.oih.dao.hbase.markdowninfo;

import static com.amazon.oih.dao.hbase.markdowninfo.MarkdownInfoHBaseDao.columnDataLevelBytes;
import static com.amazon.oih.dao.hbase.markdowninfo.MarkdownInfoHBaseDao.columnDataVersionBytes;
import static com.amazon.oih.dao.hbase.markdowninfo.MarkdownInfoHBaseDao.columnDemandIncreaseBytes;
import static com.amazon.oih.dao.hbase.markdowninfo.MarkdownInfoHBaseDao.columnDemandIncreaseRateBytes;
import static com.amazon.oih.dao.hbase.markdowninfo.MarkdownInfoHBaseDao.columnFamilyBytes;
import static com.amazon.oih.dao.hbase.markdowninfo.MarkdownInfoHBaseDao.columnRecoveryRateBytes;

import java.io.IOException;
import java.util.Collections;
import java.util.List;

import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.util.Bytes;

import com.amazon.oih.dao.hbase.base.Converter;
import com.amazon.oih.dao.markdowninfo.MarkdownInfo;
import com.amazon.oih.utils.HBaseRowkeyUtil;

/**
 * 
 * @author xlpeng
 * 
 */
@Deprecated
public class MarkdownInfoConverter implements Converter<MarkdownInfo> {

    @Override
    public MarkdownInfo convert(String rowKey, Result rs) throws IOException {
        if (rs != null && !rs.isEmpty()) {
            if (rowKey == null) {
                rowKey = Bytes.toString(rs.getRow());
            }
            MarkdownInfo markdownInfoObject = HBaseRowkeyUtil.parseMarkdownInfoRowKey(rowKey);
            markdownInfoObject.setDataLevel(Bytes.toString(rs.getValue(columnFamilyBytes, columnDataLevelBytes)));
            markdownInfoObject.setDataVersion(Bytes.toString(rs.getValue(columnFamilyBytes, columnDataVersionBytes)));
            markdownInfoObject.setDemandIncrease(Double.parseDouble(Bytes.toString(rs.getValue(columnFamilyBytes,
                    columnDemandIncreaseBytes))));
            markdownInfoObject.setDemandIncreaseRate(Double.parseDouble(Bytes.toString(rs.getValue(columnFamilyBytes,
                    columnDemandIncreaseRateBytes))));
            markdownInfoObject.setRecoveryRate(Double.parseDouble(Bytes.toString(rs.getValue(columnFamilyBytes,
                    columnRecoveryRateBytes))));
            return markdownInfoObject;
        }
        return null;
    }

    @Override
    public List<Put> convert(MarkdownInfo markdownInfo) throws IOException {
        byte[] rowKey = Bytes.toBytes(getRowKey(markdownInfo));

        Put put = new Put(rowKey);
        put.add(columnFamilyBytes, columnDemandIncreaseBytes,
                Bytes.toBytes(Double.toString(markdownInfo.getDemandIncrease())));
        put.add(columnFamilyBytes, columnDemandIncreaseRateBytes,
                Bytes.toBytes(Double.toString(markdownInfo.getDemandIncreaseRate())));
        put.add(columnFamilyBytes, columnRecoveryRateBytes,
                Bytes.toBytes(Double.toString(markdownInfo.getRecoveryRate())));
        put.add(columnFamilyBytes, columnDataLevelBytes, Bytes.toBytes(markdownInfo.getDataLevel()));
        put.add(columnFamilyBytes, columnDataVersionBytes, Bytes.toBytes(markdownInfo.getDataVersion()));

        return Collections.nCopies(1, put);
    }

    @Override
    public MarkdownInfo convert(Result rs) throws IOException {
        return convert(null, rs);
    }

    @Override
    public String getRowKey(MarkdownInfo markdownInfo) {
        return HBaseRowkeyUtil.getRowKeyBasedAsinMarketplace(markdownInfo.getAsin(), markdownInfo.getMarketplaceId());
    }
}
