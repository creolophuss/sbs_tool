package com.amazon.oih.dao.forecastnew;

import java.io.Serializable;
import java.util.Date;

import com.amazon.oih.dao.forecast.ForecastType;

public class ForecastNewDataBaseObject implements ForecastNew, Serializable {
    private static final long serialVersionUID = 1L;
	private String asin;
	private int iog;
	private String realm;
	private Date runDate;
	private double probability;
    private double week1;
    private double week2;
    private double week3;
    private double week4;
    private double week5;
    private double week6;
    private double week7;
    private double week8;
    private double week9;
    private double week10;
    private double week11;
    private double week12;
    private double week13;
    private double week14;
    private double week15;
    private double week16;
    private double week17;
    private double week18;
    private double week19;
    private double week20;
    private double week21;
    private double week22;
    private double week23;
    private double week24;
    private double week25;
    private double week26;
    private double week27;
    private double week28;
    private double week29;
    private double week30;
    private double week31;
    private double week32;
    private double week33;
    
	public long getRunID() {
		throw new UnsupportedOperationException();
	}

	public void setRunID(long runID) {
		throw new UnsupportedOperationException();
	}
	
	public String getRealm() {
		return realm;
	}

	public void setRealm(String realm) {
		this.realm = realm;
	}

	public Date getRunDate(){
		return runDate;
	}
	
	public void setRunDate(Date runDate){
		this.runDate = runDate;
	}
	
	public String getAsin() {
		return asin;
	}
	public void setAsin(String asin) {
		this.asin = asin;
	}
	public int getIog() {
		return iog;
	}
	public void setIog(int iog) {
		this.iog = iog;
	}
	public String getType() {
		throw new UnsupportedOperationException();
	}
	public void setType(String type) {
		throw new UnsupportedOperationException();
	}
	public double getProbability() {
		return probability;
	}
	public void setProbability(double probability) {
		this.probability = probability;
	}
	public double getWeek1() {
		return week1;
	}
	public void setWeek1(double week1) {
		this.week1 = week1;
	}
	public double getWeek2() {
		return week2;
	}
	public void setWeek2(double week2) {
		this.week2 = week2;
	}
	public double getWeek3() {
		return week3;
	}
	public void setWeek3(double week3) {
		this.week3 = week3;
	}
	public double getWeek4() {
		return week4;
	}
	public void setWeek4(double week4) {
		this.week4 = week4;
	}
	public double getWeek5() {
		return week5;
	}
	public void setWeek5(double week5) {
		this.week5 = week5;
	}
	public double getWeek6() {
		return week6;
	}
	public void setWeek6(double week6) {
		this.week6 = week6;
	}
	public double getWeek7() {
		return week7;
	}
	public void setWeek7(double week7) {
		this.week7 = week7;
	}
	public double getWeek8() {
		return week8;
	}
	public void setWeek8(double week8) {
		this.week8 = week8;
	}
	public double getWeek9() {
		return week9;
	}
	public void setWeek9(double week9) {
		this.week9 = week9;
	}
	public double getWeek10() {
		return week10;
	}
	public void setWeek10(double week10) {
		this.week10 = week10;
	}
	public double getWeek11() {
		return week11;
	}
	public void setWeek11(double week11) {
		this.week11 = week11;
	}
	public double getWeek12() {
		return week12;
	}
	public void setWeek12(double week12) {
		this.week12 = week12;
	}
	public double getWeek13() {
		return week13;
	}
	public void setWeek13(double week13) {
		this.week13 = week13;
	}
	public double getWeek14() {
		return week14;
	}
	public void setWeek14(double week14) {
		this.week14 = week14;
	}
	public double getWeek15() {
		return week15;
	}
	public void setWeek15(double week15) {
		this.week15 = week15;
	}
	public double getWeek16() {
		return week16;
	}
	public void setWeek16(double week16) {
		this.week16 = week16;
	}
	public double getWeek17() {
		return week17;
	}
	public void setWeek17(double week17) {
		this.week17 = week17;
	}
	public double getWeek18() {
		return week18;
	}
	public void setWeek18(double week18) {
		this.week18 = week18;
	}
	public double getWeek19() {
		return week19;
	}
	public void setWeek19(double week19) {
		this.week19 = week19;
	}
	public double getWeek20() {
		return week20;
	}
	public void setWeek20(double week20) {
		this.week20 = week20;
	}
	public double getWeek21() {
		return week21;
	}
	public void setWeek21(double week21) {
		this.week21 = week21;
	}
	public double getWeek22() {
		return week22;
	}
	public void setWeek22(double week22) {
		this.week22 = week22;
	}
	public double getWeek23() {
		return week23;
	}
	public void setWeek23(double week23) {
		this.week23 = week23;
	}
	public double getWeek24() {
		return week24;
	}
	public void setWeek24(double week24) {
		this.week24 = week24;
	}
	public double getWeek25() {
		return week25;
	}
	public void setWeek25(double week25) {
		this.week25 = week25;
	}
	public double getWeek26() {
		return week26;
	}
	public void setWeek26(double week26) {
		this.week26 = week26;
	}
	public double getWeek27() {
		return week27;
	}
	public void setWeek27(double week27) {
		this.week27 = week27;
	}
	public double getWeek28() {
		return week28;
	}
	public void setWeek28(double week28) {
		this.week28 = week28;
	}
	public double getWeek29() {
		return week29;
	}
	public void setWeek29(double week29) {
		this.week29 = week29;
	}
	public double getWeek30() {
		return week30;
	}
	public void setWeek30(double week30) {
		this.week30 = week30;
	}
	public double getWeek31() {
		return week31;
	}
	public void setWeek31(double week31) {
		this.week31 = week31;
	}
	public double getWeek32() {
		return week32;
	}
	public void setWeek32(double week32) {
		this.week32 = week32;
	}
	public double getWeek33() {
		return week33;
	}
	public void setWeek33(double week33) {
		this.week33 = week33;
	}
	@Override
	public ForecastType getForecastType() {
		return ForecastType.valueOf(getType());
	}
	@Override
	public void setForecastType(ForecastType t) {
		setType(t.name());
	}
}
