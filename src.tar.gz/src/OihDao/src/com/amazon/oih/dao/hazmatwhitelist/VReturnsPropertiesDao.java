package com.amazon.oih.dao.hazmatwhitelist;

import java.util.List;

import org.hibernate.SessionFactory;

/**
 * Interface for VReturnsProperties DAO
 * 
 */
public interface VReturnsPropertiesDao {
    /**
     * 
     * @param sessionFactory
     */
    public void setSessionFactory(SessionFactory sessionFactory);

    /**
     * Inserts or updates the given property into the database.
     * 
     * @param property
     *            the property to be saved
     */
    public void save(final VReturnsProperties property);

    /**
     * Deletes the given property from the database.
     * 
     * @param property
     *            the property to be deleted
     * 
     */
    public void delete(final VReturnsProperties property);

    /**
     * Finds property by id.
     * 
     * @param id
     * @return a <code>VReturnsProperties</code> object
     */
    public VReturnsProperties find(Long id);

    /**
     * Finds property by category and type. When category and type not specified, return all properties.
     * 
     * @param category
     *            property category
     * @param type
     *            property type
     * @return a list of <code>VReturnsProperties</code> object
     */
    public List<VReturnsProperties> find(String category, String type);
}
