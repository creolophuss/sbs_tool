package com.amazon.oih.dao.hbase.schema;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang.StringUtils;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.HColumnDescriptor;
import org.apache.hadoop.hbase.HRegionInfo;
import org.apache.hadoop.hbase.HTableDescriptor;
import org.apache.hadoop.hbase.MasterNotRunningException;
import org.apache.hadoop.hbase.ZooKeeperConnectionException;
import org.apache.hadoop.hbase.client.HBaseAdmin;
import org.apache.hadoop.hbase.client.HTableInterface;
import org.apache.hadoop.hbase.client.HTablePool;
import org.apache.hadoop.hbase.io.hfile.Compression;
import org.apache.hadoop.hbase.io.hfile.Compression.Algorithm;
import org.apache.hadoop.hbase.util.Bytes;
import org.apache.log4j.Logger;

import com.amazon.oih.dao.DaoConstants;
import com.google.common.base.Joiner;
import com.google.common.collect.Lists;

import amazon.platform.config.AppConfig;


public class HBaseSchemaDaoImpl implements HBaseSchemaDao {
    private static final char DOT = '.';

    private static Logger log = Logger.getLogger(HBaseSchemaDaoImpl.class);

    private final int POOL_MAX_SIZE = 200;
    private static volatile Map<String, HBaseSchemaDao> hbaseSchemaDaoMap = new HashMap<String, HBaseSchemaDao>();
    private Configuration hbaseConfig;
    private HTablePool htablePool;
    private Configuration conf;
    private HBaseAdmin admin;

    protected String realm = null;

    private static final String HBASE_CONFIG_OVERRIDE_MAP = "HBase.Config.Override.SourceIdentity";
    public static final String DEFAULT_SOURCE_IDENTITY = "Default";

    public HBaseSchemaDaoImpl(String realm, String sourceIdentity) throws MasterNotRunningException,
            ZooKeeperConnectionException {
        hbaseConfig = new Configuration();
        hbaseConfig.addResource("conf/apollo-hbase-default.xml");
        conf = HBaseConfiguration.create(hbaseConfig);
        updateHBaseConfig(conf, sourceIdentity);
        admin = new HBaseAdmin(conf);
        htablePool = new HTablePool(conf, POOL_MAX_SIZE);

        Runtime.getRuntime().addShutdownHook(new Thread() {
            public void run() {
                try {
                    htablePool.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

        this.realm = realm;
    }

    protected void updateHBaseConfig(Configuration hbaseConfig, String sourceIdentity) {
        log.info("Overriding hbase config for source " + sourceIdentity + "...");
        try {
            @SuppressWarnings("unchecked")
            Map<String, String> overrideHBaseConfigs = (Map<String, String>) AppConfig
                    .findMap(HBASE_CONFIG_OVERRIDE_MAP + "." + sourceIdentity);
            if (overrideHBaseConfigs == null) {
                log.info("No override found.");
                return;
            }
            for (Entry<String, String> override : overrideHBaseConfigs.entrySet()) {
                String key = override.getKey();
                String value = override.getValue();
                try {
                    String origValue = hbaseConfig.get(key);
                    log.info("Overriding " + key + " from " + origValue + " to " + value);
                    if (value != null) {
                        hbaseConfig.set(key, value);
                        log.info("Overried HBase config " + key + " to " + value);
                    }
                } catch (Exception ex) {
                    log.error("Overriding HBase config failure", ex);
                    continue;
                }
            }
        } catch (Exception ex) {
        } finally {
            log.info("Finished overriding hbase config");
        }
    }

    /**
     * The keyWord volatile before hbaseSchemaDao makes sure that this DCL(double-check-locking) work.
     * 
     * @param realm
     * @return
     */
    public static synchronized HBaseSchemaDao getInstance(String realm, String sourceIdentity) {
        if (StringUtils.isEmpty(sourceIdentity)) {
            sourceIdentity = DEFAULT_SOURCE_IDENTITY;
        }
        HBaseSchemaDao hbaseSchemaDao = hbaseSchemaDaoMap.get(sourceIdentity);
        if (hbaseSchemaDao == null) {
            try {
                if (hbaseSchemaDao == null) {
                    hbaseSchemaDao = new HBaseSchemaDaoImpl(realm, sourceIdentity);
                    hbaseSchemaDaoMap.put(sourceIdentity, hbaseSchemaDao);
                }
            } catch (MasterNotRunningException ex) {
                ex.printStackTrace();
                throw new RuntimeException("Fail to get HBase DAO Instance: MasterNotRunningException", ex);
            } catch (ZooKeeperConnectionException ex) {
                ex.printStackTrace();
                throw new RuntimeException("Fail to get HBase DAO Instance: ZooKeeperConnectionException", ex);
            }
        }
        return hbaseSchemaDao;
    }

    @Override
    public HTableInterface getHtable(String tableName) {
        HTableInterface table = htablePool.getTable(tableName);
        table.setAutoFlush(false);
        return table;
    }

    @Override
    public void createHTable(String tableName, String[] columnFamilies) throws IOException {
        if (tableExists(tableName)) {
            throw new RuntimeException("Table " + tableName + " has existed.");
        }
        HTableDescriptor htdesc = new HTableDescriptor(tableName);
        for (String columnFamily : columnFamilies) {
            HColumnDescriptor hColDescriptor = new HColumnDescriptor(columnFamily);
            if (isCompressEnabled(tableName, columnFamily)) {
                String compressionTypeName = getCompressionTypeName(tableName, columnFamily);
                Algorithm compressionType = Compression.getCompressionAlgorithmByName(compressionTypeName);
                hColDescriptor.setCompressionType(compressionType); // Enable the column family compression
            }
            htdesc.addFamily(hColDescriptor);
        }
        admin.createTable(htdesc);
    }
        
    public void createHTable(String tableName, String[] columnFamilies, String[] splitKeys) throws IOException {
        if (tableExists(tableName)) {
            throw new RuntimeException("Table " + tableName + " has existed.");
        }
        HTableDescriptor htdesc = new HTableDescriptor(tableName);
        for (String columnFamily : columnFamilies) {
            htdesc.addFamily(new HColumnDescriptor(columnFamily));
        }
        admin.createTable(htdesc, Bytes.toByteArrays(splitKeys));
    }    

    /**
     * Find the column family's compression type which can be configured in the Brazil configuration. 
     * If you do not specify the compression codec, it will use the gzip by default.
     * 
     * @param keyString
     * @return
     */
    private String getCompressionTypeName(String tableName, String cfName) {
        // Default codec use gzip, it's better to use the Snappy in future
        String defaultCodec = AppConfig.findString(DaoConstants.HBASE_CF_COMPRESSION_CODEC, Algorithm.GZ.getName());
        String codecKey = Joiner.on(DOT).join(DaoConstants.HBASE_CF_COMPRESSION_CODEC, tableName, cfName);
        String compressionTypeName = AppConfig.findString(codecKey, defaultCodec);

        return compressionTypeName;
    }

    private boolean isCompressEnabled(String tableName, String cfName) {
        Boolean globalCompressionEnableStatus = AppConfig.findBoolean(DaoConstants.HBASE_CF_COMPRESSION_ENABLED, true);
        String cfKey = Joiner.on(DOT).join(DaoConstants.HBASE_CF_COMPRESSION_ENABLED, tableName, cfName);
        Boolean value = AppConfig.findBoolean(cfKey, globalCompressionEnableStatus); // By default we enable the compression
        return value.booleanValue();
    }

    @Override
    public void recreateHTable(String tableName, String[] columnFamilies) throws IOException {
        if (tableExists(tableName)) {
            log("Table " + tableName + " exists. deleting... ");
            deleteHTable(tableName);
        }
        log("Creating table " + tableName + "...");
        createHTable(tableName, columnFamilies);
        log("Table " + tableName + " created.");
    }

    @Override
    public void deleteHTable(String tableName) throws IOException {
        if (!tableExists(tableName)) {
            throw new RuntimeException("Table " + tableName + " does NOT exist.");
        }
        try {
            if(admin.isTableEnabled(tableName)){
                admin.disableTable(tableName);                
            }
            admin.deleteTable(tableName);
        } catch (MasterNotRunningException e) {
            e.printStackTrace();
        } catch (ZooKeeperConnectionException e) {
            e.printStackTrace();
        }
    }

    @Override
    public boolean tableExists(String tableName) throws IOException {
        return admin.tableExists(tableName);
    }

    public void setAdmin(HBaseAdmin admin) {
        this.admin = admin;
    }

    public HBaseAdmin getAdmin() {
        return admin;
    }

    private static void log(Object msg) {
        log.info(msg);
        System.out.println(msg);
    }

    @Override
    synchronized public void createHTableIfNotExisted(String tableName, String columnFamily) throws IOException {
        if (!tableExists(tableName)) {
            String[] families = {
                columnFamily
            };
            createHTable(tableName, families);
        }
    }
    
    @Override
    public List<String> getHtableColumnFamilies(String tableName) throws IOException{
        if (!tableExists(tableName)) {
            throw new IOException("Table " + tableName + " does NOT exist.");
        }
        HTableInterface htable = this.getHtable(tableName);
        List<String> cfs = new ArrayList<String>();
        for(byte[] cf : htable.getTableDescriptor().getFamiliesKeys()){
            cfs.add(Bytes.toString(cf));
        }
        return cfs;
    }
    
    @Override
    public List<String> getHtableRegionSplitKeys(String tableName) throws IOException{
        if (!tableExists(tableName)) {
            throw new IOException("Table " + tableName + " does NOT exist.");
        }
        List<HRegionInfo> regions = admin.getTableRegions(Bytes.toBytes(tableName));
        List<String> splitKeys = new ArrayList<String>();
        for(HRegionInfo region : regions){
            if(region.getStartKey().length > 0){
                splitKeys.add(Bytes.toString(region.getStartKey()));
            }            
        }
        return splitKeys;
    }
    
    @Override
    public List<String> listHtableNames() throws IOException{
         HTableDescriptor[] tables = admin.listTables();
         List<String> tableNames = Lists.newArrayList();
         for(HTableDescriptor td : tables){
             tableNames.add(Bytes.toString(td.getName()));
         } 
         return tableNames;
    }
    
}
