package com.amazon.oih.dao.unsellable.damagedvrds;

import java.util.Date;

import com.amazon.carbonado.Alias;
import com.amazon.carbonado.AlternateKeys;
import com.amazon.carbonado.Key;
import com.amazon.carbonado.Nullable;
import com.amazon.carbonado.PrimaryKey;
import com.amazon.carbonado.Sequence;
import com.amazon.carbonado.Storable;
import com.amazon.carbonado.constraint.FloatConstraint;
import com.amazon.carbonado.constraint.IntegerConstraint;
import com.amazon.carbonado.constraint.LengthConstraint;

@Alias("damaged_vrds_item")
@PrimaryKey("id")
@AlternateKeys( {
    @Key( {
            "fnsku", "fcsku", "iog", "warehouse", "condition", "distributorShipmentItemId"
    })
})
public abstract class DamagedVRDSItem implements Storable<DamagedVRDSItem> {
    @Sequence("id")
    public abstract long getId();

    public abstract void setId(long id);

    public abstract String getFnsku();

    @LengthConstraint(min = 10, max = 10)
    public abstract void setFnsku(String fnsku);

    public abstract String getFcsku();

    @LengthConstraint(min = 0, max = 10)
    public abstract void setFcsku(String fcsku);

    public abstract int getIog();

    @IntegerConstraint(min = 1, max = Integer.MAX_VALUE)
    public abstract void setIog(int iog);

    public abstract String getDestVendor();

    @LengthConstraint(min = 0, max = 5)
    public abstract void setDestVendor(String vendor);

    @Nullable
    public abstract String getSourceVendor();

    @LengthConstraint(min = 0, max = 5)
    public abstract void setSourceVendor(String vendor);

    public abstract String getWarehouse();

    @LengthConstraint(min = 0, max = 4)
    public abstract void setWarehouse(String warehouse);

    public abstract String getDisposition();

    public abstract void setDisposition(String disposition);

    public abstract String getCondition();

    public abstract void setCondition(String condition);

    public abstract long getQuantity();

    @IntegerConstraint(min = 0, max = Long.MAX_VALUE)
    public abstract void setQuantity(long quantity);

    @Nullable
    public abstract String getBaseCurrencyCode();

    public abstract void setBaseCurrencyCode(String currencyCode);

    @Nullable
    public abstract String getRefundBasicCode();

    public abstract void setRefundBasicCode(String refundBasicCode);

    public abstract double getCost();

    @FloatConstraint(min = 0.0, max = Float.MAX_VALUE)
    public abstract void setCost(double cost);

    public abstract double getRefundAmount();

    @FloatConstraint(min = 0.0, max = Float.MAX_VALUE)
    public abstract void setRefundAmount(double refundAmount);

    @Nullable
    public abstract Boolean getIsAuthorizationRequired();

    public abstract void setIsAuthorizationRequired(Boolean isAuthorizationRequired);

    @Nullable
    public abstract String getOpenAuthorizationNumber();
    
    public abstract void setOpenAuthorizationNumber(String openAuthorizationNumber);
    
    @Nullable
    public abstract Integer getReturnByMinDays();

    @IntegerConstraint(min = 0, max = Integer.MAX_VALUE)
    public abstract void setReturnByMinDays(Integer returnByMinDays);

    @Nullable
    public abstract Integer getReturnByMaxDays();

    @IntegerConstraint(min = 0, max = Integer.MAX_VALUE)
    public abstract void setReturnByMaxDays(Integer returnByMaxDays);

    @Nullable
    public abstract String getVRDSDescription();

    public abstract void setVRDSDescription(String description);
    
    @Nullable
    @Alias("dsi_id")
    public abstract Long getDistributorShipmentItemId();

    public abstract void setDistributorShipmentItemId(Long dsi_Id);

    @Nullable
    public abstract Date getDistributorOrderDate();

    public abstract void setDistributorOrderDate(Date distributorOrderDate);

    @Nullable
    public abstract String getDistributorId();

    public abstract void setDistributorId(String distributorId);

    @Nullable
    public abstract String getDistributorOrderId();

    public abstract void setDistributorOrderId(String distributorOrderId);

    @Nullable
    public abstract Long getDistributorOrderType();

    public abstract void setDistributorOrderType(Long distributorOrderId);

    @Nullable
    public abstract String getDistributorShipmentId();

    public abstract void setDistributorShipmentId(String distributorShipmentId);

    @Nullable
    public abstract Date getShipmentReceiveDate();

    public abstract void setShipmentReceiveDate(Date shipmentReceiveDate);

    @Nullable
    public abstract Double getPrice();

    public abstract void setPrice(Double price);
    
    @Nullable
    public abstract String getForeignCurrencyCode();
    
    public abstract void setForeignCurrencyCode(String ForeignCurrencyCode);
    
    public abstract double getCostForeignCurrency();
    
    @FloatConstraint(min = 0.0, max = Float.MAX_VALUE)
    public abstract void setCostForeignCurrency(double costForeignCurrency);
    
    public abstract double getRefundAmountForeignCurrency();
    
    @FloatConstraint(min = 0.0, max = Float.MAX_VALUE)
    public abstract void setRefundAmountForeignCurrency(double refundAmountForeignCurrency);

    public abstract double getDistributorCostForeignCurrency();
    
    @FloatConstraint(min = 0.0, max = Float.MAX_VALUE)
    public abstract void setDistributorCostForeignCurrency(double distributorCostForeignCurrency);
    
    public abstract double getDistributorListPriceForeignCurrency();

    @FloatConstraint(min = 0.0, max = Float.MAX_VALUE)
    public abstract void setDistributorListPriceForeignCurrency(double distributorListPriceForeignCurrency);
 
}
