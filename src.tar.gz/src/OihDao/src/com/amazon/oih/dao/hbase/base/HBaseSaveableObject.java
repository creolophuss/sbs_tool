package com.amazon.oih.dao.hbase.base;

public abstract class HBaseSaveableObject<HBASE_OBJ_TYPE extends AsinScopeValueHBaseObject<?>> {

    public abstract HBASE_OBJ_TYPE toHBaseObject();
   
}
