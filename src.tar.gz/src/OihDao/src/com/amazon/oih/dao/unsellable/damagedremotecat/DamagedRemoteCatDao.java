package com.amazon.oih.dao.unsellable.damagedremotecat;

import java.util.List;

import amazon.platform.profiler.Profiler;
import amazon.platform.profiler.ProfilerScope;

import com.amazon.carbonado.ConfigurationException;
import com.amazon.carbonado.FetchException;
import com.amazon.carbonado.IsolationLevel;
import com.amazon.carbonado.PersistException;
import com.amazon.carbonado.Repository;
import com.amazon.carbonado.RepositoryException;
import com.amazon.carbonado.Storage;
import com.amazon.carbonado.Transaction;
import com.amazon.oih.dao.exception.DaoRuntimeException;
import com.amazon.oih.dao.exception.OihPersistenceException;
import com.amazon.oih.dao.remotecat.RemoteCatValueObject;

public class DamagedRemoteCatDao implements IDamagedRemoteCatDao {
    protected String domain = null;
    protected Repository repository = null;

    public DamagedRemoteCatDao(String domain) {
        this.domain = domain;
    }

    public void setRepository(Repository repository) {
        if (null == repository) {
            throw new IllegalArgumentException("repository is null");
        }
        this.repository = repository;
    }

    @Override
    public DamagedRemoteCatObject createRemoteCat(RemoteCatValueObject valueObject) throws OihPersistenceException{
        ProfilerScope scope = Profiler.scopeStart(this.getClass().getName() + "::create");
        try {
            Storage<DamagedRemoteCatObject> sRemoteCat = repository.storageFor(DamagedRemoteCatObject.class);
            DamagedRemoteCatObject myRemoteCat = sRemoteCat.prepare();
            setValues(myRemoteCat, valueObject);
            return myRemoteCat;

        } catch (ConfigurationException e) {
            throw new DaoRuntimeException(e);
        } catch (RepositoryException e) {
            throw new OihPersistenceException(e);
        } finally {
            Profiler.scopeEnd(scope);
        }
    }

    private void setValues(DamagedRemoteCatObject myRemoteCat, RemoteCatValueObject valueObject) {
        myRemoteCat.setAsin(valueObject.getAsin());
        myRemoteCat.setIog(valueObject.getIog());
        myRemoteCat.setBinding(valueObject.getBinding());
        myRemoteCat.setBrandName(valueObject.getBrandName());
        myRemoteCat.setBrandCode(valueObject.getBrandCode());
        myRemoteCat.setCategory(valueObject.getCategory());
        myRemoteCat.setEan(valueObject.getEan());
        myRemoteCat.setGl(valueObject.getGl());
        myRemoteCat.setHazmatException(valueObject.getHazmatException());
        myRemoteCat.setHazmatItem(valueObject.isHazmatItem());
        myRemoteCat.setHazmatTransportationRegularClass(valueObject.getHazmatTransportationRegularClass());
        myRemoteCat.setMapRequired(valueObject.getMapRequired());
        myRemoteCat.setUnPrepRequired(valueObject.isUnPrepRequired());
        myRemoteCat.setListPrice(valueObject.getListPrice());
        myRemoteCat.setMapEndDate(valueObject.getMapEndDate());
        myRemoteCat.setMapPrice(valueObject.getMapPrice());
        myRemoteCat.setMapStrict(valueObject.getMapStrict());
        myRemoteCat.setMapStrictPrice(valueObject.getMapStrictPrice());
        myRemoteCat.setModelNumber(valueObject.getModelNumber());
        myRemoteCat.setOurPrice(valueObject.getOurPrice());
        myRemoteCat.setParentAsin(valueObject.getParentAsin());
        myRemoteCat.setPublicationDate(valueObject.getPublicationDate());
        myRemoteCat.setPublisherCode(valueObject.getPublisherCode());
        myRemoteCat.setReleaseDate(valueObject.getReleaseDate());
        myRemoteCat.setReplenishmentCategory(valueObject.getReplenishmentCategory());
        myRemoteCat.setSeasons(valueObject.getSeasons());
        myRemoteCat.setSiteLaunchDate(valueObject.getSiteLaunchDate());
        myRemoteCat.setSourceCountryCode(valueObject.getSourceCountryCode());
        myRemoteCat.setSubCategory(valueObject.getSubCategory());
        myRemoteCat.setTextbookType(valueObject.getTextbookType());
        myRemoteCat.setTitle(valueObject.getTitle());
        myRemoteCat.setUpc(valueObject.getUpc());
    }

    @Override
    public boolean exists(String asin, int iog) throws OihPersistenceException {
        ProfilerScope scope = Profiler.scopeStart(this.getClass().getName() + "::existsWithVendor");

        try {
            Storage<DamagedRemoteCatObject> sf = repository.storageFor(DamagedRemoteCatObject.class);
            boolean retVal = sf.query("asin = ? & iog = ? ").with(asin).with(iog).exists();

            return retVal;
        } catch (ConfigurationException e) {
            throw new DaoRuntimeException(e);
        } catch (RepositoryException e) {
            throw new OihPersistenceException(e);
        } finally {
            Profiler.scopeEnd(scope);
        }

    }

    @Override
    public DamagedRemoteCatObject find(String asin, int iog) throws OihPersistenceException {
        ProfilerScope scope = Profiler.scopeStart(this.getClass().getName() + "::find");

        try {
            Storage<DamagedRemoteCatObject> sf = repository.storageFor(DamagedRemoteCatObject.class);
            return sf.query("asin = ? & iog = ? ").with(asin).with(iog).loadOne();
        } catch (FetchException e) {// find nothing from the DB
            return null;
        } catch (Exception e) {
            throw new OihPersistenceException(e);
        } finally {
            Profiler.scopeEnd(scope);
        }
    }

    @Override
    public void save(List<DamagedRemoteCatObject> remoteCats) throws OihPersistenceException {
        Transaction txn = repository.enterTransaction(IsolationLevel.READ_UNCOMMITTED);
        try {
            for (DamagedRemoteCatObject remoteCat : remoteCats) {
                if (!remoteCat.tryLoad()) {
                    remoteCat.insert();
                }
            }

            txn.commit();
        } catch (PersistException e) {
            throw new OihPersistenceException(e);
        } catch (Exception e) {
            throw new DaoRuntimeException(e);
        } finally {
            exitTransaction(txn);
        }
    }

    @Override
    public void save(DamagedRemoteCatObject remoteCat) throws OihPersistenceException {
        ProfilerScope scope = Profiler.scopeStart(this.getClass().getName() + "::save");
        try {
            remoteCat.insert();
        } catch (PersistException e) {
            throw new OihPersistenceException(e);
        } finally {
            Profiler.scopeEnd(scope);
        }
    }

    private void exitTransaction(Transaction txn) throws OihPersistenceException {
        try {
            txn.exit();
        } catch (PersistException e) {
            throw new OihPersistenceException(e);
        }
    }
}