package com.amazon.oih.dao.inventorysourcingcost;

import java.util.Collection;
import java.util.List;

import com.amazon.oih.dao.exception.OihPersistenceException;

public interface InventorySourcingCostDao {

    void save(InventorySourcingCost cost) throws OihPersistenceException;;

    void save(List<InventorySourcingCost> costs) throws OihPersistenceException;

    boolean exists(Long runId, String asin, String scopeId) throws OihPersistenceException;

    InventorySourcingCost findOne(Long runId, String asin, String scopeId) throws OihPersistenceException;

    List<InventorySourcingCost> findList(Long runId, Collection<String> asins, Collection<String> scopeIds)
            throws OihPersistenceException;

    void delete(InventorySourcingCost cost) throws OihPersistenceException;

    void delete(List<InventorySourcingCost> costs) throws OihPersistenceException;

    void deleteAll() throws OihPersistenceException;

}
