package com.amazon.oih.dao.targetInvLevel;

import java.io.Serializable;

public class TargetInventoryLevel implements Serializable {
    private static final long serialVersionUID = 1L;
    private long runID;
    private String asin;
    private int iog;
    private int til;
    private int cartonQty;
    private boolean nonIpcResponsible = false;
    private int idealTIL;
    private int minROL;

    public TargetInventoryLevel(long runID, String asin, int iog, int til, int cartonQty) {
        this.runID = runID;
        this.asin = asin;
        this.iog = iog;
        this.til = til;
        this.cartonQty = cartonQty;
    }

    public TargetInventoryLevel(long runID, String asin, int iog, int til, int cartonQty, int idealTIL, int minROL) {
        this(runID, asin, iog, til, cartonQty);
        this.idealTIL = idealTIL;
        this.minROL = minROL;
    }

    public TargetInventoryLevel() {

    }

    public void setRunID(long runID) {
        this.runID = runID;
    }

    public long getRunID() {
        return runID;
    }

    public void setAsin(String asin) {
        this.asin = asin;
    }

    public String getAsin() {
        return asin;
    }

    public void setIog(int iog) {
        this.iog = iog;
    }

    public int getIog() {
        return iog;
    }

    public void setTil(int til) {
        this.til = til;
    }

    public int getTil() {
        return til;
    }

    public void setCartonQty(int cartonQty) {
        this.cartonQty = cartonQty;
    }

    public int getCartonQty() {
        return cartonQty;
    }
    
    public void setNonIpcResponsible(boolean nonIpcResponsible){
    	this.nonIpcResponsible = nonIpcResponsible;
    }
    
    public boolean isNonIpcResponsible(){
    	return this.nonIpcResponsible;
    }

    public int getIdealTIL() {
        return idealTIL;
    }

    public void setIdealTIL(int idealTIL) {
        this.idealTIL = idealTIL;
    }

    public int getMinROL() {
        return minROL;
    }

    public void setMinROL(int minROL) {
        this.minROL = minROL;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof TargetInventoryLevel == false) {
            return false;
        }
        if (this == obj) {
            return true;
        }

        TargetInventoryLevel other = (TargetInventoryLevel) obj;

        return this.asin.equals(other.getAsin()) && this.iog == other.getIog() && this.til == other.getTil()
                && this.cartonQty == other.getCartonQty() && this.idealTIL == other.getIdealTIL()
                        && this.minROL == other.getMinROL() && this.runID == other.getRunID();
    }

    @Override
    public String toString() {
        return asin + "|" + iog + ":[" + til + "," + cartonQty + "," + nonIpcResponsible + "]";
    }

    @Override
    public int hashCode() {
        final int prime = 127; // changed from default - 31 is a lame prime #
        int result = 1;
        result = prime * result + ((asin == null) ? 0 : asin.hashCode());
        result = prime * result + iog;
        result = prime * result + (int) runID;
        return result;
    }
}
