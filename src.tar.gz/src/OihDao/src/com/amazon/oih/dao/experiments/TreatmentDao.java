package com.amazon.oih.dao.experiments;

import com.amazon.oih.dao.exception.OihPersistenceException;

public interface TreatmentDao {
    public Treatment createTreatment(long runId, int experimentId, int iog, String asin) throws OihPersistenceException;

    public void save(Treatment treatment) throws OihPersistenceException;

    public boolean exists(long runID, int experimentId, int iog, String asin) throws OihPersistenceException;

}
