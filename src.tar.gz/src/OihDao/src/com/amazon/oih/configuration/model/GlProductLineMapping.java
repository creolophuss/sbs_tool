package com.amazon.oih.configuration.model;

import java.io.Serializable;

public class GlProductLineMapping implements Serializable {
    private static final long serialVersionUID = 1L;
    private int gl;
    private String org;
    private String productLine;

    public GlProductLineMapping(int gl, String org, String productLine) {
        super();
        this.gl = gl;
        this.org = org;
        this.productLine = productLine;
    }

    public GlProductLineMapping() {
    }

    public int getGl() {
        return gl;
    }

    public void setGl(int gl) {
        this.gl = gl;
    }

    public String getOrg() {
        return org;
    }

    public void setOrg(String org) {
        this.org = org;
    }

    public String getProductLine() {
        return productLine;
    }

    public void setProductLine(String productLine) {
        this.productLine = productLine;
    }
}
