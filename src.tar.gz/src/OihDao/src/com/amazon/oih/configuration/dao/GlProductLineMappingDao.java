package com.amazon.oih.configuration.dao;

import java.util.List;

import com.amazon.oih.configuration.model.GlProductLineMapping;

public interface GlProductLineMappingDao {
    void save(GlProductLineMapping mapping);

    void save(List<GlProductLineMapping> mappings);

    void delete(GlProductLineMapping mapping);

    List<GlProductLineMapping> findAll(String org);

    List<GlProductLineMapping> findAll();
}
