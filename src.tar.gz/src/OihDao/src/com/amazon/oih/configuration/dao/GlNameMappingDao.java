package com.amazon.oih.configuration.dao;

import java.util.List;

import com.amazon.oih.configuration.model.GlNameMapping;

public interface GlNameMappingDao {
    void save(GlNameMapping mapping);

    void save(List<GlNameMapping> mappings);

    void delete(GlNameMapping mapping);

    List<GlNameMapping> findAll(String org);

    List<GlNameMapping> findAll();
}
