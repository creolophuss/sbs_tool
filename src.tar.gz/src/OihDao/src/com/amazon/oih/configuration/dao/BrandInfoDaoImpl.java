package com.amazon.oih.configuration.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.classic.Session;

import com.amazon.oih.configuration.model.*;
import com.amazon.oih.dao.base.BaseDaoImpl;


public class BrandInfoDaoImpl extends BaseDaoImpl<BrandInfo> implements BrandInfoDao {

    @Override
    public void save(BrandInfo brandInfo) {
        super.saveOrUpdate(brandInfo);
    }

    @Override
    public void save(List<BrandInfo> brandInfos) {
        super.saveOrUpdate(brandInfos);
    }

    @Override
    public List<BrandInfo> findAll() {        
        return super.findAll(BrandInfo.class);
    }


    @Override
    public List<BrandInfo> findAll(String realm) {
        try {
            Session session = getSessionFactory().getCurrentSession();
            @SuppressWarnings("unchecked")
            List<BrandInfo> infos = (List<BrandInfo>)session.getNamedQuery("BrandInfo.findByRealm")
                    .setParameter("realm", realm ).list();
            return infos;
        } catch (HibernateException e) {
            throw new RuntimeException("hibernate exception in BrandInfo.findByRealm for realm: " + realm, e);
        } 
    }
    
    @Override
    public List<String> findByType(String realm, String type) {
        try {
            Session session = getSessionFactory().getCurrentSession();  
            @SuppressWarnings("unchecked")
            List<String> infos = (List<String>)session.getNamedQuery("BrandInfo.findByType")
                    .setParameter("type", type)
                    .setParameter("realm", realm).list();
            return infos;
        } catch (HibernateException e) {
            throw new RuntimeException("hibernate exception in BrandInfo.findByType for type: " + type, e);
        } 
    }

}
