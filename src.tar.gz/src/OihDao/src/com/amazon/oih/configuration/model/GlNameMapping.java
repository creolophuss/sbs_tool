package com.amazon.oih.configuration.model;

import java.io.Serializable;

public class GlNameMapping implements Serializable {
    private static final long serialVersionUID = 1L;
    private int gl;
    private String org;
    private String name;

    public GlNameMapping(int gl, String org, String name) {
        super();
        this.gl = gl;
        this.org = org;
        this.name = name;
    }

    public GlNameMapping() {
    }

    public int getGl() {
        return gl;
    }

    public void setGl(int gl) {
        this.gl = gl;
    }

    public String getOrg() {
        return org;
    }

    public void setOrg(String org) {
        this.org = org;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
