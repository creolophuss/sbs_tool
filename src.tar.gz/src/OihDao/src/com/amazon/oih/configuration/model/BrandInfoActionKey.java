package com.amazon.oih.configuration.model;

public enum BrandInfoActionKey {
	/**
	 * the default value for each key should not be null.
	 */
    WOC_BASED_TIP_FACTOR("20");
    
    private BrandInfoActionKey(String defaultValue){
    	this.defaultValue = defaultValue;
    }
    private String defaultValue;
    
    public String getDefaultValue(){
    	return defaultValue;
    }
}
