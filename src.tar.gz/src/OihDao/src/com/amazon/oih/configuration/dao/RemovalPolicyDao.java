package com.amazon.oih.configuration.dao;

import java.util.List;

import com.amazon.oih.configuration.model.RemovalPolicy;

public interface RemovalPolicyDao {
    
    void save(RemovalPolicy policy);

    void save(List<RemovalPolicy> policies);

    void delete(RemovalPolicy policy);

    List<RemovalPolicy> findAll(String org);

    List<RemovalPolicy> findAll();

}
