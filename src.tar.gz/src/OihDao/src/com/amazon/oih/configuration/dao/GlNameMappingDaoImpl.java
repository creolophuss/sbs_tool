package com.amazon.oih.configuration.dao;

import java.util.ArrayList;
import java.util.List;

import com.amazon.oih.configuration.model.GlNameMapping;
import com.amazon.oih.dao.base.BaseDaoImpl;

public class GlNameMappingDaoImpl extends BaseDaoImpl<GlNameMapping> implements GlNameMappingDao {
    public void delete(GlNameMapping mapping) {
        super.delete(mapping);
    }

    public List<GlNameMapping> findAll(String org) {
        List<GlNameMapping> mappings = new ArrayList<GlNameMapping>();
        for (GlNameMapping map : findAll()) {
            if (org.equalsIgnoreCase(map.getOrg())) {
                mappings.add(map);
            }
        }
        return mappings;
    }

    public List<GlNameMapping> findAll() {
        return super.findAll(GlNameMapping.class);
    }

    public void save(GlNameMapping mapping) {
        super.saveOrUpdate(mapping);
    }

    @Override
    public void save(List<GlNameMapping> mappings) {
        super.saveOrUpdate(mappings);
    }
}
