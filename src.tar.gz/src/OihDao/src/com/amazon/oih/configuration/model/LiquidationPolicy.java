package com.amazon.oih.configuration.model;

import java.io.Serializable;

public class LiquidationPolicy implements Serializable {
    private static final long serialVersionUID = 1L;
    private int iog;
    private int gl;
    private String org;
    private String vendor;
    private String priceType;
    private double value;
    private int perOrderCap;

    public LiquidationPolicy() {
    }

    public LiquidationPolicy(int iog, int gl, String org, String vendor, String priceType, double value, int perOrderCap) {
        super();
        this.iog = iog;
        this.gl = gl;
        this.org = org;
        this.vendor = vendor;
        this.priceType = priceType;
        this.value = value;
        this.perOrderCap = perOrderCap;
        this.org = org;
    }

    public int getIog() {
        return iog;
    }

    public void setIog(int iog) {
        this.iog = iog;
    }

    public int getGl() {
        return gl;
    }

    public void setGl(int gl) {
        this.gl = gl;
    }

    public String getVendor() {
        return vendor;
    }

    public void setVendor(String vendor) {
        this.vendor = vendor;
    }

    public String getPriceType() {
        return priceType;
    }

    public void setPriceType(String priceType) {
        this.priceType = priceType;
    }

    public double getValue() {
        return value;
    }

    public void setValue(double value) {
        this.value = value;
    }

    public int getPerOrderCap() {
        return perOrderCap;
    }

    public void setPerOrderCap(int perOrderCap) {
        this.perOrderCap = perOrderCap;
    }

    public void setOrg(String org) {
        this.org = org;
    }

    public String getOrg() {
        return org;
    }

    public boolean match(int gl, int iog) {
        return (this.gl == gl && this.iog == iog);
    }
}
