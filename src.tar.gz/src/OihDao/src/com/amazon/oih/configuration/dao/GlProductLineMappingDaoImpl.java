package com.amazon.oih.configuration.dao;

import java.util.ArrayList;
import java.util.List;

import com.amazon.oih.configuration.model.GlProductLineMapping;
import com.amazon.oih.dao.base.BaseDaoImpl;

public class GlProductLineMappingDaoImpl extends BaseDaoImpl<GlProductLineMapping> implements GlProductLineMappingDao {
    @Override
    public void save(GlProductLineMapping mapping) {
        super.saveOrUpdate(mapping);
    }

    @Override
    public void delete(GlProductLineMapping mapping) {
        super.delete(mapping);
    }

    @Override
    public List<GlProductLineMapping> findAll(String org) {
        List<GlProductLineMapping> mappings = new ArrayList<GlProductLineMapping>();
        for (GlProductLineMapping map : findAll()) {
            if (org.equalsIgnoreCase(map.getOrg())) {
                mappings.add(map);
            }
        }
        return mappings;
    }

    @Override
    public List<GlProductLineMapping> findAll() {
        return findAll(GlProductLineMapping.class);
    }

    @Override
    public void save(List<GlProductLineMapping> mappings) {
        super.saveOrUpdate(mappings);
    }
}
