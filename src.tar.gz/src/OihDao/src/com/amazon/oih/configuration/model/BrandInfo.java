package com.amazon.oih.configuration.model;

import java.io.Serializable;

public class BrandInfo implements Serializable{

    private static final long serialVersionUID = -3393264908230036489L;
    
    private String id;

    private String realm;
    
    private String brandCode;
    
    private String brandType;
    
    private String  actionKey;
    
    private String actionValue;
    
    public BrandInfo(){
        super();
    }
    
    public BrandInfo(String realm, String brandId, String brandType, String actionKey, String actionValue) {
        super();
        this.realm = realm;
        this.brandCode = brandId;
        this.brandType = brandType;
        this.actionKey = actionKey;
        this.actionValue = actionValue;
    }
    
    
    public String getId() {
        return id;
    }

    protected void setId( String id ) {
        this.id = id;
    }
    
    public String getRealm() {
        return realm;
    }

    public void setRealm(String realm) {
        this.realm = realm;
    }

    public String getBrandCode() {
        return brandCode;
    }

    public void setBrandCode(String brandId) {
        this.brandCode = brandId;
    }

    public String getBrandType() {
        return brandType;
    }

    public void setBrandType(String brandType) {
        this.brandType = brandType;
    }

    public String getActionKey() {
        return actionKey;
    }

    public void setActionKey(String actionKey) {
        this.actionKey = actionKey;
    }

    public String getActionValue() {
        return actionValue;
    }

    public void setActionValue(String actionValue) {
        this.actionValue = actionValue;
    }

}
