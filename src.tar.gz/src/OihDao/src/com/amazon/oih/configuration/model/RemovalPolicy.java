package com.amazon.oih.configuration.model;

import java.io.Serializable;

public class RemovalPolicy implements Serializable {
    private static final long serialVersionUID = 1L;
    private int iog;
    private int gl;
    private String policyType;
    private int value;
    private String warehouse;
    private String orderType;
    private String org;

    public RemovalPolicy(int iog, int gl, String policyType, int value, String warehouse, String orderType, String org) {
        super();
        this.iog = iog;
        this.gl = gl;
        this.policyType = policyType;
        this.value = value;
        this.warehouse = warehouse;
        this.orderType = orderType;
        this.org = org;
    }

    public RemovalPolicy() {

    }

    public int getIog() {
        return iog;
    }

    public void setIog(int iog) {
        this.iog = iog;
    }

    public int getGl() {
        return gl;
    }

    public void setGl(int gl) {
        this.gl = gl;
    }

    public String getPolicyType() {
        return policyType;
    }

    public void setPolicyType(String policyType) {
        this.policyType = policyType;
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }

    public String getWarehouse() {
        return warehouse;
    }

    public void setWarehouse(String warehouse) {
        this.warehouse = warehouse;
    }

    public String getOrderType() {
        return orderType;
    }

    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }

    public void setOrg(String org) {
        this.org = org;
    }

    public String getOrg() {
        return org;
    }
}
