package com.amazon.oih.configuration.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.StatelessSession;
import org.hibernate.Transaction;

import com.amazon.oih.configuration.model.LiquidationPolicy;
import com.amazon.oih.dao.base.BaseDaoImpl;

public class LiquidationPolicyDaoImpl extends BaseDaoImpl<LiquidationPolicy> implements LiquidationPolicyDao {

    @Override
    public void delete(LiquidationPolicy policy) {
        super.delete(policy);
    }

    @Override
    public List<LiquidationPolicy> findAll(String org) {
        List<LiquidationPolicy> mappings = new ArrayList<LiquidationPolicy>();
        for (LiquidationPolicy policy : findAll()) {
            if (org.equalsIgnoreCase(policy.getOrg())) {
                mappings.add(policy);
            }
        }
        return mappings;
    }

    @Override
    public List<LiquidationPolicy> findAll() {
        return findAll(LiquidationPolicy.class);
    }

    @Override
    public void save(LiquidationPolicy policy) {
        super.saveOrUpdate(policy);
    }

    @Override
    public void save(List<LiquidationPolicy> policies) {
        super.saveOrUpdate(policies);
    }
}
