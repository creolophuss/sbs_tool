package com.amazon.oih.configuration.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.amazon.oih.configuration.model.LiquidationPolicy;
import com.amazon.oih.configuration.model.RemovalPolicy;
import com.amazon.oih.dao.base.BaseDaoImpl;

public class RemovalPolicyDaoImpl extends BaseDaoImpl<RemovalPolicy> implements RemovalPolicyDao {

    @Override
    public void delete(RemovalPolicy policy) {
        super.delete(policy);
    }

    @Override
    public List<RemovalPolicy> findAll(String org) {
        List<RemovalPolicy> policies = new ArrayList<RemovalPolicy>();
        for (RemovalPolicy policy : findAll()) {
            if (org.equalsIgnoreCase(policy.getOrg())) {
                policies.add(policy);
            }
        }
        return policies;
    }

    @Override
    public List<RemovalPolicy> findAll() {
        return findAll(RemovalPolicy.class);
    }

    @Override
    public void save(RemovalPolicy policy) {
        super.saveOrUpdate(policy);
    }

    @Override
    public void save(List<RemovalPolicy> policies) {
        super.saveOrUpdate(policies);
    }

}
