package com.amazon.oih.configuration.dao;

import java.util.List;

import com.amazon.oih.configuration.model.*;

public interface BrandInfoDao {
    
    void save(BrandInfo brandInfo);

    void save(List<BrandInfo> brandInfos);

    void delete(BrandInfo brandInfo);

    List<BrandInfo> findAll();
    
    List<BrandInfo> findAll(String realm);

    List<String> findByType(String realm, String type);    

}
