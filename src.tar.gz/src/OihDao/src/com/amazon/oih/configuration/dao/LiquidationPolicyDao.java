package com.amazon.oih.configuration.dao;

import java.util.List;

import com.amazon.oih.configuration.model.LiquidationPolicy;

public interface LiquidationPolicyDao {
    
    void save(LiquidationPolicy policy);

    void save(List<LiquidationPolicy> policies);

    void delete(LiquidationPolicy policy);

    List<LiquidationPolicy> findAll(String org);

    List<LiquidationPolicy> findAll();
    
}
