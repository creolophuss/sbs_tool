package com.amazon.oih.costs;

import static org.hibernate.criterion.Restrictions.eq;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import org.apache.commons.beanutils.PropertyUtils;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.amazon.oih.common.KVDao;
import com.amazon.oih.costs.GLCostDetail;
import com.amazon.oih.dao.exception.OihPersistenceException;
import com.google.common.annotations.VisibleForTesting;
import com.google.common.collect.Lists;


public class VendorFCsDaoImpl implements VendorFCsDao, KVDao<VendorFCs>{
    private final static Logger logger = Logger.getLogger(VendorFCsDaoImpl.class);
    private final SessionFactory sessionFactory;
    public VendorFCsDaoImpl(SessionFactory sessionFactory){
        this.sessionFactory = sessionFactory;
    }
    
    @Override
    @SuppressWarnings("unchecked")
    public List<VendorFCs> loadAll(String realm) throws OihPersistenceException{
        Session session = null;
        try {
            session = openSession();
            List<VendorFCs> result = session.createCriteria(VendorFCs.class)
                                         .add(eq("realm", realm))
                                         .setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY)
                                         .list();
            if (result == null){
                return Collections.emptyList();
            }
            return convertAllToVendorFCs(result);
        } catch (RuntimeException e) {
            logger.error("Failed to load entity " + logger + " with exception ", e);
            throw new OihPersistenceException(e);
        } finally {
            closeSession(session);
        }
    }
    

    @Override
    public void saveAll(Collection<VendorFCs> all, Collection<VendorFCs> changed) throws OihPersistenceException {
        save(constructChangedDBInstance(all, changed));       
    }
    
    @Override
    public void save(Collection<VendorFCs> os) throws OihPersistenceException {
        Transaction tx = null;
        Session session = null;
        try {
            session = openSession();
            tx = session.beginTransaction();
            for (VendorFCs o : os){
                session.saveOrUpdate(o);
            }
            tx.commit();
        } catch (RuntimeException e) {
            logger.error("Failed to save entities " + os + " with exception ", e);
            e.printStackTrace();
            if (tx != null) {
                tx.rollback();
            }
            throw new OihPersistenceException(e);
        } finally {
            closeSession(session);
        }
    }

    @Override
    public void save(VendorFCs o) throws OihPersistenceException {
        Transaction tx = null;
        Session session = null;
        try {
            session = openSession();
            tx = session.beginTransaction();
            session.saveOrUpdate(o);
            tx.commit();
        } catch (RuntimeException e) {
            logger.error("Failed to save entity " + o + " with exception ", e);
            e.printStackTrace();
            if (tx != null) {
                tx.rollback();
            }
            throw new OihPersistenceException(e);
        } finally {
            closeSession(session);
        }
    }
    
    private Session openSession() {
        return sessionFactory.openSession();
    }

    private void closeSession(Session session) {
        if (session != null) {
            session.close();
        }
    }

    @Override
    public String getPhysicalId(VendorFCs fc) {
        return fc.getId();
    }
    
    public static List<VendorFCs> convertAllToVendorFCs(Collection<VendorFCs> dbInstances){
        List<VendorFCs> result = new ArrayList<VendorFCs>();
        for (VendorFCs fc : dbInstances){
            result.add(fc);
            if (fc.getDetailedCostsList4GLs() != null && fc.getDetailedCostsList4GLs().size() != 0){
                result.addAll(convertToVendorFCs(fc.getDetailedCostsList4GLs(), fc));
            }
        }
        return result;
    }
    
    private static List<VendorFCs> convertToVendorFCs(Collection<GLCostDetail> costDetails, VendorFCs fc){
        List<VendorFCs> result = new ArrayList<VendorFCs>();
        for (GLCostDetail detail : costDetails){
            VendorFCs fcFormatObj = new VendorFCs();
            try {
                PropertyUtils.copyProperties(fcFormatObj, fc);
                PropertyUtils.copyProperties(fcFormatObj, detail);
            } catch (Exception e) {
                throw new RuntimeException("copy property error for " + detail, e);
            }
            result.add(fcFormatObj);
        }
        return result;
    }
    
    @VisibleForTesting
    public static List<VendorFCs> constructChangedDBInstance(Collection<VendorFCs> all, Collection<VendorFCs> changed){
        Set<String> changedFCId = new HashSet<String>();
        List<VendorFCs> changedFCCosts = new ArrayList<VendorFCs>();       
        List<VendorFCs> changedGlDetails = new ArrayList<VendorFCs>();
        for (VendorFCs costs : changed){
            if (costs.getGl() != null){               
                changedGlDetails.add(costs);
            } else {
                if (costs.getId() == null){
                    throw new RuntimeException("Not allowd to insert VendrFCs instance!!!" + costs);
                }
                changedFCId.add(costs.getId());
                changedFCCosts.add(costs);
            }            
        }
        for (VendorFCs glDetail : changedGlDetails){
            List<VendorFCs> found = findFCByIdentityNoGL(all, glDetail);
            if (found.size() == 0){
                throw new RuntimeException("Could not find VendorFCs record for this GLdetail:" + glDetail);
            }
            for (VendorFCs fc : found){
                updateGLDetails(fc, glDetail);
                if (!changedFCId.contains(fc.getId())){
                    changedFCCosts.add(fc);
                }
            }
        }
        return changedFCCosts;
    }
    
    private static void updateGLDetails(VendorFCs fc, VendorFCs glDetail){
        List<GLCostDetail> glDetails= findByGL(fc, glDetail.getGl());
        if (glDetails == null || glDetails.size() == 0){
            GLCostDetail toInsert = new GLCostDetail();
            glDetails = Lists.newArrayList(toInsert);
            fc.addDetailedCost(toInsert);
        }

        for (GLCostDetail toUpdate : glDetails){
            try {
                PropertyUtils.copyProperties(toUpdate, glDetail);
                if (toUpdate.getId() == null){
                    toUpdate.setId(UUID.randomUUID().toString());
                }
            } catch (Exception e) {
                throw new RuntimeException("copy property error for " + glDetail, e);
            }
        }
    }
    
    private static List<GLCostDetail> findByGL(VendorFCs fc, long gl){
        if (fc.getDetailedCostsList4GLs() == null || fc.getDetailedCostsList4GLs().size() == 0){
            return null;
        }
        List<GLCostDetail> matched = new ArrayList<GLCostDetail>();
        for (GLCostDetail currentGlDetail : fc.getDetailedCostsList4GLs()){
            if (currentGlDetail.getGl() == gl){
                matched.add(currentGlDetail);
            }
        }
        return matched;
    }
    
    private static List<VendorFCs> findFCByIdentityNoGL(Collection<VendorFCs> all, VendorFCs glDetails){
        List<VendorFCs> result = new ArrayList<VendorFCs>();
        for (VendorFCs fc : all){
            if (fc.getGl() == null && fc.getIdentityNoGL().equals(glDetails.getIdentityNoGL())){
                result.add(fc);
            }
        }
        return result;
    }
}
