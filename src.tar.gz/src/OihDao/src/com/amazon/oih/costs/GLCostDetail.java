package com.amazon.oih.costs;

import javax.persistence.Embeddable;
import javax.persistence.Column;


/**
 * This is a value class, it do not has IOG and Marketplace as it identity, so it could be used to update any Marketplace/IOG's
 * same FC/GL's holdingCost.
 * 
 * @author jialei
 *
 */
@Embeddable
public class GLCostDetail {    
    @Column(name = "id", nullable = false)
    private String id;
    
    @Column(name = "warehouse_id", nullable = false)
    private String warehouseId;
    
    @Column(name = "gl", nullable = false)
    private Long gl;    
    
    @Column(name = "receiptcost_estimates")
    private Double receiptCost;
    
    @Column(name = "removalcost_estimates")
    private Double removalCost;
    
    @Column(name = "holdingcost_est")
    private Double holdingCost;
    
    @Column(name = "transportion_in_estimate")
    private Double transferInCost;
    
    @Column(name = "transportion_out_estimate")
    private Double transferOutCost;
    
    @Column(name = "destroy_return_estimate")
    private Double destroyReturnEstimate;
    
    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }

    public String getWarehouseId() {
        return warehouseId;
    }
    public void setWarehouseId(String warehouseId) {
        this.warehouseId = warehouseId;
    }
    public Long getGl() {
        return gl;
    }
    public void setGl(Long gl) {
        this.gl = gl;
    }
    public Double getReceiptCost() {
        return receiptCost;
    }
    public void setReceiptCost(Double receiptCost) {
        this.receiptCost = receiptCost;
    }
    public Double getRemovalCost() {
        return removalCost;
    }
    public void setRemovalCost(Double removalCost) {
        this.removalCost = removalCost;
    }
    public Double getHoldingCost() {
        return holdingCost;
    }
    public void setHoldingCost(Double holdingCost) {
        this.holdingCost = holdingCost;
    }
    public Double getTransferInCost() {
        return transferInCost;
    }
    public void setTransferInCost(Double transferInCost) {
        this.transferInCost = transferInCost;
    }
    public Double getTransferOutCost() {
        return transferOutCost;
    }
    public void setTransferOutCost(Double transferOutCost) {
        this.transferOutCost = transferOutCost;
    }
    public Double getDestroyReturnEstimate() {
        return destroyReturnEstimate;
    }
    public void setDestroyReturnEstimate(Double destroyReturnEstimate) {
        this.destroyReturnEstimate = destroyReturnEstimate;
    }
    
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((destroyReturnEstimate == null) ? 0 : destroyReturnEstimate.hashCode());
        result = prime * result + ((gl == null) ? 0 : gl.hashCode());
        result = prime * result + ((holdingCost == null) ? 0 : holdingCost.hashCode());
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        result = prime * result + ((receiptCost == null) ? 0 : receiptCost.hashCode());
        result = prime * result + ((removalCost == null) ? 0 : removalCost.hashCode());
        result = prime * result + ((transferInCost == null) ? 0 : transferInCost.hashCode());
        result = prime * result + ((transferOutCost == null) ? 0 : transferOutCost.hashCode());
        result = prime * result + ((warehouseId == null) ? 0 : warehouseId.hashCode());
        return result;
    }
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        GLCostDetail other = (GLCostDetail) obj;
        if (destroyReturnEstimate == null) {
            if (other.destroyReturnEstimate != null)
                return false;
        } else if (!destroyReturnEstimate.equals(other.destroyReturnEstimate))
            return false;
        if (gl == null) {
            if (other.gl != null)
                return false;
        } else if (!gl.equals(other.gl))
            return false;
        if (holdingCost == null) {
            if (other.holdingCost != null)
                return false;
        } else if (!holdingCost.equals(other.holdingCost))
            return false;
        if (id == null) {
            if (other.id != null)
                return false;
        } else if (!id.equals(other.id))
            return false;
        if (receiptCost == null) {
            if (other.receiptCost != null)
                return false;
        } else if (!receiptCost.equals(other.receiptCost))
            return false;
        if (removalCost == null) {
            if (other.removalCost != null)
                return false;
        } else if (!removalCost.equals(other.removalCost))
            return false;
        if (transferInCost == null) {
            if (other.transferInCost != null)
                return false;
        } else if (!transferInCost.equals(other.transferInCost))
            return false;
        if (transferOutCost == null) {
            if (other.transferOutCost != null)
                return false;
        } else if (!transferOutCost.equals(other.transferOutCost))
            return false;
        if (warehouseId == null) {
            if (other.warehouseId != null)
                return false;
        } else if (!warehouseId.equals(other.warehouseId))
            return false;
        return true;
    }
    @Override
    public String toString() {
        return "GLCostDetail [id=" + id + ", warehouseId=" + warehouseId + ", gl=" + gl + ", receiptCost=" + receiptCost
                + ", removalCost=" + removalCost + ", holdingCost=" + holdingCost + ", transferInCost=" + transferInCost + ", transferOutCost="
                + transferOutCost + ", destroyReturnEstimate=" + destroyReturnEstimate + "]";
    }
}
