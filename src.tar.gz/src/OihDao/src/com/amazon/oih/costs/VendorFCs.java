package com.amazon.oih.costs;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.amazon.oih.common.Identifiable;
import com.amazon.oih.common.KeyValueBase.NamedValue;
import com.amazon.oih.common.KVFormater.FileColumnNames;
import com.amazon.oih.costs.GLCostDetail;

@Entity
@Table(name = "VENDOR_FCS")
@FileColumnNames(value = {"MarketplaceId", "IOG", "WarehouseId", "GL", "ReceiptCost", "RemovalCost", "HoldingCost", "TransferInCost", 
        "TransferOutCost", "DestroyReturnEstimate"})
public class VendorFCs implements Identifiable{
    @Id
    @Column(name = "id", nullable = false)
    private String id;
    
    @NamedValue("WarehouseId")
    @Column(name = "warehouse_id", nullable = false)
    private String warehouseId;
    
    @NamedValue("MarketplaceId")
    @Column(name = "marketplace_id", nullable = false)
    private Long marketplaceId;
    
    @NamedValue("IOG")
    @Column(name = "iog")
    private Long iog;
    
    @Transient
    @NamedValue("GL")
    private Long gl;
    
    @NamedValue("ReceiptCost")
    @Column(name = "receiptcost_estimates")
    private Double receiptCost;
    
    @NamedValue("RemovalCost")
    @Column(name = "removalcost_estimates")
    private Double removalCost;
    
    @NamedValue("HoldingCost")
    @Column(name = "holdingcost_est")
    private Double holdingCost;
    
    @NamedValue("TransferInCost")
    @Column(name = "transportion_in_estimate")
    private Double transferInCost;
    
    @NamedValue("TransferOutCost")
    @Column(name = "transportion_out_estimate")
    private Double transferOutCost;
    
    @NamedValue("DestroyReturnEstimate")
    @Column(name = "destroy_return_estimate")
    private Double destroyReturnEstimate;
    
    @Column(name = "realm")
    private String realm;

    @org.hibernate.annotations.CollectionOfElements(fetch = FetchType.EAGER)
    @JoinTable(
        name = "FC_GL_COST",
        joinColumns = @JoinColumn(name = "warehouse_index")
    )
    private Set<GLCostDetail> detailedCostsList4GLs;
    
    public void addDetailedCost(GLCostDetail detailCost){
        if (detailedCostsList4GLs == null){
            detailedCostsList4GLs = new HashSet<GLCostDetail>();
        }
        detailedCostsList4GLs.add(detailCost);
    }
    
    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }
    public String getRealm() {
        return realm;
    }

    public void setRealm(String realm) {
        this.realm = realm;
    }

    public String getWarehouseId() {
        return warehouseId;
    }
    public void setWarehouseId(String warehouseId) {
        this.warehouseId = warehouseId;
    }
    public Long getMarketplaceId() {
        return marketplaceId;
    }
    public void setMarketplaceId(Long marketplaceId) {
        this.marketplaceId = marketplaceId;
    }
    public Long getIog() {
        return iog;
    }
    public void setIog(Long iog) {
        this.iog = iog;
    }
    public Long getGl() {
        return gl;
    }
    public void setGl(Long gl) {
        this.gl = gl;
    }
    /*public Boolean getIsValid() {
        return isValid;
    }
    public void setIsValid(Boolean isValid) {
        this.isValid = isValid;
    }*/
    public Double getReceiptCost() {
        return receiptCost;
    }
    public void setReceiptCost(Double receiptCost) {
        this.receiptCost = receiptCost;
    }
    public Double getRemovalCost() {
        return removalCost;
    }
    public void setRemovalCost(Double removalCost) {
        this.removalCost = removalCost;
    }
    public Double getHoldingCost() {
        return holdingCost;
    }
    public void setHoldingCost(Double holdingCost) {
        this.holdingCost = holdingCost;
    }
    public Double getTransferInCost() {
        return transferInCost;
    }
    public void setTransferInCost(Double transferInCost) {
        this.transferInCost = transferInCost;
    }
    public Double getTransferOutCost() {
        return transferOutCost;
    }
    public void setTransferOutCost(Double transferOutCost) {
        this.transferOutCost = transferOutCost;
    }
    public Double getDestroyReturnEstimate() {
        return destroyReturnEstimate;
    }
    public void setDestroyReturnEstimate(Double destroyReturnEstimate) {
        this.destroyReturnEstimate = destroyReturnEstimate;
    }
    public Set<GLCostDetail> getDetailedCostsList4GLs() {
        return detailedCostsList4GLs;
    }
    public void setDetailedCostsList4GLs(Set<GLCostDetail> detailedCostsList4GLs) {
        this.detailedCostsList4GLs = detailedCostsList4GLs;
    }

    @Override
    public String toString() {
        return "VendorFCs [id=" + id + ", warehouseId=" + warehouseId + ", marketplaceId=" + marketplaceId + ", iog=" + iog + ", gl=" + gl + ", receiptCost="
                + receiptCost + ", removalCost=" + removalCost + ", holdingCost=" + holdingCost + ", transferInCost=" + transferInCost + ", transferOutCost="
                + transferOutCost + ", destroyReturnEstimate=" + destroyReturnEstimate + ", realm=" + realm + "]";
    }

    @Override
    public String getIdentity() {
        return "" + marketplaceId + "|" + iog + "|" + warehouseId + "|" + gl;
    }
    
    public String getIdentityNoGL() {
        return "" + marketplaceId + "|" + iog + "|" + warehouseId;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((destroyReturnEstimate == null) ? 0 : destroyReturnEstimate.hashCode());
        result = prime * result + ((gl == null) ? 0 : gl.hashCode());
        result = prime * result + ((holdingCost == null) ? 0 : holdingCost.hashCode());
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        result = prime * result + ((iog == null) ? 0 : iog.hashCode());
        result = prime * result + ((marketplaceId == null) ? 0 : marketplaceId.hashCode());
        result = prime * result + ((realm == null) ? 0 : realm.hashCode());
        result = prime * result + ((receiptCost == null) ? 0 : receiptCost.hashCode());
        result = prime * result + ((removalCost == null) ? 0 : removalCost.hashCode());
        result = prime * result + ((transferInCost == null) ? 0 : transferInCost.hashCode());
        result = prime * result + ((transferOutCost == null) ? 0 : transferOutCost.hashCode());
        result = prime * result + ((warehouseId == null) ? 0 : warehouseId.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        VendorFCs other = (VendorFCs) obj;
        if (destroyReturnEstimate == null) {
            if (other.destroyReturnEstimate != null)
                return false;
        } else if (!destroyReturnEstimate.equals(other.destroyReturnEstimate))
            return false;
        if (gl == null) {
            if (other.gl != null)
                return false;
        } else if (!gl.equals(other.gl))
            return false;
        if (holdingCost == null) {
            if (other.holdingCost != null)
                return false;
        } else if (!holdingCost.equals(other.holdingCost))
            return false;
        if (id == null) {
            if (other.id != null)
                return false;
        } else if (!id.equals(other.id))
            return false;
        if (iog == null) {
            if (other.iog != null)
                return false;
        } else if (!iog.equals(other.iog))
            return false;
        if (marketplaceId == null) {
            if (other.marketplaceId != null)
                return false;
        } else if (!marketplaceId.equals(other.marketplaceId))
            return false;
        if (realm == null) {
            if (other.realm != null)
                return false;
        } else if (!realm.equals(other.realm))
            return false;
        if (receiptCost == null) {
            if (other.receiptCost != null)
                return false;
        } else if (!receiptCost.equals(other.receiptCost))
            return false;
        if (removalCost == null) {
            if (other.removalCost != null)
                return false;
        } else if (!removalCost.equals(other.removalCost))
            return false;
        if (transferInCost == null) {
            if (other.transferInCost != null)
                return false;
        } else if (!transferInCost.equals(other.transferInCost))
            return false;
        if (transferOutCost == null) {
            if (other.transferOutCost != null)
                return false;
        } else if (!transferOutCost.equals(other.transferOutCost))
            return false;
        if (warehouseId == null) {
            if (other.warehouseId != null)
                return false;
        } else if (!warehouseId.equals(other.warehouseId))
            return false;
        return true;
    }
    
    
}
