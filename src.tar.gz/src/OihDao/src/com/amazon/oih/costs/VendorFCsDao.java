package com.amazon.oih.costs;

import java.util.Collection;
import java.util.List;

import com.amazon.oih.dao.exception.OihPersistenceException;

public interface VendorFCsDao {
    public List<VendorFCs> loadAll(String realm) throws OihPersistenceException;
    
    public void save(Collection<VendorFCs> os) throws OihPersistenceException;
    
    public void save(VendorFCs o) throws OihPersistenceException;
}
