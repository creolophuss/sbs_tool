package oih.config;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.amazon.oih.dao.g2s2.G2S2AppConfigsReadonlyDao;


import org.jmock.Expectations;
import org.jmock.Mockery;
import org.jmock.integration.junit4.JUnit4Mockery;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import amazon.platform.config.AppConfig;

class TestObject {
    private Integer int1;
    private String str1;
    public TestObject(){
        
    }
    public TestObject(Integer int1, String str1){
        this.int1 = int1;
        this.str1 = str1;
    }
    public Integer getInt1() {
        return int1;
    }
    public void setInt1(Integer int1) {
        this.int1 = int1;
    }
    public String getStr1() {
        return str1;
    }
    public void setStr1(String str1) {
        this.str1 = str1;
    }
    
}
public class G2S2ConfigTest {

    private static G2S2AppConfigsReadonlyDao g2s2Dao;
    static private Mockery context;
    static private G2S2Config g2s2Config;
    
    @BeforeClass
    public static void initConfigTree() {

        if (!AppConfig.isInitialized()){
            String args[] = new String[] {
                    "--domain=test",
                    "--realm=USAmazon",
                    "--root=/tmp"
                    };
            AppConfig.initialize("someapp","someappgroup",args);
        }
        //NOTE: Need to force config-settings from BrazilConfig to get used. Otherwise if any tests
        //before this had setup maps to get used, that mapConfig will continue getting used for tests
        //below.
        ConfigFactory.useBrazilConfig();

        context = new JUnit4Mockery();

        g2s2Dao = context.mock(G2S2AppConfigsReadonlyDao.class);
        
        context.checking(new Expectations() {
            {
                atLeast(1).of(g2s2Dao).getAppConfig("testString", String.class);
                will(returnValue("StrValue"));
            }
            {
                atLeast(1).of(g2s2Dao).getAppConfig("testInt", Integer.class);
                will(returnValue(Integer.valueOf(999)));
            }
            {
                atLeast(1).of(g2s2Dao).getAppConfig("testBool", Boolean.class);
                will(returnValue(Boolean.valueOf(true)));
            }
            {
                atLeast(1).of(g2s2Dao).getAppConfig("testDouble", Double.class);
                will(returnValue(Double.valueOf(0.01)));
            }
            {
                atLeast(1).of(g2s2Dao).getAppConfig("testMap", Map.class);
                Map<String, String> testMap = new HashMap<String, String>();
                testMap.put("testKey1", "valueMap1");testMap.put("testKey2", "valueMap2");
                will(returnValue(testMap));
            }
            {
                atLeast(1).of(g2s2Dao).getAppConfig("testMap", HashMap.class);
                Map<String, String> testMap = new HashMap<String, String>();
                testMap.put("testKey1", "valueMap1");testMap.put("testKey2", "valueMap2");
                will(returnValue(testMap));
            }
            {
                atLeast(1).of(g2s2Dao).getAppConfig("testList", List.class);
                List<String> testList = new ArrayList<String>();
                testList.add("valueList1");testList.add("valueList2");
                will(returnValue(testList));
            }
            {
                atLeast(1).of(g2s2Dao).getAppConfig("testList", ArrayList.class);
                List<String> testList = new ArrayList<String>();
                testList.add("valueList1");testList.add("valueList2");
                will(returnValue(testList));
            }
            {
                atLeast(1).of(g2s2Dao).getAppConfig("testObject", TestObject.class);
                TestObject tObject = new TestObject(5, "str5");
                will(returnValue(tObject));
            }
            {
                atLeast(1).of(g2s2Dao).getAppConfigList("testObjectList", TestObject.class);
                List<TestObject> tObjectList = new ArrayList<TestObject>();
                tObjectList.add(new TestObject(6, "str6"));
                tObjectList.add(new TestObject(7, "str7"));
                will(returnValue(tObjectList));
            }
            {
                atLeast(1).of(g2s2Dao).flushCache();
            }
        });
        G2S2Config.setG2S2Dao(g2s2Dao);
        g2s2Config = new G2S2Config();
    }
    @Test
    public void testFindString() {
        Assert.assertEquals("StrValue",g2s2Config.findString("testString"));
    }

    @Test
    public void testFindInteger() {
        Assert.assertEquals(Integer.valueOf(999),g2s2Config.findInteger("testInt"));
    }

    @Test
    public void testFindBoolean() {
        Assert.assertEquals(Boolean.valueOf(true),g2s2Config.findBoolean("testBool"));
    }

    @Test
    public void testFindDouble() {
        Assert.assertEquals(Double.valueOf(0.01),g2s2Config.findDouble("testDouble"));
    }
    
    @Test
    public void testFindMap() {
        Map<String, String> testMap = (Map<String, String>)g2s2Config.findMap("testMap");
        Assert.assertEquals("valueMap1",testMap.get("testKey1"));
        Assert.assertEquals("valueMap2",testMap.get("testKey2"));
    }
    
    @Test
    public void testFindList() {
        List<String> testList = (List<String>)g2s2Config.findList("testList");
        Assert.assertEquals("valueList1",testList.get(0));
        Assert.assertEquals("valueList2",testList.get(1));
    }
    

    @Test
    public void testFindObject() {
        TestObject testObject = (TestObject)g2s2Config.findObject("testObject", TestObject.class);
        Assert.assertEquals(Integer.valueOf(5),testObject.getInt1());
        Assert.assertEquals("str5",testObject.getStr1());
    }
    
    @Test
    public void testFindObjectList(){
        List<TestObject> testObjectList = (List<TestObject>)g2s2Config.findList("testObjectList", TestObject.class);
        Assert.assertEquals(Integer.valueOf(6),testObjectList.get(0).getInt1());
        Assert.assertEquals("str6",testObjectList.get(0).getStr1());
        Assert.assertEquals(Integer.valueOf(7),testObjectList.get(1).getInt1());
        Assert.assertEquals("str7",testObjectList.get(1).getStr1());
    }
    
    @Test
    public void testReloadConfig(){
        TestObject testObject = (TestObject)g2s2Config.findObject("testObject", TestObject.class);
        Assert.assertEquals(Integer.valueOf(5),testObject.getInt1());
        Assert.assertEquals("str5",testObject.getStr1());
        List<TestObject> testObjectList = (List<TestObject>)g2s2Config.findList("testObjectList", TestObject.class);
        Assert.assertEquals(Integer.valueOf(6),testObjectList.get(0).getInt1());
        Assert.assertEquals("str6",testObjectList.get(0).getStr1());
        Assert.assertEquals(Integer.valueOf(7),testObjectList.get(1).getInt1());
        Assert.assertEquals("str7",testObjectList.get(1).getStr1());
        
        g2s2Config.reloadConfig();
        
        TestObject testObject1 = (TestObject)g2s2Config.findObject("testObject", TestObject.class);
        Assert.assertEquals(Integer.valueOf(5),testObject1.getInt1());
        Assert.assertEquals("str5",testObject1.getStr1());
        List<TestObject> testObjectList1 = (List<TestObject>)g2s2Config.findList("testObjectList", TestObject.class);
        Assert.assertEquals(Integer.valueOf(6),testObjectList1.get(0).getInt1());
        Assert.assertEquals("str6",testObjectList1.get(0).getStr1());
        Assert.assertEquals(Integer.valueOf(7),testObjectList1.get(1).getInt1());
        Assert.assertEquals("str7",testObjectList1.get(1).getStr1());
    }
}
