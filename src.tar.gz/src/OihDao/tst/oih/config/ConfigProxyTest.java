package oih.config;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.amazon.oih.dao.g2s2.G2S2AppConfigsReadonlyDao;


import org.jmock.Expectations;
import org.jmock.Mockery;
import org.jmock.integration.junit4.JUnit4Mockery;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import amazon.platform.config.AppConfig;

public class ConfigProxyTest {

    static private Mockery contextG2S2;
    private static G2S2AppConfigsReadonlyDao g2s2Dao;
    private static ConfigProxy configProxy;
    private static Config c;
    
    @BeforeClass
    public static void initConfigTree() {

        if (!AppConfig.isInitialized()){
            String args[] = new String[] {
                                "--JARConfigFile=./tst/testBrazilConfig.jar",
                                "--domain=test",
                                "--realm=USAmazon",
                                "--root=/tmp",
                                "--override=TestBrazilConfig.cfg"
                                };
            AppConfig.initialize("OihDao","oih",args);
        }
        //NOTE: Need to force config-settings from BrazilConfig to get used. Otherwise if any tests
        //before this had setup maps to get used, that mapConfig will continue getting used for tests
        //below.
        ConfigFactory.useBrazilConfig();
        
        contextG2S2 = new JUnit4Mockery();

        g2s2Dao = contextG2S2.mock(G2S2AppConfigsReadonlyDao.class);
        
        contextG2S2.checking(new Expectations() {
            {
                atLeast(1).of(g2s2Dao).getAppConfig("testString", String.class);
                will(returnValue("StrValue"));
            }
            {
                atLeast(1).of(g2s2Dao).getAppConfig("testInt", Integer.class);
                will(returnValue(Integer.valueOf(999)));
            }
            {
                atLeast(1).of(g2s2Dao).getAppConfig("testBool", Boolean.class);
                will(returnValue(Boolean.valueOf(true)));
            }
            {
                atLeast(1).of(g2s2Dao).getAppConfig("testDouble", Double.class);
                will(returnValue(Double.valueOf(0.01)));
            }
            {
                atLeast(1).of(g2s2Dao).getAppConfig("testMap", Map.class);
                Map<String, String> testMap = new HashMap<String, String>();
                testMap.put("testKey1", "valueMap1");testMap.put("testKey2", "valueMap2");
                will(returnValue(testMap));
            }
            {
                atLeast(1).of(g2s2Dao).getAppConfig("testList", List.class);
                List<String> testList = new ArrayList<String>();
                testList.add("valueList1");testList.add("valueList2");
                will(returnValue(testList));
            }
            {
                atLeast(1).of(g2s2Dao).getAppConfig("testObject", TestObject.class);
                TestObject tObject = new TestObject(5, "str5");
                will(returnValue(tObject));
            }
        });
        G2S2Config.setG2S2Dao(g2s2Dao);
        
        configProxy = new ConfigProxy();

    }
    @Test
    public void testFindString() {
        Assert.assertEquals("StrValue",configProxy.findString("testString"));
    }

    @Test
    public void testFindInteger() {
        Assert.assertEquals(Integer.valueOf(999),configProxy.findInteger("testInt"));
    }

    @Test
    public void testFindBoolean() {
        Assert.assertEquals(Boolean.valueOf(true),configProxy.findBoolean("testBool"));
    }

    @Test
    public void testFindDouble() {
        Assert.assertEquals(Double.valueOf(0.01),configProxy.findDouble("testDouble"));
    }
    
    @Test
    public void testFindMap() {
        Map<String, String> testMap = (Map<String, String>)configProxy.findMap("testMap");
        Assert.assertEquals("valueMap1",testMap.get("testKey1"));
        Assert.assertEquals("valueMap2",testMap.get("testKey2"));
    }
    
    @Test
    public void testFindList() {
        List<String> testList = (List<String>)configProxy.findList("testList");
        Assert.assertEquals("valueList1",testList.get(0));
        Assert.assertEquals("valueList2",testList.get(1));
    }
    

    @Test
    public void testFindObject() {
        TestObject testObject = (TestObject)configProxy.findObject("testObject", TestObject.class);
        Assert.assertEquals(Integer.valueOf(5),testObject.getInt1());
        Assert.assertEquals("str5",testObject.getStr1());
    }
    
    
    @Test
    public void testFindStringBC() {
        Assert.assertEquals("a",configProxy.findString("stringKey.a"));
    }

    @Test
    public void testFindIntegerBC() {
        Assert.assertEquals(Integer.valueOf(3),configProxy.findInteger("integerKey.a"));
    }

    @Test
    public void testFindBooleanBC() {
        Assert.assertEquals(Boolean.valueOf(false),configProxy.findBoolean("booleanKey.c"));
    }

    @Test
    public void testFindDoubleBC() {
        ConfigFactory.useConfig(c);
        Assert.assertEquals(Double.valueOf(5.0),configProxy.findDouble("doubleKey.b"));
    }
    
    @Test
    public void testFindMapBC() {
        Assert.assertTrue(configProxy.findMap("mapKey.a") instanceof Map<?,?>);
 /*       Map<String, String> testMap = (Map<String, String>)configProxy.findMap("testMap");
        Assert.assertEquals("valueMap1BC",testMap.get("testKey1BC"));
        Assert.assertEquals("valueMap2BC",testMap.get("testKey2BC"));*/
    }
    
    @Test
    public void testFindListBC() {
        Assert.assertTrue(configProxy.findList("listKey.a") instanceof List<?>);
        /*
        List<String> testList = (List<String>)configProxy.findList("testList");
        Assert.assertEquals("valueList1BC",testList.get(0));
        Assert.assertEquals("valueList2BC",testList.get(1));
        */
    }

    @Test
    public void testFindObjectBC() {
        TestObject testObject = (TestObject)configProxy.findObject("testObject", TestObject.class);
        Assert.assertEquals(Integer.valueOf(5),testObject.getInt1());
        Assert.assertEquals("str5",testObject.getStr1());
    }

    @Test
    public void testGetDomain(){
        Assert.assertEquals("test",configProxy.getDomain());
    }
    
    @Test
    public void testGetRealmName(){
        Assert.assertEquals("USAmazon",configProxy.getRealmName());
    }
}
