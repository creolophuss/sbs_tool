package oih.config;

import java.util.ArrayList;

import org.junit.Assert;
import org.junit.Test;

import java.util.Arrays;

public class ConfigUtilsTest {
    
    @Test
    public void testContains(){
        Assert.assertFalse(ConfigUtils.contains(null, "14"));
        Assert.assertFalse(ConfigUtils.contains(new ArrayList(), "14"));
        Assert.assertTrue(ConfigUtils.contains(Arrays.asList("14","15"), "14"));
        Assert.assertTrue(ConfigUtils.contains(Arrays.asList("-1","15"), "14"));
        Assert.assertTrue(ConfigUtils.contains(Arrays.asList("-1"), "14"));
        Assert.assertTrue(ConfigUtils.contains(Arrays.asList("*"), "14"));
        Assert.assertTrue(ConfigUtils.contains(Arrays.asList("all"), "14"));
        Assert.assertTrue(ConfigUtils.contains(Arrays.asList("ALL"), "14"));
    }
    
    @Test
    public void testExcluded(){
        Assert.assertTrue(ConfigUtils.contains(Arrays.asList("!=15"), "14"));
        Assert.assertFalse(ConfigUtils.contains(Arrays.asList("!=15"), "15"));
        Assert.assertFalse(ConfigUtils.contains(Arrays.asList("!=15","!=14"), "14"));
        Assert.assertFalse(ConfigUtils.contains(Arrays.asList("!=15","!=14"), "15"));
        Assert.assertTrue(ConfigUtils.contains(Arrays.asList("!=15","!=14"), "16"));
    }  
    

}
