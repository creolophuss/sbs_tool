package oih.config;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

import junit.framework.JUnit4TestAdapter;


import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.amazon.oih.dao.g2s2.G2S2AppConfigsReadWriteDaoImpl;
import com.amazon.oih.dao.g2s2.G2S2AppConfigsReadonlyDaoImpl;


import amazon.platform.config.AppConfig;

/**
 * Exercises BrazilConfig.
 * 
 * Uses actual key-value pairs in TestBrazilConfig.cfg file in
 * testBrazilConfig.jar
 * 
 * @author svisvan
 *
 */
public class BrazilConfigTest {
	
	@BeforeClass
	public static void initAppConfig() {
		String args[] = new String[] {
							"--JARConfigFile=./tst/testBrazilConfig.jar",
							"--domain=test",
							"--realm=USAmazon",
							"--override=TestBrazilConfig.cfg"
							};
        if (AppConfig.isInitialized()) {
            AppConfig.destroy();
        }
		AppConfig.initialize("someapp","someappgroup",args);
		//NOTE: Need to force config-settings from BrazilConfig to get used. Otherwise if any tests
		//before this had setup maps to get used, that mapConfig will continue getting used for tests
		//below.
		ConfigFactory.useBrazilConfig();
        
	}

	@Before
	public void setUp() {
		G2S2Config.setG2S2Dao(new G2S2AppConfigsReadonlyDaoImpl());
		G2S2AppConfigsReadonlyDaoImpl.initializeClientHolder(); 
	}
	
	@Test
	public void testFindString() {
		Config cfg = ConfigFactory.getDefaultConfig();
				
		//findString returns textual value in most cases
		Assert.assertEquals("a",cfg.findString("stringKey.a"));
		Assert.assertEquals("b",cfg.findString("stringKey.b"));
		Assert.assertNull(cfg.findString("stringkey.notthere`"));
		
		Assert.assertEquals("3",cfg.findString("integerKey.a"));
		Assert.assertEquals("3.0",cfg.findString("doubleKey.a"));
		
		Assert.assertEquals("true",cfg.findString("booleanKey.a"));
		Assert.assertEquals("true",cfg.findString("booleanKey.b"));
		Assert.assertEquals("F",cfg.findString("booleanKey.c"));
		
		//for list & map, returns null
		Assert.assertNull(cfg.findString("listKey.a"));
		Assert.assertNull(cfg.findString("listKey.b"));
		Assert.assertNull(cfg.findString("mapKey.a"));
	}
	
	@Test
	public void testFindInteger() {
		Config cfg = ConfigFactory.getDefaultConfig();
		
		//findInteger only works on int's
		Assert.assertEquals(3,cfg.findInteger("integerKey.a").intValue());
		Assert.assertEquals(5,cfg.findInteger("integerKey.b").intValue());
		Assert.assertEquals(null,cfg.findInteger("integerKey.notthere"));
		
		//fails for other types
		try {
			cfg.findInteger("doubleKey.a");
			Assert.assertTrue(false);
		} catch (RuntimeException e) {
			Assert.assertTrue(true);
		}
		
		try {
			cfg.findInteger("stringKey.a");
			Assert.assertTrue(false);
		} catch (RuntimeException e) {
			Assert.assertTrue(true);
		}
		
		try {
			cfg.findInteger("booleanKey.a");
			Assert.assertTrue(false);
		} catch (RuntimeException e) {
			Assert.assertTrue(true);
		}
		
		//returns null for list, map
		Assert.assertNull(cfg.findInteger("listKey.a"));
		Assert.assertNull(cfg.findInteger("mapKey.a"));
	}
	
	@Test
	public void testFindIntegerWithDefault() {
		Config cfg = ConfigFactory.getDefaultConfig();
		
		Assert.assertEquals(3,cfg.findInteger("integerKey.a",0).intValue());
		Assert.assertEquals(0,cfg.findInteger("integerKey.notthere",0).intValue());
	}
	
	@Test
	public void testFindDouble() {
		Config cfg = ConfigFactory.getDefaultConfig();
	
		//findDouble works for list and int
		Assert.assertEquals(3.0,cfg.findDouble("doubleKey.a").doubleValue(),0.0);
		Assert.assertEquals(5.0,cfg.findDouble("doubleKey.b").doubleValue(),0.0);
		Assert.assertEquals(null,cfg.findDouble("doubleKey.notthere"));
		
		Assert.assertEquals(3.0,cfg.findDouble("integerKey.a").doubleValue(),0.0);
		
		//throws exception for other primitives
		try {
			cfg.findDouble("stringKey.a");
			Assert.assertTrue(false);
		} catch (RuntimeException e) {
			Assert.assertTrue(true);
		}
		
		try {
			cfg.findDouble("booleanKey.b");
			Assert.assertTrue(false);
		} catch (RuntimeException e) {
			Assert.assertTrue(true);
		}
		
		//returns null for list, map
		Assert.assertNull(cfg.findDouble("listKey.a"));
		Assert.assertNull(cfg.findDouble("mapKey.a"));
	}
	
	@Test
	public void testFindDoubleWithDefault() {
		Config cfg = ConfigFactory.getDefaultConfig();
		
		Assert.assertEquals(3d,cfg.findDouble("doubleKey.a",0d).doubleValue(),0.0);
		Assert.assertEquals(0d,cfg.findDouble("doubleKey.nothere",0d).doubleValue(),0.0);
		
	}
	
	@Test
	public void testFindBoolean() {
		Config cfg = ConfigFactory.getDefaultConfig();
		
		//findBoolean works with true/false, T,F
		Assert.assertEquals(true,cfg.findBoolean("booleanKey.a").booleanValue());
		Assert.assertEquals(true,cfg.findBoolean("booleanKey.b").booleanValue());
		Assert.assertEquals(false,cfg.findBoolean("booleanKey.c").booleanValue());
		Assert.assertEquals(null,cfg.findBoolean("booleanKey.notthere"));
		
		//throws exception for other primitives
		try {
			cfg.findBoolean("doubleKey.a");
			Assert.assertTrue(false);
		} catch (RuntimeException e) {
			Assert.assertTrue(true);
		}
		
		try {
			cfg.findBoolean("stringKey.a");
			Assert.assertTrue(false);
		} catch (RuntimeException e) {
			Assert.assertTrue(true);
		}
		
		try {
			cfg.findBoolean("integerKey.b");
			Assert.assertTrue(false);
		} catch (RuntimeException e) {
			Assert.assertTrue(true);
		}
		
		//returns null for list, map
		Assert.assertNull(cfg.findBoolean("listKey.a"));
		Assert.assertNull(cfg.findBoolean("mapKey.a"));
	}
	
	@Test
	public void testFindBooleanWithDefault() {
		Config cfg = ConfigFactory.getDefaultConfig();
		
		Assert.assertEquals(true,cfg.findBoolean("booleanKey.a",false).booleanValue());
		Assert.assertEquals(false,cfg.findBoolean("booleanKey.notthere",false).booleanValue());
	}
	
	@Test
	public void testFindObject() {
		Config cfg = ConfigFactory.getDefaultConfig();
		
		Assert.assertNotNull(cfg.findObject("booleanKey.a"));
		Assert.assertNotNull(cfg.findObject("integerKey.b"));
		Assert.assertNotNull(cfg.findObject("mapKey.a"));
		Assert.assertNull(cfg.findObject("notThere"));
	}
	
	@Test
	public void testFindList() {
		Config cfg = ConfigFactory.getDefaultConfig();
		
		//findList returns valid lists
		Assert.assertNotNull(cfg.findList("listKey.a"));
		Assert.assertTrue(cfg.findList("listKey.a") instanceof List<?>);
		Assert.assertNotNull(cfg.findList("listKey.b"));
		Assert.assertTrue(cfg.findList("listKey.b") instanceof List<?>);
		
		//for other types, it returns null
		Assert.assertNull(cfg.findList("integerKey.a"));
		Assert.assertNull(cfg.findList("doubleKey.a"));
		Assert.assertNull(cfg.findList("booleanKey.a"));
		Assert.assertNull(cfg.findList("mapKey.a"));
		Assert.assertNull(cfg.findList("notThere"));
	}
	
	@Test
	public void testFindMap() {
		Config cfg = ConfigFactory.getDefaultConfig();
		
		//findList returns valid maps
		Assert.assertNotNull(cfg.findMap("mapKey.a"));
		Assert.assertTrue(cfg.findMap("mapKey.a") instanceof Map<?,?>);
		
		//for other types, it returns null
		Assert.assertNull(cfg.findMap("integerKey.a"));
		Assert.assertNull(cfg.findMap("doubleKey.a"));
		Assert.assertNull(cfg.findMap("booleanKey.a"));
		Assert.assertNull(cfg.findMap("listKey.a"));
		Assert.assertNull(cfg.findMap("notThere"));
	}
	
	@Test
	public void testFindObjects() {
		Config cfg = ConfigFactory.getDefaultConfig();
		
		HashSet<String> expected1 = new HashSet<String>(
					Arrays.asList(new String[] { "foo.a", "foo.b" }));
		Assert.assertEquals(expected1,cfg.findObjects("foo.*").keySet());
		
		HashSet<String> expected2 = new HashSet<String>(
				Arrays.asList(new String[] { "foo.c.d", "foo.c.e" }));
		Assert.assertEquals(expected2,cfg.findObjects("foo.c.*").keySet());
		
		HashSet<String> expected3 = new HashSet<String>(
				Arrays.asList(new String[] { "foo.c.d", "foo.c.e", "foo.a.b" }));
		Assert.assertEquals(expected3,cfg.findObjects("foo.*.*").keySet());
		
		Assert.assertTrue(cfg.findObjects("foo.z.*").size() == 0);
	}
	
	@Test
	public void testFindObjectsByPrefix() {
		Config cfg = ConfigFactory.getDefaultConfig();
		
		HashSet<String> expected1 = new HashSet<String>(
				Arrays.asList(new String[] { "foo.a.b", "foo.a" }));
		Assert.assertEquals(expected1,cfg.findObjectsByPrefix("foo.a").keySet());
		
		HashSet<String> expected2 = new HashSet<String>(
				Arrays.asList(new String[] { "foo.c.d", "foo.c.e" }));
		Assert.assertEquals(expected2,cfg.findObjectsByPrefix("foo.c").keySet());
		
		Assert.assertTrue(cfg.findObjectsByPrefix("foo.z").size() == 0);
	}

	public static junit.framework.Test suite() {
		return new JUnit4TestAdapter(BrazilConfigTest.class);
	}
}
