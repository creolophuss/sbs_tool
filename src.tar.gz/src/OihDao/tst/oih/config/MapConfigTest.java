package oih.config;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import junit.framework.JUnit4TestAdapter;


import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

public class MapConfigTest {

	@BeforeClass
	public static void initMapConfig() {
		Map<String,Object> seed = new HashMap<String,Object>();
		seed.put("stringKey.a", "a");
		seed.put("stringKey.b", 13);
		seed.put("integerKey.a", 100);
		seed.put("integerKey.b",13.13);
		seed.put("doubleKey.a", 100.00);
		seed.put("doubleKey.b", 13);
		seed.put("booleanKey.a", false);
		seed.put("booleanKey.b", 13);
		seed.put("listKey.a",Arrays.asList(new int[] {10,20,30}));
		seed.put("listKey.b",Arrays.asList(new Object[] {"x",20,Arrays.asList(new int[] {10,20,30})}));
		
		HashMap<Object,Object> junk = new HashMap<Object,Object>();
		junk.put(13, "foo");
		junk.put(new RuntimeException("hello"), 13.00);
		junk.put("somelist", new int[] {10,20,30});
		seed.put("mapKey.a", junk);
		
		ConfigFactory.useConfigFrom(seed);
	}
	
	@Test
	public void testMapConfig(){
		Config testConfig = ConfigFactory.getDefaultConfig();
		Assert.assertEquals("a", testConfig.findString("stringKey.a"));
		Assert.assertEquals(new Integer(100), testConfig.findInteger("integerKey.a"));
		Assert.assertEquals(new Double(100.0), testConfig.findDouble("doubleKey.a"));
		Assert.assertEquals(false, testConfig.findBoolean("booleanKey.a"));
		
		try{
			testConfig.findString("stringKey.b");
			Assert.fail();
		} catch(ConfigException e){
			Assert.assertEquals("Value for 'stringKey.b' is not a class java.lang.String", e.getMessage());
		}
		
		try {
			testConfig.findInteger("integerKey.b");
			Assert.fail();
		} catch (ConfigException e){
			Assert.assertEquals("Value for 'integerKey.b' is not a class java.lang.Integer", e.getMessage());
		}

		try {
			testConfig.findDouble("doubleKey.b");
			Assert.fail();
		} catch (ConfigException e){
			Assert.assertEquals("Value for 'doubleKey.b' is not a class java.lang.Double", e.getMessage());
		}
		try {
			testConfig.findBoolean("booleanKey.b");
			Assert.fail();
		} catch (ConfigException e){
			Assert.assertEquals("Value for 'booleanKey.b' is not a class java.lang.Boolean", e.getMessage());
		}		
		
	}
	
	public static junit.framework.Test suite() {
		return new JUnit4TestAdapter(MapConfigTest.class);
	}
}
