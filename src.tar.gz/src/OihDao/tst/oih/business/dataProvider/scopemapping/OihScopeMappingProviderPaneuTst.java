package oih.business.dataProvider.scopemapping;

import java.util.List;
import java.util.Map;

import oih.config.ConfigFactory;
import oih.util.paneu.PANEUConstants;


import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.amazon.oih.dao.scopemapping.OihScopeMapping;
import com.amazon.oih.dao.scopemapping.ScopeConfigTestData;
import static com.amazon.oih.dao.scopemapping.ScopeConfigTestData.*;

public class OihScopeMappingProviderPaneuTst {
    
    private Map<String,Object> configMap ;
    

    @Before
    public void setup(){
        configMap = ScopeConfigTestData.getConfigMap();        
        ConfigFactory.useConfigFrom("test",PANEUConstants.EUREALM, configMap);        
    }
  
    
    @Test
    public void testGetAllScopemapping(){
        List<OihScopeMapping> msList = OihScopeMappingProvider.getAllScopeMapping();
        Assert.assertTrue(isSameOihScopeMapping(US_SCOPE ,msList.get(0)));
        Assert.assertTrue(isSameOihScopeMapping(GB_SCOPE ,msList.get(2)));
        Assert.assertTrue(isSameOihScopeMapping(PANEU_SCOPE ,msList.get(9)));
        Assert.assertTrue(isSameOihScopeMapping(FR_SCOPE ,msList.get(3)));
        Assert.assertTrue(isSameOihScopeMapping(IN_RC1_SCOPE ,msList.get(10)));
        Assert.assertTrue(isSameOihScopeMapping(IN_RC2_SCOPE ,msList.get(11)));
    }
    
    @Test
    public void testGetScopeMappingByIog(){   
        for(Long iog : PANEU_SCOPE.getIogs()){
            Assert.assertTrue(isSameOihScopeMapping(PANEU_SCOPE ,OihScopeMappingProvider.getScopeMappingByIog(iog)));
        }
        for(OihScopeMapping scope : (List<OihScopeMapping>)(configMap.get("ScopeMapping"))){
            if( !scope.equals(PANEU_SCOPE)){
                for(Long iog : scope.getIogs()){
                    Assert.assertTrue(isSameOihScopeMapping(scope ,OihScopeMappingProvider.getScopeMappingByIogConsideringCountry(iog)));
                }               
            }
        }
    }    
    
    @Test
    public void testGetScopeMappingByMarketplaceId(){        
        for(Long marketId : PANEU_SCOPE.getMarketplaces() ){
            Assert.assertTrue(isSameOihScopeMapping(PANEU_SCOPE ,OihScopeMappingProvider.getScopeMappingByMarketplaceId(marketId)));
        }        
        for(OihScopeMapping scope : (List<OihScopeMapping>)(configMap.get("ScopeMapping"))){
            if( !scope.equals(IN_RC1_SCOPE) && !scope.equals(IN_RC2_SCOPE) && !scope.equals(IN_RC3_SCOPE) && !scope.equals(IN_RC4_SCOPE) && !scope.equals(IN_RC5_SCOPE)   && !scope.equals(PANEU_SCOPE)){
                for(Long marketId : scope.getMarketplaces() ){
                    Assert.assertTrue(isSameOihScopeMapping(scope ,OihScopeMappingProvider.getScopeMappingByMarketplaceIdConsideringCountry(marketId)));
                }               
            }
        }
    }
 
    @Test
    public void testGetScopeNameByIog(){
        for(Long iog : PANEU_SCOPE.getIogs()){
            Assert.assertEquals(PANEU_SCOPE.getScope() ,OihScopeMappingProvider.getScopeNameByIog(iog));
        } 
    }
    
    @Test
    public void testGetPrimaryIogByIog(){
        for(Long iog : PANEU_SCOPE.getIogs()){
            Assert.assertEquals( Long.valueOf((PANEUConstants.VIRTUAL_IOG)),OihScopeMappingProvider.getPrimaryIogByIog(iog));
        } 
    }
    @Test
    public void testGetPrimaryMarketplaceIdByIog(){
        Assert.assertEquals(new Long(PANEUConstants.VIRTUAL_MARKETPLACEID),OihScopeMappingProvider.getPrimaryMarketplaceIdByIog(7l));
        for(Long iog : PANEU_SCOPE.getIogs()){
            Assert.assertEquals(new Long(PANEUConstants.VIRTUAL_MARKETPLACEID),OihScopeMappingProvider.getPrimaryMarketplaceIdByIog(iog));
        }
    }

    @Test
    public void testGetForecastGroupByIog(){
        Assert.assertEquals("PAN-EU",OihScopeMappingProvider.getForecastGroupByIog(7l));
        for(Long iog : PANEU_SCOPE.getIogs()){
            Assert.assertEquals(PANEU_SCOPE.getForecastGroup(),OihScopeMappingProvider.getForecastGroupByIog(iog));
        }
        
    }
    
    private static boolean isSameOihScopeMapping(OihScopeMapping o1, OihScopeMapping scope2 ){
        return o1.getScope().equals(scope2.getScope())
        && o1.getPrimaryIogId().equals(scope2.getPrimaryIogId())
        && o1.getPrimaryMarketplaceId().equals(scope2.getPrimaryMarketplaceId() );      
    }
}
