package com.amazon.oih.dao.hbase.converter;

import java.util.Date;

import com.amazon.oih.dao.hbase.converter.Column;
import com.amazon.oih.dao.hbase.converter.RowKey;

@RowKey({"asin", "marketplace", "merchant"})
public class ConvertorObject {

    private String asin;
    private String marketplace;
    private String merchant;
    
    @Column(name="col1",index=0)
    private int gl = 0;
    @Column(name="col1",index=1)
    private String title = "";

    @Column(name="col2",index=0)
    private double ourPrice = 0.0;
    @Column(name="col2",index=3)
    private Date publicationDate = null;
    @Column(name="col2",index=4)
    private Date releaseDate = null;
    @Column(name="col2",index=5)
    private boolean flag = true;

    public boolean isFlag() {
        return flag;
    }
    public void setFlag(boolean flag) {
        this.flag = flag;
    }
    public Date getReleaseDate() {
        return releaseDate;
    }
    public void setReleaseDate(Date releaseDate) {
        this.releaseDate = releaseDate;
    }
    
    public String getAsin() {
        return asin;
    }
    public void setAsin(String asin) {
        this.asin = asin;
    }
    public String getMarketplace() {
        return marketplace;
    }
    public void setMarketplace(String marketplace) {
        this.marketplace = marketplace;
    }
    public String getMerchant() {
        return merchant;
    }
    public void setMerchant(String merchant) {
        this.merchant = merchant;
    }
    public int getGl() {
        return gl;
    }
    public void setGl(int gl) {
        this.gl = gl;
    }
    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    public double getOurPrice() {
        return ourPrice;
    }
    public void setOurPrice(double ourPrice) {
        this.ourPrice = ourPrice;
    }
    public Date getPublicationDate() {
        return publicationDate;
    }
    public void setPublicationDate(Date publicationDate) {
        this.publicationDate = publicationDate;
    }
    
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((asin == null) ? 0 : asin.hashCode());
        result = prime * result + gl;
        result = prime * result + ((marketplace == null) ? 0 : marketplace.hashCode());
        result = prime * result + ((merchant == null) ? 0 : merchant.hashCode());
        long temp;
        temp = Double.doubleToLongBits(ourPrice);
        result = prime * result + (int) (temp ^ (temp >>> 32));
        result = prime * result + ((publicationDate == null) ? 0 : publicationDate.hashCode());
        result = prime * result + ((title == null) ? 0 : title.hashCode());
        return result;
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        ConvertorObject other = (ConvertorObject) obj;
        if (asin == null) {
            if (other.asin != null)
                return false;
        } else if (!asin.equals(other.asin))
            return false;
        if (gl != other.gl)
            return false;
        if (marketplace == null) {
            if (other.marketplace != null)
                return false;
        } else if (!marketplace.equals(other.marketplace))
            return false;
        if (merchant == null) {
            if (other.merchant != null)
                return false;
        } else if (!merchant.equals(other.merchant))
            return false;
        if (Double.doubleToLongBits(ourPrice) != Double.doubleToLongBits(other.ourPrice))
            return false;
        if (publicationDate == null) {
            if (other.publicationDate != null)
                return false;
        } else if (!publicationDate.equals(other.publicationDate))
            return false;
        if (title == null) {
            if (other.title != null)
                return false;
        } else if (!title.equals(other.title))
            return false;
        return true;
    }    
    
    
}
