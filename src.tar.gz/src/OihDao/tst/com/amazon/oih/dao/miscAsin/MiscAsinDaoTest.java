package com.amazon.oih.dao.miscAsin;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.amazon.oih.dao.exception.OihPersistenceException;
import com.amazon.oih.dao.repository.DaoFactory;
import com.amazon.oih.dao.repository.RepositoryFactory;

public class MiscAsinDaoTest {
    private static MiscAsinDao dao = DaoFactory.getMiscAsinDao(RepositoryFactory.UNIT_TEST);
    private static long RUN_ID = 1;
    private static String ASIN = "0000000000";
    private static String ORG = "US";
    private static String TYPE = "TEST_APUB";
    
    @Before
    public void init() throws OihPersistenceException {
        Logger.getRootLogger().setLevel(Level.OFF);
        dao.deleteAll();// clear the data from the in-memory session
    }
    
    @Test
    public void testCreate() {
        MiscAsin object = dao.createMiscAsin(RUN_ID, ASIN, ORG, TYPE);
        assertResult(object);
    }
    
    @Test
    public void testExists() throws OihPersistenceException {
        MiscAsin object4Save = dao.createMiscAsin(RUN_ID, ASIN, ORG, TYPE);
        dao.save(object4Save);

        // verify that data exists
        Assert.assertTrue(dao.exists(RUN_ID, ASIN, ORG, TYPE));

        String type = "TEST_NO_EXIST";
        // verify that data not exists
        Assert.assertFalse(dao.exists(RUN_ID, ASIN, ORG, type));
    }
    
    private void assertResult(MiscAsin object) {
        Assert.assertEquals(RUN_ID, object.getRunID());
        Assert.assertEquals(ASIN, object.getAsin());
        Assert.assertEquals(ORG, object.getOrg());
        Assert.assertEquals(TYPE, object.getType());
    }
}
