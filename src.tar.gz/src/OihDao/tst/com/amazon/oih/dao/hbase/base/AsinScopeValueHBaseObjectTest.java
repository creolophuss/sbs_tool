package com.amazon.oih.dao.hbase.base;

import java.lang.annotation.Annotation;
import java.util.HashMap;
import java.util.Map;

import org.junit.Test;

import junit.framework.Assert;

import com.amazon.oih.common.KeyValueBase.NamedValue;
import com.amazon.oih.common.RowKeyBuildType;
import com.amazon.oih.common.RowKeyType;
import com.amazon.oih.dao.hbase.base.CommonKVHBaseDao.HTable;
import com.amazon.oih.dao.hbase.converter.Column;
import com.amazon.oih.dao.hbase.converter.RowKey;

public class AsinScopeValueHBaseObjectTest {

    @Test
    public void testGetBeanAnnotation() throws SecurityException, NoSuchFieldException {
        Annotation[] classAnno = MyHBaseBean.class.getAnnotations();
        Map<Class, Annotation> annoMap = new HashMap<Class, Annotation>();
        
        for(Annotation anno : classAnno) {
            annoMap.put(anno.annotationType(), anno);
        }
        
        Assert.assertTrue(annoMap.containsKey(HTable.class) && ((HTable)annoMap.get(HTable.class)).value().equals("UnitTestTable"));
        Assert.assertTrue(annoMap.containsKey(RowKey.class) && ((RowKey)annoMap.get(RowKey.class)).value()[0].equals("asin"));
        Assert.assertTrue(annoMap.containsKey(RowKeyBuildType.class) && ((RowKeyBuildType)annoMap.get(RowKeyBuildType.class)).
                value().equals(RowKeyType.ASIN_SCOPE));
        
        NamedValue fieldAnno = (NamedValue)MyHBaseBean.class.getField("asin").getAnnotations()[0];
        Assert.assertEquals("asin", fieldAnno.value());
    
    }
    
    @HTable("UnitTestTable")
    private static class MyHBaseBean extends AsinScopeValueHBaseObject<MyApplicationBean> {

        private String test = "";
        
        @Override
        public MyApplicationBean toApplicationObject() {
            // TODO Auto-generated method stub
            return null;
        }
        
    }
    
    
    
    private static class MyApplicationBean {
        
    }
}
