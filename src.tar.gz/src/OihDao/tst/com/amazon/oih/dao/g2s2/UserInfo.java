package com.amazon.oih.dao.g2s2;

import com.amazon.oih.dao.g2s2.ConfigKey;

import java.util.Map;

@ConfigKey("Ion.Test.UserDefinedType.UserInfo")
public class UserInfo{
	private String username;
	private int age;
	private Map<String,String> features;
	
	public UserInfo(){};
	public UserInfo(String username){
		this.username = username;
	}
	
	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
    public Map<String,String> getFeatures() {
        return features;
    }
    public void setFeatures(Map<String,String> features) {
        this.features = features;
    }
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + age;
        result = prime * result + ((features == null) ? 0 : features.hashCode());
        result = prime * result + ((username == null) ? 0 : username.hashCode());
        return result;
    }
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        UserInfo other = (UserInfo) obj;
        if (age != other.age)
            return false;
        if (features == null) {
            if (other.features != null)
                return false;
        } else if (!features.equals(other.features))
            return false;
        if (username == null) {
            if (other.username != null)
                return false;
        } else if (!username.equals(other.username))
            return false;
        return true;
    }

}
