package com.amazon.oih.dao.forecast;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.naming.NamingException;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.joda.time.DateTime;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import amazon.platform.config.AppConfig;

import com.amazon.carbonado.RepositoryException;
import com.amazon.oih.dao.repository.RepositoryFactory;

/**
 * Unit Test for ForecastObject
 * 
 * @author zhongwei
 * 
 */
public class ForecastObjectTest {
    private static String source = RepositoryFactory.UNIT_TEST;
    final static Date RUN_DATE = new DateTime("2010-01-19").toDate();
    private static final String realm = "USAmazon";
    private static final String root = "/tmp";

    private final static int NUM_OF_WEEKS = 52;
    private static List<Double> forecasts = new ArrayList<Double>(NUM_OF_WEEKS);

    static {
        for (int i = 0; i < NUM_OF_WEEKS; i++) {
            forecasts.add(Double.valueOf(i + i));
        }
    }

    @BeforeClass
    public static void init() {
        Logger.getRootLogger().setLevel(Level.OFF);

        if (!AppConfig.isInitialized()) {
            AppConfig.initialize("OihMetrics", "Oih", new String[] {
                    "--root=" + root, "--domain=" + source, "--realm=" + realm,
            });
        }
    }

    @Test
    public void testEquals() {
        String asin1 = "0000000000";
        String asin2 = "0000000002";
        int iog1 = 1;
        int iog2 = 1;

        ForecastObject forecast1 = new ForecastObject(asin1, iog1, source, RUN_DATE, forecasts);
        ForecastObject forecast2 = new ForecastObject(asin1, iog1, source, RUN_DATE, forecasts);
        ForecastObject forecast3 = new ForecastObject(asin2, iog2, source, RUN_DATE, forecasts);
        ForecastObject forecast4 = new ForecastObject(asin1, iog1, source, RUN_DATE, forecasts);
        ForecastObject forecast5 = new ForecastObject(asin2, iog1, source, RUN_DATE, forecasts);

        Assert.assertTrue(forecast1.equals(forecast2));
        Assert.assertFalse(forecast1.equals(forecast3));
        Assert.assertFalse(forecast1.equals(forecast3));
        Assert.assertFalse(forecast2.equals(forecast3));
        Assert.assertFalse(forecast3.equals(forecast4));
        Assert.assertFalse(forecast3.equals(forecast4));
        Assert.assertFalse(forecast4.equals(forecast5));
    }

    @Test
    public void testForecastConstruct() throws NamingException, RepositoryException, ClassNotFoundException {
        String asin = "0000000000";
        int iog = 1;

        ForecastObject forecast = new ForecastObject(asin, iog, source, RUN_DATE, forecasts);
        Assert.assertEquals(asin, forecast.getAsin());
        Assert.assertEquals(iog, forecast.getIog());
        Assert.assertTrue(forecast.getFirstLoadDate() == RUN_DATE);
        Assert.assertTrue(forecast.getLastLoadDate() == RUN_DATE);
        Assert.assertTrue(forecast.getExpiredDate().getTime() > RUN_DATE.getTime());

        Assert.assertEquals(forecast.getForecasts().size(), NUM_OF_WEEKS);

        Assert.assertEquals(forecast.getForecast1(), forecasts.get(0), 0.000001);
        Assert.assertEquals(forecast.getForecast2(), forecasts.get(1), 0.000001);
        Assert.assertEquals(forecast.getForecast3(), forecasts.get(2), 0.000001);
        Assert.assertEquals(forecast.getForecast4(), forecasts.get(3), 0.000001);
        Assert.assertEquals(forecast.getForecast5(), forecasts.get(4), 0.000001);
        Assert.assertEquals(forecast.getForecast6(), forecasts.get(5), 0.000001);
        Assert.assertEquals(forecast.getForecast7(), forecasts.get(6), 0.000001);
        Assert.assertEquals(forecast.getForecast8(), forecasts.get(7), 0.000001);
        Assert.assertEquals(forecast.getForecast9(), forecasts.get(8), 0.000001);
        Assert.assertEquals(forecast.getForecast10(), forecasts.get(9), 0.000001);
        Assert.assertEquals(forecast.getForecast11(), forecasts.get(10), 0.000001);
        Assert.assertEquals(forecast.getForecast12(), forecasts.get(11), 0.000001);
        Assert.assertEquals(forecast.getForecast13(), forecasts.get(12), 0.000001);
        Assert.assertEquals(forecast.getForecast14(), forecasts.get(13), 0.000001);
        Assert.assertEquals(forecast.getForecast15(), forecasts.get(14), 0.000001);
        Assert.assertEquals(forecast.getForecast16(), forecasts.get(15), 0.000001);
        Assert.assertEquals(forecast.getForecast17(), forecasts.get(16), 0.000001);
        Assert.assertEquals(forecast.getForecast18(), forecasts.get(17), 0.000001);
        Assert.assertEquals(forecast.getForecast19(), forecasts.get(18), 0.000001);
        Assert.assertEquals(forecast.getForecast20(), forecasts.get(19), 0.000001);
        Assert.assertEquals(forecast.getForecast21(), forecasts.get(20), 0.000001);
        Assert.assertEquals(forecast.getForecast22(), forecasts.get(21), 0.000001);
        Assert.assertEquals(forecast.getForecast23(), forecasts.get(22), 0.000001);
        Assert.assertEquals(forecast.getForecast24(), forecasts.get(23), 0.000001);
        Assert.assertEquals(forecast.getForecast25(), forecasts.get(24), 0.000001);
        Assert.assertEquals(forecast.getForecast26(), forecasts.get(25), 0.000001);
        Assert.assertEquals(forecast.getForecast27(), forecasts.get(26), 0.000001);
        Assert.assertEquals(forecast.getForecast28(), forecasts.get(27), 0.000001);
        Assert.assertEquals(forecast.getForecast29(), forecasts.get(28), 0.000001);
        Assert.assertEquals(forecast.getForecast30(), forecasts.get(29), 0.000001);
        Assert.assertEquals(forecast.getForecast31(), forecasts.get(30), 0.000001);
        Assert.assertEquals(forecast.getForecast32(), forecasts.get(31), 0.000001);
        Assert.assertEquals(forecast.getForecast33(), forecasts.get(32), 0.000001);
        Assert.assertEquals(forecast.getForecast34(), forecasts.get(33), 0.000001);
        Assert.assertEquals(forecast.getForecast35(), forecasts.get(34), 0.000001);
        Assert.assertEquals(forecast.getForecast36(), forecasts.get(35), 0.000001);
        Assert.assertEquals(forecast.getForecast37(), forecasts.get(36), 0.000001);
        Assert.assertEquals(forecast.getForecast38(), forecasts.get(37), 0.000001);
        Assert.assertEquals(forecast.getForecast39(), forecasts.get(38), 0.000001);
        Assert.assertEquals(forecast.getForecast40(), forecasts.get(39), 0.000001);
        Assert.assertEquals(forecast.getForecast41(), forecasts.get(40), 0.000001);
        Assert.assertEquals(forecast.getForecast42(), forecasts.get(41), 0.000001);
        Assert.assertEquals(forecast.getForecast43(), forecasts.get(42), 0.000001);
        Assert.assertEquals(forecast.getForecast44(), forecasts.get(43), 0.000001);
        Assert.assertEquals(forecast.getForecast45(), forecasts.get(44), 0.000001);
        Assert.assertEquals(forecast.getForecast46(), forecasts.get(45), 0.000001);
        Assert.assertEquals(forecast.getForecast47(), forecasts.get(46), 0.000001);
        Assert.assertEquals(forecast.getForecast48(), forecasts.get(47), 0.000001);
        Assert.assertEquals(forecast.getForecast49(), forecasts.get(48), 0.000001);
        Assert.assertEquals(forecast.getForecast50(), forecasts.get(49), 0.000001);
        Assert.assertEquals(forecast.getForecast51(), forecasts.get(50), 0.000001);
        Assert.assertEquals(forecast.getForecast52(), forecasts.get(51), 0.000001);
    }

    @Test
    public void testGetKey() throws NamingException, RepositoryException, ClassNotFoundException {
        String asin = "0000000000";
        int iog = 1;

        ForecastObject forecast = new ForecastObject(asin, iog, source, RUN_DATE, forecasts);
        Assert.assertEquals(forecast.getKey(), forecast.getAsin() + "|" + forecast.getIog() + "|" + forecast.getRealm() + "|" + forecast.getType());
    }
}
