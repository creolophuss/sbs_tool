package com.amazon.oih.dao.removalleadtime;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.amazon.oih.dao.exception.OihPersistenceException;
import com.amazon.oih.dao.repository.DaoFactory;
import com.amazon.oih.dao.repository.RepositoryFactory;


public class RemoveLeadTimeDaoImplTest {
    private static RemoveLeadTimeDao dao = DaoFactory.getRemoveLeadTimeDao(RepositoryFactory.UNIT_TEST);

    @BeforeClass
    public static void init() throws OihPersistenceException {
        Logger.getRootLogger().setLevel(Level.OFF);
        dao.deleteAll();// clear the data from the in-memory session
    }

    @Test
    public void testCreate() {
        long runId = 1;
        String asin = "0000000000";
        int iog = 1;
        int gl=14;
        double rlt = 2.0;
        Disposition disposition = Disposition.LIQUIDATION;

        RemoveLeadTime object = dao.createInstance( runId,  asin,  iog,  gl , disposition, rlt);
        
        Assert.assertEquals(runId, object.getRunID());
        Assert.assertEquals(asin, object.getAsin());
        Assert.assertEquals(iog, object.getIog());
        Assert.assertEquals(gl, object.getGl());
        Assert.assertEquals((int)rlt, (int)object.getRemovalLeadTime());
        Assert.assertEquals(disposition, object.getDisposition());
    }

    @Test
    public void testFind() throws OihPersistenceException {
    	long runId = 1;
        String asin = "0000000000";
        int iog = 1;
        int gl=14;
        double rlt = 2.0;
        Disposition disposition = Disposition.LIQUIDATION;
        List<RemoveLeadTime> l = new ArrayList<RemoveLeadTime>();

        l.add(dao.createInstance(runId++,  asin,  iog,  gl , disposition, rlt));
        l.add(dao.createInstance(runId++,  asin,  iog,  gl , disposition, rlt));
        l.add(dao.createInstance(runId++,  asin,  iog,  gl , disposition, rlt));
        l.add(dao.createInstance(runId++,  asin,  iog,  gl , disposition, rlt));

        // set up test data
        for (RemoveLeadTime it : l) {
            dao.save(it);
        }

        // verify that we can find the data with correct runId, asin and iog.
        for (RemoveLeadTime it : l) {
        	RemoveLeadTime rlt4Retrieve = dao.find(it.getRunID(), it.getAsin(), it.getIog(), it.getGl(), it.getDisposition());
            Assert.assertEquals(it.getAsin(), rlt4Retrieve.getAsin());
            Assert.assertEquals(it.getIog(), rlt4Retrieve.getIog());
            Assert.assertEquals(it.getGl(), rlt4Retrieve.getGl());
            Assert.assertEquals(it.getRunID(), rlt4Retrieve.getRunID());
            Assert.assertEquals(it.getDisposition(), rlt4Retrieve.getDisposition());
            Assert.assertEquals((int)it.getRemovalLeadTime(), (int)rlt4Retrieve.getRemovalLeadTime());
        }

        // verify that we cannot find the data with wrong run id.
        Assert.assertNull(dao.find(runId, "vendor1", iog, gl, Disposition.RETURN));
    }


    @Test
    public void testExists() throws OihPersistenceException {
    	long runId = 1;
        String asin = "0000000000";
        int iog = 2;
        int gl=14;
        double rlt = 2.0;
        Disposition disposition = Disposition.LIQUIDATION;
        List<RemoveLeadTime> l = new ArrayList<RemoveLeadTime>();

        l.add(dao.createInstance(runId,  asin,  iog,  gl , disposition, rlt));
        dao.save(l);
        // verify that data exists
        Assert.assertTrue(dao.exists(runId, asin, iog, gl, disposition));

        // verify that data not exists
        Assert.assertFalse(dao.exists(runId, asin, ++iog, gl, disposition));
    }
    
}
