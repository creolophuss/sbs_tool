package com.amazon.oih.dao.ourPrice;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.naming.NamingException;

import junit.framework.Assert;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.joda.time.DateTime;
import org.junit.BeforeClass;
import org.junit.Test;

import amazon.platform.config.AppConfig;

import com.amazon.carbonado.PersistException;
import com.amazon.carbonado.RepositoryException;
import com.amazon.oih.dao.exception.DaoRuntimeException;
import com.amazon.oih.dao.exception.OihPersistenceException;
import com.amazon.oih.dao.ourprice.OurPriceDao;
import com.amazon.oih.dao.ourprice.OurPriceObject;
import com.amazon.oih.dao.repository.DaoFactory;
import com.amazon.oih.dao.repository.RepositoryFactory;
import com.amazon.oih.utils.AsinIogPair;

/**
 * Unit test for OurPriceDaoTest
 * 
 * @author zhongwei
 * 
 */
public class OurPriceDaoTest {
    private static String domain = RepositoryFactory.UNIT_TEST;
    private static String realm = "USAmazon";
    private static final String source = RepositoryFactory.UNIT_TEST;
    private static OurPriceDao ourPriceDao = (OurPriceDao) DaoFactory.getDao(OurPriceObject.class, source);
    final static Date RUN_DATE = new DateTime("2010-01-19").toDate();

    @BeforeClass
    public static void init() {
        Logger.getRootLogger().setLevel(Level.OFF);

        if (!AppConfig.isInitialized()) {
            AppConfig.initialize("OihMetrics", "Oih", new String[] {
                    "--root=/tmp", "--domain=" + domain, "--realm=" + realm,
            });
        }
    }

    @Test
    public void testCurrent() throws PersistException, NamingException, RepositoryException, ClassNotFoundException,
            DaoRuntimeException, OihPersistenceException {
        String asin = "0000000000";
        int iog = 1;
        double oldValue = 1;
        double newValue = 9;

        OurPriceObject origPrice = new OurPriceObject(asin, iog, source, oldValue, RUN_DATE);
        OurPriceObject newPrice = new OurPriceObject(asin, iog, source, newValue, RUN_DATE);
        ourPriceDao.oihInsert(origPrice);
        ourPriceDao.oihInsert(newPrice);

        ourPriceDao.find(origPrice, RUN_DATE);

        OurPriceObject current = (OurPriceObject) ourPriceDao.findCurrent(asin, iog, source);
        Assert.assertEquals(current.getAsin(), asin);
        Assert.assertEquals(current.getIog(), iog);
        Assert.assertEquals(current.getSource(), source);
        Assert.assertEquals(current.getIsCurrent(), "Y");
        Assert.assertEquals(current.getStatus(), "OK");

        Assert.assertEquals(current.getOurPrice(), newValue, 0.000001);
    }

    @Test
    public void testFindCurrentByObject() throws NamingException, RepositoryException, ClassNotFoundException,
            DaoRuntimeException, OihPersistenceException {
        OurPriceObject price1, price2;

        price1 = new OurPriceObject("0000000000", 1, source, 7, RUN_DATE);
        ourPriceDao.oihInsert(price1);
        Assert.assertEquals(price1, ourPriceDao.findCurrent(price1));

        price2 = new OurPriceObject("0000000GAF", 1, source, 7, RUN_DATE);
        ourPriceDao.oihInsert(price2);
        Assert.assertEquals(price2, ourPriceDao.findCurrent(price2));

        Assert.assertTrue("ASIN " + price1.getAsin() + "IOG " + price1.getIog() + " inserted but not found!",
                ourPriceDao.findCurrent(price1) != null);

        OurPriceObject price3 = new OurPriceObject("000000TEST", 1, source, 7, RUN_DATE);
        Assert.assertTrue("ASIN " + price3.getAsin() + "IOG " + (price3.getIog()) + " was not inserted but not found!",
                ourPriceDao.findCurrent(price3) == null);
    }

    @Test
    public void testFindCurrentByRawParameter() throws NamingException, RepositoryException, ClassNotFoundException,
            DaoRuntimeException, OihPersistenceException {
        OurPriceObject price1, price2;

        price1 = new OurPriceObject("0000000000", 1, source, 7, RUN_DATE);
        ourPriceDao.oihInsert(price1);
        Assert.assertEquals(price1, ourPriceDao.findCurrent(price1.getAsin(), price1.getIog(), price1.getSource()));

        price2 = new OurPriceObject("0000000GAF", 1, source, 7, RUN_DATE);
        ourPriceDao.oihInsert(price2);
        Assert.assertEquals(price2, ourPriceDao.findCurrent(price2.getAsin(), price2.getIog(), price2.getSource()));

        Assert.assertTrue("ASIN " + price1.getAsin() + "IOG " + price1.getIog() + " inserted but not found!",
                ourPriceDao.findCurrent(price1.getAsin(), price1.getIog(), price1.getSource()) != null);

        OurPriceObject price3 = new OurPriceObject("000000TEST", 1, source, 7, RUN_DATE);
        Assert.assertTrue("ASIN " + price3.getAsin() + "IOG " + (price3.getIog()) + " was not inserted but not found!",
                ourPriceDao.findCurrent(price3.getAsin(), price3.getIog(), price3.getSource()) == null);
    }

    @Test
    public void testFindByObject() throws NamingException, RepositoryException, ClassNotFoundException,
            DaoRuntimeException, OihPersistenceException {
        OurPriceObject price1, price2;

        price1 = new OurPriceObject("0000000000", 1, source, 7, RUN_DATE);
        ourPriceDao.oihInsert(price1);
        Assert.assertEquals(price1, ourPriceDao.find(price1, RUN_DATE));

        price2 = new OurPriceObject("0000000GAF", 1, source, 7, RUN_DATE);
        ourPriceDao.oihInsert(price2);
        Assert.assertEquals(price2, ourPriceDao.find(price2, RUN_DATE));

        Assert.assertTrue("ASIN " + price1.getAsin() + "IOG " + price1.getIog() + " inserted but not found!",
                ourPriceDao.find(price1, RUN_DATE) != null);

        OurPriceObject price3 = new OurPriceObject("000000TEST", 1, source, 7, RUN_DATE);
        Assert.assertTrue("ASIN " + price3.getAsin() + "IOG " + (price3.getIog()) + " was not inserted but not found!",
                ourPriceDao.find(price3, RUN_DATE) == null);
    }

    @Test
    public void testFindByRawParameter() throws NamingException, RepositoryException, ClassNotFoundException,
            DaoRuntimeException, OihPersistenceException {
        OurPriceObject price1, price2;

        price1 = new OurPriceObject("0000000000", 1, source, 7, RUN_DATE);
        ourPriceDao.oihInsert(price1);
        Assert.assertEquals(price1, ourPriceDao.find(price1.getAsin(), price1.getIog(), price1.getSource(), RUN_DATE));

        price2 = new OurPriceObject("0000000GAF", 1, source, 7, RUN_DATE);
        ourPriceDao.oihInsert(price2);
        Assert.assertEquals(price2, ourPriceDao.find(price2.getAsin(), price2.getIog(), price2.getSource(), RUN_DATE));

        Assert.assertTrue("ASIN " + price1.getAsin() + "IOG " + price1.getIog() + " inserted but not found!",
                ourPriceDao.find(price1.getAsin(), price1.getIog(), price1.getSource(), RUN_DATE) != null);

        OurPriceObject price3 = new OurPriceObject("000000TEST", 1, source, 7, RUN_DATE);
        Assert.assertTrue("ASIN " + price3.getAsin() + "IOG " + (price3.getIog()) + " was not inserted but not found!",
                ourPriceDao.find(price3.getAsin(), price3.getIog(), price3.getSource(), RUN_DATE) == null);
    }

    @Test
    public void testBatchFind() throws NamingException, RepositoryException, ClassNotFoundException,
            DaoRuntimeException, OihPersistenceException {

        List<OurPriceObject> objects4Save = new ArrayList<OurPriceObject>();
        objects4Save.add(new OurPriceObject("0000000001", 1, source, 1.7, RUN_DATE));
        objects4Save.add(new OurPriceObject("0000000002", 2, source, 2.7, RUN_DATE));
        objects4Save.add(new OurPriceObject("0000000003", 1, source, 3.7, RUN_DATE));
        objects4Save.add(new OurPriceObject("0000000004", 1, source, 4.7, RUN_DATE));
        objects4Save.add(new OurPriceObject("0000000005", 2, source, 5.7, RUN_DATE));
        objects4Save.add(new OurPriceObject("0000000006", 1, source, 6.7, RUN_DATE));
        ourPriceDao.oihInsert(objects4Save);

        Map<AsinIogPair, OurPriceObject> saveMap = new HashMap<AsinIogPair, OurPriceObject>();
        for (OurPriceObject object : objects4Save) {
            saveMap.put(new AsinIogPair(object.getAsin(), String.valueOf(object.getIog())), object);
        }

        List<AsinIogPair> asinIogPairs = new ArrayList<AsinIogPair>();
        for (OurPriceObject object : objects4Save) {
            asinIogPairs.add(new AsinIogPair(object.getAsin(), String.valueOf(object.getIog())));
        }
        List<OurPriceObject> ourPrices4Retrieve = ourPriceDao.find(asinIogPairs, source, RUN_DATE);

        Map<AsinIogPair, OurPriceObject> retrieveMap = new HashMap<AsinIogPair, OurPriceObject>();
        for (OurPriceObject object : ourPrices4Retrieve) {
            retrieveMap.put(new AsinIogPair(object.getAsin(), String.valueOf(object.getIog())), object);
        }

        for (AsinIogPair object : asinIogPairs) {
            Assert.assertTrue(saveMap.containsKey(object));
            Assert.assertTrue(retrieveMap.containsKey(object));

            OurPriceObject oldOurPrice = saveMap.get(object);
            OurPriceObject newOurPrice = retrieveMap.get(object);

            Assert.assertEquals(oldOurPrice.getOurPrice(), newOurPrice.getOurPrice());
            Assert.assertEquals(oldOurPrice.getSource(), newOurPrice.getSource());
        }
    }
}
