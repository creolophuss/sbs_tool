package com.amazon.oih.dao.targetInvLevel;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.amazon.oih.dao.exception.OihPersistenceException;
import com.amazon.oih.dao.repository.DaoFactory;
import com.amazon.oih.dao.repository.RepositoryFactory;

public class TargetInventoryLevelScopeTest {
    private static TargetInventoryLevelScopeDao dao = DaoFactory
            .getTargetInventoryLevelScopeDao(RepositoryFactory.UNIT_TEST);

    @BeforeClass
    public static void init() throws OihPersistenceException {
        Logger.getRootLogger().setLevel(Level.OFF);
        dao.deleteAll();// clear the data from the in-memory session
    }

    @Test
    public void testCreate() {
        long runId = 1;
        String asin = "0000000000";
        String scopeId = "Amazon_DE";
        int til = 12;
        int carton_qty = 4;
        int idealTIL = 10;
        int minROL = 6;

        TargetInventoryLevelScope object = dao.create(runId, asin, scopeId, til, carton_qty, idealTIL, minROL);
        Assert.assertEquals(runId, object.getRunID());
        Assert.assertEquals(asin, object.getAsin());
        Assert.assertEquals(scopeId, object.getScopeId());
        Assert.assertEquals(til, object.getTil());
        Assert.assertEquals(carton_qty, object.getCartonQty());
        Assert.assertEquals(idealTIL, object.getIdealTIL());
        Assert.assertEquals(minROL, object.getMinROL());
    }

    @Test
    public void testFind() throws OihPersistenceException {
        long runId = 1L;
        String scopeId = "Amazon_DE";

        List<TargetInventoryLevelScope> l = new ArrayList<TargetInventoryLevelScope>();

        l.add(dao.create(runId, "0000000000", scopeId, 12, 4, 10, 2));
        l.add(dao.create(runId, "00000000A0", scopeId, 126, 0, 126, 126));
        l.add(dao.create(runId, "0000000B00", scopeId, 20000, 1, 20000, 20000));
        l.add(dao.create(runId, "000000C000", scopeId, 30000, 2000, 29000, 28000));

        // set up test data
        for (TargetInventoryLevelScope it : l) {
            dao.save(it);
        }

        // verify that we can find the data with correct runId, asin and iog.
        for (TargetInventoryLevelScope it : l) {
            TargetInventoryLevelScope til4Retrieve = dao.find(it.getRunID(), it.getAsin(), scopeId);
            Assert.assertEquals(it.getAsin(), til4Retrieve.getAsin());
            Assert.assertEquals(it.getScopeId(), til4Retrieve.getScopeId());
            Assert.assertEquals(it.getTil(), til4Retrieve.getTil());
            Assert.assertEquals(it.getCartonQty(), til4Retrieve.getCartonQty());
            Assert.assertEquals(it.getIdealTIL(), til4Retrieve.getIdealTIL());
            Assert.assertEquals(it.getMinROL(), til4Retrieve.getMinROL());
        }

        // verify that we cannot find the data with wrong run id.
        Assert.assertNull(dao.find(++runId, "0000000B00", scopeId));
    }

    @Test
    public void testExists() throws OihPersistenceException {
        long runId = 0L;
        String asin = "0123456789";
        String scopeId = "Amazon_DE";
        int cartonQty = 2000;
        int idealTIL = 29000;
        int minROL = 28000;

        // set up test data
        dao.save(dao.create(runId, asin, scopeId, 30000, cartonQty, idealTIL, minROL));

        // verify that data exists
        Assert.assertTrue(dao.exists(runId, asin, scopeId));

        // verify that data not exists
        Assert.assertFalse(dao.exists(runId, asin, "FAKE_SCOPE_ID"));
    }
    

    @Test
    public void testSaveOrUpdate() throws OihPersistenceException {
        long runId = 0L;
        String asin1 = "0123456781";
        String asin2 = "0123456782";
        String scopeId = "Amazon_DE";
        int til = 3000;
        int newTil = 5000;
        int cartonQty = 2000;
        int newCartonQty = 1500;
        int idealTIL = 2000;
        int newIdealTIL = 4000;
        int minROL = 1000;
        int newMinROL = 3500;
        
        TargetInventoryLevelScope o1 = dao.create(runId, asin1, scopeId, til, cartonQty, idealTIL, minROL);
        TargetInventoryLevelScope o2 = dao.create(runId, asin2, scopeId, til, cartonQty, idealTIL, minROL);
        
        List<TargetInventoryLevelScope> tilList = new ArrayList<TargetInventoryLevelScope>();
        tilList.add(o1);
        tilList.add(o2);
        // set up test data
        dao.save(tilList);

        // verify that data exists
        Assert.assertTrue(dao.exists(runId, asin1, scopeId));
        Assert.assertTrue(dao.exists(runId, asin2, scopeId));
        // verify that data not exists
        Assert.assertFalse(dao.exists(runId, asin1, "FAKE_SCOPE_ID"));
        
        o1.setCartonQty(newCartonQty);
        o1.setTil(newTil);
        o1.setIdealTIL(newIdealTIL);
        o1.setMinROL(newMinROL);
        o2.setCartonQty(newCartonQty);
        o2.setTil(newTil);
        o2.setIdealTIL(newIdealTIL);
        o2.setMinROL(newMinROL);
        
        dao.saveOrUpdate(tilList);
        TargetInventoryLevelScope oSave1 = dao.find(runId, asin1, scopeId);
        TargetInventoryLevelScope oSave2 = dao.find(runId, asin2, scopeId);
        
        Assert.assertTrue(oSave1.getCartonQty() == newCartonQty);
        Assert.assertTrue(oSave2.getCartonQty() == newCartonQty);
        Assert.assertTrue(oSave1.getTil() == newTil);
        Assert.assertTrue(oSave2.getTil() == newTil);
        Assert.assertTrue(oSave1.getIdealTIL() == newIdealTIL);
        Assert.assertTrue(oSave2.getIdealTIL() == newIdealTIL);
        Assert.assertTrue(oSave1.getMinROL() == newMinROL);
        Assert.assertTrue(oSave2.getMinROL() == newMinROL);
    }

}
