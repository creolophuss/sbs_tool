package com.amazon.oih.dao.hbase.converter;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.beanutils.BeanUtilsBean;
import org.apache.commons.beanutils.ConvertUtilsBean2;
import org.apache.commons.beanutils.PropertyUtilsBean;
import org.apache.commons.beanutils.converters.DateConverter;
import org.apache.commons.beanutils.converters.DateTimeConverter;
import org.apache.hadoop.hbase.KeyValue;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.util.Bytes;
import org.joda.time.DateTime;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.amazon.oih.dao.hbase.converter.HBaseObjectDefaultConverter;

public class HBaseObjectDefaultConverterTest {
    static private HBaseObjectDefaultConverter<ConvertorObject> convertor;
    static private ConvertorObject obj;
    static private ConvertorObject obj2;
    static private String columnFamily="columnFamily";
    static private BeanUtilsBean beanUtils = null;
    
    @BeforeClass
    public static void init() {
        convertor = new HBaseObjectDefaultConverter<ConvertorObject>();
        obj = new ConvertorObject();
        obj.setAsin("1234");
        obj.setGl(15);
        obj.setTitle("abcd");
        obj.setMarketplace("999");
        obj.setMerchant("222");
        obj.setOurPrice(19.8);
        obj.setPublicationDate(new DateTime("2010-01-19").toDate());

        obj2 = new ConvertorObject();
        obj2.setAsin("123");
        obj2.setGl(15);
        obj2.setTitle("");
        obj2.setMarketplace("888");
        obj2.setMerchant("333");
        obj2.setOurPrice(19.8);
        obj2.setPublicationDate(null);
        obj2.setReleaseDate(null);
        obj2.setFlag(false);
        
        ConvertUtilsBean2 convertUtils = new ConvertUtilsBean2();
        DateTimeConverter dateConverter = new DateConverter(null);
        dateConverter.setPattern("yyyyMMddHHmmssZ");
        convertUtils.deregister(Date.class);
        convertUtils.register(dateConverter, Date.class);
        beanUtils = new BeanUtilsBean(convertUtils, new PropertyUtilsBean());
    }
    
   
    @Test
    public void testConvertToPut() {

        final List<Put> puts = getPuts(obj);
        
        List<Put> putsConverted = convertor.convert(columnFamily, obj);

        Assert.assertEquals(putsConverted.get(1).getFamilyMap().get(Bytes.toBytes(columnFamily)), 
                puts.get(1).getFamilyMap().get(Bytes.toBytes(columnFamily)));
        Assert.assertEquals(putsConverted.get(0).getFamilyMap().get(Bytes.toBytes(columnFamily)), 
                puts.get(0).getFamilyMap().get(Bytes.toBytes(columnFamily)));
        
    }
    
    @Test
    public void testConvertToObj(){

        final List<Put> puts = getPuts(obj);
        Result resultMock = new Result() {

            @Override
            public boolean isEmpty() {
                return false;
            }

            @Override
            public KeyValue[] raw() {
                KeyValue[] kv = new KeyValue[0];
                kv = puts.get(0).getFamilyMap().get(Bytes.toBytes(columnFamily)).toArray(new KeyValue[0]);
                KeyValue[] kv2 = puts.get(1).getFamilyMap().get(Bytes.toBytes(columnFamily)).toArray(new KeyValue[0]);
                KeyValue[] kvList = new KeyValue[kv.length + kv2.length];
                int i = 0;
                for (KeyValue k : kv){
                    kvList[i++] = k;
                }
                for (KeyValue k : kv2){
                    kvList[i++] = k;
                }
                return kvList;
            }
        };
        
        ConvertorObject bObj;
        bObj = convertor.convert(ConvertorObject.class, new String(puts.get(0).getRow()), resultMock);
        Assert.assertEquals(bObj, obj);
    }
    
    @Test
    public void testNullValueInObj(){

        final List<Put> puts = convertor.convert(columnFamily, obj2);
        Result resultMock = new Result() {

            @Override
            public boolean isEmpty() {
                return false;
            }

            @Override
            public KeyValue[] raw() {
                KeyValue[] kv = new KeyValue[0];
                kv = puts.get(0).getFamilyMap().get(Bytes.toBytes(columnFamily)).toArray(new KeyValue[0]);
                KeyValue[] kv2 = puts.get(1).getFamilyMap().get(Bytes.toBytes(columnFamily)).toArray(new KeyValue[0]);
                KeyValue[] kvList = new KeyValue[kv.length + kv2.length];
                int i = 0;
                for (KeyValue k : kv){
                    kvList[i++] = k;
                }
                for (KeyValue k : kv2){
                    kvList[i++] = k;
                }
                return kvList;
            }
        };
        
        ConvertorObject bObj;
        bObj = convertor.convert(ConvertorObject.class, new String(puts.get(0).getRow()), resultMock);
        Assert.assertEquals(bObj, obj2);
    }
    
    @Test
    public void testGetFields() {
        HashMap<String, Field> ret = new HashMap<String, Field>();
        convertor.getFields(ret, Child.class);
        
        Assert.assertTrue(ret.size() == 4);
    }
    
    private List<Put> getPuts(ConvertorObject obj){
        
        String rowKey = obj.getAsin() + convertor.getRowKeySplit() + obj.getMarketplace() + convertor.getRowKeySplit() + obj.getMerchant();

        List<Put> puts = new ArrayList<Put>();
        final Put put1 = new Put(Bytes.toBytes(rowKey));
        String value1 = obj.getGl() + convertor.getValueSplit() + obj.getTitle();
        put1.add(Bytes.toBytes(columnFamily), Bytes.toBytes("col1"), Bytes.toBytes(value1));
        puts.add(put1);

        final Put put2 = new Put(Bytes.toBytes(rowKey));
        try {
            System.out.println("date:" + beanUtils.getProperty(obj, "publicationDate"));
            String value2 = obj.getOurPrice() + convertor.getValueSplit() + beanUtils.getProperty(obj, "publicationDate");
            put2.add(Bytes.toBytes(columnFamily), Bytes.toBytes("col2"), Bytes.toBytes(value2));
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        puts.add(put2);
        
        return puts;
    }
    
    private static class Parent {
        public String pa;
        private String pb;
    }
    
    private static class Child extends Parent {
        private String ca;
        public String cb;
        private String pa;
    }
}
