package com.amazon.oih.dao.unsellable.inventorycandidate;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import junit.framework.Assert;

import org.junit.Before;
import org.junit.Test;

import com.amazon.carbonado.Repository;
import com.amazon.carbonado.RepositoryException;
import com.amazon.carbonado.Storage;
import com.amazon.carbonado.SupportException;
import com.amazon.oih.dao.exception.DaoRuntimeException;
import com.amazon.oih.dao.exception.OihPersistenceException;
import com.amazon.oih.dao.repository.DaoFactory;
import com.amazon.oih.dao.repository.RepositoryFactory;

public class InventoryCandidateCompositeDaoTest {
    private InventoryCandidateCompositeDao dao = DaoFactory
            .getInventoryCandidateCompositeDao(RepositoryFactory.UNIT_TEST);
    private static String ASIN = "ASIN--TEST";
    private static String FCSKU = "FCSKU-TEST";
    private static String FNSKU = "FNSKU-TEST";
    private static int IOG = 1;
    private static String CONDITION = "Defective";
    private static String WAREHOUSE = "LEX2";
    private static int ON_HAND_QUANTITY = 10;
    private static int BOUND_QUANTITY = 2;
    private static int PLANNING_SIDE_QUANTITY = 1;
    private static int FC_SIDE_QUANTITY = 1;

    @Before
    public void setUp() throws SupportException, RepositoryException {
        // clean up repository
        Repository r = RepositoryFactory.getInst().getRepository(InventoryCandidateComposite.class,
                RepositoryFactory.UNIT_TEST);
        Storage<InventoryCandidateComposite> sf = r.storageFor(InventoryCandidateComposite.class);
        sf.truncate();
    }

    @Test
    public void testCreate() throws DaoRuntimeException, OihPersistenceException, ParseException {
        ICCItem item = createICCItem();

        InventoryCandidateComposite compositeItem = dao.createICComposite(item);
        assertData(compositeItem, item);
    }

    private void assertData(InventoryCandidateComposite compositeItem, ICCItem item) {
        Assert.assertEquals(compositeItem.getAsin(), item.getAsin());
        Assert.assertEquals(compositeItem.getFcsku(), item.getFcsku());
        Assert.assertEquals(compositeItem.getFnsku(), item.getFnsku());
        Assert.assertEquals(compositeItem.getIog(), item.getIog());
        Assert.assertEquals(compositeItem.getCondition(), item.getCondition());
        Assert.assertEquals(compositeItem.getWarehouse(), item.getWarehouse());
        Assert.assertEquals(compositeItem.getOnhandQuantity(), item.getOnhandQuantity());
        Assert.assertEquals(compositeItem.getBoundQuantity(), item.getBoundQuantity());
        Assert.assertEquals(compositeItem.getPlanningSideQuantity(), item.getPsQuantity());
        Assert.assertEquals(compositeItem.getFcSideQuantity(), item.getFsQuantity());
    }

    private ICCItem createICCItem() throws DaoRuntimeException, OihPersistenceException, ParseException {
        ICCItem item = new ICCItem();
        item.setAsin(ASIN);
        item.setFnsku(FNSKU);
        item.setFcsku(FCSKU);
        item.setIog(IOG);
        item.setCondition(CONDITION);
        item.setWarehouse(WAREHOUSE);
        item.setOnhandQuantity(ON_HAND_QUANTITY);
        item.setBoundQuantity(BOUND_QUANTITY);
        item.setPsQuantity(PLANNING_SIDE_QUANTITY);
        item.setFsQuantity(FC_SIDE_QUANTITY);

        return item;
    }

    @Test
    public void testExists() throws DaoRuntimeException, OihPersistenceException, ParseException {
        ICCItem item = createICCItem();
        InventoryCandidateComposite compositeItem = dao.createICComposite(item);
        dao.save(compositeItem);

        Assert.assertTrue(dao.exists(item.getAsin(), item.getFnsku(), item.getFcsku(), item.getIog(),
                item.getCondition(), item.getWarehouse()));
    }

    @Test
    public void testSaveAndFind() throws DaoRuntimeException, OihPersistenceException, ParseException {
        ICCItem object4Save = createICCItem();
        InventoryCandidateComposite compositeItem4Save = dao.createICComposite(object4Save);
        dao.save(compositeItem4Save);

        InventoryCandidateComposite compositeItem4Retrieve = dao.find(ASIN, FNSKU, FCSKU, IOG, CONDITION, WAREHOUSE);

        Assert.assertNotNull(compositeItem4Retrieve);
    }

    @Test
    public void testSaveBatchAndFind() throws DaoRuntimeException, OihPersistenceException, ParseException {
        // save'em
        ICCItem object4Save1 = createICCItem();
        object4Save1.setAsin("FNSKUTEST1");
        object4Save1.setFcsku("FNSKUTEST1");
        object4Save1.setFnsku("FNSKUTEST1");
        InventoryCandidateComposite compositeItem4Save1 = dao.createICComposite(object4Save1);

        ICCItem object4Save2 = createICCItem();
        object4Save2.setAsin("FNSKUTEST2");
        object4Save2.setFcsku("FNSKUTEST2");
        object4Save2.setFnsku("FNSKUTEST2");
        InventoryCandidateComposite compositeItem4Save2 = dao.createICComposite(object4Save2);

        ICCItem object4Save3 = createICCItem();
        object4Save3.setAsin("FNSKUTEST3");
        object4Save3.setFcsku("FNSKUTEST3");
        object4Save3.setFnsku("FNSKUTEST3");
        InventoryCandidateComposite compositeItem4Save3 = dao.createICComposite(object4Save3);

        List<InventoryCandidateComposite> iccItems = new ArrayList<InventoryCandidateComposite>();
        iccItems.add(compositeItem4Save1);
        iccItems.add(compositeItem4Save2);
        iccItems.add(compositeItem4Save3);

        dao.save(iccItems);

        Assert.assertTrue(dao.exists("FNSKUTEST1", "FNSKUTEST1", "FNSKUTEST1", IOG, CONDITION, WAREHOUSE));
        Assert.assertTrue(dao.exists("FNSKUTEST2", "FNSKUTEST2", "FNSKUTEST2", IOG, CONDITION, WAREHOUSE));
        Assert.assertTrue(dao.exists("FNSKUTEST3", "FNSKUTEST3", "FNSKUTEST3", IOG, CONDITION, WAREHOUSE));
    }
}
