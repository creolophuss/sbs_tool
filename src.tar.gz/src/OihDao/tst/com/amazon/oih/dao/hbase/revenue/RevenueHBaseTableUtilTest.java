package com.amazon.oih.dao.hbase.revenue;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import junit.framework.Assert;

import org.junit.BeforeClass;
import org.junit.Test;

import amazon.platform.config.AppConfig;

import com.amazon.oih.dao.repository.RepositoryFactory;
import com.amazon.oih.utils.RevenueHBaseTableUtil;

public class RevenueHBaseTableUtilTest {
	
    private static String source = RepositoryFactory.UNIT_TEST;
    private static final String realm = "USAmazon";
    private static final String root = "/tmp";

    @BeforeClass
    public static void init() {
        if (!AppConfig.isInitialized()) {
            AppConfig.initialize("OihMetrics", "Oih", new String[] {
                    "--root=" + root, "--domain=" + source, "--realm=" + realm,
            });
        }
        AppConfig.insertString("IhrMetrics.AsinRevenueDataHBase.TableName", "AsinRevenueData");
    }


    @Test
    public void testConvertInventoryRevenueMap2String() {
        Collection<Entry<String, AsinRevenueData>> origData = AsinRevenueDataTestUtil.buildObjMapDummyData().entrySet();

        for (Entry<String, AsinRevenueData> data : origData) {
            Map<Integer, List<Double>> convertedMap = RevenueHBaseTableUtil.convertString2InventoryRevenueMap(data
                    .getValue().getInventory2RevenueMapOfStringFormat());
            Assert.assertTrue(data.getValue().getInventory2RevenueMap().equals(convertedMap));
        }
    }

    @Test
    public void testConvertInventoryRevenueMap2StringWithNull() {
        Collection<Entry<String, AsinRevenueData>> origData = AsinRevenueDataTestUtil.buildObjMapDummyDataWithNull()
                .entrySet();

        for (Entry<String, AsinRevenueData> data : origData) {
            Map<Integer, List<Double>> convertedMap = RevenueHBaseTableUtil.convertString2InventoryRevenueMap(data
                    .getValue().getInventory2RevenueMapOfStringFormat());
            Assert.assertTrue(data.getValue().getInventory2RevenueMap().equals(convertedMap));
        }
    }
}
