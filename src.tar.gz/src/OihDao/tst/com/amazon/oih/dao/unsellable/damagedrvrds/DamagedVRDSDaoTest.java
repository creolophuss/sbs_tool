package com.amazon.oih.dao.unsellable.damagedrvrds;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.naming.NamingException;

import junit.framework.Assert;

import org.junit.Before;
import org.junit.Test;

import com.amazon.carbonado.ConfigurationException;
import com.amazon.carbonado.Repository;
import com.amazon.carbonado.RepositoryException;
import com.amazon.carbonado.Storage;
import com.amazon.oih.dao.exception.DaoRuntimeException;
import com.amazon.oih.dao.exception.OihPersistenceException;
import com.amazon.oih.dao.repository.DaoFactory;
import com.amazon.oih.dao.repository.RepositoryFactory;
import com.amazon.oih.dao.unsellable.damagedvrds.DamagedVRDSItem;
import com.amazon.oih.dao.unsellable.damagedvrds.IDamagedVRDSDao;
import com.amazon.oih.dao.unsellable.damagedvrds.OihVRDSItem;

public class DamagedVRDSDaoTest {
    private IDamagedVRDSDao dao = DaoFactory.getDamagedVRDSDao(RepositoryFactory.UNIT_TEST);

    @Before
    public void setUp() throws ConfigurationException, NamingException, RepositoryException, ClassNotFoundException {
        // clean up repository
        Repository r = RepositoryFactory.getInst().getRepository(DamagedVRDSItem.class, RepositoryFactory.UNIT_TEST);
        Storage<DamagedVRDSItem> sf = r.storageFor(DamagedVRDSItem.class);
        sf.truncate();
    }

    @Test
    public void testCreate() throws DaoRuntimeException, OihPersistenceException, ParseException {
        // save'em
        OihVRDSItem oihVRDSItem = createOihVRDSItem();
        DamagedVRDSItem damagedVRDSItem = dao.createDamagedVRDSItem(oihVRDSItem);
        assertData(damagedVRDSItem, oihVRDSItem);
    }

    @Test
    public void testSaveAndFind() throws DaoRuntimeException, OihPersistenceException, ParseException {
        // save'em
        OihVRDSItem oihVRDSItem = createOihVRDSItem();
        DamagedVRDSItem item4Save = dao.createDamagedVRDSItem(oihVRDSItem);
        dao.save(item4Save);

        // find, expect them to be in descending order of shipment receive date
        List<DamagedVRDSItem> itemsFound = dao.find("0123456789", 1);
        Assert.assertTrue(itemsFound != null);
        DamagedVRDSItem item4Retrieve = itemsFound.get(0);

        assertData(item4Save, item4Retrieve);

        Assert.assertTrue(true);
    }

    @Test
    public void testSaveBatchAndFind() throws DaoRuntimeException, OihPersistenceException, ParseException {
        List<DamagedVRDSItem> damagedVRDSItems = new ArrayList<DamagedVRDSItem>();
        // save'em
        OihVRDSItem oihVRDSItem1 = createOihVRDSItem();
        oihVRDSItem1.setFnsku("FNSKUTEST1");
        oihVRDSItem1.setIog(1);
        oihVRDSItem1.setDistributorShipmentItemId(1);
        damagedVRDSItems.add(dao.createDamagedVRDSItem(oihVRDSItem1));

        OihVRDSItem oihVRDSItem2 = createOihVRDSItem();
        oihVRDSItem2.setFnsku("FNSKUTEST2");
        oihVRDSItem2.setIog(2);
        oihVRDSItem2.setDistributorShipmentItemId(2);
        damagedVRDSItems.add(dao.createDamagedVRDSItem(oihVRDSItem2));

        OihVRDSItem oihVRDSItem3 = createOihVRDSItem();
        oihVRDSItem3.setFnsku("FNSKUTEST3");
        oihVRDSItem3.setIog(3);
        oihVRDSItem3.setDistributorShipmentItemId(3);
        damagedVRDSItems.add(dao.createDamagedVRDSItem(oihVRDSItem3));

        List<OihVRDSItem> oihVRDSItems = new ArrayList<OihVRDSItem>();
        oihVRDSItems.add(oihVRDSItem1);
        oihVRDSItems.add(oihVRDSItem2);
        oihVRDSItems.add(oihVRDSItem3);
        
        dao.save(damagedVRDSItems);
        
        Assert.assertTrue(dao.exists("FNSKUTEST1", 1));
        Assert.assertTrue(dao.exists("FNSKUTEST2", 2));
        Assert.assertTrue(dao.exists("FNSKUTEST3", 3));
    }

    @Test
    public void testExists() throws DaoRuntimeException, OihPersistenceException, ParseException {
        OihVRDSItem oihVRDSItem = createOihVRDSItem();
        DamagedVRDSItem item4Save = dao.createDamagedVRDSItem(oihVRDSItem);
        dao.save(item4Save);

        Assert.assertTrue(dao.exists(item4Save.getFnsku(), item4Save.getIog()));
    }

    private OihVRDSItem createOihVRDSItem() {

        OihVRDSItem retVal = new OihVRDSItem();
        retVal.setFnsku("0123456789");
        retVal.setFnsku("0123456789");
        retVal.setIog(1);
        retVal.setFcsku("0123456789");
        retVal.setWarehouse("LEX2");
        retVal.setCondition("DEFECTIVE");

        retVal.setAuthorizationRequired(false);
        retVal.setOpenAuthorizationNumber(null);

        retVal.setDestVendor("DVDOR");
        retVal.setSourceVendor("SVDOR");
        retVal.setDisposition("RETURN");
        retVal.setQuantity(10);
        
        retVal.setBaseCurrencyCode("USD");
        retVal.setRefundBasisCode("C");
        retVal.setCost(100);
        
        retVal.setDistributorShipmentItemId(123456789);
        retVal.setDistributorOrderId("TEST001");
        retVal.setDistributorOrderDate(new Date());
        retVal.setDistributorOrderType(9);
        retVal.setDistributorShipmentId("TEST00002");
        
        retVal.setReturnByMaxDays(100);
        retVal.setReturnByMinDays(10);
        
        retVal.setVrdsDescription("VRDSDescription");
        retVal.setPrice(11.2233);
        retVal.setDistributorId("SVDOR");
        
        retVal.setForeignCurrencyCode("USD");
        retVal.setRefundAmountForeignCurrency(123.56);
        retVal.setCostForeignCurrency(125.21);
        retVal.setDistributorListPriceForeignCurrency(130.78);
        retVal.setDistributorCostForeignCurrency(1870.78);

        return retVal;
    }

    private void assertData(DamagedVRDSItem firstItem, OihVRDSItem secondItem) {
        Assert.assertEquals(firstItem.getFnsku(), secondItem.getFnsku());
        Assert.assertEquals(firstItem.getFcsku(), secondItem.getFcsku());
        Assert.assertEquals(firstItem.getIog(), secondItem.getIog());
        Assert.assertEquals(firstItem.getCondition(), secondItem.getCondition());
        Assert.assertEquals(firstItem.getWarehouse(), secondItem.getWarehouse());
        Assert.assertEquals(firstItem.getQuantity(), secondItem.getQuantity());
        Assert.assertEquals(firstItem.getDestVendor(), secondItem.getDestVendor());
        Assert.assertEquals(firstItem.getSourceVendor(), secondItem.getSourceVendor());

        Assert.assertEquals(firstItem.getDisposition(), secondItem.getDisposition());
        Assert.assertEquals(firstItem.getIsAuthorizationRequired().booleanValue(), secondItem.isAuthorizationRequired());
        Assert.assertEquals(firstItem.getOpenAuthorizationNumber(), secondItem.getOpenAuthorizationNumber());
        Assert.assertEquals(firstItem.getRefundAmount(), secondItem.getAmount());
        Assert.assertEquals(firstItem.getCost(), secondItem.getCost());
        Assert.assertEquals(firstItem.getBaseCurrencyCode(), secondItem.getBaseCurrencyCode());
        Assert.assertEquals(firstItem.getRefundBasicCode(), secondItem.getRefundBasisCode());
        Assert.assertEquals(firstItem.getPrice(), secondItem.getPrice(), 0.00001);
        
        Assert.assertEquals(firstItem.getForeignCurrencyCode(), secondItem.getForeignCurrencyCode());
        Assert.assertEquals(firstItem.getCostForeignCurrency(), secondItem.getCostForeignCurrency());
        Assert.assertEquals(firstItem.getRefundAmountForeignCurrency(), secondItem.getRefundAmountForeignCurrency());
        Assert.assertEquals(firstItem.getDistributorCostForeignCurrency(), secondItem.getDistributorCostForeignCurrency());
        Assert.assertEquals(firstItem.getDistributorListPriceForeignCurrency(), secondItem.getDistributorListPriceForeignCurrency());

        Assert.assertEquals(firstItem.getVRDSDescription(), secondItem.getVrdsDescription());
        
        Assert.assertEquals(firstItem.getReturnByMinDays().intValue(), secondItem.getReturnByMinDays());
        Assert.assertEquals(firstItem.getReturnByMaxDays().intValue(), secondItem.getReturnByMaxDays());
        
        Assert.assertEquals(firstItem.getDistributorId(), secondItem.getDistributorId());
        Assert.assertEquals(firstItem.getDistributorOrderId(), secondItem.getDistributorOrderId());
        Assert.assertEquals(firstItem.getDistributorShipmentId(), secondItem.getDistributorShipmentId());
        Assert.assertEquals(firstItem.getDistributorOrderDate(), secondItem.getDistributorOrderDate());
        Assert.assertEquals(firstItem.getDistributorOrderType().intValue(), secondItem.getDistributorOrderType());
        Assert.assertEquals(firstItem.getDistributorShipmentItemId().intValue(), secondItem.getDistributorShipmentItemId());
        Assert.assertEquals(firstItem.getShipmentReceiveDate(), secondItem.getShipmentReceiveDate());
    }

    private void assertData(DamagedVRDSItem firstItem, DamagedVRDSItem secondItem) {
        Assert.assertEquals(firstItem.getFnsku(), secondItem.getFnsku());
        Assert.assertEquals(firstItem.getFcsku(), secondItem.getFcsku());
        Assert.assertEquals(firstItem.getIog(), secondItem.getIog());
        Assert.assertEquals(firstItem.getCondition(), secondItem.getCondition());
        Assert.assertEquals(firstItem.getWarehouse(), secondItem.getWarehouse());
        Assert.assertEquals(firstItem.getQuantity(), secondItem.getQuantity());
        Assert.assertEquals(firstItem.getDestVendor(), secondItem.getDestVendor());
        Assert.assertEquals(firstItem.getSourceVendor(), secondItem.getSourceVendor());
        
        Assert.assertEquals(firstItem.getDisposition(), secondItem.getDisposition());
        Assert.assertEquals(firstItem.getIsAuthorizationRequired(), secondItem.getIsAuthorizationRequired());
        Assert.assertEquals(firstItem.getOpenAuthorizationNumber(), secondItem.getOpenAuthorizationNumber());
        Assert.assertEquals(firstItem.getRefundAmount(), secondItem.getRefundAmount());
        Assert.assertEquals(firstItem.getCost(), secondItem.getCost());
        Assert.assertEquals(firstItem.getBaseCurrencyCode(), secondItem.getBaseCurrencyCode());
        Assert.assertEquals(firstItem.getRefundBasicCode(), secondItem.getRefundBasicCode());
        Assert.assertEquals(firstItem.getPrice(), secondItem.getPrice(), 0.00001);

        Assert.assertEquals(firstItem.getVRDSDescription(), secondItem.getVRDSDescription());
        
        Assert.assertEquals(firstItem.getForeignCurrencyCode(), secondItem.getForeignCurrencyCode());
        Assert.assertEquals(firstItem.getCostForeignCurrency(), secondItem.getCostForeignCurrency());
        Assert.assertEquals(firstItem.getRefundAmountForeignCurrency(), secondItem.getRefundAmountForeignCurrency());
        Assert.assertEquals(firstItem.getDistributorCostForeignCurrency(), secondItem.getDistributorCostForeignCurrency());
        Assert.assertEquals(firstItem.getDistributorListPriceForeignCurrency(), secondItem.getDistributorListPriceForeignCurrency());

        Assert.assertEquals(firstItem.getReturnByMinDays().intValue(), secondItem.getReturnByMinDays().intValue());
        Assert.assertEquals(firstItem.getReturnByMaxDays().intValue(), secondItem.getReturnByMaxDays().intValue());
        
        Assert.assertEquals(firstItem.getDistributorId(), secondItem.getDistributorId());
        Assert.assertEquals(firstItem.getDistributorOrderId(), secondItem.getDistributorOrderId());
        Assert.assertEquals(firstItem.getDistributorShipmentId(), secondItem.getDistributorShipmentId());
        Assert.assertEquals(firstItem.getDistributorOrderDate(), secondItem.getDistributorOrderDate());
        Assert.assertEquals(firstItem.getDistributorOrderType().intValue(), secondItem.getDistributorOrderType().intValue());
        Assert.assertEquals(firstItem.getDistributorShipmentItemId().intValue(), secondItem.getDistributorShipmentItemId().intValue());
        Assert.assertEquals(firstItem.getShipmentReceiveDate(), secondItem.getShipmentReceiveDate());
    }
}