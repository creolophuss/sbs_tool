package com.amazon.oih.dao.vendorleadtime;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import amazon.platform.config.AppConfig;

import com.amazon.oih.dao.exception.OihPersistenceException;
import com.amazon.oih.dao.repository.DaoFactory;
import com.amazon.oih.dao.repository.RepositoryFactory;
import com.amazon.oih.utils.AsinIogPair;

public class VendorLeadTimeDaoImplTest {
    private static VendorLeadTimeDao dao = DaoFactory.getVendorLeadTimeDao(RepositoryFactory.UNIT_TEST);

    @BeforeClass
    public static void init() throws OihPersistenceException {
        Logger.getRootLogger().setLevel(Level.OFF);
        dao.deleteAll();// clear the data from the in-memory session
    }

    @Test
    public void testCreate() {
        long runId = 1;
        String vendor = "vendor1";
        long merchantId = 1;
        int gl=14;
        double avgvlt = 2.0;

        VendorLeadTime object = dao.createInstance( runId,  vendor,  merchantId,  gl ,  avgvlt);
        
        Assert.assertEquals(runId, object.getRunID());
        Assert.assertEquals(vendor, object.getVendor());
        Assert.assertEquals(merchantId, object.getMerchantId());
        Assert.assertEquals(gl, object.getGl());
        Assert.assertEquals((int)avgvlt, (int)object.getAverageVlt());;
    }

    @Test
    public void testFind() throws OihPersistenceException {
        long runId = 1L;
        long merchantId = 3;
        String vendor = "vendor1";
        int gl=1;
        int avgvlt=10;
        List<VendorLeadTime> l = new ArrayList<VendorLeadTime>();

        l.add(dao.createInstance(runId++,  vendor,  merchantId++,  gl ,  avgvlt++));
        l.add(dao.createInstance(runId++,  vendor,  merchantId++,  gl ,  avgvlt++));
        l.add(dao.createInstance(runId++,  vendor,  merchantId++,  gl ,  avgvlt++));
        l.add(dao.createInstance(runId++,  vendor,  merchantId++,  gl ,  avgvlt++));

        // set up test data
        for (VendorLeadTime it : l) {
            dao.save(it);
        }

        // verify that we can find the data with correct runId, asin and iog.
        for (VendorLeadTime it : l) {
        	VendorLeadTime vlt4Retrieve = dao.find(it.getRunID(), it.getVendor(), it.getMerchantId(), it.getGl());
            Assert.assertEquals(it.getVendor(), vlt4Retrieve.getVendor());
            Assert.assertEquals(it.getMerchantId(), vlt4Retrieve.getMerchantId());
            Assert.assertEquals(it.getGl(), vlt4Retrieve.getGl());
            Assert.assertEquals(it.getRunID(), vlt4Retrieve.getRunID());
            Assert.assertEquals((int)it.getAverageVlt(), (int)vlt4Retrieve.getAverageVlt());
        }

        // verify that we cannot find the data with wrong run id.
        Assert.assertEquals((int)dao.find(runId, "vendor1", merchantId, gl).getAverageVlt(), 7);
    }


    @Test
    public void testExists() throws OihPersistenceException {
    	long runId = 1L;
        long merchantId = 4;
        String vendor = "vendor3";
        int gl=1;
        int avgvlt=10;

        // set up test data
        dao.save(dao.createInstance( runId,  vendor,  merchantId,  gl ,  avgvlt));

        // verify that data exists
        Assert.assertTrue(dao.exists(runId, vendor, merchantId, gl));

        // verify that data not exists
        Assert.assertFalse(dao.exists(runId, vendor, ++merchantId, gl));
    }
    
}
