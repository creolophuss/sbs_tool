package com.amazon.oih.dao.markdowninfo;

import java.util.Date;

import javax.naming.NamingException;

import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import amazon.platform.config.AppConfig;

import com.amazon.carbonado.PersistException;
import com.amazon.carbonado.Repository;
import com.amazon.carbonado.RepositoryException;
import com.amazon.carbonado.Storage;
import com.amazon.carbonado.SupportException;
import com.amazon.oih.dao.exception.OihPersistenceException;
import com.amazon.oih.dao.repository.DaoFactory;
import com.amazon.oih.dao.repository.RepositoryFactory;

public class MarkdownInfoDaoTest {
    private IMarkdownInfoDao dao = DaoFactory.getMarkdownInfoDao(new Date() ,RepositoryFactory.UNIT_TEST);
    
    @BeforeClass
    public static void init() {
        if(!AppConfig.isInitialized()){
            String args[] = new String[] {
                                "--JARConfigFile=./tst/testBrazilConfig.jar",
                                "--domain=test",
                                "--realm=USAmazon",
                                "--override=TestBrazilConfig.cfg"
                                };
            AppConfig.initialize("someapp","someappgroup",args);
        }
    }
    
    @Before
    public void cleanUpRepository() throws SupportException, RepositoryException {
        Repository r = RepositoryFactory.getInst().getRepository(MarkdownInfoBDBObject.class, RepositoryFactory.UNIT_TEST);
        Storage<MarkdownInfoBDBObject> sf = r.storageFor(MarkdownInfoBDBObject.class);
        sf.truncate();
    }
    
    @Test
    public void testClassOfDaoMustBeMarkdownInfoDao(){
        Assert.assertEquals(MarkdownInfoDao.class, dao.getClass());
    }

    @Test
    public void testCreate() throws NamingException, RepositoryException, ClassNotFoundException, OihPersistenceException {
        long runId = 1;
        String asin = "0000000000";
        int marketplaceId = 1;
        double recoveryRate = 0.75;
        double demandIncrease = 1.5;
        double demandIncreaseRate = 0.5;
        String dataLevel = "dataLevelTest";
        String dataVersion = "dataVersionTest";
        
        MarkdownInfo info = dao.createMarkdownInfo(runId, asin, marketplaceId, recoveryRate, demandIncrease, demandIncreaseRate, dataLevel, dataVersion);
        Assert.assertEquals(info.getAsin(), asin);
        Assert.assertEquals(info.getMarketplaceId(), marketplaceId);
        Assert.assertEquals(info.getRecoveryRate(), recoveryRate, 0.000001);
        Assert.assertEquals(info.getDemandIncrease(), demandIncrease, 0.000001);
        Assert.assertEquals(info.getDemandIncreaseRate(), demandIncreaseRate, 0.000001);
        Assert.assertEquals(info.getDataLevel(), dataLevel);
        Assert.assertEquals(info.getDataVersion(), dataVersion);
    }

    @Test
    public void testDuplicate() throws PersistException, NamingException, RepositoryException, ClassNotFoundException {
        try {
            dao.save(dao.createMarkdownInfo(new Long(1), "0000000000", 1, 0.75, 1.5, 0.5, "dataLevel", "dataVersion"));
            dao.save(dao.createMarkdownInfo(new Long(1), "0000000000", 1, 0.75, 1.5, 0.5, "dataLevel", "dataVersion"));
            Assert.fail("Should have failed due to duplicate forecast");
        }catch (OihPersistenceException e) {
            // OK, expected
        }
    }

    @Test
    public void testExisted() throws NamingException, RepositoryException, ClassNotFoundException, OihPersistenceException {
        long runId = 1;
        String asin = "0000000000";
        int mpId = 1;

        MarkdownInfo infoForSave = dao.createMarkdownInfo(runId, asin, mpId, 0.75, 1.5, 0.5, "dataLevel", "dataVersion");
        dao.save(infoForSave);
        Assert.assertTrue(dao.exists(runId, asin, mpId));
    }

    @Test
    public void testFind() throws NamingException, RepositoryException, ClassNotFoundException, OihPersistenceException {
        long runId = 1;
        String asin = "0000000000";
        int mpId = 1;
        MarkdownInfo infoForSave = dao.createMarkdownInfo(runId, asin, mpId, 0.75, 1.5, 0.5, "dataLevel", "dataVersion");
        dao.save(infoForSave);
        
        MarkdownInfo infoForRetrieve =  dao.find(runId, asin, mpId);
        
        Assert.assertTrue( infoForRetrieve!= null);
        
        Assert.assertEquals(infoForSave.getAsin(), infoForRetrieve.getAsin());
        Assert.assertEquals(infoForSave.getMarketplaceId(), infoForRetrieve.getMarketplaceId());
        Assert.assertEquals(infoForSave.getRecoveryRate(), infoForRetrieve.getRecoveryRate(), 0.000001);
        Assert.assertEquals(infoForSave.getDemandIncrease(), infoForRetrieve.getDemandIncrease(), 0.000001);
        Assert.assertEquals(infoForSave.getDemandIncreaseRate(), infoForRetrieve.getDemandIncreaseRate(), 0.000001);
        Assert.assertEquals(infoForSave.getDataLevel(), infoForRetrieve.getDataLevel());
        Assert.assertEquals(infoForSave.getDataVersion(), infoForRetrieve.getDataVersion());
    }
}
