package com.amazon.oih.dao.averageliquidationinfo;

import java.util.List;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.amazon.oih.dao.exception.OihPersistenceException;
import com.amazon.oih.dao.repository.DaoFactory;
import com.amazon.oih.dao.repository.RepositoryFactory;

public class AverageLiquidationInfoDaoTest {
    private static AverageLiquidationInfoDao dao = DaoFactory.getAverageLiquidationInfoDao(RepositoryFactory.UNIT_TEST);
    private static long RUN_ID = 1;
    private static int IOG = 1;
    private static String COUNTRY = "US";
    private static String GL = "14";
    private static String CATEGORY = "TEST_CATEGORY";
    private static String SUB_CATEGORY = "TEST_SUB_CATEGORY";
    private static String TYPE = "TEST_TYPE";
    private static String LAYER = "TEST_LAYER";
    private static double RATE = 77.11;
    private static boolean RATE_FOUND = true;

    @Before
    public void init() throws OihPersistenceException {
        Logger.getRootLogger().setLevel(Level.OFF);
        dao.deleteAll();// clear the data from the in-memory session
    }

    @Test
    public void testCreate() {
        AverageLiquidationInfo object = dao.createAverageLiquidationInfo(RUN_ID, IOG, COUNTRY, GL, CATEGORY,
                SUB_CATEGORY, RATE, TYPE, LAYER, RATE_FOUND);

        assertResult(object);
    }

    @Test
    public void testFind() throws OihPersistenceException {
        AverageLiquidationInfo object4Save = dao.createAverageLiquidationInfo(RUN_ID, IOG, COUNTRY, GL, CATEGORY,
                SUB_CATEGORY, RATE, TYPE, LAYER, RATE_FOUND);

        dao.save(object4Save);

        AverageLiquidationInfo object4Retrieve = dao.find(RUN_ID, IOG, COUNTRY, GL, CATEGORY, SUB_CATEGORY);
        Assert.assertNotNull(object4Retrieve);

        assertResult(object4Retrieve);
    }

    private void assertResult(AverageLiquidationInfo object) {
        Assert.assertEquals(RUN_ID, object.getRunID());
        Assert.assertEquals(IOG, object.getIog());
        Assert.assertEquals(COUNTRY, object.getCountry());
        Assert.assertEquals(GL, object.getGl());
        Assert.assertEquals(CATEGORY, object.getCategory());
        Assert.assertEquals(SUB_CATEGORY, object.getSubCategory());
        Assert.assertEquals(TYPE, object.getType());
        Assert.assertEquals(LAYER, object.getLayer());
        Assert.assertEquals(RATE, object.getRate(), 0.00001);
        Assert.assertEquals(RATE_FOUND ? "Y" : "N", object.getRateFound());
    }

    @Test
    public void testExists() throws OihPersistenceException {
        AverageLiquidationInfo object4Save = dao.createAverageLiquidationInfo(RUN_ID, IOG, COUNTRY, GL, CATEGORY,
                SUB_CATEGORY, RATE, TYPE, LAYER, RATE_FOUND);

        dao.save(object4Save);

        // verify that data exists
        Assert.assertTrue(dao.exists(RUN_ID, IOG, COUNTRY, GL, CATEGORY, SUB_CATEGORY));

        int badIog = 1010;
        // verify that data not exists
        Assert.assertFalse(dao.exists(RUN_ID, badIog, COUNTRY, GL, CATEGORY, SUB_CATEGORY));
    }
    
    @Test
    public void testFindList() throws OihPersistenceException {
        AverageLiquidationInfo object4Save = dao.createAverageLiquidationInfo(RUN_ID, IOG, COUNTRY, GL, CATEGORY,
                SUB_CATEGORY, RATE, TYPE, LAYER, RATE_FOUND);
        dao.save(object4Save);
        
        object4Save = dao.createAverageLiquidationInfo(RUN_ID, 2, COUNTRY, "15", CATEGORY,
                SUB_CATEGORY, RATE, TYPE, LAYER, RATE_FOUND);
        dao.save(object4Save);
        
        
        object4Save = dao.createAverageLiquidationInfo(2L, IOG, COUNTRY, "15", CATEGORY,
                SUB_CATEGORY, RATE, TYPE, LAYER, RATE_FOUND);
        dao.save(object4Save);
        
        object4Save = dao.createAverageLiquidationInfo(RUN_ID, IOG, "CA", "15", CATEGORY,
                SUB_CATEGORY, RATE, TYPE, LAYER, RATE_FOUND);
        dao.save(object4Save);
        
        List<AverageLiquidationInfo> result = dao.find(COUNTRY, RUN_ID);
        Assert.assertTrue(result.size() == 2);
    }
}
