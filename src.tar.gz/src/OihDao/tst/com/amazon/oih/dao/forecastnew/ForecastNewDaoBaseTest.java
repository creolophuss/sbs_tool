package com.amazon.oih.dao.forecastnew;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.naming.NamingException;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.amazon.carbonado.PersistException;
import com.amazon.carbonado.Repository;
import com.amazon.carbonado.RepositoryException;
import com.amazon.carbonado.Storage;
import com.amazon.carbonado.SupportException;
import com.amazon.oih.dao.forecast.ForecastType;
import com.amazon.oih.dao.repository.DaoFactory;
import com.amazon.oih.dao.repository.RepositoryFactory;

public class ForecastNewDaoBaseTest {
    private static Long _runId = 0L;
    private static ForecastNewDao forecastDao = DaoFactory.getForecastNewBDBDao(RepositoryFactory.UNIT_TEST);

    List<Double> forecasts = new ArrayList<Double>();
    
    @Before
    public void cleanUpRepository() throws SupportException, RepositoryException {
        Repository r = RepositoryFactory.getInst().getRepository(ForecastNewBDBObject.class, RepositoryFactory.UNIT_TEST);
        Storage<ForecastNewBDBObject> sf = r.storageFor(ForecastNewBDBObject.class);
        sf.truncate();
        
        for (int i=0; i<33; i++) {
            forecasts.add(Double.valueOf(i+1));
        }
    }

    @Test
    public void testCreate() throws NamingException, RepositoryException, ClassNotFoundException {
        ForecastType[] forecastTypes = new ForecastType[] {
                ForecastType.OIH, ForecastType.P50, ForecastType.OIH, ForecastType.MEAN
        };
        long runId = 1;
        String asin = "0000000000";
        int iog = 1;
        int period = 7;
        double probablity = 0.5;
        double value = 0.1;

        for (ForecastType type : forecastTypes) {
            ForecastNew forecast = forecastDao.createForecast(runId, asin, iog, type, probablity, forecasts, "");
            Assert.assertEquals(runId, forecast.getRunID());
            Assert.assertEquals(asin, forecast.getAsin());
            Assert.assertEquals(type, forecast.getForecastType());
            Assert.assertEquals(probablity, forecast.getProbability(), 0);
            Assert.assertEquals(1, forecast.getWeek1(), 0);
            Assert.assertEquals(2, forecast.getWeek2(), 0);
            Assert.assertEquals(3, forecast.getWeek3(), 0);
            Assert.assertEquals(4, forecast.getWeek4(), 0);
            Assert.assertEquals(5, forecast.getWeek5(), 0);
            Assert.assertEquals(6, forecast.getWeek6(), 0);
            Assert.assertEquals(7, forecast.getWeek7(), 0);
            Assert.assertEquals(8, forecast.getWeek8(), 0);
            Assert.assertEquals(9, forecast.getWeek9(), 0);
            Assert.assertEquals(10, forecast.getWeek10(), 0);
            Assert.assertEquals(11, forecast.getWeek11(), 0);
            Assert.assertEquals(12, forecast.getWeek12(), 0);
            Assert.assertEquals(13, forecast.getWeek13(), 0);
            Assert.assertEquals(14, forecast.getWeek14(), 0);
            Assert.assertEquals(15, forecast.getWeek15(), 0);
            Assert.assertEquals(16, forecast.getWeek16(), 0);
            Assert.assertEquals(17, forecast.getWeek17(), 0);
            Assert.assertEquals(18, forecast.getWeek18(), 0);
            Assert.assertEquals(19, forecast.getWeek19(), 0);
            Assert.assertEquals(20, forecast.getWeek20(), 0);
            Assert.assertEquals(21, forecast.getWeek21(), 0);
            Assert.assertEquals(22, forecast.getWeek22(), 0);
            Assert.assertEquals(23, forecast.getWeek23(), 0);
            Assert.assertEquals(24, forecast.getWeek24(), 0);
            Assert.assertEquals(25, forecast.getWeek25(), 0);
            Assert.assertEquals(26, forecast.getWeek26(), 0);
            Assert.assertEquals(27, forecast.getWeek27(), 0);
            Assert.assertEquals(28, forecast.getWeek28(), 0);
            Assert.assertEquals(29, forecast.getWeek29(), 0);
            Assert.assertEquals(30, forecast.getWeek30(), 0);
            Assert.assertEquals(31, forecast.getWeek31(), 0);
            Assert.assertEquals(32, forecast.getWeek32(), 0);
            Assert.assertEquals(33, forecast.getWeek33(), 0);
        }
    }

    @Test(expected = IllegalArgumentException.class)
    public void testCreateWrongAsin() throws NamingException, RepositoryException, ClassNotFoundException {
        forecastDao.createForecast(_runId++, "0000000000000", 1, ForecastType.OIH, 0.5,forecasts, "");
    }


    @Test(expected = IllegalArgumentException.class)
    public void testCreateWrongPorbability() throws NamingException, RepositoryException, ClassNotFoundException {
        forecastDao.createForecast(_runId++, "0000ABC000", 1, ForecastType.OIH, 2.0, forecasts, "");
    }


    @Test
    public void testSaveMulti() throws NamingException, RepositoryException, ClassNotFoundException {
        List<ForecastNew> l = new ArrayList<ForecastNew>();

        l.add(forecastDao.createForecast(_runId++, "0000000000", 1, ForecastType.OIH, 0.5, forecasts, ""));

        forecastDao.save(l);
    }
   
    @Test
    public void testDuplicate() throws PersistException, NamingException, RepositoryException, ClassNotFoundException {
        long runId = _runId++;
        // as long as one of runId, asin, type, or period differ, there should be no problem
        forecastDao.save(forecastDao.createForecast(runId, "0000000000", 1, ForecastType.OIH, 0.5,forecasts, ""));
        forecastDao.save(forecastDao.createForecast(runId, "0000000000", 1, ForecastType.OIH, 0.6, forecasts, ""));
        forecastDao.save(forecastDao.createForecast(runId, "0000000000", 1, ForecastType.P50, 0.5, forecasts, ""));
        try {
            forecastDao.save(forecastDao.createForecast(runId, "0000000000", 1, ForecastType.OIH, 0.5, forecasts, ""));
            Assert.fail("Should have failed due to duplicate forecast");
        } catch (RepositoryException ex) {
            // OK, expected
        }
    }
    
    @Test
    public void testExisted() throws NamingException, RepositoryException, ClassNotFoundException {
        ForecastNew f1;

        long _runId = 1;
        String asin = "0000000000";
        int iog = 1;
        
        f1 = forecastDao.createForecast(_runId, asin, iog, ForecastType.OIH, 0.85, forecasts, "");
        forecastDao.save(f1);
        Assert.assertTrue(forecastDao.exists(_runId, asin, iog, ""));
    }
    
   
    @Test
    public void testFind() throws NamingException, RepositoryException, ClassNotFoundException {
        ForecastNew f1, f2, f3, f4;

        long _runId = 1;
        
        f1 = forecastDao.createForecast(_runId, "0000000000", 1, ForecastType.OIH, 0.5, forecasts, "");
        forecastDao.save(f1);
        
        Assert.assertTrue("ASIN " + f1.getAsin() + " inserted but not found!",
                forecastDao.find(_runId, f1.getAsin(), f1.getIog(), "").size() > 0);
        
        
    }
    
    @Test
    public void testFindOrderByProbablity() throws NamingException, RepositoryException, ClassNotFoundException {
        ForecastNew f1, f2, f3, f4, f5;
        ForecastNew cf1, cf2, cf3, cf4, cf5;

        long _runId = 1;
        String asin = "0000000000";
        int iog = 1;
        
        f1 = forecastDao.createForecast(_runId, asin, iog, ForecastType.OIH, 0.5, forecasts, "");
        forecastDao.save(f1);

        f3 = forecastDao.createForecast(_runId, asin, iog, ForecastType.OIH, 0.7, forecasts, "");
        forecastDao.save(f3);
        
        f4 = forecastDao.createForecast(_runId, asin, iog, ForecastType.OIH, 0.6, forecasts, "");
        forecastDao.save(f4);

        List<? extends ForecastNew>  forecasts =  forecastDao.findOrderedByProbability(_runId, asin, iog, ForecastType.OIH, "");

        Assert.assertEquals(forecasts.get(0).getProbability(), 0.5, 0.0);
        Assert.assertEquals(forecasts.get(1).getProbability(), 0.6, 0.0);
        Assert.assertEquals(forecasts.get(2).getProbability(), 0.7, 0.0);
        
    }
    
}
