package com.amazon.oih.dao.ilbo;

import java.util.Properties;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.amazon.oih.dao.DaoConstants;
import com.amazon.oih.dao.HibernateUtil;
import com.amazon.oih.dao.exception.DaoRuntimeException;
import com.amazon.oih.dao.exception.OihPersistenceException;
import com.amazon.oih.dao.repository.DaoFactory;
import com.amazon.oih.dao.repository.RepositoryFactory;

public class IlboDaoTest {
    private static Long _runId = 0L;
    
    private SessionFactory sessionFactory;
    private static IlboDao ilboDao = (IlboDao) DaoFactory.getDao(IlboObject.class, DaoConstants.UNIT_TEST);
    
    
    @Before
    public void setup() {
        //SessionFactory/HSQLDB/schema is built for each test.  
        //Not fast, but we have a clean DB each test
        //Setup all config properties by hand.
        Properties props = new Properties();
        props.setProperty("hibernate.connection.driver_class", "org.hsqldb.jdbcDriver");
        //to connect to server running on localhost, use url like: jdbc:hsqldb:hsql://localhost/xdb
        props.setProperty("hibernate.connection.url", "jdbc:hsqldb:file:/var/tmp/testdb");
        props.setProperty("hibernate.connection.username", "sa");
        props.setProperty("hibernate.connection.password", "");
        props.setProperty("hibernate.dialect", "org.hibernate.dialect.HSQLDialect");
        props.setProperty("connection.pool_size", "5");
        props.setProperty("hibernate.hbm2ddl.auto", "create");
        props.setProperty("show_sql", "true");
        Configuration config = new Configuration();
        config.setProperties(props);
        try {
            //need to specify classes to be mapped by hand too
            config.addClass(IlboObject.class);
            sessionFactory = config.buildSessionFactory();
            HibernateUtil.setSessionFactory(sessionFactory);
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Unable to setup sessionFactory");
        }
        HibernateUtil.setSessionFactory(sessionFactory);       
    }

    @Test
    public void testFindCurrent() throws OihPersistenceException, DaoRuntimeException {
        IlboObject i1, i2, i3;
        try {
            i1 = new IlboObject("0000000000", 1, RepositoryFactory.UNIT_TEST, "LEX1", 0, 0, 0, 0);
            ilboDao.insert(i1);
            //i2 = new IlboObject("0000000001", 1, RepositoryFactory.UNIT_TEST, "LEX1", 0, 0, 0, 0);
            i2 = (IlboObject) ilboDao.findCurrent(i1);          
            Assert.assertEquals(i1, i2);
        } catch (DaoRuntimeException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            throw e;
        } catch (OihPersistenceException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            throw e;
        }
    }
 
    @Test
    public void testGeneral() throws OihPersistenceException, DaoRuntimeException {
        IlboObject i1, i2, i3, i4;
        try {
            
            //test insert
            i1 = new IlboObject("0000000000", 1, RepositoryFactory.UNIT_TEST, "LEX1", 0, 0, 0, 0);
            ilboDao.insert(i1);

            // test find
            i2 = (IlboObject) ilboDao.findCurrent(i1);          
            Assert.assertEquals(i1, i2);
            
            //test update
            i2.setSellableAllocatedQty(1);
            i2.setUnsellableOnHandQty(4);
            ilboDao.update(i2);
            i3 = (IlboObject) ilboDao.findCurrent(i2);
            Assert.assertEquals(i3, i2);
            Assert.assertFalse(i3.equals(i1));
            
            // test delete
            ilboDao.delete(i2);
            i4 = (IlboObject) ilboDao.findCurrent(i2);
            Assert.assertNull(i4);
  
        } catch (DaoRuntimeException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            throw e;
        } catch (OihPersistenceException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            throw e;
        }
    }

}
