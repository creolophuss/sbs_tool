package com.amazon.oih.dao.shipcosts;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class AsinShipoutCostInfoEncoderTest {

    private AsinShipoutCostInfo info;
    
    @Before
    public void init() {
        info = new AsinShipoutCostInfo();
        info.setAsin("0000000001");
        info.setScopeId("TESTAmazon");
        
        info.addCost(1.0, "FC1", 10.0);
        info.addCost(1.0, "FC2", 11.0);
        info.addCost(1.0, "FC3", 12.0);
        
        info.addCost(2.0, "FC1", 20.0);
        info.addCost(2.0, "FC2", 21.0);
        info.addCost(2.0, "FC3", 22.0);
        
        info.addCost(3.0, "FC1", 30.0);
        info.addCost(3.0, "FC2", 31.0);
        info.addCost(3.0, "FC3", 32.0);
    }
    
    @Test
    public void testAsinShipCostInfotoHBaseObject() {
        AsinShipoutCostInfoHBaseObject hbaseObj = AsinShipoutCostInfoEncoder.asinShipCostInfotoHBaseObject(info);
        Assert.assertNotNull(hbaseObj);
        
        System.out.println(hbaseObj.getAsin() + ":" + hbaseObj.getScopeId());
        System.out.println(hbaseObj.getValue());
    }
    
    @Test
    public void testHBaseObjectToAsinShipoutCostInfo() {
        AsinShipoutCostInfoHBaseObject hbaseObj = AsinShipoutCostInfoEncoder.asinShipCostInfotoHBaseObject(info);
        
        AsinShipoutCostInfoHBaseObject newO = new AsinShipoutCostInfoHBaseObject();
       
        AsinShipoutCostInfo newInfo = AsinShipoutCostInfoEncoder.hBaseObjectToAsinShipoutCostInfo(hbaseObj);
        
        
        Assert.assertNotNull(newInfo);
        Assert.assertEquals(newInfo.getAsin(), info.getAsin());
        
        Assert.assertNotNull(newInfo);
        Assert.assertEquals(newInfo.getScopeId(), info.getScopeId());
        
        Assert.assertTrue(20.0 == newInfo.getCostTable().get(2.0, "FC1"));
        Assert.assertTrue(31.0 == newInfo.getCostTable().get(3.0, "FC2"));
        Assert.assertTrue(12.0 == newInfo.getCostTable().get(1.0, "FC3"));
        
        hbaseObj.setValue("{}");
        Assert.assertTrue(AsinShipoutCostInfoEncoder.hBaseObjectToAsinShipoutCostInfo(hbaseObj).getCostTable().isEmpty());
    }
}
