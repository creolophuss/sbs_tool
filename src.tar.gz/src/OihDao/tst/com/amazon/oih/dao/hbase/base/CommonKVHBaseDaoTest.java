package com.amazon.oih.dao.hbase.base;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.junit.Assert;
import org.junit.Test;

import com.amazon.oih.dao.hbase.base.CommonKVHBaseDao.HTable;
import com.amazon.oih.dao.hbase.converter.Column;
import com.amazon.oih.dao.hbase.converter.RowKey;
import com.google.common.collect.Sets;


public class CommonKVHBaseDaoTest {
	private CommonKVHBaseDao<TestClass> dao = new CommonKVHBaseDao<TestClass>(TestClass.class); 
	
	@Test
	public void testGenerateRowKey() {
    	TestClass testObj = new TestClass();
    	testObj.setAsin("ASIN1");
    	testObj.setIog(1);
    	testObj.setValue(0.44);
    	
    	String rowKey = dao.generateRowKey(testObj);
    	Assert.assertEquals("ASIN1:1", rowKey);
	}

	@Test
	public void testGenerateColumnValueMap() {
    	TestClass testObj = new TestClass();
    	testObj.setAsin("ASIN1");
    	testObj.setIog(1);
    	testObj.setValue(0.44);
    	testObj.setStrValue("String");
		Map<String, String> valueMap = dao.generateColumnValueMap(testObj);
		
		Assert.assertEquals(1, valueMap.size());
		Assert.assertEquals("0.44,String", valueMap.get("test"));
	}

	@Test
	public void testConstruct() {
    	TestClass testObj = new TestClass();
    	testObj.setAsin("ASIN1");
    	testObj.setIog(1);
    	testObj.setValue(0.44);
    	testObj.setStrValue("String");
		Map<String, String> valueMap = dao.generateColumnValueMap(testObj);
		String rowKey = dao.generateRowKey(testObj);

		TestClass result = dao.construct(rowKey, valueMap);
		Assert.assertEquals("ASIN1", result.getAsin());
		Assert.assertEquals(1, result.getIog());
		Assert.assertTrue(result.getValue().doubleValue() - 0.44 == 0);
		Assert.assertEquals("String", result.getStrValue());
		Assert.assertFalse(testObj == result);
	}
	
	@Test
	public void testObtainTableName() {
		String tableName = CommonKVHBaseDao.obtainTableName(TestClass.class, null);
		Assert.assertEquals("test", tableName);		
	}
	
	@Test
	public void testFindExistRowKeys(){
	    List<Integer> resultList = new ArrayList<Integer>();
	    List<String> keyList = new ArrayList<String>();
	    resultList.add(1);
	    resultList.add(1);
	    resultList.add(null);
	    resultList.add(1);
	    keyList.add("ASIN1");
	    keyList.add("ASIN2");
	    keyList.add("ASIN3");
	    keyList.add("ASIN4");
	    
	    Set<String> existKeys = HBaseDaoImplAdaptor.findExistRowKeys(keyList, resultList);
	    Assert.assertEquals(Sets.newHashSet("ASIN1", "ASIN2", "ASIN4"), existKeys);
	}

	@RowKey({"asin", "iog"})
	@HTable("test")
    public static class TestClass {
    	private String asin;
    	private int iog;
    	
    	@Column(name="test",index=0)
    	private Double value;
    	@Column(name="test",index=1)
    	private String strValue;
    	
		public String getAsin() {
			return asin;
		}
		public void setAsin(String asin) {
			this.asin = asin;
		}
		public int getIog() {
			return iog;
		}
		public void setIog(int iog) {
			this.iog = iog;
		}
		public Double getValue() {
			return value;
		}
		public void setValue(Double value) {
			this.value = value;
		}
		public String getStrValue() {
			return strValue;
		}
		public void setStrValue(String strValue) {
			this.strValue = strValue;
		}  	
    }
}
