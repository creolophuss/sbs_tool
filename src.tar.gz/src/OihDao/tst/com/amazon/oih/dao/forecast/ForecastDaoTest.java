package com.amazon.oih.dao.forecast;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.naming.NamingException;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.joda.time.DateTime;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import amazon.platform.config.AppConfig;

import com.amazon.carbonado.RepositoryException;
import com.amazon.oih.dao.exception.DaoRuntimeException;
import com.amazon.oih.dao.exception.OihPersistenceException;
import com.amazon.oih.dao.repository.DaoFactory;
import com.amazon.oih.dao.repository.RepositoryFactory;

/**
 * Unit test for forecast Dao
 * 
 * @author zhongwei
 * 
 */
public class ForecastDaoTest {
    private static String domain = RepositoryFactory.UNIT_TEST;
    private static String realm = "USAmazon";
    final static Date RUN_DATE = new DateTime("2010-01-19").toDate();
    private ForecastDao forecastDao = (ForecastDao) DaoFactory.getDao(ForecastObject.class, domain);
    private final static int NUM_OF_WEEKS = 52;
    private static List<Double> forecastsOld = new ArrayList<Double>(NUM_OF_WEEKS);
    private static List<Double> forecastsNew = new ArrayList<Double>(NUM_OF_WEEKS);

    static {
        for (int i = 0; i < NUM_OF_WEEKS; i++) {
            forecastsOld.add(Double.valueOf(i + i));
        }

        for (int i = 0; i < NUM_OF_WEEKS; i++) {
            forecastsNew.add(Double.valueOf(i));
        }

    }

    @BeforeClass
    public static void init() {
        Logger.getRootLogger().setLevel(Level.OFF);

        if (!AppConfig.isInitialized()) {
            AppConfig.initialize("OihMetrics", "Oih", new String[] {
                    "--root=/tmp", "--domain=" + domain, "--realm=" + realm,
            });
        }
    }

    /**
     * Try to insert into the database two times, then the old value should be updated by the new value
     * 
     * @throws DaoRuntimeException
     * @throws OihPersistenceException
     */

    @Test
    public void testInsert() throws DaoRuntimeException, OihPersistenceException {
        String asin = "0000000000";
        long old_seq_id = 12345;
        int iog = 1;

        ForecastObject oldForecastValueForSave = new ForecastObject(asin, iog, domain, RUN_DATE, forecastsOld);
        oldForecastValueForSave.setSequenceId(old_seq_id);

        forecastDao.oihInsert(oldForecastValueForSave);

        ForecastObject current = (ForecastObject) forecastDao.find(asin, iog, domain, RUN_DATE);
        Assert.assertNotNull(current);
        Assert.assertEquals(current.getAsin(), asin);
        Assert.assertEquals(current.getIog(), iog);
        Assert.assertEquals(current.getSource(), domain);
        Assert.assertEquals(current.getStatus(), "OK");

        List<Double> forecasts4Retrieve = current.getForecasts();
        Assert.assertEquals(forecasts4Retrieve.size(), NUM_OF_WEEKS);

        for (int i = 0; i < NUM_OF_WEEKS; i++) {
            Assert.assertEquals(forecasts4Retrieve.get(i), forecastsOld.get(i));
        }
    }

    /**
     * Try to insert into the database two times, then the old value should be updated by the new value
     * 
     * @throws DaoRuntimeException
     * @throws OihPersistenceException
     */

    @Test
    public void testDuplicate() throws DaoRuntimeException, OihPersistenceException {
        String asin = "0000000000";
        long old_seq_id = 12345;
        long new_seq_id = 12346;
        int iog = 1;

        ForecastObject oldForecastValueForSave = new ForecastObject(asin, iog, domain, RUN_DATE, forecastsOld);
        ForecastObject newForecastValueForSave = new ForecastObject(asin, iog, domain, RUN_DATE, forecastsNew);
        oldForecastValueForSave.setSequenceId(old_seq_id);
        newForecastValueForSave.setSequenceId(new_seq_id);

        forecastDao.oihInsert(oldForecastValueForSave);
        forecastDao.oihInsert(newForecastValueForSave);

        ForecastObject current = (ForecastObject) forecastDao.findCurrent(asin, iog, domain);
        Assert.assertNotNull(current);
        Assert.assertEquals(current.getAsin(), asin);
        Assert.assertEquals(current.getIog(), iog);
        Assert.assertEquals(current.getSource(), domain);
        Assert.assertEquals(current.getStatus(), "OK");

        List<Double> forecasts4Retrieve = current.getForecasts();
        Assert.assertEquals(forecasts4Retrieve.size(), NUM_OF_WEEKS);

        for (int i = 0; i < NUM_OF_WEEKS; i++) {
            Assert.assertEquals(forecasts4Retrieve.get(i), forecastsNew.get(i));
        }

    }

    /**
     * Insert into the database, then try to retrieve it by findCurrent
     * 
     * @throws DaoRuntimeException
     * @throws OihPersistenceException
     */
    @Test
    public void testFindCurrentByObject() throws NamingException, RepositoryException, ClassNotFoundException,
            DaoRuntimeException, OihPersistenceException {
        ForecastObject f1, f2;

        f1 = new ForecastObject("0000000000", 1, domain, RUN_DATE, forecastsNew);
        forecastDao.oihInsert(f1);
        Assert.assertEquals(f1, forecastDao.findCurrent(f1));

        f2 = new ForecastObject("0000000GAF", 1, domain, RUN_DATE, forecastsNew);
        forecastDao.oihInsert(f2);
        Assert.assertEquals(f2, forecastDao.findCurrent(f2));

        Assert.assertTrue("ASIN " + f1.getAsin() + "IOG " + f1.getIog() + " inserted but not found!", forecastDao
                .findCurrent(f1) != null);

        ForecastObject f3 = new ForecastObject("000000TEST", 1, domain, RUN_DATE, forecastsNew);
        Assert.assertTrue("ASIN " + f3.getAsin() + "IOG " + (f3.getIog()) + " was not inserted but found!", forecastDao
                .findCurrent(f3) == null);
    }

    /**
     * Insert into the database, then try to retrieve it by findCurrent
     * 
     * @throws DaoRuntimeException
     * @throws OihPersistenceException
     */
    @Test
    public void testFindCurrentByRawParameter() throws NamingException, RepositoryException, ClassNotFoundException,
            DaoRuntimeException, OihPersistenceException {
        ForecastObject f1, f2;

        f1 = new ForecastObject("0000000000", 1, domain, RUN_DATE, forecastsNew);
        forecastDao.oihInsert(f1);
        Assert.assertEquals(f1, forecastDao.findCurrent(f1.getAsin(), f1.getIog(), f1.getSource()));

        f2 = new ForecastObject("0000000GAF", 1, domain, RUN_DATE, forecastsNew);
        forecastDao.oihInsert(f2);
        Assert.assertEquals(f2, forecastDao.findCurrent(f2.getAsin(), f2.getIog(), f2.getSource()));

        Assert.assertTrue("ASIN " + f1.getAsin() + "IOG " + f1.getIog() + " inserted but not found!", forecastDao
                .findCurrent(f1.getAsin(), f1.getIog(), f1.getSource()) != null);

        ForecastObject f3 = new ForecastObject("000000TEST", 1, domain, RUN_DATE, forecastsNew);
        Assert.assertTrue("ASIN " + f3.getAsin() + "IOG " + (f3.getIog()) + " was not inserted but found!", forecastDao
                .findCurrent(f3.getAsin(), f3.getIog(), f3.getSource()) == null);
    }

    /**
     * Insert into the database, then try to retrieve it by findCurrent
     * 
     * @throws DaoRuntimeException
     * @throws OihPersistenceException
     */
    @Test
    public void testFindByObject() throws NamingException, RepositoryException, ClassNotFoundException,
            DaoRuntimeException, OihPersistenceException {
        ForecastObject f1, f2;

        f1 = new ForecastObject("0000000000", 1, domain, RUN_DATE, forecastsNew);
        forecastDao.oihInsert(f1);
        Assert.assertEquals(f1, forecastDao.find(f1, RUN_DATE));

        f2 = new ForecastObject("0000000GAF", 1, domain, RUN_DATE, forecastsNew);
        forecastDao.oihInsert(f2);
        Assert.assertEquals(f2, forecastDao.find(f2, RUN_DATE));

        Assert.assertTrue("ASIN " + f1.getAsin() + "IOG " + f1.getIog() + " inserted but not found!", forecastDao
                .findCurrent(f1) != null);

        ForecastObject f3 = new ForecastObject("000000TEST", 1, domain, RUN_DATE, forecastsNew);
        Assert.assertTrue("ASIN " + f3.getAsin() + "IOG " + (f3.getIog()) + " was not inserted but found!", forecastDao
                .find(f3, RUN_DATE) == null);
    }

    /**
     * Insert into the database, then try to retrieve it by findCurrent
     * 
     * @throws DaoRuntimeException
     * @throws OihPersistenceException
     */
    @Test
    public void testFindByParameter() throws NamingException, RepositoryException, ClassNotFoundException,
            DaoRuntimeException, OihPersistenceException {
        ForecastObject f1, f2;

        f1 = new ForecastObject("0000000000", 1, domain, RUN_DATE, forecastsNew);
        forecastDao.oihInsert(f1);
        Assert.assertEquals(f1, forecastDao.find(f1.getAsin(), f1.getIog(), f1.getSource(), RUN_DATE));

        f2 = new ForecastObject("0000000GAF", 1, domain, RUN_DATE, forecastsNew);
        forecastDao.oihInsert(f2);
        Assert.assertEquals(f2, forecastDao.find(f2.getAsin(), f2.getIog(), f2.getSource(), RUN_DATE));

        Assert.assertTrue("ASIN " + f1.getAsin() + "IOG " + f1.getIog() + " inserted but not found!", forecastDao.find(
                f1.getAsin(), f1.getIog(), f1.getSource(), RUN_DATE) != null);

        ForecastObject f3 = new ForecastObject("000000TEST", 1, domain, RUN_DATE, forecastsNew);
        Assert.assertTrue("ASIN " + f3.getAsin() + "IOG " + (f3.getIog()) + " was not inserted but found!", forecastDao
                .find(f3.getAsin(), f3.getIog(), f3.getSource(), RUN_DATE) == null);
    }
}
