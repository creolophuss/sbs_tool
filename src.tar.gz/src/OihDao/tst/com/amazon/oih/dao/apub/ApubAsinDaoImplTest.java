package com.amazon.oih.dao.apub;

import java.util.List;

import junit.framework.Assert;

import org.junit.Test;

import com.amazon.oih.dao.exception.OihPersistenceException;
import com.amazon.oih.dao.repository.DaoFactory;
import com.amazon.oih.dao.repository.RepositoryFactory;

public class ApubAsinDaoImplTest {
    
    private static ApubAsinDao dao = DaoFactory.getApubAsinDao(RepositoryFactory.UNIT_TEST);

    @Test
    public void testCreate() {
        
        try {
            dao.save(newApubAsin("0000000001", 2L));
            Assert.assertTrue(true);
        } catch (OihPersistenceException e) {
            e.printStackTrace();
            Assert.fail();
        }
    }
    
    @Test
    public void testQueryApubAsins() throws OihPersistenceException {
        dao.save(newApubAsin("0000000001", 1L));
        dao.save(newApubAsin("0000000002", 1L));
        dao.save(newApubAsin("0000000003", 2L));
        
        List<ApubAsin> actual = dao.getApubAsins(1L);
        Assert.assertEquals(2, actual.size());
    }
    
    private ApubAsin newApubAsin(String asinStr, Long runId) {
        ApubAsin asin = new ApubAsin();
        asin.setAsin(asinStr);
        asin.setOrg("USAmazon");
        asin.setRunId(runId);
        asin.setType("APUB");
        return asin;
    }
}
