package com.amazon.oih.dao;

import java.util.HashMap;
import java.util.Properties;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.amazon.oih.dao.holdingcost.HoldingCost;
import com.amazon.oih.dao.holdingcost.HoldingCostDao;
import com.amazon.oih.dao.holdingcost.HoldingCostDaoImpl;
import com.amazon.oih.dao.transportationcost.TransportationCost;
import com.amazon.oih.dao.transportationcost.TransportationCostDao;
import com.amazon.oih.dao.transportationcost.TransportationCostDaoImpl;

public class FakeDAOUtil {

    private static boolean showSql = true;

    @SuppressWarnings("rawtypes")
    private static HashMap<Class, String> resouceMap = new HashMap<Class, String>();

    static {
        resouceMap.put(HoldingCost.class, "com/amazon/oih/dao/holdingcost/holdingcost.hbm.xml");
        resouceMap.put(TransportationCost.class, "com/amazon/oih/dao/transportationcost/transportationcost.hbm.xml");
    }

    public static HoldingCostDao getHoldingCostDao() {
        SessionFactoryManager.registSessionFactory(SessionFactoryManager.CONFIG_VENDORFLEX,
                getSessionFactory(HoldingCost.class));
        return new HoldingCostDaoImpl();
    }
    
    public static TransportationCostDao getTransportationCostDao() {
        SessionFactoryManager.registSessionFactory(SessionFactoryManager.CONFIG_VENDORFLEX,
                getSessionFactory(TransportationCost.class));
        return new TransportationCostDaoImpl();
    }

    @SuppressWarnings("rawtypes")
    private static SessionFactory getSessionFactory(Class clazz) {
        Properties props = getProperties();

        Configuration config = new Configuration();
        config.setProperties(props);

        config.addResource(resouceMap.get(clazz));
        return config.buildSessionFactory();
    }

    private static Properties getProperties() {
        Properties props = new Properties();

        props.setProperty("hibernate.connection.driver_class", "org.hsqldb.jdbcDriver");
        props.setProperty("hibernate.connection.url", "jdbc:hsqldb:mem:testdb");

        props.setProperty("hibernate.connection.username", "sa");
        props.setProperty("hibernate.connection.password", "");
        props.setProperty("hibernate.dialect", "org.hibernate.dialect.HSQLDialect");
        props.setProperty("connection.pool_size", "5");
        props.setProperty("hibernate.hbm2ddl.auto", "create");
        props.setProperty("hibernate.jdbc.batch_size", "0");
        if (showSql) {
            props.setProperty("hibernate.show_sql", "true");
            props.setProperty("hibernate.format_sql", "true");
            props.setProperty("hibernate.use_sql_comments", "true");
        }
        return props;
    }

}
