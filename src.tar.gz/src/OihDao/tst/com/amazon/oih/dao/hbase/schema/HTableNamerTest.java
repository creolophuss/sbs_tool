package com.amazon.oih.dao.hbase.schema;

import java.text.ParseException;
import java.util.Date;

import org.apache.commons.httpclient.util.DateParseException;
import org.junit.Assert;
import org.junit.Test;

import amazon.rest.collections.Triple;

public class HTableNamerTest {
    
    public void testGenerateParse(String inputName , String realm, Date date) throws DateParseException, ParseException{        
        HTableNamer namer = new HTableNamer();
        String tableName = namer.generateName(inputName, realm, date);
        Triple<String, String, Date> res = namer.parseName(tableName);
        Assert.assertEquals(inputName, res.getFirst());
        Assert.assertEquals(realm, res.getSecond());
        Assert.assertEquals(date, res.getThird());        
    }
    
    @Test
    public void testParseNormaltHtableName() throws DateParseException, ParseException{
        testGenerateParse("civ", "BRAmazon", HTableNamer.SIMPLE_DATE_FORMAT.parse("2014-08-01"));
        testGenerateParse("civ_yuliang", "BRAmazon", HTableNamer.SIMPLE_DATE_FORMAT.parse("2014-08-01"));
        testGenerateParse("civ_Test", "BRAmazon", HTableNamer.SIMPLE_DATE_FORMAT.parse("2014-08-01"));
    }
    
    
    @Test
    public void testParseIllegalFormatHtableName(){
        HTableNamer namer = new HTableNamer();
        try {
            Triple<String, String, Date> res = namer.parseName("member");
            Assert.fail("should have exception");
        } catch (ParseException e) {
        }
        try {
            Triple<String, String, Date> res = namer.parseName("member_USAmazon_8y99");
            Assert.fail("should have exception");
        } catch (ParseException e) {
        }        
        
    }    

}
