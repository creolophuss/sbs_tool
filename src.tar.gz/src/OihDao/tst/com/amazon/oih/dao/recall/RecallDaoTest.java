package com.amazon.oih.dao.recall;

import javax.naming.NamingException;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.amazon.carbonado.Repository;
import com.amazon.carbonado.RepositoryException;
import com.amazon.carbonado.Storage;
import com.amazon.carbonado.SupportException;
import com.amazon.oih.dao.exception.OihPersistenceException;
import com.amazon.oih.dao.repository.DaoFactory;
import com.amazon.oih.dao.repository.RepositoryFactory;

public class RecallDaoTest {
    private static IRecallDao dao = DaoFactory.getRecallDao(RepositoryFactory.UNIT_TEST);
    private static String ASIN = "B001TEST00";
    private static String IOG = "1";
    private static boolean IS_RECALLED = true;

    @Before
    public void cleanUpRepository() throws SupportException, RepositoryException {
        Repository r = RepositoryFactory.getInst().getRepository(RecallObject.class, RepositoryFactory.UNIT_TEST);
        Storage<RecallObject> sf = r.storageFor(RecallObject.class);
        sf.truncate();
    }

    @Test
    public void testCreate() throws NamingException, RepositoryException, ClassNotFoundException,
            OihPersistenceException {
        RecallInfo info = new RecallInfo(ASIN, IOG, IS_RECALLED);
        RecallObject recall = dao.createRecall(info);
        Assert.assertEquals(recall.getAsin(), info.getAsin());
        Assert.assertEquals(String.valueOf(recall.getIog()), info.getIog());
        Assert.assertEquals(recall.isRecalled(), info.isRecalled());
    }

    @Test
    public void testFind() throws NamingException, RepositoryException, ClassNotFoundException, OihPersistenceException {
        RecallInfo info = new RecallInfo(ASIN, IOG, IS_RECALLED);
        RecallObject recall4Save = dao.createRecall(info);
        dao.save(recall4Save);

        RecallObject recall4Retrieve = dao.find(recall4Save.getAsin(), recall4Save.getIog());

        Assert.assertEquals(recall4Save.getAsin(), recall4Retrieve.getAsin());
        Assert.assertEquals(recall4Save.getIog(), recall4Retrieve.getIog());
        Assert.assertEquals(recall4Save.isRecalled(), recall4Retrieve.isRecalled());
    }

    @Test
    public void testExist() throws NamingException, RepositoryException, ClassNotFoundException,
            OihPersistenceException {
        RecallInfo info = new RecallInfo(ASIN, IOG, IS_RECALLED);
        RecallObject recall4Save = dao.createRecall(info);
        dao.save(recall4Save);

        Assert.assertTrue(dao.exists(recall4Save.getAsin(), recall4Save.getIog()));
    }

    @Test
    public void testDuplicatedSave() throws NamingException, RepositoryException, ClassNotFoundException,
            OihPersistenceException {
        RecallInfo info = new RecallInfo(ASIN, IOG, IS_RECALLED);
        RecallObject recall4Save = dao.createRecall(info);
        dao.save(recall4Save);

        try {
            dao.save(recall4Save);
            Assert.assertTrue(false);// should come here
        } catch (Exception e) {
            // Exception is expected
        }
    }
}
