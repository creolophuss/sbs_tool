package com.amazon.oih.dao.hbase.revenue;

import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import com.amazon.oih.utils.HBaseRowkeyUtil;

public class AsinRevenueDataTestUtil {

    public static void log(Object obj) {
        System.out.println(obj);
    }

    public static Map<String, AsinRevenueData> buildObjMapDummyData() {
        DecimalFormat df = new DecimalFormat("B000000000");
        int size = 200;
        int invLevel = 65;
        int weekCount = 20;

        Map<String, AsinRevenueData> datas = new HashMap<String, AsinRevenueData>(size, 1.0f);
        for (int i = 0; i < size; i++) {
            String asin = df.format(i);
            AsinRevenueData data = new AsinRevenueData(asin, "AMAZON_US");
            datas.put(HBaseRowkeyUtil.getRowKeyForAsinRevenueData(data), data);
            Map<Integer, List<Double>> revenues = new HashMap<Integer, List<Double>>();
            data.setInventory2RevenueMap(revenues);
            int currInv = 0;
            for (int j = 0; j < invLevel; j++) {
                List<Double> npv = new LinkedList<Double>();
                revenues.put(currInv, npv);
                int deltaInv = 1 + (int) (10 * Math.random());
                currInv += deltaInv;
                for (int k = 0; k < weekCount; k++) {
                    npv.add(((int) (Math.random() * 1000000)) * 1.0);
                }
            }
            data.setCost(Math.random() * 1000);
            data.setOurPrice(data.getCost() + Math.random() * 500);
        }
        return datas;
    }

    public static Map<String, AsinRevenueData> buildObjMapDummyDataWithNull() {
        int size = 2;

        Map<String, AsinRevenueData> datas = new HashMap<String, AsinRevenueData>(size, 1.0f);
        AsinRevenueData data = new AsinRevenueData("B000000000", "AMAZON_US");
        data.setCost(null);
        data.setOurPrice(null);
        datas.put(HBaseRowkeyUtil.getRowKeyForAsinRevenueData(data), data);

        data = new AsinRevenueData("B000000001", "AMAZON_US");
        data.setCost(null);
        data.setOurPrice(Math.random() * 1000);
        datas.put(HBaseRowkeyUtil.getRowKeyForAsinRevenueData(data), data);

        data = new AsinRevenueData("B000000002", "AMAZON_US");
        data.setCost(Math.random() * 1000);
        data.setOurPrice(null);
        datas.put(HBaseRowkeyUtil.getRowKeyForAsinRevenueData(data), data);

        data = new AsinRevenueData("B000000003", "AMAZON_US");
        data.setInventory2RevenueMap(null);
        data.setCost(Math.random() * 1000);
        data.setOurPrice(null);
        datas.put(HBaseRowkeyUtil.getRowKeyForAsinRevenueData(data), data);

        data = new AsinRevenueData("B000000004", "AMAZON_US");
        data.setInventory2RevenueMap(null);
        data.setCost(null);
        data.setOurPrice(null);
        datas.put(HBaseRowkeyUtil.getRowKeyForAsinRevenueData(data), data);

        return datas;
    }

}
