package com.amazon.oih.dao.vrdsDisposition;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.NamingException;

import junit.framework.Assert;

import org.junit.Before;
import org.junit.Test;

import com.amazon.carbonado.ConfigurationException;
import com.amazon.carbonado.Repository;
import com.amazon.carbonado.RepositoryException;
import com.amazon.carbonado.Storage;
import com.amazon.oih.dao.exception.DaoRuntimeException;
import com.amazon.oih.dao.exception.OihPersistenceException;
import com.amazon.oih.dao.repository.DaoFactory;
import com.amazon.oih.dao.repository.RepositoryFactory;

public class VRDSReturmTermsDaoImplTest {
    private VRDSReturnTermsDao dao = DaoFactory.getVRDSReturnTermsDao(RepositoryFactory.UNIT_TEST);

    @Before
    public void setUp() throws ConfigurationException, NamingException, RepositoryException, ClassNotFoundException {
        // clean up repository
        Repository r = RepositoryFactory.getInst().getRepository(VRDSReturnTerms.class, RepositoryFactory.UNIT_TEST);
        Storage<VRDSReturnTerms> sf = r.storageFor(VRDSReturnTerms.class);
        sf.truncate();
    }

    @Test
    public void testSaveAndFind() throws DaoRuntimeException, OihPersistenceException, ParseException {
        // save'em
        dao.save(dao.createVRDSReturnTerms(1L, newReturnTermInfo("0123456789", 1, 1, "VEND1", true, true, true)));
        dao.save(dao.createVRDSReturnTerms(1L, newReturnTermInfo("0123456789", 1, 1, "VEND2", true, true, true)));
        dao.save(dao.createVRDSReturnTerms(1L, newReturnTermInfo("2123456789", 1, 1, "VEND1", true, true, true)));
        dao.save(dao.createVRDSReturnTerms(1L, newReturnTermInfo("2123456789", 1, 1, "VEND3", true, true, true)));

        // find
        List<VRDSReturnTerms> found = dao.find(1L, "0123456789", 1, "VEND1");
        Assert.assertEquals(1, found.size());
        VRDSReturnTerms f = found.get(0);
        Assert.assertTrue(null != f);
        Assert.assertTrue("0123456789".equals(f.getAsin()));
        Assert.assertTrue("VEND1".equals(f.getVendor()));

        found = dao.find(1L, "2123456789", 1, "VEND1");
        Assert.assertEquals(1, found.size());
        f = found.get(0);
        Assert.assertTrue(null != f);
        Assert.assertTrue("2123456789".equals(f.getAsin()));
        Assert.assertTrue("VEND1".equals(f.getVendor()));

        found = dao.find(1L, "2123456789", 1, "VEND3");
        Assert.assertEquals(1, found.size());
        f = found.get(0);
        Assert.assertTrue(null != f);
        Assert.assertTrue("2123456789".equals(f.getAsin()));
        Assert.assertTrue("VEND3".equals(f.getVendor()));

    }

    @Test
    public void testSaveAndFindInBatch() throws DaoRuntimeException, OihPersistenceException, ParseException {
        List<VRDSReturnTerms> rterms = new ArrayList<VRDSReturnTerms>();
        rterms.add(dao.createVRDSReturnTerms(1L, newReturnTermInfo("0123456789", 1, 1, "VEND1", true, true, true)));
        rterms.add(dao.createVRDSReturnTerms(1L, newReturnTermInfo("0123456789", 1, 1, "VEND2", true, false, true)));
        rterms.add(dao.createVRDSReturnTerms(1L, newReturnTermInfo("2123456789", 1, 1, "VEND1", true, true, true)));
        rterms.add(dao.createVRDSReturnTerms(1L, newReturnTermInfo("2123456789", 1, 1, "VEND3", true, false, true)));
        dao.save(rterms);

        // find
        List<VRDSReturnTerms> found = dao.find(1L, "0123456789", 1, "VEND1");
        Assert.assertEquals(1, found.size());
        VRDSReturnTerms f = found.get(0);
        Assert.assertTrue(null != f);
        Assert.assertTrue("0123456789".equals(f.getAsin()));
        Assert.assertTrue("VEND1".equals(f.getVendor()));
        Assert.assertTrue( f.getIsAsinReturnAllowed());

        found = dao.find(1L, "2123456789", 1, "VEND1");
        Assert.assertEquals(1, found.size());
        f = found.get(0);
        Assert.assertTrue(null != f);
        Assert.assertTrue("2123456789".equals(f.getAsin()));
        Assert.assertTrue("VEND1".equals(f.getVendor()));
        Assert.assertTrue( f.getIsAsinReturnAllowed());

        found = dao.find(1L, "2123456789", 1, "VEND3");
        Assert.assertEquals(1, found.size());
        f = found.get(0);
        Assert.assertTrue(null != f);
        Assert.assertTrue("2123456789".equals(f.getAsin()));
        Assert.assertTrue("VEND3".equals(f.getVendor()));
        Assert.assertTrue( !f.getIsAsinReturnAllowed());

    }

    @Test
    public void testExists() throws DaoRuntimeException, OihPersistenceException, ParseException {

        dao.save(dao.createVRDSReturnTerms(1L, newReturnTermInfo("0123456789", 1, 1, "VEND1", true, true, true)));
        dao.save(dao.createVRDSReturnTerms(1L, newReturnTermInfo("0123456789", 1, 1, "VEND2", true, true, true)));

        Assert.assertTrue(dao.exists(1L, "0123456789", 1, "VEND1"));
        Assert.assertFalse(dao.exists(1L, "0123456789", 1, "VEND4"));
        Assert.assertTrue(dao.exists(1L, "0123456789", 1, "VEND2"));
    }

    @Test
    public void testReturnCap() throws DaoRuntimeException, OihPersistenceException, ParseException {

        dao.save(dao.createVRDSReturnTerms(1L, newReturnTermInfoForReturnCap("0123456789", 1, 1, "VEND1", "COST", 20.0, "YEAR")));
        dao.save(dao.createVRDSReturnTerms(1L, newReturnTermInfoForReturnCap("0123456789", 1, 1, "VEND2", "LISTPRICE", 10.0, "MONTH")));

        List<VRDSReturnTerms> found = dao.find(1L, "0123456789", 1, "VEND1");
        Assert.assertEquals(1, found.size());
        VRDSReturnTerms f = found.get(0);
        Assert.assertTrue("COST".equals(f.getReturnCapBasis()));
        Assert.assertTrue("YEAR".equals(f.getReturnCapTimePeriod()));
        Assert.assertTrue(f.getReturnCapAmount() == 20.0);
        
        found = dao.find(1L, "0123456789", 1, "VEND2");
        Assert.assertEquals(1, found.size());
        f = found.get(0);
        Assert.assertTrue("LISTPRICE".equals(f.getReturnCapBasis()));
        Assert.assertTrue("MONTH".equals(f.getReturnCapTimePeriod()));
        Assert.assertTrue(f.getReturnCapAmount() == 10.0);
    }
    private ReturnTermInfo newReturnTermInfo(String asin, int iog, int marketplace, String vendor,
            boolean returnsAllowed,boolean isAsinReturnAllowed, boolean authRequired) throws ParseException {
        ReturnTermInfo retVal = new ReturnTermInfo();

        retVal.asin = asin;
        retVal.iog = iog;
        retVal.marketplaceId = marketplace;
        retVal.vendor = vendor;
        retVal.isReturnAllowed = returnsAllowed;
        retVal.isAsinReturnAllowed = isAsinReturnAllowed;
        retVal.isAuthRequired = authRequired;

        // set some default values for the rest
        retVal.refundPercentage = 100.0;
        retVal.refundBasisCode = "ABD";
        retVal.returnByMaxDays = 0;
        retVal.returnByMaxDays = 30;
        retVal.perUnitRestockingValue = 0.1;
        retVal.perUnitRestockingBasis = "ABC";

        return retVal;
    }
    
    private ReturnTermInfo newReturnTermInfoForReturnCap(String asin, int iog, int marketplace, String vendor,
            String returnCapBasis, double returnCapAmount, String returnCapPeriod) throws ParseException {
        ReturnTermInfo retVal = new ReturnTermInfo();
        ReturnCapInfo retCap = new ReturnCapInfo();

        retVal.asin = asin;
        retVal.iog = iog;
        retVal.marketplaceId = marketplace;
        retVal.vendor = vendor;
        retVal.isReturnAllowed = true;
        retVal.isAsinReturnAllowed = true;
        retVal.isAuthRequired = true;

        // set some default values for the rest
        retVal.refundPercentage = 100.0;
        retVal.refundBasisCode = "ABD";
        retVal.returnByMaxDays = 0;
        retVal.returnByMaxDays = 30;
        retVal.perUnitRestockingValue = 0.1;
        retVal.perUnitRestockingBasis = "ABC";
        
        retCap.amount = returnCapAmount;
        retCap.basis = returnCapBasis;
        retCap.returnCapTimePeriod = returnCapPeriod;
        
        retVal.setReturnCap(retCap);

        return retVal;
    }
}
