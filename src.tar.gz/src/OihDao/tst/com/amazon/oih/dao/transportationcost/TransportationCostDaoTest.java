package com.amazon.oih.dao.transportationcost;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import junit.framework.Assert;
import com.amazon.oih.dao.FakeDAOUtil;

public class TransportationCostDaoTest {
    
    private TransportationCostDao dao = null;
    private List<TransportationCost> costs = null;
    
    @Before
    public void setup() throws Exception {
        dao = FakeDAOUtil.getTransportationCostDao();
        costs = new ArrayList<TransportationCost>();
        costs.add(createTransportationCost("JPAmazon", "JP", null, 150.0, 14));
        costs.add(createTransportationCost("JPAmazon", null, "US", 150.0, 14));
        costs.add(createTransportationCost("JPAmazon", "JP", "DE", 150.0, 14));
        for (TransportationCost cost : costs) {
            dao.save(cost);            
        }
    }

    private TransportationCost createTransportationCost(String realm, String whseLoc, String vcLoc, Double outCost, Integer gl) {
        TransportationCost cost = new TransportationCost();
        cost.setRealm(realm);
        cost.setGl(gl);
        cost.setOutCost(outCost);
        cost.setVendorLocation(vcLoc);
        cost.setWarehouseLocation(whseLoc);        
        return cost;
    }
    
    @Test
    public void testTransportationCosts() throws Exception {
        List<TransportationCost> result = dao.getTransportationCosts("JPAmazon");
        for (TransportationCost c : result) {
            Assert.assertTrue(costs.contains(c));
        }
    }
}
