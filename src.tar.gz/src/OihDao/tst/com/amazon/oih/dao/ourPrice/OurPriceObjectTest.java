package com.amazon.oih.dao.ourPrice;

import java.util.Date;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.joda.time.DateTime;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import amazon.platform.config.AppConfig;

import com.amazon.oih.dao.ourprice.OurPriceObject;
import com.amazon.oih.dao.repository.RepositoryFactory;

/**
 * Unit test for OurPriceDaoTest
 * 
 * @author zhongwei
 * 
 */
public class OurPriceObjectTest {
    private static String source = RepositoryFactory.UNIT_TEST;
    final static Date RUN_DATE = new DateTime("2010-01-19").toDate();
    private static final String realm = "USAmazon";
    private static final String root = "/tmp";

    @BeforeClass
    public static void init() {
        Logger.getRootLogger().setLevel(Level.OFF);

        if (!AppConfig.isInitialized()) {
            AppConfig.initialize("OihMetrics", "Oih", new String[] {
                    "--root=" + root, "--domain=" + source, "--realm=" + realm,
            });
        }
    }

    @Test
    public void testCreate() {
        String asin = "0000000000";
        int iog = 1;
        double price = 70;

        OurPriceObject ourPrice = new OurPriceObject(asin, iog, source, price, RUN_DATE);
        Assert.assertEquals(asin, ourPrice.getAsin());
        Assert.assertEquals(iog, ourPrice.getIog());
        Assert.assertEquals(source, ourPrice.getSource());
        Assert.assertEquals(price, ourPrice.getOurPrice(), 0.000001);
        Assert.assertTrue(ourPrice.getFirstLoadDate() == RUN_DATE);
        Assert.assertTrue(ourPrice.getLastLoadDate() == RUN_DATE);
        Assert.assertTrue(ourPrice.getExpiredDate().getTime() > RUN_DATE.getTime());
        Assert.assertEquals(realm, ourPrice.getRealm());
    }

    @Test
    public void testEquals() {
        String asin1 = "0000000000";
        String asin2 = "0000000000";
        int iog1 = 1;
        int iog2 = 1;
        double price1 = 70;
        double price2 = 50;

        OurPriceObject ourPrice1 = new OurPriceObject(asin1, iog1, source, price1, RUN_DATE);
        OurPriceObject ourPrice2 = new OurPriceObject(asin1, iog1, source, price1, RUN_DATE);
        OurPriceObject ourPrice3 = new OurPriceObject(asin1, iog1, source, price2, RUN_DATE);
        OurPriceObject ourPrice4 = new OurPriceObject(asin2, iog1, source, price1, RUN_DATE);
        OurPriceObject ourPrice5 = new OurPriceObject(asin1, iog2, source, price2, RUN_DATE);
        Assert.assertTrue( ourPrice1.equals(ourPrice2) );
        Assert.assertFalse( ourPrice1.equals(ourPrice3) );
        Assert.assertFalse( ourPrice1.equals(ourPrice3) );
        Assert.assertFalse( ourPrice2.equals(ourPrice3) );
        Assert.assertFalse( ourPrice3.equals(ourPrice4) );
        Assert.assertFalse( ourPrice3.equals(ourPrice4) );
        Assert.assertFalse( ourPrice4.equals(ourPrice5) );
    }

    @Test
    public void testGetKey() {
        String asin = "0000000000";
        int iog = 1;
        double price = 70.05;

        OurPriceObject ourPrice = new OurPriceObject(asin, iog, source, price, RUN_DATE);
        Assert.assertEquals(ourPrice.getKey(), ourPrice.getAsin() + "|" + ourPrice.getIog() + "|" + realm);
        Assert.assertEquals(Double.valueOf(ourPrice.getValues()), price, 0.000001);
    }

}