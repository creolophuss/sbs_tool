package com.amazon.oih.dao.hbase.base;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.junit.Assert;
import org.junit.Test;

import com.amazon.oih.common.KeyValueBase.NamedValue;
import com.amazon.oih.dao.hbase.base.CommonKVHBaseDao.HTable;
import com.amazon.oih.dao.hbase.converter.Column;
import com.amazon.oih.dao.hbase.converter.RowKey;
import com.amazon.oih.dao.hbase.converter.SubKey;

public class SubKeyAwareHBaseDaoTest {
    private SubKeyAwareHBaseDao<SingleColumnClass> dao = new SubKeyAwareHBaseDao<SingleColumnClass>(
            SingleColumnClass.class);
    private SubKeyAwareHBaseDao<MultiColumnClass> dao4DynamicColumn = new SubKeyAwareHBaseDao<MultiColumnClass>(
            MultiColumnClass.class);

    @Test
    public void testGenerateRowKey() {
        List<SingleColumnClass> testObjs = obtainTestObjs();

        String rowKey = dao.generateRowKey(testObjs);
        Assert.assertEquals("ASIN1:1", rowKey);

        SingleColumnClass testObj1 = new SingleColumnClass();
        testObj1.setAsin("ASIN2");
        testObj1.setIog(1);
        testObj1.setFc("SDF1");
        testObj1.setValue(0.11);
        testObj1.setStrValue("String1");
        testObjs.add(testObj1);

        try {
            rowKey = dao.generateRowKey(testObjs);
            Assert.assertTrue(false);
        } catch (Exception e) {
            Assert.assertTrue(true);
        }
    }

    @Test
    public void testGenerateColumnValueMap() {
        List<SingleColumnClass> testObjs = obtainTestObjs();
        Map<String, String> valueMap = dao.generateColumnValueMap(testObjs);

        Assert.assertEquals(2, valueMap.size());
        Assert.assertEquals("0.11,String1", valueMap.get("SDF1"));
        Assert.assertEquals("0.22,String2", valueMap.get("SDF2"));
    }
    
    @Test
    public void testGenerateColumnValueMap4MultiColumnClass() {
        List<MultiColumnClass> testObjs = obtainTestObjs4DynamicColumnName();
        Map<String, String> valueMap = dao4DynamicColumn.generateColumnValueMap(testObjs);

        Assert.assertEquals(6, valueMap.size());
        Assert.assertEquals("String1,String11", valueMap.get("SDF1:SDF11.St"));
        Assert.assertEquals("0.11", valueMap.get("SDF1:SDF11.Dt"));
        Assert.assertEquals("", valueMap.get("SDF1:SDF11.Null"));
        Assert.assertEquals("String2,String22", valueMap.get("SDF2:SDF22.St"));
        Assert.assertEquals("0.22", valueMap.get("SDF2:SDF22.Dt"));
        Assert.assertEquals("", valueMap.get("SDF2:SDF22.Null"));
    }

    @Test
    public void testConstruct() {
        List<SingleColumnClass> testObjs = obtainTestObjs();
        Map<String, String> valueMap = dao.generateColumnValueMap(testObjs);
        String rowKey = dao.generateRowKey(testObjs);
        List<SingleColumnClass> results = dao.construct(rowKey, valueMap);

        Assert.assertEquals(2, results.size());
        for (SingleColumnClass obj : results) {
            Assert.assertEquals("ASIN1", obj.getAsin());
            Assert.assertEquals(1, obj.getIog());
            if (obj.getFc().equals("SDF1")) {
                Assert.assertTrue(obj.getValue().doubleValue() - 0.11 == 0);
                Assert.assertEquals("String1", obj.getStrValue());
                Assert.assertEquals(testObjs.get(0).getFc(), obj.getFc());
                Assert.assertFalse(testObjs.get(0) == obj);
            } else {
                Assert.assertEquals("SDF2", obj.getFc());
                Assert.assertTrue(obj.getValue().doubleValue() - 0.22 == 0);
                Assert.assertEquals("String2", obj.getStrValue());
                Assert.assertEquals(testObjs.get(1).getFc(), obj.getFc());
                Assert.assertFalse(testObjs.get(1) == obj);
            }
        }
    }
    
    @Test
    public void testConstruct4MultiColumnClass() {
        List<MultiColumnClass> testObjs = obtainTestObjs4DynamicColumnName();
        Map<String, String> valueMap = dao4DynamicColumn.generateColumnValueMap(testObjs);
        String rowKey = dao4DynamicColumn.generateRowKey(testObjs);
        List<MultiColumnClass> results = dao4DynamicColumn.construct(rowKey, valueMap);

        Assert.assertEquals(2, results.size());
        for (MultiColumnClass obj : results) {
            Assert.assertEquals("ASIN1", obj.getAsin());
            Assert.assertEquals(1, obj.getIog());
            if (obj.getFc().equals("SDF1")) {
                Assert.assertEquals("SDF11", obj.getFc1());
                Assert.assertTrue(obj.getValue().doubleValue() - 0.11 == 0);
                Assert.assertEquals("String1", obj.getStrValue());
                Assert.assertEquals("String11", obj.getStrValue2());
                Assert.assertEquals(false, obj.getNullColum());
                Assert.assertEquals(testObjs.get(0).getFc(), obj.getFc());
                Assert.assertFalse(testObjs.get(0) == obj);
            } else {
                Assert.assertEquals("SDF2", obj.getFc());
                Assert.assertEquals("SDF22", obj.getFc1());
                Assert.assertTrue(obj.getValue().doubleValue() - 0.22 == 0);
                Assert.assertEquals("String2", obj.getStrValue());
                Assert.assertEquals("String22", obj.getStrValue2());
                Assert.assertEquals(false, obj.getNullColum());
                Assert.assertEquals(testObjs.get(1).getFc(), obj.getFc());
                Assert.assertFalse(testObjs.get(1) == obj);
            }
        }
    }

    private List<SingleColumnClass> obtainTestObjs() {
        SingleColumnClass testObj1 = new SingleColumnClass();
        testObj1.setAsin("ASIN1");
        testObj1.setIog(1);
        testObj1.setFc("SDF1");
        testObj1.setValue(0.11);
        testObj1.setStrValue("String1");

        SingleColumnClass testObj2 = new SingleColumnClass();
        testObj2.setAsin("ASIN1");
        testObj2.setIog(1);
        testObj2.setFc("SDF2");
        testObj2.setValue(0.22);
        testObj2.setStrValue("String2");

        List<SingleColumnClass> result = new ArrayList<SingleColumnClass>();
        result.add(testObj1);
        result.add(testObj2);

        return result;
    }
    
    private List<MultiColumnClass> obtainTestObjs4DynamicColumnName() {
        MultiColumnClass testObj1 = new MultiColumnClass();
        testObj1.setAsin("ASIN1");
        testObj1.setIog(1);
        testObj1.setFc("SDF1");
        testObj1.setFc1("SDF11");
        testObj1.setValue(0.11);
        testObj1.setStrValue("String1");
        testObj1.setStrValue2("String11");

        MultiColumnClass testObj2 = new MultiColumnClass();
        testObj2.setAsin("ASIN1");
        testObj2.setIog(1);
        testObj2.setFc("SDF2");
        testObj2.setFc1("SDF22");
        testObj2.setValue(0.22);
        testObj2.setStrValue("String2");
        testObj2.setStrValue2("String22");

        List<MultiColumnClass> result = new ArrayList<MultiColumnClass>();
        result.add(testObj1);
        result.add(testObj2);

        return result;
    }

    @RowKey({ "asin", "iog" })
    @SubKey({ "fc" })
    @HTable("test")
    public static class SingleColumnClass {
        private String asin;
        private int iog;
        private String fc;

        @Column(name = "test", index = 0)
        private Double value;
        @Column(name = "test", index = 1)
        private String strValue;

        public String getAsin() {
            return asin;
        }

        public void setAsin(String asin) {
            this.asin = asin;
        }

        public int getIog() {
            return iog;
        }

        public void setIog(int iog) {
            this.iog = iog;
        }

        public String getFc() {
            return fc;
        }

        public void setFc(String fc) {
            this.fc = fc;
        }

        public Double getValue() {
            return value;
        }

        public void setValue(Double value) {
            this.value = value;
        }

        public String getStrValue() {
            return strValue;
        }

        public void setStrValue(String strValue) {
            this.strValue = strValue;
        }

        @Override
        public String toString() {
            return "TestClass [asin=" + asin + ", iog=" + iog + ", fc=" + fc
                    + ", value=" + value + ", strValue=" + strValue + "]";
        }
    }

    @RowKey({ "asin", "iog" })
    @SubKey({ "fc", "fc1" })
    @HTable("test")
    public static class MultiColumnClass {
        private String asin;
        private int iog;
        @NamedValue("fcName")
        private String fc;
        @NamedValue("fcName1")
        private String fc1;

        @NamedValue("value")
        @Column(name = "Dt", index = 0)
        private Double value;
        
        @NamedValue("strV1")
        @Column(name = "St", index = 0)
        private String strValue;
        
        @NamedValue("strV2")
        @Column(name = "St", index = 1)
        private String strValue2;
        
        @NamedValue("Null")
        @Column(name = "Null", index = 0)
        private Boolean nullColum= null;
        
        public String getAsin() {
            return asin;
        }

        public void setAsin(String asin) {
            this.asin = asin;
        }

        public int getIog() {
            return iog;
        }

        public void setIog(int iog) {
            this.iog = iog;
        }

        public String getFc() {
            return fc;
        }

        public void setFc(String fc) {
            this.fc = fc;
        }

        public String getFc1() {
            return fc1;
        }

        public void setFc1(String fc1) {
            this.fc1 = fc1;
        }

        public Double getValue() {
            return value;
        }

        public void setValue(Double value) {
            this.value = value;
        }

        public String getStrValue() {
            return strValue;
        }

        public void setStrValue(String strValue) {
            this.strValue = strValue;
        }

        public String getStrValue2() {
            return strValue2;
        }

        public void setStrValue2(String strValue2) {
            this.strValue2 = strValue2;
        }

        public Boolean getNullColum() {
            return nullColum;
        }

        public void setNullColum(Boolean nullColum) {
            this.nullColum = nullColum;
        }

        @Override
        public String toString() {
            return "TestClass2 [asin=" + asin + ", iog=" + iog + ", fc=" + fc
                    + ", value=" + value + ", nullColum=" + nullColum + "]";
        }
    }
}
