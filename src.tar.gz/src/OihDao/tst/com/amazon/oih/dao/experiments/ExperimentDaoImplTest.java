package com.amazon.oih.dao.experiments;

import java.util.Calendar;
import java.util.List;

import javax.naming.NamingException;

import org.joda.time.DateTime;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.amazon.carbonado.ConfigurationException;
import com.amazon.carbonado.Repository;
import com.amazon.carbonado.RepositoryException;
import com.amazon.carbonado.Storage;
import com.amazon.oih.dao.exception.OihPersistenceException;
import com.amazon.oih.dao.repository.DaoFactory;
import com.amazon.oih.dao.repository.RepositoryFactory;

public class ExperimentDaoImplTest {
    ExperimentDao dao = DaoFactory.getExperimentDao(RepositoryFactory.UNIT_TEST);

    @Before
    public void setUp() throws ConfigurationException, NamingException, RepositoryException, ClassNotFoundException {
        // clean up repository
        Repository r = RepositoryFactory.getInst().getRepository(Experiment.class, RepositoryFactory.UNIT_TEST);
        Storage<Experiment> sf = r.storageFor(Experiment.class);
        sf.truncate();
    }

    @Test
    public void testSimpleCreate() throws Exception {
        DateTime startDate = new DateTime(Calendar.getInstance().getTime()).withTime(0, 0, 0, 0);
        DateTime endDate = startDate.plusDays(10);
        Experiment e = dao.createExperiment("E1", startDate, endDate, true, 1, 14, false);
        e.setId(1);
        dao.save(e);
        e = dao.createExperiment("E2", startDate, endDate, false, 1, 14, false);
        e.setId(2);
        dao.save(e);
        e = dao.find("E1").get(0);
        Assert.assertNotNull(e);
        e = dao.find("E2").get(0);
        ;
        Assert.assertNotNull(e);
        List<Experiment> es = dao.find();
        Assert.assertNotNull(es);
        Assert.assertEquals(2, es.size());
        es = dao.find(true);
        Assert.assertNotNull(es);
        Assert.assertEquals(1, es.size());
        e = es.get(0);
        Assert.assertEquals("E1", e.getName());
        e = dao.find("E1", startDate, true).get(0);
        Assert.assertNotNull(e);
        Assert.assertEquals("E1", e.getName());
    }

    @Test
    public void testFailureOnConstraint() throws Exception {
        DateTime startDate = new DateTime(Calendar.getInstance().getTime());
        DateTime endDate = startDate.plusDays(10);
        Experiment e = dao.createExperiment("E1", startDate, endDate, true, 1, 14, false);
        e.setId(1);
        dao.save(e);
        e = dao.createExperiment("E1", startDate, endDate, false, 1, 14, false);
        e.setId(2);
        try {
            dao.save(e);
        } catch (OihPersistenceException ex) {
            return;
        }
        Assert.fail();
    }

    @Test
    public void testExperimentStartingToday() throws Exception {
        DateTime startDate = new DateTime(Calendar.getInstance().getTime()).withTime(0, 0, 0, 0);
        DateTime endDate = startDate.plusDays(10);
        Experiment e = dao.createExperiment("E1", startDate, endDate, true, 1, 14, false);
        e.setId(1);
        dao.save(e);
        e = dao.createExperiment("E2", startDate.plusDays(20), endDate.plusDays(20), true, 1, 14, false);
        e.setId(2);
        dao.save(e);
        List<Experiment> es = dao.find(startDate, true);
        Assert.assertNotNull(es);
        Assert.assertEquals(1, es.size());
        e = es.get(0);
        Assert.assertNotNull(e);
        Assert.assertEquals("E1", e.getName());

    }
}
