package com.amazon.oih.dao.hbase.base;

import java.util.Set;

import junit.framework.Assert;

import org.junit.Test;

import com.amazon.oih.dao.hbase.base.SubKeyAwareHBaseDaoTest.MultiColumnClass;
import com.google.common.collect.Sets;

public class ProjectionProviderTest {
    private ProjectionProvider<MultiColumnClass> provider = new ProjectionProvider<MultiColumnClass>(MultiColumnClass.class);
    @Test
    public void testFindProjectionsByNamedValue(){
        Set<String> projections = provider.findProjectionsByNamedValue(Sets.newHashSet("fcName", "fcName1", "strV1", "strV2", "Null"));
        Assert.assertEquals(projections, Sets.newHashSet("St", "Null"));
    }
    
    @Test
    public void testFindProjectionsByNamedValueNoSubKey(){
        try {
            provider.findProjectionsByNamedValue(Sets.newHashSet("strV1", "strV2", "Null"));
        } catch (Exception e){
            Assert.assertTrue(e.getMessage().contains("fc"));
            Assert.assertTrue(e.getMessage().contains("fc1"));
            return;
        }
        Assert.assertFalse(true);
    }
    
    @Test
    public void testFindProjectionsByNamedValueNoEnoughSubKey(){
        try {
            provider.findProjectionsByNamedValue(Sets.newHashSet("fcName1", "strV1", "strV2", "Null"));
        } catch (Exception e){
            Assert.assertTrue(e.getMessage().contains("fc"));
            return;
        }
        Assert.assertFalse(true);
    }
    
    @Test
    public void testFindProjectionsByNamedValueWrongNamedValue(){
        try {
            provider.findProjectionsByNamedValue(Sets.newHashSet("fcName", "fcName1", "strV1", "strV2", "Null11"));
        } catch (Exception e){
            Assert.assertTrue(e.getMessage().contains("Null11"));
            return;
        }
        Assert.assertFalse(true);
    }
    
    @Test
    public void testFindProjectionsByNamedValueInvalidNamedValue(){
        try {
            provider.findProjectionsByNamedValue(Sets.newHashSet("fcName", "fcName1", "strV1", "Null"));
        } catch (Exception e){
            Assert.assertTrue(e.getMessage().contains("strV2"));
            Assert.assertTrue(e.getMessage().contains("St"));
            return;
        }
        Assert.assertFalse(true);
    }
}
