package com.amazon.oih.dao.targetInvLevel;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.amazon.oih.dao.exception.OihPersistenceException;
import com.amazon.oih.dao.repository.DaoFactory;
import com.amazon.oih.dao.repository.RepositoryFactory;
import com.amazon.oih.utils.AsinIogPair;

public class TargetInventoryLevelDaoImplTest {
    private static TargetInventoryLevelDao dao = DaoFactory.getTargetInventoryLevelDao(RepositoryFactory.UNIT_TEST);

    @BeforeClass
    public static void init() throws OihPersistenceException {
        Logger.getRootLogger().setLevel(Level.OFF);
        dao.deleteAll();// clear the data from the in-memory session
    }

    @Test
    public void testCreate() {
        long runId = 1;
        String asin = "0000000000";
        int iog = 1;
        int til = 12;
        int carton_qty = 4;

        TargetInventoryLevel object = dao.createTargetInventoryLevel(runId, asin, iog, til, carton_qty);
        Assert.assertEquals(runId, object.getRunID());
        Assert.assertEquals(asin, object.getAsin());
        Assert.assertEquals(iog, object.getIog());
        Assert.assertEquals(til, object.getTil());
        Assert.assertEquals(carton_qty, object.getCartonQty());
    }

    @Test
    public void testFind() throws OihPersistenceException {
        long runId = 1L;
        int iog = 3;

        List<TargetInventoryLevel> l = new ArrayList<TargetInventoryLevel>();

        l.add(dao.createTargetInventoryLevel(runId, "0000000000", iog, 12, 4));
        l.add(dao.createTargetInventoryLevel(runId, "00000000A0", iog, 126, 0));
        l.add(dao.createTargetInventoryLevel(runId, "0000000B00", iog, 20000, 1));
        l.add(dao.createTargetInventoryLevel(runId, "000000C000", iog, 30000, 2000));

        // set up test data
        for (TargetInventoryLevel it : l) {
            dao.save(it);
        }

        // verify that we can find the data with correct runId, asin and iog.
        for (TargetInventoryLevel it : l) {
            TargetInventoryLevel til4Retrieve = dao.find(it.getRunID(), it.getAsin(), it.getIog());
            Assert.assertEquals(it.getAsin(), til4Retrieve.getAsin());
            Assert.assertEquals(it.getIog(), til4Retrieve.getIog());
            Assert.assertEquals(it.getTil(), til4Retrieve.getTil());
            Assert.assertEquals(it.getCartonQty(), til4Retrieve.getCartonQty());
        }

        // verify that we cannot find the data with wrong run id.
        Assert.assertNull(dao.find(++runId, "0000000B00", iog));
    }

    @Test
    public void testFindBatch() throws OihPersistenceException {
        long runId = 1L;
        List<TargetInventoryLevel> objects4Save = new ArrayList<TargetInventoryLevel>();
        objects4Save.add(dao.createTargetInventoryLevel(runId, "0000000001", 1, 12, 4));
        objects4Save.add(dao.createTargetInventoryLevel(runId, "0000000001", 2, 12, 4));
        objects4Save.add(dao.createTargetInventoryLevel(runId, "0000000002", 1, 126, 0));
        objects4Save.add(dao.createTargetInventoryLevel(runId, "0000000002", 2, 126, 0));
        objects4Save.add(dao.createTargetInventoryLevel(runId, "0000000003", 1, 2000, 0));
        objects4Save.add(dao.createTargetInventoryLevel(runId, "0000000004", 1, 3000, 10));
        objects4Save.add(dao.createTargetInventoryLevel(runId, "0000000005", 1, 110, 0));
        objects4Save.add(dao.createTargetInventoryLevel(runId, "0000000005", 2, 110, 0));
        objects4Save.add(dao.createTargetInventoryLevel(runId, "0000000005", 3, 110, 0));
        objects4Save.add(dao.createTargetInventoryLevel(runId, "0000000006", 3, 115, 0));

        for (TargetInventoryLevel object : objects4Save) {
            dao.save(object);
        }

        Map<AsinIogPair, TargetInventoryLevel> saveMap = new HashMap<AsinIogPair, TargetInventoryLevel>();
        for (TargetInventoryLevel object : objects4Save) {
            saveMap.put(new AsinIogPair(object.getAsin(), String.valueOf(object.getIog())), object);
        }

        List<AsinIogPair> asinIogPairs = new ArrayList<AsinIogPair>();
        for (TargetInventoryLevel object : objects4Save) {
            asinIogPairs.add(new AsinIogPair(object.getAsin(), String.valueOf(object.getIog())));
        }
        List<TargetInventoryLevel> til4Retrieve = dao.find(runId, asinIogPairs);

        Map<AsinIogPair, TargetInventoryLevel> retrieveMap = new HashMap<AsinIogPair, TargetInventoryLevel>();
        for (TargetInventoryLevel object : til4Retrieve) {
            retrieveMap.put(new AsinIogPair(object.getAsin(), String.valueOf(object.getIog())), object);
        }

        Assert.assertEquals(retrieveMap.size(), saveMap.size());

        for (AsinIogPair object : asinIogPairs) {
            Assert.assertTrue(saveMap.containsKey(object));
            Assert.assertTrue(retrieveMap.containsKey(object));

            TargetInventoryLevel oldObject = saveMap.get(object);
            TargetInventoryLevel newObject = retrieveMap.get(object);

            Assert.assertEquals(oldObject.getTil(), newObject.getTil());
            Assert.assertEquals(oldObject.getCartonQty(), newObject.getCartonQty());
            Assert.assertEquals(oldObject.getCartonQty(), newObject.getCartonQty());
        }
    }

    @Test
    public void testExists() throws OihPersistenceException {
        long runId = 0L;
        String asin = "0123456789";
        int iog = 1;
        int cartonQty = 2000;

        // set up test data
        dao.save(dao.createTargetInventoryLevel(runId, asin, iog, 30000, cartonQty));

        // verify that data exists
        Assert.assertTrue(dao.exists(runId, asin, iog));

        // verify that data not exists
        Assert.assertFalse(dao.exists(runId, asin, ++iog));
    }
    
    @Test
    public void testCount() throws OihPersistenceException {
        dao.deleteAll();
        long runId = 0L;
        int iog = 1;
        int cartonQty = 2000;
        // set up test data
        dao.save(dao.createTargetInventoryLevel(runId, "ABCDE00001", iog, 1, cartonQty));
        dao.save(dao.createTargetInventoryLevel(runId, "ABCDE00002", iog, 2, cartonQty));
        dao.save(dao.createTargetInventoryLevel(runId, "ABCDE00003", iog, 3, cartonQty));
        dao.save(dao.createTargetInventoryLevel(runId, "ABCDE00004", iog, 4, cartonQty));
        dao.save(dao.createTargetInventoryLevel(1000L, "ABCDE00005", iog, 5, cartonQty));
        
        Integer count = dao.getTotalCountByRunId(0L);
        // verify that data exists
        Assert.assertEquals(4, count.intValue());
    }
    
    @Test
    public void testInvalidDataCount() throws OihPersistenceException {
        dao.deleteAll();
        long runId = 0L;
        int iog = 1;
        int cartonQty = 2000;
        // set up test data
        dao.save(dao.createTargetInventoryLevel(runId, "ABCDE00005", iog, 5, cartonQty));
        dao.save(dao.createTargetInventoryLevel(runId, "ABCDE00006", iog, 6, cartonQty));
        dao.save(dao.createTargetInventoryLevel(runId, "ABCDE00007", iog, -1, cartonQty));
        dao.save(dao.createTargetInventoryLevel(runId, "ABCDE00008", iog, -1, cartonQty));
        dao.save(dao.createTargetInventoryLevel(1000L, "ABCDE00009", iog, -1, cartonQty));
        
        Integer count = dao.getInvalidTILCountByRunId(0L);
        // verify that data exists
        Assert.assertEquals(2, count.intValue());
    }
}
