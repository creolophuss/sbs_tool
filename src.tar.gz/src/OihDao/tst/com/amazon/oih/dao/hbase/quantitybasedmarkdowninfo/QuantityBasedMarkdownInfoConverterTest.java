package com.amazon.oih.dao.hbase.quantitybasedmarkdowninfo;

import java.util.HashMap;
import java.util.Map;

import junit.framework.Assert;
import mockit.Deencapsulation;

import org.junit.Test;

import com.amazon.oih.dao.markdowninfo.MarkdownInfo;
import com.amazon.oih.dao.quantitymarkdowninfo.QuantityBasedMarkdownInfo;

/**
 * @author gaoxing
 *
 */
public class QuantityBasedMarkdownInfoConverterTest {

    /**
     * Test method for {@link com.amazon.oih.dao.hbase.quantitybasedmarkdowninfo.QuantityBasedMarkdownInfoConverter#parseQuantityBasedMarkdownInfo(java.util.Map<Integer, MarkdownInfo>, java.lang.String)}.
     */
    @Test
    public void testParseQuantityBasedMarkdownInfo() {
        QuantityBasedMarkdownInfoConverter converter = new QuantityBasedMarkdownInfoConverter();
        Map<Integer, MarkdownInfo> quantityBasedMarkdownInfoMap = new HashMap<Integer, MarkdownInfo>();
        Deencapsulation.invoke(converter, "parseQuantityBasedMarkdownInfo", quantityBasedMarkdownInfoMap, "1=5.864298223728171E-5,0.827566,0.3923694987923909");
        
        for (Map.Entry<Integer, MarkdownInfo> eachEntry : quantityBasedMarkdownInfoMap.entrySet()) {
            Assert.assertEquals("Quantity Key is not properly parsed", 1, eachEntry.getKey().intValue());
            Assert.assertEquals("Recovery Rate is not properly parsed", 5.864298223728171E-5, eachEntry.getValue().getRecoveryRate());
            Assert.assertEquals("Demand Increase Rate is not properly parsed", 0.3923694987923909, eachEntry.getValue().getDemandIncreaseRate());
            Assert.assertEquals("Demand Increase is not properly parsed", 0.827566, eachEntry.getValue().getDemandIncrease());
        }
    }
    
    @Test
    public void testConvertQtyBasedMarkdownHBaseObj() {
        QuantityBasedMarkdownInfoConverter converter = new QuantityBasedMarkdownInfoConverter();
        QtyBasedMarkdownHBaseObj hObj = new QtyBasedMarkdownHBaseObj();
        hObj.setAsin("ASIN1");
        hObj.setMarketplaceId(1);
        hObj.setDataVersion("V1");
        hObj.setRawMarkdownInfo("1=0.68,0.18,0.008;2=0.68,0.18,0.008;3=0.68,0.18,0.008;4=0.68,0.18,0.008;5=0.68,0.18,0.008");
        hObj.setRawDataLevels("AVERAGE_AGG");
        QuantityBasedMarkdownInfo info = converter.convert(hObj);
        System.out.println(info);
        
    }
}
