package com.amazon.oih.dao.hazmatwhitelist;

import java.util.ArrayList;
import java.util.List;

import junit.framework.Assert;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.support.FileSystemXmlApplicationContext;

import amazon.platform.config.AppConfig;
import amazon.platform.logging.AppConfigLog4jConfigurator;

import com.amazon.oih.dao.base.PostgreSqlDaoFactory;

public class VReturnsPropertiesDaoTest {
    private static VReturnsPropertiesDao dao = null;
    private static final String VRETURNS_CATEGORY = "vreturns";
    private static final String HAZMAT_EXCEPTION_WHITE_LIST = "hazmat_exception_white_list";
    private String propertyCategoryName = VRETURNS_CATEGORY;
    private String propertyTypeName = HAZMAT_EXCEPTION_WHITE_LIST;
    private String lastUpdatedBy = "nobody";
    private String lastActedUponBy = "nobody";

    public static final String APP = "OihDao";
    public static final String APPGROUP = "oih";
    public static final String ROOT = "/tmp";
    private static String REALM = "USAmazon";
    private static String domain = "test";

    @Before
    public void setUp() throws Exception {
        if (!AppConfig.isInitialized()) {
            AppConfigLog4jConfigurator.configureForBootstrap();
            AppConfig.initialize(APP, APPGROUP, new String[] {
                    "--domain=" + domain, "--realm=" + REALM, "--root=" + ROOT
            });
            AppConfigLog4jConfigurator.configureFromAppConfig();
        }

        // mock the applicationContext
        System.getProperties().put("domain", domain);// replace the place holder in the hibernate.xml
        FileSystemXmlApplicationContext appContext = new FileSystemXmlApplicationContext(new String[] {
            "spring-configuration/VRetPostgreDb/hibernate.cfg.xml"
        });
        PostgreSqlDaoFactory.setAppContext(appContext);

        dao = PostgreSqlDaoFactory.getVReturnsPropertiesDao();
    }

    @Test
    public void testSave() {
        List<String> hazmats = getHazmatList();
        Long id = new Long(0);
        for (String hazmat : hazmats) {
            VReturnsProperties property = new VReturnsProperties();
            property.setId(id++);
            property.setPropertyCategoryName(propertyCategoryName);
            property.setPropertyTypeName(propertyTypeName);
            property.setPropertyValue(hazmat);

            property.setLastActedUponBy(lastUpdatedBy);
            property.setLastUpdatedBy(lastActedUponBy);
            property.setLastUpdatedDate(null);

            dao.save(property);
        }
    }

    @Test
    public void testFind() {
        List<String> hazmats = getHazmatList();
        Long id = new Long(0);
        for (String hazmat : hazmats) {
            VReturnsProperties property = new VReturnsProperties();
            property.setId(id++);
            property.setPropertyCategoryName(propertyCategoryName);
            property.setPropertyTypeName(propertyTypeName);
            property.setPropertyValue(hazmat);

            property.setLastActedUponBy(lastUpdatedBy);
            property.setLastUpdatedBy(lastActedUponBy);
            property.setLastUpdatedDate(null);

            dao.save(property);
        }

        List<VReturnsProperties> hazmats4Retrieve = dao.find(propertyCategoryName, propertyTypeName);
        for (VReturnsProperties properity : hazmats4Retrieve) {
            Assert.assertEquals(properity.getLastActedUponBy(), lastActedUponBy);
            Assert.assertEquals(properity.getLastUpdatedBy(), lastUpdatedBy);
            Assert.assertEquals(properity.getPropertyCategoryName(), propertyCategoryName);
            Assert.assertEquals(properity.getPropertyTypeName(), propertyTypeName);
            Assert.assertTrue(hazmats.contains(properity.getPropertyValue()));
        }

    }

    private List<String> getHazmatList() {
        String hamzmatsString = "DE_SmallLithiumIonBatteryWithEquipment|US_SmallLithiumIonBatteryWithEquipment|CA_SmallLithiumIonBatteryWithEquipment|JP_SmallLithiumIonBatteryWithEquipment|CN_SmallLithiumIonBatteryWithEquipment|FR_SmallLithiumIonBatteryWithEquipment|GB_SmallLithiumIonBatteryWithEquipment|DE_LithiumBattery|US_SmallLithiumIonBatteryInEquipment|CA_SmallLithiumIonBatteryInEquipment|JP_SmallLithiumIonBatteryInEquipment|CN_SmallLithiumIonBatteryInEquipment|FR_LithiumBattery|GB_Lithium Battery|GB_LithiumBattery";
        List<String> hazmats = new ArrayList<String>();
        for (String hazmat : hamzmatsString.split("\\|")) {
            hazmats.add(hazmat);
        }

        return hazmats;
    }
}
