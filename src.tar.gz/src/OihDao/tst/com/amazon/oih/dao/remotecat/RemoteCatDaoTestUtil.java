package com.amazon.oih.dao.remotecat;

import org.joda.time.DateTime;
import org.junit.Assert;

import com.amazon.oih.dao.remotecat.RemoteCat;
import com.amazon.oih.dao.remotecat.RemoteCatValueObject;

public class RemoteCatDaoTestUtil {
    public static RemoteCatValueObject createRemoteCatValueObject() {
        RemoteCatValueObject object = new RemoteCatValueObject();
        object.setAsin("B00100ASIN");
        object.setMarketplace(1);
        object.setMerchant(1);
        object.setBinding("Paperback");
        object.setBrandCode("Harper");
        object.setBrandName("Harper Collins Publishers");
        object.setCategory(1000);
        object.setSubCategory(0);
        object.setEan("9780137806515");
        object.setGl(228);
        object.setHazmatException("");
        object.setHazmatItem("");
        object.setHazmatTransportationRegularClass("");
        object.setMapRequired("N");
        object.setUnPrepRequired(false);
        object.setListPrice(14.5);
        object.setMapEndDate(new DateTime("2006-07-04").toDate());
        object.setMapPrice(10.5);
        object.setMapStrict("N");
        object.setMapStrictPrice(11.5);
        object.setModelNumber("20060704");
        object.setOurPrice(11.5);
        object.setParentAsin("B001PARENT");
        object.setPublicationDate(new DateTime("2010-07-09").toDate());
        object.setPublisherCode("Adidas");
        object.setReleaseDate(new DateTime("2010-07-05").toDate());
        object.setReplenishmentCategory("2");
        object.setSeasons("winter");
        object.setSiteLaunchDate(new DateTime("2010-06-05").toDate());
        object.setSourceCountryCode("US");
        object.setTextbookType("3");
        object.setTitle("RemoteCatTitleTest");
        object.setUpc("0099525992");
        object.setRetailOffer("Y");

        return object;
    }

    public static void validate(RemoteCat remoteCatOne, RemoteCat remoteCatTwo) {
        Assert.assertEquals(remoteCatOne.getAsin(), remoteCatTwo.getAsin());
        Assert.assertEquals(remoteCatOne.getMarketplace(), remoteCatTwo.getMarketplace());
        Assert.assertEquals(remoteCatOne.getMerchant(), remoteCatTwo.getMerchant());
        Assert.assertEquals(remoteCatOne.getBinding(), remoteCatTwo.getBinding());
        Assert.assertEquals(remoteCatOne.getBrandName(), remoteCatTwo.getBrandName());
        Assert.assertEquals(remoteCatOne.getBrandCode(), remoteCatTwo.getBrandCode());
        Assert.assertEquals(remoteCatOne.getCategory(), remoteCatTwo.getCategory());
        Assert.assertEquals(remoteCatOne.getEan(), remoteCatTwo.getEan());
        Assert.assertEquals(remoteCatOne.getGl(), remoteCatTwo.getGl());
        Assert.assertEquals(remoteCatOne.getHazmatException(), remoteCatTwo.getHazmatException());
        Assert.assertEquals(remoteCatOne.getHazmatItem(), remoteCatTwo.getHazmatItem());
        Assert.assertEquals(remoteCatOne.getHazmatTransportationRegularClass(), remoteCatTwo
                .getHazmatTransportationRegularClass());
        Assert.assertEquals(remoteCatOne.getMapRequired(), remoteCatTwo.getMapRequired());
        Assert.assertEquals(remoteCatOne.isUnPrepRequired(), remoteCatTwo.isUnPrepRequired());
        Assert.assertEquals(remoteCatOne.getListPrice(), remoteCatTwo.getListPrice(), 0.00001);
        Assert.assertEquals(remoteCatOne.getMapEndDate(), remoteCatTwo.getMapEndDate());
        Assert.assertEquals(remoteCatOne.getMapPrice(), remoteCatTwo.getMapPrice(), 0.00001);
        Assert.assertEquals(remoteCatOne.getMapStrict(), remoteCatTwo.getMapStrict());
        Assert.assertEquals(remoteCatOne.getMapStrictPrice(), remoteCatTwo.getMapStrictPrice(), 0.00001);
        Assert.assertEquals(remoteCatOne.getModelNumber(), remoteCatTwo.getModelNumber());
        Assert.assertEquals(remoteCatOne.getOurPrice(), remoteCatTwo.getOurPrice(), 0.00001);
        Assert.assertEquals(remoteCatOne.getParentAsin(), remoteCatTwo.getParentAsin());
        Assert.assertEquals(remoteCatOne.getPublicationDate(), remoteCatTwo.getPublicationDate());
        Assert.assertEquals(remoteCatOne.getPublisherCode(), remoteCatTwo.getPublisherCode());
        Assert.assertEquals(remoteCatOne.getReleaseDate(), remoteCatTwo.getReleaseDate());
        Assert.assertEquals(remoteCatOne.getReplenishmentCategory(), remoteCatTwo.getReplenishmentCategory());
        Assert.assertEquals(remoteCatOne.getSeasons(), remoteCatTwo.getSeasons());
        Assert.assertEquals(remoteCatOne.getSiteLaunchDate(), remoteCatTwo.getSiteLaunchDate());
        Assert.assertEquals(remoteCatOne.getSourceCountryCode(), remoteCatTwo.getSourceCountryCode());
        Assert.assertEquals(remoteCatOne.getSubCategory(), remoteCatTwo.getSubCategory());

        Assert.assertEquals(remoteCatOne.getTextbookType(), remoteCatTwo.getTextbookType());
        Assert.assertEquals(remoteCatOne.getTitle(), remoteCatTwo.getTitle());
        Assert.assertEquals(remoteCatOne.getUpc(), remoteCatTwo.getUpc());
        Assert.assertEquals(remoteCatOne.getRetailOffer(), remoteCatTwo.getRetailOffer());
    }

    public static void validate(RemoteCat remoteCat, RemoteCatValueObject valueObject) {
        Assert.assertEquals(remoteCat.getAsin(), valueObject.getAsin());
        Assert.assertEquals(remoteCat.getMarketplace(), valueObject.getMarketplace());
        Assert.assertEquals(remoteCat.getMerchant(), valueObject.getMerchant());
        Assert.assertEquals(remoteCat.getBinding(), valueObject.getBinding());
        Assert.assertEquals(remoteCat.getBrandName(), valueObject.getBrandName());
        Assert.assertEquals(remoteCat.getBrandCode(), valueObject.getBrandCode());
        Assert.assertEquals(remoteCat.getCategory(), valueObject.getCategory());
        Assert.assertEquals(remoteCat.getEan(), valueObject.getEan());
        Assert.assertEquals(remoteCat.getGl(), valueObject.getGl());
        Assert.assertEquals(remoteCat.getHazmatException(), valueObject.getHazmatException());
        Assert.assertEquals(remoteCat.getHazmatItem(), valueObject.isHazmatItem());
        Assert.assertEquals(remoteCat.getHazmatTransportationRegularClass(), valueObject
                .getHazmatTransportationRegularClass());
        Assert.assertEquals(remoteCat.getMapRequired(), valueObject.getMapRequired());
        Assert.assertEquals(remoteCat.isUnPrepRequired(), valueObject.isUnPrepRequired());
        Assert.assertEquals(remoteCat.getListPrice(), valueObject.getListPrice(), 0.00001);
        Assert.assertEquals(remoteCat.getMapEndDate(), valueObject.getMapEndDate());
        Assert.assertEquals(remoteCat.getMapPrice(), valueObject.getMapPrice(), 0.00001);
        Assert.assertEquals(remoteCat.getMapStrict(), valueObject.getMapStrict());
        Assert.assertEquals(remoteCat.getMapStrictPrice(), valueObject.getMapStrictPrice(), 0.00001);
        Assert.assertEquals(remoteCat.getModelNumber(), valueObject.getModelNumber());
        Assert.assertEquals(remoteCat.getOurPrice(), valueObject.getOurPrice(), 0.00001);
        Assert.assertEquals(remoteCat.getParentAsin(), valueObject.getParentAsin());
        Assert.assertEquals(remoteCat.getPublicationDate(), valueObject.getPublicationDate());
        Assert.assertEquals(remoteCat.getPublisherCode(), valueObject.getPublisherCode());
        Assert.assertEquals(remoteCat.getReleaseDate(), valueObject.getReleaseDate());
        Assert.assertEquals(remoteCat.getReplenishmentCategory(), valueObject.getReplenishmentCategory());
        Assert.assertEquals(remoteCat.getSeasons(), valueObject.getSeasons());
        Assert.assertEquals(remoteCat.getSiteLaunchDate(), valueObject.getSiteLaunchDate());
        Assert.assertEquals(remoteCat.getSourceCountryCode(), valueObject.getSourceCountryCode());
        Assert.assertEquals(remoteCat.getSubCategory(), valueObject.getSubCategory());

        Assert.assertEquals(remoteCat.getTextbookType(), valueObject.getTextbookType());
        Assert.assertEquals(remoteCat.getTitle(), valueObject.getTitle());
        Assert.assertEquals(remoteCat.getUpc(), valueObject.getUpc());
        Assert.assertEquals(remoteCat.getRetailOffer(), valueObject.getRetailOffer());
    }

}
