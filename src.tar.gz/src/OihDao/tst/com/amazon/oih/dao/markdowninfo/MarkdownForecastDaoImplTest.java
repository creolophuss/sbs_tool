package com.amazon.oih.dao.markdowninfo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import amazon.platform.config.AppConfig;

import com.amazon.oih.dao.exception.OihPersistenceException;
import com.amazon.oih.dao.repository.DaoFactory;
import com.amazon.oih.dao.repository.RepositoryFactory;
import com.amazon.oih.utils.AsinIogPair;

public class MarkdownForecastDaoImplTest {
    private static MarkdownForecastDao dao = DaoFactory.getMarkdownForecastDao(RepositoryFactory.UNIT_TEST);

    @BeforeClass
    public static void init() throws OihPersistenceException {
        Logger.getRootLogger().setLevel(Level.OFF);
        dao.deleteAll();// clear the data from the in-memory session
    }

    @Test
    public void testCreate() {
        long runId = 1;
        String asin = "0000000000";
        int marketplace = 1;
        int demandIncrease = 12;
        int demandIncreaseRate = 4;
        int recoveryRate = 10;
        String dataLevel = "testLevel";
        String dataVersion = "testVersion";

        MarkdownForecast object = dao.createInstance(runId, asin, marketplace, (double)demandIncrease, (double)demandIncreaseRate,
        		(double)recoveryRate,  dataVersion, dataLevel);
        
        Assert.assertEquals(runId, object.getRunID());
        Assert.assertEquals(asin, object.getAsin());
        Assert.assertEquals(marketplace, object.getMarketplaceId());
        Assert.assertEquals(demandIncrease, (int)object.getDemandIncrease());
        Assert.assertEquals(demandIncreaseRate, (int)object.getDemandIncreaseRate());
        Assert.assertEquals(recoveryRate, (int)object.getRecoveryRate());
        Assert.assertEquals(dataVersion, object.getDataVersion());
        Assert.assertEquals(dataLevel, object.getDataLevel());
    }

    @Test
    public void testFind() throws OihPersistenceException {
        long runId = 1L;
        int marketplace = 3;

        List<MarkdownForecast> l = new ArrayList<MarkdownForecast>();

        l.add(dao.createInstance(runId, "0000000000", marketplace, 1.0, 1.0, 1.0, "version1", "level1"));
        l.add(dao.createInstance(runId, "00000000A0", marketplace, 2.0, 2.0, 2.0, "version2", "level2"));
        l.add(dao.createInstance(runId, "0000000B00", marketplace, 3.0, 3.0, 3.0, "version3", "level3"));
        l.add(dao.createInstance(runId, "000000C000", marketplace, 4.0, 4.0, 4.0, "version4", "level4"));

        // set up test data
        for (MarkdownForecast it : l) {
            dao.save(it);
        }

        // verify that we can find the data with correct runId, asin and iog.
        for (MarkdownForecast it : l) {
        	MarkdownForecast til4Retrieve = dao.find(it.getRunID(), it.getAsin(), it.getMarketplaceId());
            Assert.assertEquals(it.getAsin(), til4Retrieve.getAsin());
            Assert.assertEquals(it.getMarketplaceId(), til4Retrieve.getMarketplaceId());
            Assert.assertEquals(it.getDataVersion(), til4Retrieve.getDataVersion());
            Assert.assertEquals(it.getDataLevel(), til4Retrieve.getDataLevel());
        }

        // verify that we cannot find the data with wrong run id.
        Assert.assertNull(dao.find(++runId, "0000000B00", marketplace));
    }


    @Test
    public void testExists() throws OihPersistenceException {
        long runId = 0L;
        String asin = "0123456789";
        int marketplace = 1;

        // set up test data
        dao.save(dao.createInstance(runId, asin, marketplace, 1.0, 1.0, 1.0, "version1", "level1"));

        // verify that data exists
        Assert.assertTrue(dao.exists(runId, asin, marketplace));

        // verify that data not exists
        Assert.assertFalse(dao.exists(runId, asin, ++marketplace));
    }
    
}
