package com.amazon.oih.dao.forecast34To52;

import java.util.ArrayList;
import java.util.List;

import javax.naming.NamingException;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.amazon.carbonado.PersistException;
import com.amazon.carbonado.Repository;
import com.amazon.carbonado.RepositoryException;
import com.amazon.carbonado.Storage;
import com.amazon.carbonado.SupportException;
import com.amazon.oih.dao.forecast.ForecastType;
import com.amazon.oih.dao.forecast34to52.Forecast34To52;
import com.amazon.oih.dao.forecast34to52.Forecast34To52Dao;
import com.amazon.oih.dao.repository.DaoFactory;
import com.amazon.oih.dao.repository.RepositoryFactory;

public class Forecast34To52DaoTest {

    private static Forecast34To52Dao forecast34To52Dao = DaoFactory.getForecast34To52Dao(RepositoryFactory.UNIT_TEST);

    List<Double> forecasts = new ArrayList<Double>();
    
    @Before
    public void cleanUpRepository() throws SupportException, RepositoryException {
        Repository r = RepositoryFactory.getInst().getRepository(Forecast34To52.class, RepositoryFactory.UNIT_TEST);
        Storage<Forecast34To52> sf = r.storageFor(Forecast34To52.class);
        sf.truncate();
        
        for (int i=0; i<33; i++) {
            forecasts.add(Double.valueOf(i+1));
        }
    }
    

    @Test
    public void testCreate() throws NamingException, RepositoryException, ClassNotFoundException {
        ForecastType[] forecastTypes = new ForecastType[] {
                ForecastType.OIH, ForecastType.P50, ForecastType.OIH, ForecastType.MEAN
        };
        String asin = "0000000000";
        Integer marketplaceid = 1;

        for (ForecastType type : forecastTypes) {
        	Forecast34To52 forecast = forecast34To52Dao.createForecast34To52(asin, marketplaceid, type, forecasts);
            Assert.assertEquals(asin, forecast.getAsin());
            Assert.assertEquals(type, forecast.getForecastType());
            Assert.assertEquals(1, forecast.getWeek34(), 0);
            Assert.assertEquals(2, forecast.getWeek35(), 0);
            Assert.assertEquals(3, forecast.getWeek36(), 0);
            Assert.assertEquals(4, forecast.getWeek37(), 0);
            Assert.assertEquals(5, forecast.getWeek38(), 0);
            Assert.assertEquals(6, forecast.getWeek39(), 0);
            Assert.assertEquals(7, forecast.getWeek40(), 0);
            Assert.assertEquals(8, forecast.getWeek41(), 0);
            Assert.assertEquals(9, forecast.getWeek42(), 0);
            Assert.assertEquals(10, forecast.getWeek43(), 0);
            Assert.assertEquals(11, forecast.getWeek44(), 0);
            Assert.assertEquals(12, forecast.getWeek45(), 0);
            Assert.assertEquals(13, forecast.getWeek46(), 0);
            Assert.assertEquals(14, forecast.getWeek47(), 0);
            Assert.assertEquals(15, forecast.getWeek48(), 0);
            Assert.assertEquals(16, forecast.getWeek49(), 0);
            Assert.assertEquals(17, forecast.getWeek50(), 0);
            Assert.assertEquals(18, forecast.getWeek51(), 0);
            Assert.assertEquals(19, forecast.getWeek52(), 0);
        }
    }
    

    @Test(expected = IllegalArgumentException.class)
    public void testCreateWrongAsin() throws NamingException, RepositoryException, ClassNotFoundException {
        Integer marketplaceid = 1;
    	forecast34To52Dao.createForecast34To52("0000000000000", marketplaceid, ForecastType.OIH, forecasts);
    }
    

    @Test
    public void testDuplicate() throws PersistException, NamingException, RepositoryException, ClassNotFoundException {
        Integer marketplaceid = 1;
        // as long as one of runId, asin, type, or period differ, there should be no problem
        forecast34To52Dao.save(forecast34To52Dao.createForecast34To52("0000000000", marketplaceid, ForecastType.OIH, forecasts));
        forecast34To52Dao.save(forecast34To52Dao.createForecast34To52("0000000000", marketplaceid, ForecastType.P50, forecasts));
        try {
            forecast34To52Dao.save(forecast34To52Dao.createForecast34To52("0000000000", marketplaceid, ForecastType.OIH, forecasts));
            Assert.fail("Should have failed due to duplicate forecast");
        } catch (RepositoryException ex) {
            // OK, expected
        }
    }
    
    @Test
    public void testExisted() throws NamingException, RepositoryException, ClassNotFoundException {
        Forecast34To52 f1;
        Integer marketplaceid = 1;

        String asin = "0000000000";
        
        f1 = forecast34To52Dao.createForecast34To52(asin, marketplaceid, ForecastType.OIH, forecasts);
        forecast34To52Dao.save(f1);
        Assert.assertTrue(forecast34To52Dao.exists(asin, marketplaceid));
    }
   
    @Test
    public void testFind() throws NamingException, RepositoryException, ClassNotFoundException {
        Forecast34To52 f1;
        Integer marketplaceid = 1;

        f1 = forecast34To52Dao.createForecast34To52("0000000000", marketplaceid, ForecastType.OIH, forecasts);
        forecast34To52Dao.save(f1);
        
        Assert.assertTrue("ASIN " + f1.getAsin() + " inserted but not found!",
                forecast34To52Dao.find(f1.getAsin(), marketplaceid).size() > 0);
    }
}
