package com.amazon.oih.dao.ilbo;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.amazon.oih.dao.DaoConstants;

public class IlboObjectTest {

    @Test
    public void testCompare(){
        IlboObject i1, i2;
        i1 = new IlboObject("0000000000", 1, DaoConstants.UNIT_TEST, "LEX1", 0, 0, 0, 0);
        
        i2 = new IlboObject("0000000000", 1, DaoConstants.UNIT_TEST, "LEX1", 0, 0, 0, 0);
        Assert.assertTrue(i1.equals(i2));
        
        i2 = new IlboObject("0000000000", 1, DaoConstants.UNIT_TEST, "LEX1", 0, 0, 0, 1);
        Assert.assertFalse(i1.equals(i2));
        
        i2 = new IlboObject("0000000000", 1, DaoConstants.UNIT_TEST, "LEX1", 0, 0, 1, 0);
        Assert.assertFalse(i1.equals(i2));
        
        i2 = new IlboObject("0000000000", 1, DaoConstants.UNIT_TEST, "LEX1", 0, 1, 0, 0);
        Assert.assertFalse(i1.equals(i2));
        
        i2 = new IlboObject("0000000000", 1, DaoConstants.UNIT_TEST, "LEX1", 1, 0, 0, 0);
        Assert.assertFalse(i1.equals(i2));
        
        i2 = new IlboObject("0000000000", 1, DaoConstants.UNIT_TEST, "LEX2", 0, 0, 0, 0);
        Assert.assertFalse(i1.equals(i2));
        
        i2 = new IlboObject("0000000000", 1, "", "LEX2", 0, 0, 0, 0);
        Assert.assertFalse(i1.equals(i2));
        
        i2 = new IlboObject("0000000001", 1, DaoConstants.UNIT_TEST, "LEX2", 0, 0, 0, 0);
        Assert.assertFalse(i1.equals(i2));
        
        i2 = new IlboObject("0000000000", 2, DaoConstants.UNIT_TEST, "LEX2", 0, 0, 0, 0);
        Assert.assertFalse(i1.equals(i2));
        
        Assert.assertFalse(i1.equals(null));
    }
    

    @Test
    public void testCopyValues(){
        IlboObject i1, i2;
        i1 = new IlboObject("0000000000", 1, DaoConstants.UNIT_TEST, "LEX1", 1, 2, 3, 4);
        
        i2 = new IlboObject("0000000000", 1, DaoConstants.UNIT_TEST, "LEX1", 0, 0, 0, 0);
        
        i2.copyValues(i1);
        Assert.assertTrue(i1.equals(i2));
        
    }
    
    @Test
    public void testGetKey(){
        IlboObject i1, i2;
        i1 = new IlboObject("0000000000", 1, DaoConstants.UNIT_TEST, "LEX1", 1, 2, 3, 4);
        Assert.assertEquals(i1.getKey(), "0000000000|1|LEX1");
    }
    
    @Test
    public void testGetValues(){
        IlboObject i1, i2;
        i1 = new IlboObject("0000000000", 1, DaoConstants.UNIT_TEST, "LEX1", 1, 2, 3, 4);
        Assert.assertEquals(i1.getValues(), "1|2|3|4");
        Assert.assertEquals(i1.getAsin(), "0000000000");
        Assert.assertEquals(i1.getIog(), 1);
        Assert.assertEquals(i1.getWarehouseId(), "LEX1");
        Assert.assertEquals(i1.getSellableOnHandQty(), 1);
        Assert.assertEquals(i1.getSellableAllocatedQty(), 2);
        Assert.assertEquals(i1.getSellableUnallocated(), 3);
        Assert.assertEquals(i1.getUnsellableOnHandQty(), 4);
    }
    
    @Test
    public void testDate(){
        IlboObject i1;
        i1 = new IlboObject("0000000000", 1, DaoConstants.UNIT_TEST, "LEX1", 1, 2, 3, 4);
        Date  expectedDate = new Date();
        i1.setDates(expectedDate);
        
        Assert.assertEquals(expectedDate, i1.getFirstLoadDate());
        Assert.assertEquals(expectedDate, i1.getLastLoadDate());
        
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date exp = null;
        try {
            exp = dateFormat.parse(DaoConstants.EXPIRE_DATE);
        } catch (ParseException e) {
            e.printStackTrace();
        } 
        Assert.assertEquals(exp,i1.getExpiredDate());
    }
    
    @Test
    public void testNullable(){
        IlboObject i2;
       
        i2 = new IlboObject(null, 1, null, "LEX1", 0, 0, 0, 0);

        Assert.assertNotNull(i2);
    }
}
