package com.amazon.oih.dao.hbase.revenue;

import java.io.IOException;
import java.util.Collection;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import junit.framework.Assert;

import org.apache.hadoop.hbase.KeyValue;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.client.Result;
import org.junit.BeforeClass;
import org.junit.Test;

import amazon.platform.config.AppConfig;

import com.amazon.oih.dao.repository.RepositoryFactory;

public class RevenueHBaseDaoTest {

    static Map<String, AsinRevenueData> dummyObjData;
    static Map<String, AsinRevenueData> dummyObjDataWithNull;
    static RevenueHBaseDao dao;
    private static String source = RepositoryFactory.UNIT_TEST;
    private static final String realm = "USAmazon";
    private static final String root = "/tmp";

    @BeforeClass
    public static void prepareGlobal() throws IOException {
    	if (!AppConfig.isInitialized()) {
    		AppConfig.initialize("OihMetrics", "Oih", new String[] {
    				"--root=" + root, "--domain=" + source, "--realm=" + realm,
    		});
    	}
    	AppConfig.insertString("IhrMetrics.AsinRevenueDataHBase.TableName", "AsinRevenueData");
        dummyObjData = AsinRevenueDataTestUtil.buildObjMapDummyData();
        dummyObjDataWithNull = AsinRevenueDataTestUtil.buildObjMapDummyDataWithNull();
        dao = new RevenueHBaseDao();
    }


    @Test
    public void testAsinRevenueData2StringConvert() throws IOException {
        List<Put> puts = new LinkedList<Put>();
        Collection<AsinRevenueData> values = dummyObjData.values();
        for (AsinRevenueData bObject : values) {
            puts.addAll(dao.convert(bObject));
        }

        Assert.assertEquals(puts.size(), values.size());

        Assert.assertTrue(values.containsAll(convertPuts2AsinRevenueDatas(puts)));
    }

    @Test
    public void testAsinRevenueData2StringConvertWithNull() throws IOException {
        List<Put> puts = new LinkedList<Put>();
        Collection<AsinRevenueData> values = dummyObjDataWithNull.values();
        for (AsinRevenueData bObject : values) {
            puts.addAll(dao.convert(bObject));
        }

        Assert.assertEquals(puts.size(), values.size());

        Assert.assertTrue(values.containsAll(convertPuts2AsinRevenueDatas(puts)));
    }

    private Collection<AsinRevenueData> convertPuts2AsinRevenueDatas(Collection<Put> puts) throws IOException {
        List<AsinRevenueData> ret = new LinkedList<AsinRevenueData>();
        for (final Put put : puts) {
            Result resultMock = new Result() {

                @Override
                public boolean isEmpty() {
                    return false;
                }

                @Override
                public KeyValue[] raw() {
                    return put.getFamilyMap().get(RevenueHBaseDao.columnFamilyBytes).toArray(new KeyValue[0]);
                }

            };
            AsinRevenueData bObj;
            bObj = dao.convert(new String(put.getRow()), resultMock);
            ret.add(bObj);
        }
        return ret;
    }
}
