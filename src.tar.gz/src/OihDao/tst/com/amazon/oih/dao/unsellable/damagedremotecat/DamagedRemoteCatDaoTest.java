package com.amazon.oih.dao.unsellable.damagedremotecat;

import javax.naming.NamingException;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.amazon.carbonado.Repository;
import com.amazon.carbonado.RepositoryException;
import com.amazon.carbonado.Storage;
import com.amazon.carbonado.SupportException;
import com.amazon.oih.dao.exception.OihPersistenceException;
import com.amazon.oih.dao.remotecat.RemoteCatDaoTestUtil;
import com.amazon.oih.dao.remotecat.RemoteCatValueObject;
import com.amazon.oih.dao.repository.DaoFactory;
import com.amazon.oih.dao.repository.RepositoryFactory;

public class DamagedRemoteCatDaoTest {
    private static IDamagedRemoteCatDao dao = DaoFactory.getDamagedRemoteCatDao(RepositoryFactory.UNIT_TEST);

    @Before
    public void cleanUpRepository() throws SupportException, RepositoryException {
        Repository r = RepositoryFactory.getInst().getRepository(DamagedRemoteCatObject.class,
                RepositoryFactory.UNIT_TEST);
        Storage<DamagedRemoteCatObject> sf = r.storageFor(DamagedRemoteCatObject.class);
        sf.truncate();
    }

    @Test
    public void testCreate() throws NamingException, RepositoryException, ClassNotFoundException,
            OihPersistenceException {
        RemoteCatValueObject valueObject = RemoteCatDaoTestUtil.createRemoteCatValueObject();
        DamagedRemoteCatObject remoteCat = dao.createRemoteCat(valueObject);
        validate(valueObject, remoteCat);
    }

    @Test
    public void testFind() throws NamingException, RepositoryException, ClassNotFoundException, OihPersistenceException {
        RemoteCatValueObject valueObject = RemoteCatDaoTestUtil.createRemoteCatValueObject();
        DamagedRemoteCatObject remoteCat4Save = dao.createRemoteCat(valueObject);
        dao.save(remoteCat4Save);

        DamagedRemoteCatObject remoteCat4Retrieve = dao.find(valueObject.getAsin(), valueObject.getIog());

        validate(remoteCat4Retrieve, remoteCat4Save);
    }

    @Test
    public void testExist() throws NamingException, RepositoryException, ClassNotFoundException,
            OihPersistenceException {
        RemoteCatValueObject valueObject = RemoteCatDaoTestUtil.createRemoteCatValueObject();
        DamagedRemoteCatObject remoteCat4Save = dao.createRemoteCat(valueObject);
        dao.save(remoteCat4Save);

        Assert.assertTrue(dao.exists(valueObject.getAsin(), valueObject.getIog()));

        DamagedRemoteCatObject remoteCat4Retrieve = dao.find(valueObject.getAsin(), valueObject.getIog());

        validate(remoteCat4Retrieve, remoteCat4Save);
    }

    @Test
    public void testDuplicatedSave() throws NamingException, RepositoryException, ClassNotFoundException,
            OihPersistenceException {
        RemoteCatValueObject valueObject = RemoteCatDaoTestUtil.createRemoteCatValueObject();
        DamagedRemoteCatObject remoteCat4Save = dao.createRemoteCat(valueObject);
        dao.save(remoteCat4Save);

        try {
            dao.save(remoteCat4Save);
            Assert.assertTrue(false);// should come here
        } catch (Exception e) {
            // Exception is expected
        }
    }

    public static void validate(RemoteCatValueObject remoteCat, DamagedRemoteCatObject valueObject) {
        Assert.assertEquals(remoteCat.getAsin(), valueObject.getAsin());
        Assert.assertEquals(remoteCat.getIog(), valueObject.getIog());
        Assert.assertEquals(remoteCat.getAsin(), valueObject.getAsin());
        Assert.assertEquals(remoteCat.getIog(), valueObject.getIog());
        Assert.assertEquals(remoteCat.getBinding(), valueObject.getBinding());
        Assert.assertEquals(remoteCat.getBrandName(), valueObject.getBrandName());
        Assert.assertEquals(remoteCat.getBrandCode(), valueObject.getBrandCode());
        Assert.assertEquals(remoteCat.getCategory(), valueObject.getCategory());
        Assert.assertEquals(remoteCat.getEan(), valueObject.getEan());
        Assert.assertEquals(remoteCat.getGl(), valueObject.getGl());
        Assert.assertEquals(remoteCat.getHazmatException(), valueObject.getHazmatException());
        Assert.assertEquals(remoteCat.isHazmatItem(), valueObject.getHazmatItem());
        Assert.assertEquals(remoteCat.getHazmatTransportationRegularClass(), valueObject
                .getHazmatTransportationRegularClass());
        Assert.assertEquals(remoteCat.getMapRequired(), valueObject.getMapRequired());
        Assert.assertEquals(remoteCat.isUnPrepRequired(), valueObject.isUnPrepRequired());
        Assert.assertEquals(remoteCat.getListPrice(), valueObject.getListPrice(), 0.00001);
        Assert.assertEquals(remoteCat.getMapEndDate(), valueObject.getMapEndDate());
        Assert.assertEquals(remoteCat.getMapPrice(), valueObject.getMapPrice(), 0.00001);
        Assert.assertEquals(remoteCat.getMapStrict(), valueObject.getMapStrict());
        Assert.assertEquals(remoteCat.getMapStrictPrice(), valueObject.getMapStrictPrice(), 0.00001);
        Assert.assertEquals(remoteCat.getModelNumber(), valueObject.getModelNumber());
        Assert.assertEquals(remoteCat.getOurPrice(), valueObject.getOurPrice(), 0.00001);
        Assert.assertEquals(remoteCat.getParentAsin(), valueObject.getParentAsin());
        Assert.assertEquals(remoteCat.getPublicationDate(), valueObject.getPublicationDate());
        Assert.assertEquals(remoteCat.getPublisherCode(), valueObject.getPublisherCode());
        Assert.assertEquals(remoteCat.getReleaseDate(), valueObject.getReleaseDate());
        Assert.assertEquals(remoteCat.getReplenishmentCategory(), valueObject.getReplenishmentCategory());
        Assert.assertEquals(remoteCat.getSeasons(), valueObject.getSeasons());
        Assert.assertEquals(remoteCat.getSiteLaunchDate(), valueObject.getSiteLaunchDate());
        Assert.assertEquals(remoteCat.getSourceCountryCode(), valueObject.getSourceCountryCode());
        Assert.assertEquals(remoteCat.getSubCategory(), valueObject.getSubCategory());

        Assert.assertEquals(remoteCat.getTextbookType(), valueObject.getTextbookType());
        Assert.assertEquals(remoteCat.getTitle(), valueObject.getTitle());
        Assert.assertEquals(remoteCat.getUpc(), valueObject.getUpc());
    }

    public static void validate(DamagedRemoteCatObject remoteCat, DamagedRemoteCatObject valueObject) {
        Assert.assertEquals(remoteCat.getAsin(), valueObject.getAsin());
        Assert.assertEquals(remoteCat.getIog(), valueObject.getIog());
        Assert.assertEquals(remoteCat.getAsin(), valueObject.getAsin());
        Assert.assertEquals(remoteCat.getIog(), valueObject.getIog());
        Assert.assertEquals(remoteCat.getBinding(), valueObject.getBinding());
        Assert.assertEquals(remoteCat.getBrandName(), valueObject.getBrandName());
        Assert.assertEquals(remoteCat.getBrandCode(), valueObject.getBrandCode());
        Assert.assertEquals(remoteCat.getCategory(), valueObject.getCategory());
        Assert.assertEquals(remoteCat.getEan(), valueObject.getEan());
        Assert.assertEquals(remoteCat.getGl(), valueObject.getGl());
        Assert.assertEquals(remoteCat.getHazmatException(), valueObject.getHazmatException());
        Assert.assertEquals(remoteCat.getHazmatItem(), valueObject.getHazmatItem());
        Assert.assertEquals(remoteCat.getHazmatTransportationRegularClass(), valueObject
                .getHazmatTransportationRegularClass());
        Assert.assertEquals(remoteCat.getMapRequired(), valueObject.getMapRequired());
        Assert.assertEquals(remoteCat.isUnPrepRequired(), valueObject.isUnPrepRequired());
        Assert.assertEquals(remoteCat.getListPrice(), valueObject.getListPrice(), 0.00001);
        Assert.assertEquals(remoteCat.getMapEndDate(), valueObject.getMapEndDate());
        Assert.assertEquals(remoteCat.getMapPrice(), valueObject.getMapPrice(), 0.00001);
        Assert.assertEquals(remoteCat.getMapStrict(), valueObject.getMapStrict());
        Assert.assertEquals(remoteCat.getMapStrictPrice(), valueObject.getMapStrictPrice(), 0.00001);
        Assert.assertEquals(remoteCat.getModelNumber(), valueObject.getModelNumber());
        Assert.assertEquals(remoteCat.getOurPrice(), valueObject.getOurPrice(), 0.00001);
        Assert.assertEquals(remoteCat.getParentAsin(), valueObject.getParentAsin());
        Assert.assertEquals(remoteCat.getPublicationDate(), valueObject.getPublicationDate());
        Assert.assertEquals(remoteCat.getPublisherCode(), valueObject.getPublisherCode());
        Assert.assertEquals(remoteCat.getReleaseDate(), valueObject.getReleaseDate());
        Assert.assertEquals(remoteCat.getReplenishmentCategory(), valueObject.getReplenishmentCategory());
        Assert.assertEquals(remoteCat.getSeasons(), valueObject.getSeasons());
        Assert.assertEquals(remoteCat.getSiteLaunchDate(), valueObject.getSiteLaunchDate());
        Assert.assertEquals(remoteCat.getSourceCountryCode(), valueObject.getSourceCountryCode());
        Assert.assertEquals(remoteCat.getSubCategory(), valueObject.getSubCategory());

        Assert.assertEquals(remoteCat.getTextbookType(), valueObject.getTextbookType());
        Assert.assertEquals(remoteCat.getTitle(), valueObject.getTitle());
        Assert.assertEquals(remoteCat.getUpc(), valueObject.getUpc());
    }

}
