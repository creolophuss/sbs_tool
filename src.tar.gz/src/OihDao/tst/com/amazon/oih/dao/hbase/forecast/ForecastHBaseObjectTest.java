package com.amazon.oih.dao.hbase.forecast;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.joda.time.DateTime;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import amazon.platform.config.AppConfig;

import com.amazon.oih.dao.hbase.forecast.ForecastColumn;
import com.amazon.oih.dao.hbase.forecast.ForecastHBaseObject;
import com.amazon.oih.dao.repository.RepositoryFactory;
import com.google.common.collect.Sets;

public class ForecastHBaseObjectTest {
    private static String source = RepositoryFactory.UNIT_TEST;
    final static Date RUN_DATE = new DateTime("2010-01-19").toDate();
    private static final String realm = "USAmazon";
    private static final String root = "/tmp";

    @BeforeClass
    public static void init() {
        Logger.getRootLogger().setLevel(Level.OFF);

        if (!AppConfig.isInitialized()) {
            AppConfig.initialize("OihMetrics", "Oih", new String[] {
                    "--root=" + root, "--domain=" + source, "--realm=" + realm,
            });
        }
    }

    @Test
    public void testInitForecast() {
        ForecastHBaseObject forecastHBaseObject = new ForecastHBaseObject("1234567890", 1);
        Map<String, List<Double>> forecastMap = new HashMap<String, List<Double>>();
        List<Double> forecastValueListOrig = new ArrayList<Double>();
        for (int week = 0; week < 33; week++) {
            forecastValueListOrig.add(week + week * 0.1);
        }
        forecastMap.put(ForecastColumn.P50.getCode(), forecastValueListOrig);
        forecastHBaseObject.setForecast(forecastMap);

        Assert.assertEquals(forecastHBaseObject.getAsin(), "1234567890");
        Assert.assertEquals(forecastHBaseObject.getMarketplace(), 1);
        Assert.assertTrue(forecastHBaseObject.getForecastMap().containsKey(ForecastColumn.P50.getCode()));

        List<Double> forecastValueList = forecastHBaseObject.getForecastMap().get(ForecastColumn.P50.getCode());
        Assert.assertEquals(forecastValueListOrig.size(), forecastValueList.size());
        Assert.assertArrayEquals(forecastValueListOrig.toArray(), forecastValueList.toArray());

    }

    @Test
    public void testGetValue() {
        ForecastHBaseObject forecastHBaseObject = new ForecastHBaseObject("0000000001", 1);
        Map<String, List<Double>> forecastMap = new HashMap<String, List<Double>>();
        List<Double> forecastValueList = new ArrayList<Double>();
        forecastValueList.add(1.0);
        forecastValueList.add(2.0);
        forecastValueList.add(3.0);
        forecastValueList.add(4.0);
        forecastValueList.add(5.0);
        forecastValueList.add(6.0);
        forecastValueList.add(7.0);
        forecastValueList.add(8.0);
        forecastValueList.add(9.0);
        forecastValueList.add(10.0);
        forecastValueList.add(11.0);
        forecastMap.put(ForecastColumn.P50.getCode(), forecastValueList);
        forecastHBaseObject.setForecast(forecastMap);

        Assert.assertEquals("1.0,2.0,3.0,4.0,5.0,6.0,7.0,8.0,9.0,10.0,11.0",
                forecastHBaseObject.getValues(ForecastColumn.P50.getCode()));
    }

    @Test
    public void testGetValue1() {
        ForecastHBaseObject forecastHBaseObject = new ForecastHBaseObject("0000000001", 1);
        Map<String, List<Double>> forecastMap = new HashMap<String, List<Double>>();
        List<Double> forecastValueList = new ArrayList<Double>();
        forecastValueList.add(1.0);
        forecastValueList.add(2.0);
        forecastValueList.add(3.0);
        forecastValueList.add(4.0);
        forecastValueList.add(5.0);
        forecastValueList.add(6.0);
        forecastValueList.add(7.0);
        forecastValueList.add(8.0);
        forecastValueList.add(9.0);
        forecastValueList.add(10.0);
        forecastValueList.add(0.0);
        forecastMap.put(ForecastColumn.P50.getCode(), forecastValueList);
        forecastHBaseObject.setForecast(forecastMap);

        Assert.assertEquals("1.0,2.0,3.0,4.0,5.0,6.0,7.0,8.0,9.0,10.0,9.0",
                forecastHBaseObject.getValues(ForecastColumn.P50.getCode()));
    }

    @Test
    public void testToAnnoForecastObj() {
        ForecastHBaseObject forecastHBaseObject = new ForecastHBaseObject("0000000001", 1);
        Map<String, List<Double>> forecastMap = new HashMap<String, List<Double>>();
        List<Double> forecastValueList = new ArrayList<Double>();
        forecastValueList.add(1.0);
        forecastValueList.add(2.0);
        forecastValueList.add(3.0);
        forecastValueList.add(4.0);
        forecastValueList.add(5.0);
        forecastValueList.add(6.0);
        forecastValueList.add(7.0);
        forecastValueList.add(8.0);
        forecastValueList.add(9.0);
        forecastValueList.add(10.0);
        forecastValueList.add(11.0);
        forecastMap.put(ForecastColumn.P50.getCode(), forecastValueList);
        forecastValueList = new ArrayList<Double>();
        forecastValueList.add(10.0);
        forecastValueList.add(20.0);
        forecastValueList.add(30.0);
        forecastValueList.add(40.0);
        forecastValueList.add(50.0);
        forecastValueList.add(60.0);
        forecastValueList.add(70.0);
        forecastValueList.add(80.0);
        forecastValueList.add(90.0);
        forecastValueList.add(100.0);
        forecastValueList.add(110.0);
        forecastMap.put(ForecastColumn.P90.getCode(), forecastValueList);
        forecastHBaseObject.setForecast(forecastMap);

        List<AnnoForecastHBaseObj> result = forecastHBaseObject.toAnnoForecastHBaseObj();
        Assert.assertEquals(result.size(), 2);
        for (AnnoForecastHBaseObj hbaseObj : result) {
            Assert.assertEquals("0000000001", hbaseObj.getAsin());
            Assert.assertEquals(1, hbaseObj.getMarketplace());
            if (hbaseObj.getProbability() == ForecastColumn.P90.getCode()) {
                Assert.assertEquals("10.0,20.0,30.0,40.0,50.0,60.0,70.0,80.0,90.0,100.0,110.0",
                        hbaseObj.getForecastSeq());
            } else if (hbaseObj.getProbability() == ForecastColumn.P50.getCode()) {
                Assert.assertEquals("1.0,2.0,3.0,4.0,5.0,6.0,7.0,8.0,9.0,10.0,11.0", hbaseObj.getForecastSeq());
            } else {
                Assert.assertFalse(true);
            }
        }
    }

    @Test
    public void testToForecastHBaseObject() {
        List<AnnoForecastHBaseObj> forecastList = new ArrayList<AnnoForecastHBaseObj>();
        AnnoForecastHBaseObj obj1 = new AnnoForecastHBaseObj();
        obj1.setAsin("0000000001");
        obj1.setMarketplace(1);
        obj1.setProbability(ForecastColumn.P90.getCode());
        List<Double> forecastValueList = new ArrayList<Double>();
        forecastValueList.add(10.0);
        forecastValueList.add(20.0);
        forecastValueList.add(30.0);
        forecastValueList.add(40.0);
        forecastValueList.add(50.0);
        forecastValueList.add(60.0);
        forecastValueList.add(70.0);
        forecastValueList.add(80.0);
        forecastValueList.add(90.0);
        forecastValueList.add(100.0);
        forecastValueList.add(110.0);
        obj1.setForecastSeq(forecastValueList);
        Assert.assertEquals("10.0,20.0,30.0,40.0,50.0,60.0,70.0,80.0,90.0,100.0,110.0", obj1.getForecastSeq());
        AnnoForecastHBaseObj obj2 = new AnnoForecastHBaseObj();
        obj2.setAsin("0000000001");
        obj2.setMarketplace(1);
        obj2.setProbability(ForecastColumn.P50.getCode());
        obj2.setForecastSeq("1.0,2.0,3.0,4.0,5.0,6.0,7.0,8.0,9.0,10.0,11.0");

        ForecastHBaseObject orgObj = AnnoForecastHBaseObj.toForecastHBaseObject(forecastList);
        Assert.assertNull(orgObj);
        
        forecastList.add(obj1); forecastList.add(obj2);
        orgObj = AnnoForecastHBaseObj.toForecastHBaseObject(forecastList);
        Assert.assertEquals("0000000001", orgObj.getAsin());
        Assert.assertEquals(1, orgObj.getMarketplace());
        Map<String, List<Double>> forecastMap = orgObj.getForecastMap();
        Assert.assertEquals(Sets.newHashSet(ForecastColumn.P90.getCode(), ForecastColumn.P50.getCode()), forecastMap.keySet());
        Assert.assertEquals(new Double(10.0), forecastMap.get(ForecastColumn.P90.getCode()).get(0));
        Assert.assertEquals(new Double(110.0), forecastMap.get(ForecastColumn.P90.getCode()).get(10));
        Assert.assertEquals(new Double(1.0), forecastMap.get(ForecastColumn.P50.getCode()).get(0));
        Assert.assertEquals(new Double(11.0), forecastMap.get(ForecastColumn.P50.getCode()).get(10));
    }
}
