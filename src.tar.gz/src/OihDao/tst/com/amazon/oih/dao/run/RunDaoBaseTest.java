package com.amazon.oih.dao.run;

import java.util.Calendar;
import java.util.List;

import javax.naming.NamingException;

import org.joda.time.DateTime;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.amazon.carbonado.ConfigurationException;
import com.amazon.carbonado.Repository;
import com.amazon.carbonado.RepositoryException;
import com.amazon.carbonado.Storage;
import com.amazon.oih.dao.exception.DaoRuntimeException;
import com.amazon.oih.dao.exception.OihPersistenceException;
import com.amazon.oih.dao.repository.DaoFactory;
import com.amazon.oih.dao.repository.RepositoryFactory;

public class RunDaoBaseTest {
    private RunDao runDao = DaoFactory.getRunDao(RepositoryFactory.UNIT_TEST);

    @Before
    public void setup() throws RepositoryException, RepositoryException {
        // clean up the Run table
        Repository runRepository = RepositoryFactory.getInst().getRepository(Run.class, RepositoryFactory.UNIT_TEST);
        Storage<Run> sf = runRepository.storageFor(Run.class);
        sf.truncate();
    }
    
    @Test
    public void testCreateRun() throws DaoRuntimeException, OihPersistenceException {
        String domain = "test-tag";
        String realm = "USAmazon";
        Calendar c = Calendar.getInstance();
        DateTime d = new DateTime(c.getTime());
        String tag = "tag";
        Run run = runDao.createRun(d, domain, realm, tag);
        
        // the dao will truncate the time portion of run date. 
        d = d.withTime(0, 0, 0, 0);
        Assert.assertEquals(d, run.getRunDate());
        Assert.assertEquals(domain, run.getDomain());
        Assert.assertEquals(realm, run.getRealm());
        Assert.assertEquals(tag, run.getTag());
    }
    
    @Test(expected = IllegalArgumentException.class) 
    public void testCreateRunWithNullTag() throws DaoRuntimeException, OihPersistenceException {
        Calendar c = Calendar.getInstance();
        DateTime d = new DateTime(c.getTime());

        // cannot create run id with null tag
        runDao.createRun(d, "domain", "realm", null);
    }
    
    @Test
    public void testFindRunID() throws DaoRuntimeException, OihPersistenceException {
        Calendar c = Calendar.getInstance();
        DateTime date = new DateTime(c.getTime());

        Run r = runDao.createRun(date, "prod", "USAmazon", "");
        r.setRunID(1L);
        runDao.save(r);
        Assert.assertEquals(r, runDao.find(r.getRunID()));

        date = date.minusYears(2);
        r = runDao.createRun(date, "any-domain", "CAAmazon", "tag");
        r.setRunID(2L);
        runDao.save(r);
        Assert.assertEquals(r, runDao.find(r.getRunID()));
    }

    @Test
    public void testFind() throws DaoRuntimeException, OihPersistenceException {
        // populate Run table
        Calendar c = Calendar.getInstance();
        DateTime date = new DateTime(c.getTime());
        
        // normal run id
        Run r1 = runDao.createRun(date, "prod", "USAmazon", "tag");
        r1.setRunID(1L);
        runDao.save(r1);
        // run id with empty tag
        Run r2 = runDao.createRun(date, "prod", "USAmazon", "");
        r2.setRunID(2L);
        runDao.save(r2);
        
        // found run id with "tag" 
        Run result = runDao.find(date, "prod", "USAmazon", "tag");
        Assert.assertEquals(r1, result);
                
        // found run id with empty tag
        result = runDao.find(date, "prod", "USAmazon", "");
        Assert.assertEquals(r2.toString(), result.toString());

        // cannot find run id with null tag
        result = runDao.find(date, "prod", "USAmazon", null);
        Assert.assertNull(result);
    }
    
    @Test
    public void testFindRunDate() throws DaoRuntimeException, OihPersistenceException, ConfigurationException,
            NamingException, RepositoryException, ClassNotFoundException {
        Calendar c = Calendar.getInstance();
        DateTime date = new DateTime(c.getTime());

        Run r = runDao.createRun(date, "test", "JPAmazon", "tag");
        r.setRunID(1L);
        runDao.save(r);
        Assert.assertEquals(r.toString(), runDao.find(r.getRunDate(), "test", "JPAmazon").get(0).toString());

        date = date.minusYears(2);
        r = runDao.createRun(date, "prod", "USAmazon", "");
        r.setRunID(2L);
        runDao.save(r);
        r = runDao.createRun(date, "prod", "DEAmazon", "");
        r.setRunID(3L);
        runDao.save(r);

        List<Run> result = runDao.find(date);
        Assert.assertTrue("Inserted 2 objects with date " + date.toString() + " but extracted less!",
                result.size() == 2);
    }

    @Test
    public void testFindOrCreateSave() throws DaoRuntimeException, OihPersistenceException, ConfigurationException,
            NamingException, RepositoryException, ClassNotFoundException {
        // populate Run table
        Calendar c = Calendar.getInstance();
        DateTime date = new DateTime(c.getTime());
        Run r = runDao.createRun(date, "prod", "USAmazon", "tag");
        r.setRunID(1L);
        runDao.save(r);

        // verify that the existing Run was returned
        Run result = runDao.findOrCreateSave(date, "prod", "USAmazon", "tag");
        Assert.assertEquals(r.toString(), result.toString());

        // verify that new Run was returned.
        // Ignore it for now, as the test db does not auto_increment
//        result = runDao.findOrCreateSave(date, "test", "USAmazon", "tag");
//        Assert.assertNotSame(r, result);
//        Assert.assertEquals("test", result.getDomain());
//        Assert.assertEquals("USAmazon", result.getRealm());
//        Assert.assertEquals("tag", result.getTag());
    }
}
