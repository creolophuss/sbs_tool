package com.amazon.oih.dao.g2s2;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.codehaus.jackson.type.TypeReference;
import org.jmock.Expectations;
import org.jmock.Mockery;
import org.jmock.integration.junit4.JUnit4Mockery;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import amazon.iop.metadata.cache.QueryCache;
import amazon.iop.metadata.cache.impl.ConcurrentQueryCache;
import amazon.iop.metadata.g2s2.client.G2S2RepositoryClient;
import amazon.iop.metadata.g2s2.client.Metadatum;
import amazon.iop.metadata.g2s2.client.cache.CachingClient;
import amazon.iop.metadata.g2s2.client.impl.MetadatumImpl;
import amazon.iop.metadata.g2s2.schema.G2S2CoreFields;
import amazon.iop.metadata.g2s2.schema.G2S2CoreTables;
import amazon.platform.config.AppConfig;

import com.amazon.ion.IonStruct;
import com.amazon.ion.IonSystem;
import com.amazon.ion.IonValue;
import com.amazon.ion.system.IonSystemBuilder;
import com.amazon.oih.dao.g2s2.G2S2AppConfigsReadonlyDaoImpl.G2S2RepositoryClientHolder;
import com.amazon.oih.dao.scopemapping.OihScopeMapping;

/**
 * mock data:
 * test app config:
 * {
 *     app_config_override_hierarchy:global,
 *     app_config_name:OIH,
 *     app_config_domain:test,
 *     app_config_realm:USAmazon,
 *     app_config_key:ScopeMapping,
 *     app_config:[{scope:"AMAZON_US",
 *                  iogs:[1,2],
 *                  marketplaces:[1,4861],
 *                  primaryIogId:1,
 *                  primaryMarketplaceId:1,
 *                  disabledIogs:[],
 *                  disabledMarketplaces:[]
 *                  }
 *                ],
 *     stage_version:"OIHDevo-209",
 *     audit_info:untrusted::{created_by:yuliang,creation_date:2012-08-01T11:57:48.172-00:00,merged_from:\"OIH2012-08-0104:57:45.0600\"},
 *     table_name:app_configs
 *  }
 *  
 *  test stage version label : OIHDevo
 *  test stage version : OIHDevo-209
 *  {
 *      table_name:stage_version_labels,
 *      stage_version_label:OIHDevo,
 *      is_history_tracked:true,
 *      stage_version:"OIHDevo-209",
 *      timestamp:2012-08-01T11:57:56.497-00:00,
 *      previous_history_label:'OIHDevo-201'
 *  }
 *  
 *  {
 *      table_name:stage_versions,
 *      stage_version:"OIHDevo-209",
 *      parent:"OIHDevo-208",
 *      merge_from:"OIH2012-08-0104:57:45.0600",
 *      state:IMMUTABLE,
 *      included_metadata_num:3
 *  }
 */
public class G2S2AppConfigsReadonlyDaoTest {
	private Mockery context;
	private G2S2RepositoryClient mockG2S2RepositoryClient;
	private G2S2ClientConfigs g2s2ClientConfigs;
    private G2S2AppConfigsReadonlyDao readonlyDao;
    protected static final IonSystem ios = IonSystemBuilder.standard().build();
    
	private static <T> List<T> asList(Class<T> elementType, T... elements) {
		List<T> list = new ArrayList<T>(elements.length);
		for (T element : elements) {
			list.add(element);
		}
		return list;
	}
	
	@BeforeClass
	public static void setUpBeforeClass(){
		String args[] = new String[] {
				"--JARConfigFile=./tst/testBrazilConfig.jar", "--domain=test",
				"--realm=USAmazon", "--override=TestBrazilConfig.cfg" };
		if(AppConfig.isInitialized())
			AppConfig.destroy();
		AppConfig.initialize("someapp", "someappgroup", args);
	}
	
	@Before
	public void setUp() throws Exception{

		context = new JUnit4Mockery();
		mockG2S2RepositoryClient = context.mock(G2S2RepositoryClient.class);
		g2s2ClientConfigs = new G2S2ClientConfigs();
		g2s2ClientConfigs.setG2s2StageVersionLabel("OIHDevo");
		g2s2ClientConfigs.setDomain("test");
		g2s2ClientConfigs.setRealm("USAmazon");
		//G2S2ClientFactory.setReadonlyClient(mockG2S2RepositoryClient);
		G2S2AppConfigsReadonlyDaoImpl.usingMockedG2S2Repository = true;
		G2S2AppConfigsReadonlyDaoImpl.G2S2RepositoryClientHolder.repositoryClient = mockG2S2RepositoryClient;
        QueryCache<Object, Object> cache = new ConcurrentQueryCache<Object, Object>();
        cache.setMaxQuestions(5000);
        cache.setMaxAnswers(5000);
        G2S2AppConfigsReadonlyDaoImpl.G2S2RepositoryClientHolder.repositoryClientWithCache = new CachingClient(G2S2RepositoryClientHolder.repositoryClient, cache);
        mockStageVersion();
	}

    private void mockStageVersion(){
        final Map<String, String> keys = new HashMap<String, String>();
        keys.put(G2S2Constants.STAGE_VERSION_LABEL,
                g2s2ClientConfigs.getG2s2StageVersionLabel());
        IonValue ionStruct = ios.singleValue(
                        "{table_name:stage_version_labels,stage_version_label:OIHDevo,is_history_tracked:true,stage_version:\"OIHDevo-209\",timestamp:2012-08-01T11:57:56.497-00:00,previous_history_label:'OIHDevo-201'}");
        final Metadatum stageVersionLabelMetadatum = new MetadatumImpl(
                G2S2Constants.STAGE_VERSION_TABLE, keys, (IonStruct) ionStruct);
        final  Metadatum stageVersionMetadatum = new MetadatumImpl(G2S2CoreTables.STAGE_VERSIONS,Collections.<String, String>singletonMap(G2S2CoreFields.STAGE_VERSION, "OIHDevo-209"),
                (IonStruct)ios.singleValue("{table_name:stage_versions,stage_version:\"OIHDevo-209\",parent:\"OIHDevo-208\",merge_from:\"OIH2012-08-0104:57:45.0600\",state:IMMUTABLE,included_metadata_num:3}"));
        context.checking(new Expectations() {
            {
                atLeast(0).of(mockG2S2RepositoryClient).get(
                        G2S2Constants.STAGE_VERSION_TABLE, keys);will(returnValue(asList(Metadatum.class, stageVersionLabelMetadatum).iterator()));
                atLeast(0).of(mockG2S2RepositoryClient).get(
                        G2S2Constants.STAGE_VERSION_TABLE, keys, null, null);will(returnValue(asList(Metadatum.class, stageVersionLabelMetadatum).iterator()));
                        
                atLeast(0).of(mockG2S2RepositoryClient).get(G2S2CoreTables.STAGE_VERSIONS, Collections.<String, String>singletonMap(
                                G2S2CoreFields.STAGE_VERSION, "OIHDevo-209"));will(returnValue(asList(Metadatum.class,stageVersionMetadatum).iterator()));
   
            }
        });
        readonlyDao = new G2S2AppConfigsReadonlyDaoImpl();
    }

	@After
	public void tearDown() throws Exception {
	    context.assertIsSatisfied();
	}
	
	@Test
	public void testGetAppConfig() throws Exception {
        
        //{app_config_realm:"USAmazon",app_config_domain:"test",app_config_name:"OIH",stage_version:"OIHDevo-209",app_config_override_hierarchy:"global",app_config_key:"ScopeMapping"}
        final Map<String,String> keys = new HashMap<String,String>();
        keys.put(G2S2Constants.APP_CONFIG_REALM, g2s2ClientConfigs.getRealm());
        keys.put(G2S2Constants.APP_CONFIG_DOMAIN,g2s2ClientConfigs.getDomain());
        keys.put(G2S2Constants.APP_CONFIG_NAME,G2S2Constants.APP_CONFIG_NAME_VALUE);
        keys.put(G2S2Constants.STAGE_VERSION, readonlyDao.findLatestStageVersionFromG2S2(false));
        keys.put(G2S2Constants.APP_CONFIG_OVERRIDE_HIERARCHY,G2S2Constants.APP_CONFIG_OVERRIDE_HIERARCHY_VALUE);
        keys.put(G2S2Constants.APP_CONFIG_KEY,"ScopeMapping");

        IonValue ionStruct = ios.singleValue(
                        "{app_config_override_hierarchy:global,app_config_name:OIH,app_config_domain:test,app_config_realm:USAmazon,app_config_key:ScopeMapping,app_config:[{scope:\"AMAZON_US\",iogs:[1,2],marketplaces:[1,4861],primaryIogId:1,primaryMarketplaceId:1,disabledIogs:[],disabledMarketplaces:[]}],stage_version:\"OIHDevo-209\",audit_info:untrusted::{created_by:yuliang,creation_date:2012-08-01T11:57:48.172-00:00,merged_from:\"OIH2012-08-0104:57:45.0600\"},table_name:app_configs}");
        final Metadatum scopeMappingMetadatum = new MetadatumImpl(
                G2S2Constants.STAGE_VERSION_TABLE, keys, (IonStruct) ionStruct);
        context.checking(new Expectations() {
            {
                exactly(1).of(mockG2S2RepositoryClient).get(G2S2Constants.APP_CONFIGS_TABLE, keys);
                will(returnValue(asList(Metadatum.class, scopeMappingMetadatum).iterator()));
                exactly(1).of(mockG2S2RepositoryClient).get(G2S2Constants.APP_CONFIGS_TABLE, keys,null,null);
                will(returnValue(asList(Metadatum.class, scopeMappingMetadatum).iterator()));
            }
        });
		
        List scopeMappings =readonlyDao.getAppConfig("ScopeMapping", List.class, g2s2ClientConfigs.getRealm(),g2s2ClientConfigs.getDomain(),true);
        checkScopeMappings(scopeMappings);
        
        OihScopeMapping[] oihScopeMappings = readonlyDao.getAppConfig("ScopeMapping", OihScopeMapping[].class, g2s2ClientConfigs.getRealm(),g2s2ClientConfigs.getDomain(),false);
        checkScopeMappings(oihScopeMappings);
        
        Object[] objects = readonlyDao.getAppConfig("ScopeMapping", Object[].class, g2s2ClientConfigs.getRealm(),g2s2ClientConfigs.getDomain(),false);
        scopeMappings = new ArrayList();
        for (Object object : objects) {
            Assert.assertNotNull(object);
            Assert.assertTrue(Map.class.isAssignableFrom(object.getClass()));
            scopeMappings.add(object);
        }
        checkScopeMappings(scopeMappings);
        
        Object object = readonlyDao.getAppConfig("ScopeMapping", Object.class, g2s2ClientConfigs.getRealm(),g2s2ClientConfigs.getDomain(),false);
        Assert.assertNotNull(object);
        Assert.assertTrue(List.class.isAssignableFrom(object.getClass()));
        checkScopeMappings((List)object);
        
        scopeMappings = readonlyDao.getAppConfig("ScopeMapping", List.class, g2s2ClientConfigs.getRealm(),g2s2ClientConfigs.getDomain(),false);
        checkScopeMappings(scopeMappings);
	}
	
	public void testGetAppConfig_NotExistAppConfigKeyWithCache() throws Exception {
        
        //{app_config_realm:"USAmazon",app_config_domain:"test",app_config_name:"OIH",stage_version:"OIHDevo-209",app_config_override_hierarchy:"global",app_config_key:"ScopeMapping"}
        final Map<String,String> keys = new HashMap<String,String>();
        keys.put(G2S2Constants.APP_CONFIG_REALM, g2s2ClientConfigs.getRealm());
        keys.put(G2S2Constants.APP_CONFIG_DOMAIN,g2s2ClientConfigs.getDomain());
        keys.put(G2S2Constants.APP_CONFIG_NAME,G2S2Constants.APP_CONFIG_NAME_VALUE);
        keys.put(G2S2Constants.STAGE_VERSION, readonlyDao.findLatestStageVersionFromG2S2(false));
        keys.put(G2S2Constants.APP_CONFIG_OVERRIDE_HIERARCHY,G2S2Constants.APP_CONFIG_OVERRIDE_HIERARCHY_VALUE);
        keys.put(G2S2Constants.APP_CONFIG_KEY,"ScopeMapping1");

        context.checking(new Expectations() {
            {
            	never(mockG2S2RepositoryClient).get(G2S2Constants.APP_CONFIGS_TABLE, keys);
                will(returnValue(asList(Metadatum.class).iterator()));
                one(mockG2S2RepositoryClient).get(G2S2Constants.APP_CONFIGS_TABLE, keys,null,null);
                will(returnValue(asList(Metadatum.class).iterator()));
            }
        });
		
        List scopeMappings = readonlyDao.getAppConfig("ScopeMapping1", List.class, g2s2ClientConfigs.getRealm(),g2s2ClientConfigs.getDomain(),false);
        Assert.assertTrue(scopeMappings == null);
	}

	public void testGetAppConfig_NotExistAppConfigKeyWithOutCache() throws Exception {
        
        //{app_config_realm:"USAmazon",app_config_domain:"test",app_config_name:"OIH",stage_version:"OIHDevo-209",app_config_override_hierarchy:"global",app_config_key:"ScopeMapping"}
        final Map<String,String> keys = new HashMap<String,String>();
        keys.put(G2S2Constants.APP_CONFIG_REALM, g2s2ClientConfigs.getRealm());
        keys.put(G2S2Constants.APP_CONFIG_DOMAIN,g2s2ClientConfigs.getDomain());
        keys.put(G2S2Constants.APP_CONFIG_NAME,G2S2Constants.APP_CONFIG_NAME_VALUE);
        keys.put(G2S2Constants.STAGE_VERSION, readonlyDao.findLatestStageVersionFromG2S2(false));
        keys.put(G2S2Constants.APP_CONFIG_OVERRIDE_HIERARCHY,G2S2Constants.APP_CONFIG_OVERRIDE_HIERARCHY_VALUE);
        keys.put(G2S2Constants.APP_CONFIG_KEY,"ScopeMapping1");

        context.checking(new Expectations() {
            {
            	one(mockG2S2RepositoryClient).get(G2S2Constants.APP_CONFIGS_TABLE, keys);
                will(returnValue(asList(Metadatum.class).iterator()));
                never(mockG2S2RepositoryClient).get(G2S2Constants.APP_CONFIGS_TABLE, keys,null,null);
                will(returnValue(asList(Metadatum.class).iterator()));
            }
        });
		
        List scopeMappings = readonlyDao.getAppConfig("ScopeMapping1", List.class, g2s2ClientConfigs.getRealm(),g2s2ClientConfigs.getDomain(),true);
        Assert.assertTrue(scopeMappings == null);
	}
	
	@Test
	public void testGetAppConfigList() throws Exception {
        //{app_config_realm:"USAmazon",app_config_domain:"test",app_config_name:"OIH",stage_version:"OIHDevo-209",app_config_override_hierarchy:"global",app_config_key:"ScopeMapping"}
        final Map<String,String> keys = new HashMap<String,String>();
        keys.put(G2S2Constants.APP_CONFIG_REALM, g2s2ClientConfigs.getRealm());
        keys.put(G2S2Constants.APP_CONFIG_DOMAIN,g2s2ClientConfigs.getDomain());
        keys.put(G2S2Constants.APP_CONFIG_NAME,G2S2Constants.APP_CONFIG_NAME_VALUE);
        keys.put(G2S2Constants.STAGE_VERSION, readonlyDao.findLatestStageVersionFromG2S2(false));
        keys.put(G2S2Constants.APP_CONFIG_OVERRIDE_HIERARCHY,G2S2Constants.APP_CONFIG_OVERRIDE_HIERARCHY_VALUE);
        keys.put(G2S2Constants.APP_CONFIG_KEY,"ScopeMapping");

        IonValue ionStruct = ios.singleValue(
                        "{app_config_override_hierarchy:global,app_config_name:OIH,app_config_domain:test,app_config_realm:USAmazon,app_config_key:ScopeMapping,app_config:[{scope:\"AMAZON_US\",iogs:[1,2],marketplaces:[1,4861],primaryIogId:1,primaryMarketplaceId:1,disabledIogs:[],disabledMarketplaces:[]}],stage_version:\"OIHDevo-209\",audit_info:untrusted::{created_by:yuliang,creation_date:2012-08-01T11:57:48.172-00:00,merged_from:\"OIH2012-08-0104:57:45.0600\"},table_name:app_configs}");
        final Metadatum scopeMappingMetadatum = new MetadatumImpl(
                G2S2Constants.STAGE_VERSION_TABLE, keys, (IonStruct) ionStruct);
        context.checking(new Expectations() {
            {
                one(mockG2S2RepositoryClient).get(G2S2Constants.APP_CONFIGS_TABLE, keys);
                will(returnValue(asList(Metadatum.class, scopeMappingMetadatum).iterator()));
                one(mockG2S2RepositoryClient).get(G2S2Constants.APP_CONFIGS_TABLE, keys,null,null);
                will(returnValue(asList(Metadatum.class, scopeMappingMetadatum).iterator()));
            }
        });
        
        List scopeMappings = readonlyDao.getAppConfigList("ScopeMapping", HashMap.class, g2s2ClientConfigs.getRealm(),g2s2ClientConfigs.getDomain(),true);
        checkScopeMappings(scopeMappings);
        scopeMappings = readonlyDao.getAppConfigList("ScopeMapping", HashMap.class, g2s2ClientConfigs.getRealm(),g2s2ClientConfigs.getDomain(),false);
        checkScopeMappings(scopeMappings);
        
        scopeMappings = readonlyDao.getAppConfigList("ScopeMapping", Object.class, g2s2ClientConfigs.getRealm(),g2s2ClientConfigs.getDomain(),false);
        checkScopeMappings(scopeMappings);
        
        List<OihScopeMapping> oihScopeMappings = readonlyDao.getAppConfigList("ScopeMapping", OihScopeMapping.class, g2s2ClientConfigs.getRealm(),g2s2ClientConfigs.getDomain(),false);
        checkScopeMappings((OihScopeMapping[]) oihScopeMappings.toArray(new OihScopeMapping[oihScopeMappings.size()]));
        
	}
	
	
	@Test
	public void testGetAppConfig_WithConfigKeyAnnotation() throws Exception {
        
        //{app_config_realm:"USAmazon",app_config_domain:"test",app_config_name:"OIH",stage_version:"OIHDevo-209",app_config_override_hierarchy:"global",app_config_key:"ScopeMapping"}
        final Map<String,String> keys = new HashMap<String,String>();
        keys.put(G2S2Constants.APP_CONFIG_REALM, g2s2ClientConfigs.getRealm());
        keys.put(G2S2Constants.APP_CONFIG_DOMAIN,g2s2ClientConfigs.getDomain());
        keys.put(G2S2Constants.APP_CONFIG_NAME,G2S2Constants.APP_CONFIG_NAME_VALUE);
        keys.put(G2S2Constants.STAGE_VERSION, readonlyDao.findLatestStageVersionFromG2S2(false));
        keys.put(G2S2Constants.APP_CONFIG_OVERRIDE_HIERARCHY,G2S2Constants.APP_CONFIG_OVERRIDE_HIERARCHY_VALUE);
        keys.put(G2S2Constants.APP_CONFIG_KEY,"ScopeMapping");

        IonValue ionStruct = ios.singleValue(
                        "{app_config_override_hierarchy:global,app_config_name:OIH,app_config_domain:test,app_config_realm:USAmazon,app_config_key:ScopeMapping,app_config:[{scope:\"AMAZON_US\",iogs:[1,2],marketplaces:[1,4861],primaryIogId:1,primaryMarketplaceId:1,disabledIogs:[],disabledMarketplaces:[]}],stage_version:\"OIHDevo-209\",audit_info:untrusted::{created_by:yuliang,creation_date:2012-08-01T11:57:48.172-00:00,merged_from:\"OIH2012-08-0104:57:45.0600\"},table_name:app_configs}");
        final Metadatum scopeMappingMetadatum = new MetadatumImpl(
                G2S2Constants.STAGE_VERSION_TABLE, keys, (IonStruct) ionStruct);
        context.checking(new Expectations() {
            {
                one(mockG2S2RepositoryClient).get(G2S2Constants.APP_CONFIGS_TABLE, keys);
                will(returnValue(asList(Metadatum.class, scopeMappingMetadatum).iterator()));
                one(mockG2S2RepositoryClient).get(G2S2Constants.APP_CONFIGS_TABLE, keys,null,null);
                will(returnValue(asList(Metadatum.class, scopeMappingMetadatum).iterator()));
            }
        });
        List<OihScopeMapping> scopeMappings = readonlyDao.getAppConfigList(OihScopeMapping.class , g2s2ClientConfigs.getRealm(),g2s2ClientConfigs.getDomain(),true);
        scopeMappings = readonlyDao.getAppConfigList(OihScopeMapping.class, g2s2ClientConfigs.getRealm(),g2s2ClientConfigs.getDomain(),false);
	}

	public void testGetAppConfigList_NotExistAppConfigKeyWithOutCache() throws Exception {
        
        //{app_config_realm:"USAmazon",app_config_domain:"test",app_config_name:"OIH",stage_version:"OIHDevo-209",app_config_override_hierarchy:"global",app_config_key:"ScopeMapping"}
        final Map<String,String> keys = new HashMap<String,String>();
        keys.put(G2S2Constants.APP_CONFIG_REALM, g2s2ClientConfigs.getRealm());
        keys.put(G2S2Constants.APP_CONFIG_DOMAIN,g2s2ClientConfigs.getDomain());
        keys.put(G2S2Constants.APP_CONFIG_NAME,G2S2Constants.APP_CONFIG_NAME_VALUE);
        keys.put(G2S2Constants.STAGE_VERSION, readonlyDao.findLatestStageVersionFromG2S2(false));
        keys.put(G2S2Constants.APP_CONFIG_OVERRIDE_HIERARCHY,G2S2Constants.APP_CONFIG_OVERRIDE_HIERARCHY_VALUE);
        keys.put(G2S2Constants.APP_CONFIG_KEY,"ScopeMapping1");

        context.checking(new Expectations() {
            {
            	one(mockG2S2RepositoryClient).get(G2S2Constants.APP_CONFIGS_TABLE, keys);
                will(returnValue(asList(Metadatum.class).iterator()));
                never(mockG2S2RepositoryClient).get(G2S2Constants.APP_CONFIGS_TABLE, keys,null,null);
                will(returnValue(asList(Metadatum.class).iterator()));
            }
        });
        
        List scopeMappings = readonlyDao.getAppConfigList("ScopeMapping1", HashMap.class, g2s2ClientConfigs.getRealm(),g2s2ClientConfigs.getDomain(),true);
        Assert.assertTrue(scopeMappings == null);
        
	}
	public void testGetAppConfigList_NotExistAppConfigKeyWithCache() throws Exception {
        
        final Map<String,String> keys = new HashMap<String,String>();
        keys.put(G2S2Constants.APP_CONFIG_REALM, g2s2ClientConfigs.getRealm());
        keys.put(G2S2Constants.APP_CONFIG_DOMAIN,g2s2ClientConfigs.getDomain());
        keys.put(G2S2Constants.APP_CONFIG_NAME,G2S2Constants.APP_CONFIG_NAME_VALUE);
        keys.put(G2S2Constants.STAGE_VERSION, readonlyDao.findLatestStageVersionFromG2S2(false));
        keys.put(G2S2Constants.APP_CONFIG_OVERRIDE_HIERARCHY,G2S2Constants.APP_CONFIG_OVERRIDE_HIERARCHY_VALUE);
        keys.put(G2S2Constants.APP_CONFIG_KEY,"ScopeMapping1");

        context.checking(new Expectations() {
            {
            	never(mockG2S2RepositoryClient).get(G2S2Constants.APP_CONFIGS_TABLE, keys);
                will(returnValue(asList(Metadatum.class).iterator()));
                one(mockG2S2RepositoryClient).get(G2S2Constants.APP_CONFIGS_TABLE, keys,null,null);
                will(returnValue(asList(Metadatum.class).iterator()));
            }
        });
        
        List scopeMappings = readonlyDao.getAppConfigList("ScopeMapping1", HashMap.class, g2s2ClientConfigs.getRealm(),g2s2ClientConfigs.getDomain(),false);
        Assert.assertTrue(scopeMappings == null);
        
	}

	@Test
    public void testFindLatestStageVersionFromG2S2() throws Exception {
		Assert.assertEquals("OIHDevo-209",
				readonlyDao.findLatestStageVersionFromG2S2(false));
		Assert.assertEquals("OIHDevo-209",
                readonlyDao.findLatestStageVersionFromG2S2(true));
		context.assertIsSatisfied();
	}

	@Test
	public void testQueryAppConfig(){
        final Map<String,String> keys = new HashMap<String,String>();
        keys.put(G2S2Constants.APP_CONFIG_NAME,G2S2Constants.APP_CONFIG_NAME_VALUE);
        keys.put(G2S2Constants.STAGE_VERSION, readonlyDao.findLatestStageVersionFromG2S2(false));
        keys.put(G2S2Constants.APP_CONFIG_OVERRIDE_HIERARCHY,G2S2Constants.APP_CONFIG_OVERRIDE_HIERARCHY_VALUE);
        keys.put(G2S2Constants.APP_CONFIG_KEY,"ScopeMapping");

        IonValue ionStruct = ios.singleValue(
                        "{app_config_override_hierarchy:global,app_config_name:OIH,app_config_domain:test,app_config_realm:USAmazon,app_config_key:ScopeMapping,app_config:[{scope:\"AMAZON_US\",iogs:[1,2],marketplaces:[1,4861],primaryIogId:1,primaryMarketplaceId:1,disabledIogs:[],disabledMarketplaces:[]}],stage_version:\"OIHDevo-209\",audit_info:untrusted::{created_by:yuliang,creation_date:2012-08-01T11:57:48.172-00:00,merged_from:\"OIH2012-08-0104:57:45.0600\"},table_name:app_configs}");
        final Metadatum scopeMappingMetadatum = new MetadatumImpl(
                G2S2Constants.STAGE_VERSION_TABLE, keys, (IonStruct) ionStruct);
        context.checking(new Expectations() {
            {
                exactly(1).of(mockG2S2RepositoryClient).get(G2S2Constants.APP_CONFIGS_TABLE, keys);
                will(returnValue(asList(Metadatum.class, scopeMappingMetadatum).iterator()));
            }
        });
        
        List<AppConfigInfo<OihScopeMapping>> appConfigInfos = readonlyDao.queryAppConfig("ScopeMapping", OihScopeMapping.class);
        Assert.assertNotNull(appConfigInfos);
        Assert.assertEquals(1, appConfigInfos.size());
        checkAppConfigInfo(appConfigInfos.get(0));
	}
	
	private void checkAppConfigInfo(AppConfigInfo<OihScopeMapping> appConfigInfo) {
	    Assert.assertEquals("USAmazon", appConfigInfo.getRealm());
	    Assert.assertEquals("test", appConfigInfo.getDomain());
	    Assert.assertEquals("ScopeMapping", appConfigInfo.getKey());
	    Assert.assertNotNull(appConfigInfo.getConfigContent());
	    OihScopeMapping oihScopeMapping = appConfigInfo.getConfigContent();
	    checkScopeMappings(new OihScopeMapping[]{oihScopeMapping});	    
    }

    @Test
	public void testQueryAppConfigWithTypeReference(){
        final Map<String,String> keys = new HashMap<String,String>();
        keys.put(G2S2Constants.APP_CONFIG_NAME,G2S2Constants.APP_CONFIG_NAME_VALUE);
        keys.put(G2S2Constants.STAGE_VERSION, readonlyDao.findLatestStageVersionFromG2S2(false));
        keys.put(G2S2Constants.APP_CONFIG_OVERRIDE_HIERARCHY,G2S2Constants.APP_CONFIG_OVERRIDE_HIERARCHY_VALUE);
        keys.put(G2S2Constants.APP_CONFIG_KEY,"ScopeMapping");

        IonValue ionStruct = ios.singleValue(
                        "{app_config_override_hierarchy:global,app_config_name:OIH,app_config_domain:test,app_config_realm:USAmazon,app_config_key:ScopeMapping,app_config:[{scope:\"AMAZON_US\",iogs:[1,2],marketplaces:[1,4861],primaryIogId:1,primaryMarketplaceId:1,disabledIogs:[],disabledMarketplaces:[]}],stage_version:\"OIHDevo-209\",audit_info:untrusted::{created_by:yuliang,creation_date:2012-08-01T11:57:48.172-00:00,merged_from:\"OIH2012-08-0104:57:45.0600\"},table_name:app_configs}");
        final Metadatum scopeMappingMetadatum = new MetadatumImpl(
                G2S2Constants.STAGE_VERSION_TABLE, keys, (IonStruct) ionStruct);
        context.checking(new Expectations() {
            {
                exactly(1).of(mockG2S2RepositoryClient).get(G2S2Constants.APP_CONFIGS_TABLE, keys);
                will(returnValue(asList(Metadatum.class, scopeMappingMetadatum).iterator()));
            }
        });
        
        List<AppConfigInfo<List<OihScopeMapping>>> appConfigInfos = readonlyDao.queryAppConfig("ScopeMapping", new TypeReference<List<OihScopeMapping>>(){});
        Assert.assertNotNull(appConfigInfos);
        Assert.assertEquals(1, appConfigInfos.size());
        Assert.assertNotNull(appConfigInfos.get(0));
        
        AppConfigInfo<List<OihScopeMapping>> scopeMappingList = appConfigInfos.get(0);
        
        Assert.assertEquals("USAmazon", scopeMappingList.getRealm());
        Assert.assertEquals("test", scopeMappingList.getDomain());
        Assert.assertEquals("ScopeMapping", scopeMappingList.getKey());
        
        checkScopeMappings(scopeMappingList.getConfigContent().toArray(new OihScopeMapping[1]));
	}
	
	private void checkScopeMappings(OihScopeMapping[] scopeMappings){
	    Assert.assertNotNull(scopeMappings);
	    for (OihScopeMapping oihScopeMapping : scopeMappings) {
            Assert.assertNotNull(oihScopeMapping);
            Assert.assertEquals("AMAZON_US", oihScopeMapping.getScope());
            
            Assert.assertEquals(2, oihScopeMapping.getIogs().size());
            Assert.assertEquals(asList(Long.class, 1L, 2L), oihScopeMapping.getIogs());
            
            Assert.assertEquals(asList(Long.class, 1L, 4861L), oihScopeMapping.getMarketplaces());
            Assert.assertEquals(1, oihScopeMapping.getPrimaryIogId().intValue());
            Assert.assertEquals(1, oihScopeMapping.getPrimaryMarketplaceId().intValue());
            Assert.assertEquals(0, oihScopeMapping.getDisabledIogs().size());
            Assert.assertEquals(0, oihScopeMapping.getDisabledMarketplaces().size());
        }
	}
	
    private void checkScopeMappings(List<Map> scopeMappings) {
        Assert.assertNotNull(scopeMappings);
        Assert.assertEquals(1, scopeMappings.size());
        Map scopeMapping = scopeMappings.get(0);
        Assert.assertEquals("AMAZON_US", scopeMapping.get("scope"));
        List<Integer> iogs = (List<Integer>) scopeMapping.get("iogs");
        Assert.assertEquals(2, iogs.size());
        Assert.assertEquals(asList(Integer.class, 1, 2), iogs);

        List<Integer> marketplaces = (List<Integer>) scopeMapping.get("marketplaces");
        Assert.assertEquals(2, marketplaces.size());
        Assert.assertEquals(asList(Integer.class, 1, 4861), marketplaces);

        Integer primaryIog = (Integer) scopeMapping.get("primaryIogId");
        Assert.assertEquals(1, primaryIog.intValue());

        Integer primaryMarketplaceId = (Integer) scopeMapping.get("primaryMarketplaceId");
        Assert.assertEquals(1, primaryMarketplaceId.intValue());

        List<Integer> disabledIogs = (List<Integer>) scopeMapping.get("disabledIogs");
        Assert.assertEquals(0, disabledIogs.size());

        List<Integer> disabledMarketplace = (List<Integer>) scopeMapping.get("disabledMarketplaces");
        Assert.assertEquals(0, disabledMarketplace.size());
    }

}
