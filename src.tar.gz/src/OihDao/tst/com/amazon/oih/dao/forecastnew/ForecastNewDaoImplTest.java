package com.amazon.oih.dao.forecastnew;

import java.util.Date;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.List;
import org.joda.time.DateTime;

import javax.naming.NamingException;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.amazon.carbonado.PersistException;
import com.amazon.carbonado.Repository;
import com.amazon.carbonado.RepositoryException;
import com.amazon.carbonado.Storage;
import com.amazon.oih.dao.exception.DaoRuntimeException;
import com.amazon.oih.dao.exception.OihPersistenceException;
import com.amazon.oih.dao.forecast.ForecastType;
import com.amazon.oih.dao.repository.DaoFactory;
import com.amazon.oih.dao.repository.RepositoryFactory; 
import com.amazon.oih.dao.run.Run;
import com.amazon.oih.dao.run.RunDao;

public class ForecastNewDaoImplTest {
    private static ForecastNewDaoOracleImp dao ;
    private static RunDao runDao;
    private static DateTime dateTime;
    static {
    	 Calendar c = Calendar.getInstance();
    	 dateTime = new DateTime(c.getTime());
    }
    private static String runDomain = "test";
    private static String runRealm = "USAmazon";
    @BeforeClass
    public static void init() throws OihPersistenceException {
        Logger.getRootLogger().setLevel(Level.OFF);
    }
    
    @Before
    public void setup() throws RepositoryException, RepositoryException, DaoRuntimeException, OihPersistenceException {
        // clean up the Run table
        Repository runRepository = RepositoryFactory.getInst().getRepository(Run.class, RepositoryFactory.UNIT_TEST);
        Storage<Run> sf = runRepository.storageFor(Run.class);
        sf.truncate();
        runDao = DaoFactory.getRunDao(RepositoryFactory.UNIT_TEST);
        Run run = runDao.createRun(dateTime, runDomain, runRealm, "");
        runDao.save(run);
        dao = (ForecastNewDaoOracleImp) DaoFactory.getForecastNewOracleDao(RepositoryFactory.UNIT_TEST);
        dao.setRunDaoForRunDateMapper(runDao);   
    }

    @Test
    public void testCreate() throws NamingException, RepositoryException, ClassNotFoundException, DaoRuntimeException, OihPersistenceException {
        long runId = runDao.find(dateTime, runDomain, runRealm).get(0).getRunID();
        Date runDate= runDao.find(dateTime, runDomain, runRealm).get(0).getRunDate().toDate();
        String asin = "0000000000";
        int iog = 1;
        ForecastType type = ForecastType.MEAN;
        double probability = 0.1;
        String realm = "USAmazon";
        List<Double> forecasts = new ArrayList<Double>();
        for (int i=100; i>0; i--){
            forecasts.add(13.4);
        }

        ForecastNewDataBaseObject object =(ForecastNewDataBaseObject) dao.createForecast( runId,  asin,  iog,  type,  probability, forecasts, realm);
        
        Assert.assertEquals(asin, object.getAsin());
        Assert.assertEquals(iog, object.getIog());
        Assert.assertEquals((int)(probability*100), (int)(object.getProbability()*100));
        Assert.assertEquals(realm, object.getRealm());
        Assert.assertEquals(runDate, object.getRunDate());
        Assert.assertEquals((int)(forecasts.get(0)*100), (int)(object.getWeek1()*100));
        

    }

    @Test
    public void testFind() throws OihPersistenceException, NamingException, RepositoryException, ClassNotFoundException {
        long runId = runDao.find(dateTime, runDomain, runRealm).get(0).getRunID();
        Date runDate= runDao.find(dateTime, runDomain, runRealm).get(0).getRunDate().toDate();
        String asin = "0000000001";
        int iog = 1;
        ForecastType type = ForecastType.MEAN;
        double probability = 0.1;
        String realm = "USAmazon";
        List<Double> forecasts = new ArrayList<Double>();
        for (int i=100; i>0; i--){
            forecasts.add(13.4);
        }

        List<ForecastNew> l = new ArrayList<ForecastNew>();

        l.add(dao.createForecast(runId,  asin,  iog,  type,  probability, forecasts, realm));
        l.add(dao.createForecast(runId,  asin,  iog+1,  type,  probability+0.1, forecasts, realm));
        l.add(dao.createForecast(runId,  asin,  iog+2,  type,  probability+0.2, forecasts, realm));
        l.add(dao.createForecast(runId,  asin,  iog+3,  type,  probability+0.3, forecasts, realm));

        // set up test data
        for (ForecastNew it : l) {
            dao.save(it);
        }

        // verify that we can find the data with correct runId, asin and iog.
        
        for (ForecastNew it : l) {
        	ForecastNewDataBaseObject itImp = (ForecastNewDataBaseObject) it;
        	Collection<? extends ForecastNew> forecastobjs = dao.find(runId, it.getAsin(), it.getIog(), itImp.getRealm());
        	ForecastNew forecast = (ForecastNew) Arrays.asList(forecastobjs.toArray()).get(0);
            Assert.assertEquals(it.getAsin(), forecast.getAsin());
            Assert.assertEquals(it.getIog(), forecast.getIog());
            Assert.assertEquals(realm, itImp.getRealm());
            Assert.assertEquals(runDate, itImp.getRunDate());
            Assert.assertEquals((int)(it.getProbability()*10), (int)(forecast.getProbability()*10));
            Assert.assertEquals((int)(it.getWeek1()*10), (int)(forecast.getWeek1()*10));
        }

        // verify that we cannot find the data with wrong run id.
        Collection<? extends ForecastNew> forecastobjs = dao.find(runId, asin, iog+100, realm);
        Assert.assertTrue(forecastobjs == null || forecastobjs.size() == 0);
    }


    @Test
    public void testExists() throws OihPersistenceException, PersistException, NamingException, RepositoryException, ClassNotFoundException {
        long runId = runDao.find(dateTime, runDomain, runRealm).get(0).getRunID();
        String asin = "0000000002";
        int iog = 1;
        ForecastType type = ForecastType.MEAN;
        double probability = 0.1;
        String realm = "USAmazon";
        List<Double> forecasts = new ArrayList<Double>();
        for (int i=100; i>0; i--){
            forecasts.add(13.4);
        }

        // set up test data
        dao.save(dao.createForecast(runId,  asin,  iog,  type,  probability, forecasts, realm));

        // verify that data exists
        Assert.assertTrue(dao.exists(runId, asin, iog, realm));

        // verify that data not exists
        Assert.assertFalse(dao.exists(runId, asin, ++iog, realm));
    }
    
    @Test
    public void testFindOrderByP() throws OihPersistenceException, NamingException, RepositoryException, ClassNotFoundException {
        long runId = runDao.find(dateTime, runDomain, runRealm).get(0).getRunID();
        String asin = "0000000003";
        int iog = 1;
        ForecastType type = ForecastType.MEAN;
        double probability = 0.1;
        String realm = "USAmazon";
        List<Double> forecasts = new ArrayList<Double>();
        for (int i=100; i>0; i--){
            forecasts.add(13.4);
        }

        List<ForecastNew> l = new ArrayList<ForecastNew>();

        l.add(dao.createForecast(runId,  asin,  iog,  type,  probability, forecasts, realm));
        l.add(dao.createForecast(runId,  asin,  iog,  type,  probability+0.3, forecasts, realm));
        l.add(dao.createForecast(runId,  asin,  iog,  type,  probability+0.1, forecasts, realm));
        l.add(dao.createForecast(runId,  asin,  iog,  type,  probability+0.2, forecasts, realm));


        // set up test data
        for (ForecastNew it : l) {
            dao.save(it);
        }

        // verify that we can find the data with correct runId, asin and iog.
        Collection<? extends ForecastNew> forecastobjs = dao.findOrderedByProbability(runId,  asin,  iog,  type, realm);
        Assert.assertTrue(forecastobjs.size()==4);
        for (int i=0; i<forecastobjs.size(); i++){
            ForecastNew forecast =(ForecastNew) Arrays.asList(forecastobjs.toArray()).get(i);
            Assert.assertEquals(i+1, (int) (forecast.getProbability()*10));
        }
    }
    
}
