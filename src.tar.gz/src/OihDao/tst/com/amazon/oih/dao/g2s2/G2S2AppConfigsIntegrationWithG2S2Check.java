package com.amazon.oih.dao.g2s2;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import junit.framework.Assert;

import org.apache.commons.lang.RandomStringUtils;
import org.junit.BeforeClass;
import org.junit.Test;

import amazon.iop.metadata.g2s2.client.Metadatum;
import amazon.iop.metadata.g2s2.schema.G2S2CoreFields;
import amazon.iop.metadata.g2s2.schema.G2S2CoreTables;
import amazon.platform.config.AppConfig;

import com.amazon.oih.dao.g2s2.G2S2AppConfigsReadonlyDaoImpl.G2S2RepositoryClientHolder;
import com.amazon.oih.dao.scopemapping.OihScopeMapping;
/**
 * 
 * not UT, only for checking g2s2 and ION, so the class name not is ended with Test 
 *
 */
public class G2S2AppConfigsIntegrationWithG2S2Check {
    static private G2S2AppConfigsReadWriteDao g2s2AccessLayer;
    static private G2S2AppConfigsReadonlyDao g2s2ReadonlyDao;

    @BeforeClass
    public static void init() {
        String args[] = new String[] {
                            "--JARConfigFile=./tst/testBrazilConfig.jar",
                            "--domain=test",
                            "--realm=USAmazon",
                            "--override=TestBrazilConfig.cfg"
                            };
        if (AppConfig.isInitialized()) {
            AppConfig.destroy();
        }
        AppConfig.initialize("someapp","someappgroup",args);
        g2s2AccessLayer = new G2S2AppConfigsReadWriteDaoImpl();
        g2s2ReadonlyDao = new G2S2AppConfigsReadonlyDaoImpl();
        G2S2AppConfigsReadonlyDaoImpl.G2S2RepositoryClientHolder.initialize();
        G2S2AppConfigsReadWriteDaoImpl.G2S2FullFeatureRepositoryClientHolder.initialize();
    }
    @Test
    public void testGetCofing() {
        @SuppressWarnings("rawtypes")
        List scopeMappings = g2s2AccessLayer.getAppConfig("ScopeMapping", List.class);
        checkScopeMappings(scopeMappings);
        scopeMappings = g2s2AccessLayer.getAppConfigList("ScopeMapping", HashMap.class);
        checkScopeMappings(scopeMappings);
        java.util.Iterator<Metadatum> stageVersion = g2s2AccessLayer.getG2S2InternalRepositoryClient().
        		get(G2S2CoreTables.STAGE_VERSIONS, Collections.singletonMap(G2S2CoreFields.STAGE_VERSION, "OIHDevo-209"));
        System.out.println(stageVersion.next());
    }

    @Test
    @SuppressWarnings("unchecked")
    public void testPrimitiveType() throws Exception {
        List<String> keys = asList(String.class, "Ion.Test.BaseType.Byte", "Ion.Test.BaseType.Integer",
                "Ion.Test.BaseType.Long", "Ion.Test.BaseType.Float", "Ion.Test.BaseType.Double",
                "Ion.Test.BaseType.Boolean", "Ion.Test.BaseType.String", "Ion.Test.BaseType.BigDecimal");
        @SuppressWarnings("rawtypes")
        List<Class> types = asList(Class.class, Byte.class, Integer.class, Long.class, Float.class, Double.class,
                Boolean.class, String.class, BigDecimal.class);
        List<?> values = asList(Object.class, random(Byte.class), random(Integer.class), random(Long.class),
                random(Float.class), random(Double.class), Boolean.TRUE, RandomStringUtils.random(32),
                random(BigDecimal.class));
        G2S2WriteTransaction transaction = null;
        try {
            transaction = g2s2AccessLayer.beginWriteTransacton();
            for (int i = 0; i < keys.size(); i++) {
                g2s2AccessLayer.saveAppConfig(keys.get(i), values.get(i));
            }
            transaction.commit();
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        } finally {
            if (transaction != null) {
                transaction.close();
            }
        }
        for (int i = 0; i < keys.size(); i++) {
            Assert.assertEquals(values.get(i), g2s2AccessLayer.getAppConfig(keys.get(i), types.get(i)));
        }
    }
    
    /**
     * test for saving CollectionType into gs2s
     * @throws Exception
     */
    @SuppressWarnings({
            "unchecked", "rawtypes"
    })
    @Test
    public void testCollectionType() throws Exception {
        List<String> keys = asList(String.class, "Ion.Test.Collection.Set", /*"Ion.Test.Collection.List",*/
                "Ion.Test.Collection.Map");
        List<Class> types = new ArrayList<Class>();

        List<Object> values = new ArrayList<Object>();
        Set<Object> set = new HashSet<Object>();
        set.add(RandomStringUtils.random(32, true, true));
        set.add(random(Long.class));
        set.add(random(Double.class));
        values.add(set);
        types.add(HashSet.class);

        List<Object> list = new ArrayList<Object>();
        list.add(RandomStringUtils.random(32, true, true));
        list.add(random(Long.class));
        list.add(random(Double.class));
        values.add(list);
        types.add(ArrayList.class);

        Map<String, Object> map = new HashMap<String, Object>();
        map.put("key1", RandomStringUtils.random(32, true, true));
        map.put("key2", random(Long.class));
        map.put("key3", random(Double.class));
        values.add(map);
        types.add(HashMap.class);

        G2S2WriteTransaction transaction = null;
        try {
            transaction = g2s2AccessLayer.beginWriteTransacton();
            for (int i = 0; i < keys.size(); i++) {
                g2s2AccessLayer.saveAppConfig(keys.get(i), values.get(i));
            }
            transaction.commit();
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        } finally {
            if (transaction != null) {
                transaction.close();
            }
        }
        for (int i = 0; i < keys.size(); i++) {
            Assert.assertEquals(values.get(i), g2s2AccessLayer.getAppConfig(keys.get(i), types.get(i)));
        }

    }
    @Test
    public void testForUserDefiendType() throws Exception{
        String key = "Ion.Test.UserDefinedType.UserInfo";
        UserInfo value = new UserInfo("Amazon");
        value.setAge(100);
        Map<String,String> features = new HashMap<String,String>();
        features.put("isPrimate", "false");
        features.put("role", "root,admin");
        value.setFeatures(features);
        
        G2S2WriteTransaction transaction = null;
        try {
            transaction = g2s2AccessLayer.beginWriteTransacton();
            g2s2AccessLayer.saveAppConfig(value, AppConfig.getRealm().name(),AppConfig.getDomain());
            transaction.commit();
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        } finally {
            if (transaction != null) {
                transaction.close();
            }
        }
        
        Assert.assertEquals(value, g2s2AccessLayer.getAppConfig(key, UserInfo.class));
        Assert.assertEquals(value, g2s2AccessLayer.getAppConfig(UserInfo.class,AppConfig.getRealm().name(),AppConfig.getDomain(),true));
    }
    
    @Test
    public void testGetConfigList() {
        List<OihScopeMapping> scopeMappings = g2s2ReadonlyDao.getAppConfigList("ScopeMapping", OihScopeMapping.class);
        Assert.assertEquals(15, scopeMappings.size());
        scopeMappings = g2s2ReadonlyDao.getAppConfigList(OihScopeMapping.class, "USAmazon", "default", false);
        Assert.assertEquals(15, scopeMappings.size());
    }

    // primaryMarketplaceId=1, disabledIogs=[], disabledMarketplace=[]}]
    @SuppressWarnings("unchecked")
    private void checkScopeMappings(List<Map> scopeMappings) {
        Assert.assertNotNull(scopeMappings);
        Assert.assertEquals(15, scopeMappings.size());
        Map scopeMapping = scopeMappings.get(0);
        Assert.assertEquals("AMAZON_US", scopeMapping.get("scope"));
        List<Integer> iogs = (List<Integer>) scopeMapping.get("iogs");
        Assert.assertEquals(3, iogs.size());
        Assert.assertEquals(asList(Integer.class, 1, 2, 101), iogs);

        List<Integer> marketplaces = (List<Integer>) scopeMapping.get("marketplaces");
        Assert.assertEquals(2, marketplaces.size());
        Assert.assertEquals(asList(Integer.class, 1, 4861), marketplaces);

        Integer primaryIog = (Integer) scopeMapping.get("primaryIogId");
        Assert.assertEquals(1, primaryIog.intValue());

        Integer primaryMarketplaceId = (Integer) scopeMapping.get("primaryMarketplaceId");
        Assert.assertEquals(1, primaryMarketplaceId.intValue());

        List<Integer> disabledIogs = (List<Integer>) scopeMapping.get("disabledIogs");
        Assert.assertEquals(0, disabledIogs.size());

        List<Integer> disabledMarketplace = (List<Integer>) scopeMapping.get("disabledMarketplaces");
        Assert.assertEquals(0, disabledMarketplace.size());
    }

    private <T> List<T> asList(Class<T> elementType, T... elements) {
        List<T> list = new ArrayList<T>(elements.length);
        for (T element : elements) {
            list.add(element);
        }
        return list;
    }

    private <T extends Number> T random(Class<T> clazz) {
        if (clazz.equals(Byte.class)) {
            return (T) (new Byte((byte) (Math.random() * Byte.MAX_VALUE)));
        } else if (clazz.equals(Integer.class)) {
            return (T) (new Integer((int) (Math.random() * Integer.MAX_VALUE)));
        } else if (clazz.equals(Long.class)) {
            return (T) (new Long((long) (Math.random() * Long.MAX_VALUE)));
        } else if (clazz.equals(Float.class)) {
            return (T) (new Float((float) (Math.random() * Long.MAX_VALUE)));
        } else if (clazz.equals(Double.class)) {
            return (T) (new Double(Math.random() * Long.MAX_VALUE));
        } else if (clazz.equals(BigDecimal.class)) {
            return (T) (new BigDecimal(Math.random() * Long.MAX_VALUE));
        }
        return null;
    }
    
}
