package com.amazon.oih.dao.repository;

import org.junit.Assert;
import org.junit.Test;

import com.amazon.carbonado.Repository;
import com.amazon.oih.dao.run.Run;


public class RepositoryFactoryTest {
    private RepositoryFactory rf = RepositoryFactory.getInst();
    
    @Test
    public void testGetRepositoryForUnitTest() {
        Repository r = rf.getRepository(Run.class, RepositoryFactory.UNIT_TEST);
        
        Assert.assertTrue((null != r) && "InMemoryRepository".equals(r.getName()));
    }
    
    @Test(expected = IllegalArgumentException.class)
    public void testGetRepositoryWithNullDomain() {
        rf.getRepository(Run.class, null);        
    }
    
    @Test(expected = IllegalArgumentException.class)
    public void testGetRepositoryWithNullClass() {
        rf.getRepository(null, RepositoryFactory.UNIT_TEST);        
    }
}
