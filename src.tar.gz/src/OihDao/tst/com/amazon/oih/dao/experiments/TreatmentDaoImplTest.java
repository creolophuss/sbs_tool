package com.amazon.oih.dao.experiments;

import javax.naming.NamingException;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.amazon.carbonado.ConfigurationException;
import com.amazon.carbonado.Repository;
import com.amazon.carbonado.RepositoryException;
import com.amazon.carbonado.Storage;
import com.amazon.oih.dao.exception.OihPersistenceException;
import com.amazon.oih.dao.repository.DaoFactory;
import com.amazon.oih.dao.repository.RepositoryFactory;

public class TreatmentDaoImplTest {
    TreatmentDao dao = DaoFactory.getTreatmentDao(RepositoryFactory.UNIT_TEST);

    @Before
    public void setUp() throws ConfigurationException, NamingException, RepositoryException, ClassNotFoundException {
        // clean up repository
        Repository r = RepositoryFactory.getInst().getRepository(Treatment.class, RepositoryFactory.UNIT_TEST);
        Storage<Treatment> sf = r.storageFor(Treatment.class);
        sf.truncate();
    }

    @Test
    public void testSimpleCreate() throws OihPersistenceException {
        dao.save(dao.createTreatment(1, 1, 1, "B08262A892"));
        Assert.assertTrue(dao.exists(1, 1, 1, "B08262A892"));
        Assert.assertFalse(dao.exists(1, 1, 1, "B08262A891"));
    }
}
