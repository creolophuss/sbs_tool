package com.amazon.oih.dao.holdingcost;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import junit.framework.Assert;

import org.junit.Before;
import org.junit.Test;

import com.amazon.oih.dao.FakeDAOUtil;

public class HoldingCostDaoTest {

    private final static String realm1 = "USAmazon";
    private final static String realm2 = "GBAmazon";
    private final static String currency = "USD";
    private final static String warehouse1 = "FC1";
    private final static String warehouse2 = "FC2";
    private final static String gl1 = "-1";
    private final static String gl2 = "14";

    private HoldingCostDao dao = null;

    private List<HoldingCost> costs = null;

    private Comparator<HoldingCost> comparator = new Comparator<HoldingCost>() {
        @Override
        public int compare(HoldingCost c1, HoldingCost c2) {
            int result = c1.getRealm().compareTo(c2.getRealm());
            if (result != 0)
                return result;
            result = c1.getGl().compareTo(c2.getGl());
            if (result != 0)
                return result;
            result = c1.getWarehouse().compareTo(c2.getWarehouse());
            if (result != 0)
                return result;
            result = c1.getStartDate().compareTo(c2.getStartDate());
            if (result != 0)
                return result;
            result = c1.getEndDate().compareTo(c2.getEndDate());
            return result;
        }
    };

    @Before
    public void setup() throws Exception {
        dao = FakeDAOUtil.getHoldingCostDao();
        costs = new ArrayList<HoldingCost>();
        costs.add(createHoldingCost("*", gl1, currency, warehouse1, "01-15", "02-15", 0.012));
        costs.add(createHoldingCost(realm1, gl1, currency, warehouse1, "02-15", "03-15", 0.016));
        costs.add(createHoldingCost(realm1, gl1, currency, warehouse1, "03-15", "04-15", 0.018));
        costs.add(createHoldingCost(realm1, gl1, currency, warehouse2, "01-15", "02-15", 0.018));
        costs.add(createHoldingCost(realm1, gl2, currency, warehouse1, "01-15", "02-15", 0.012));
        costs.add(createHoldingCost(realm2, gl1, currency, warehouse1, "01-15", "02-15", 0.018));
        for (HoldingCost cost : costs) {
            dao.save(cost);
        }
    }

    private HoldingCost createHoldingCost(String realm, String gl, String currency, String warehouse, String startDate,
            String endDate, double holdingcost) {
        HoldingCost cost = new HoldingCost();
        cost.setCurrency(currency);
        cost.setRealm(realm);
        cost.setGl(gl);
        cost.setWarehouse(warehouse);
        cost.setStartDate(startDate);
        cost.setEndDate(endDate);
        cost.setHoldingCost(holdingcost);
        return cost;
    }

    @Test
    public void testGetHoldingCosts() throws Exception {
        List<HoldingCost> result = dao.getHoldingCosts(realm1);
        assertList(costs.subList(0, 5), result);
    }

    @Test
    public void testGetHoldingCosts1() throws Exception {
        List<HoldingCost> result = dao.getHoldingCosts(realm1, warehouse2);
        assertList(costs.subList(3, 4), result);
    }

    private void assertList(List<HoldingCost> l1, List<HoldingCost> l2) {
        Assert.assertEquals(l1.size(), l2.size());
        Collections.sort(l1, comparator);
        Collections.sort(l2, comparator);
        for (int i = 0; i < l1.size(); i++) {
            Assert.assertEquals(l1.get(i), l2.get(i));
        }
    }

}
