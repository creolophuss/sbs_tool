package com.amazon.oih.dao.targetInvLevel;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.amazon.oih.dao.exception.OihPersistenceException;
import com.amazon.oih.dao.repository.DaoFactory;
import com.amazon.oih.dao.repository.RepositoryFactory;

public class TargetInventoryLevelMaxOverPeriodDaoImplTest {
    TargetInventoryLevelMaxOverPeriodDao dao = DaoFactory
            .getTargetInventoryLevelMaxOverPeriodDao(RepositoryFactory.UNIT_TEST);

    @Before
    public void setUp() throws OihPersistenceException {
        // clean up repository
        dao.deleteAll();
    }

    @Test
    public void testFind() throws OihPersistenceException {
        long runId = 1L;
        int iog = 3;

        List<TargetInventoryLevelMaxOverPeriod> l = new ArrayList<TargetInventoryLevelMaxOverPeriod>();

        l.add(dao.createTargetInventoryLevelMaxOverPeriod(runId, "0000000000", iog, 12, 4));
        l.add(dao.createTargetInventoryLevelMaxOverPeriod(runId, "00000000A0", iog, 126, 0));
        l.add(dao.createTargetInventoryLevelMaxOverPeriod(runId, "0000000B00", iog, 20000, 1));
        l.add(dao.createTargetInventoryLevelMaxOverPeriod(runId, "000000C000", iog, 30000, 2000));

        // set up test data
        for (TargetInventoryLevelMaxOverPeriod it : l) {
            dao.save(it);
        }

        // verify that we can find the data with correct runId, asin and iog.
        for (TargetInventoryLevelMaxOverPeriod it : l) {
            TargetInventoryLevelMaxOverPeriod object4Retrieve = dao.find(it.getRunID(), it.getAsin(), it.getIog());
            Assert.assertEquals(it.getAsin(), object4Retrieve.getAsin());
            Assert.assertEquals(it.getRunID(), object4Retrieve.getRunID());
            Assert.assertEquals(it.getIog(), object4Retrieve.getIog());
            Assert.assertEquals(it.getTil(), object4Retrieve.getTil());
            Assert.assertEquals(it.getCartonQty(), object4Retrieve.getCartonQty());
        }

        // verify that we cannot find the data with wrong run id.
        Assert.assertNull(dao.find(++runId, "0000000B00", iog));
    }

    @Test
    public void testExists() throws OihPersistenceException {
        long runId = 0L;
        String asin = "0123456789";
        int iog = 1;
        int cartonQty = 2000;

        // set up test data
        dao.save(dao.createTargetInventoryLevelMaxOverPeriod(runId, asin, iog, 30000, cartonQty));

        // verify that data exists
        Assert.assertTrue(dao.exists(runId, asin, iog));

        // verify that data not exists
        Assert.assertFalse(dao.exists(runId, asin, ++iog));
    }
    
    @Test
    public void testCount() throws OihPersistenceException {
        dao.deleteAll();
        long runId = 0L;
        int iog = 1;
        int cartonQty = 2000;
        // set up test data
        dao.save(dao.createTargetInventoryLevelMaxOverPeriod(runId, "ABCDE00001", iog, 1, cartonQty));
        dao.save(dao.createTargetInventoryLevelMaxOverPeriod(runId, "ABCDE00002", iog, 2, cartonQty));
        dao.save(dao.createTargetInventoryLevelMaxOverPeriod(runId, "ABCDE00003", iog, 3, cartonQty));
        dao.save(dao.createTargetInventoryLevelMaxOverPeriod(runId, "ABCDE00004", iog, 4, cartonQty));
        dao.save(dao.createTargetInventoryLevelMaxOverPeriod(1000L, "ABCDE00005", iog, 5, cartonQty));
        
        Integer count = dao.getTotalCountByRunId(0L);
        // verify that data exists
        Assert.assertEquals(4, count.intValue());
    }
    
    @Test
    public void testInvalidDataCount() throws OihPersistenceException {
        dao.deleteAll();
        long runId = 0L;
        int iog = 1;
        int cartonQty = 2000;
        // set up test data
        dao.save(dao.createTargetInventoryLevelMaxOverPeriod(runId, "ABCDE00005", iog, 5, cartonQty));
        dao.save(dao.createTargetInventoryLevelMaxOverPeriod(runId, "ABCDE00006", iog, 6, cartonQty));
        dao.save(dao.createTargetInventoryLevelMaxOverPeriod(runId, "ABCDE00007", iog, -1, cartonQty));
        dao.save(dao.createTargetInventoryLevelMaxOverPeriod(runId, "ABCDE00008", iog, -1, cartonQty));
        dao.save(dao.createTargetInventoryLevelMaxOverPeriod(1000L, "ABCDE00009", iog, -1, cartonQty));
        
        Integer count = dao.getInvalidTILCountByRunId(0L);
        // verify that data exists
        Assert.assertEquals(2, count.intValue());
    }
}
