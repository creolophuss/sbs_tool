package com.amazon.oih.dao.vrdsDisposition;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.naming.NamingException;

import junit.framework.Assert;

import org.junit.Before;
import org.junit.Test;

import com.amazon.carbonado.ConfigurationException;
import com.amazon.carbonado.Repository;
import com.amazon.carbonado.RepositoryException;
import com.amazon.carbonado.Storage;
import com.amazon.oih.dao.exception.DaoRuntimeException;
import com.amazon.oih.dao.exception.OihPersistenceException;
import com.amazon.oih.dao.repository.DaoFactory;
import com.amazon.oih.dao.repository.RepositoryFactory;

public class VRDSDorcInfoDaoImplTest {

    private VRDSDorcInfoDao dao = DaoFactory.getVRDSDorcInfoDao(RepositoryFactory.UNIT_TEST);
    private final static SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

    @Before
    public void setUp() throws ConfigurationException, NamingException, RepositoryException, ClassNotFoundException {
        // clean up repository
        Repository r = RepositoryFactory.getInst().getRepository(VRDSDorcInfo.class, RepositoryFactory.UNIT_TEST);
        Storage<VRDSDorcInfo> sf = r.storageFor(VRDSDorcInfo.class);
        sf.truncate();
    }

    @Test
    public void testSaveAndFind() throws DaoRuntimeException, OihPersistenceException, ParseException {
        // save'em
        dao.save(dao.createVRDSDorcInfo(1L, newDorcInfo("0123456789", 1, 1, 14, "LEX1", 2L, 1, "2010-01-01")));
        dao.save(dao.createVRDSDorcInfo(1L, newDorcInfo("0123456789", 1, 1, 14, "LEX1", 3L, 1, "2010-02-02")));
        dao.save(dao.createVRDSDorcInfo(1L, newDorcInfo("2123456789", 1, 1, 14, "LEX1", 3L, 1, "2010-09-08")));

        // find, expect them to be in descending order of shipment receive date
        List<VRDSDorcInfo> found = dao.find(1L, "0123456789", 1);
        Assert.assertEquals(2, found.size());
        VRDSDorcInfo f = found.get(0);
        Assert.assertTrue(null != f);
        Assert.assertTrue("0123456789".equals(f.getAsin()));
        Assert.assertTrue("2010-02-02".equals(sdf.format(f.getShipmentReceivedDate())));
        f = found.get(1);
        Assert.assertTrue(null != f);
        Assert.assertTrue("0123456789".equals(f.getAsin()));
        Assert.assertTrue("2010-01-01".equals(sdf.format(f.getShipmentReceivedDate())));

        found = dao.find(1L, "2123456789", 1);
        Assert.assertEquals(1, found.size());
        f = found.get(0);
        Assert.assertTrue(null != f);
        Assert.assertTrue("2123456789".equals(f.getAsin()));
        Assert.assertTrue("2010-09-08".equals(sdf.format(f.getShipmentReceivedDate())));
        // foreign currency test
        Assert.assertEquals("USD", f.getForeignCurrencyCode());
        Assert.assertEquals(125.21, f.getCostForeignCurrency());
        Assert.assertEquals(123.45, f.getRefundAmountForeignCurrency());
        Assert.assertEquals(150.21, f.getDistributorCostForeignCurrency());
        Assert.assertEquals(1521.99, f.getDistributorListPriceForeignCurrency());
    }

    @Test
    public void testSaveAndFindInBatch() throws DaoRuntimeException, OihPersistenceException, ParseException {
        // save'em
        List<VRDSDorcInfo> dorcInfos = new ArrayList<VRDSDorcInfo>();
        dorcInfos.add(dao.createVRDSDorcInfo(1L, newDorcInfo("0123456789", 1, 1, 14, "LEX1", 2L, 1, "2010-01-01")));
        dorcInfos.add(dao.createVRDSDorcInfo(1L, newDorcInfo("0123456789", 1, 1, 14, "LEX1", 3L, 1, "2010-02-02")));
        dorcInfos.add(dao.createVRDSDorcInfo(1L, newDorcInfo("2123456789", 1, 1, 14, "LEX1", 3L, 1, "2010-09-08")));
        dao.save(dorcInfos);

        // find, expect them to be in descending order of shipment receive date
        List<VRDSDorcInfo> found = dao.find(1L, "0123456789", 1);
        Assert.assertEquals(2, found.size());
        VRDSDorcInfo f = found.get(0);
        Assert.assertTrue(null != f);
        Assert.assertTrue("0123456789".equals(f.getAsin()));
        Assert.assertTrue("2010-02-02".equals(sdf.format(f.getShipmentReceivedDate())));
        // foreign currency test
        Assert.assertEquals("USD", f.getForeignCurrencyCode());
        Assert.assertEquals(125.21, f.getCostForeignCurrency());
        Assert.assertEquals(123.45, f.getRefundAmountForeignCurrency());
        Assert.assertEquals(150.21, f.getDistributorCostForeignCurrency());
        Assert.assertEquals(1521.99, f.getDistributorListPriceForeignCurrency());
        f = found.get(1);
        Assert.assertTrue(null != f);
        Assert.assertTrue("0123456789".equals(f.getAsin()));
        Assert.assertTrue("2010-01-01".equals(sdf.format(f.getShipmentReceivedDate())));

        found = dao.find(1L, "2123456789", 1);
        Assert.assertEquals(1, found.size());
        f = found.get(0);
        Assert.assertTrue(null != f);
        Assert.assertTrue("2123456789".equals(f.getAsin()));
        Assert.assertTrue("2010-09-08".equals(sdf.format(f.getShipmentReceivedDate())));
    }

    @Test
    public void testExists() throws DaoRuntimeException, OihPersistenceException, ParseException {

        dao.save(dao.createVRDSDorcInfo(1L, newDorcInfo("0123456789", 1, 1, 14, "LEX1", 2L, 1, "2010-02-01")));
        dao.save(dao.createVRDSDorcInfo(1L, newDorcInfo("0123456789", 1, 1, 14, "LEX1", 3L, 1, "2010-03-03")));

        Assert.assertTrue(dao.exists(1L, "0123456789", 1));
        Assert.assertTrue(dao.exists(1L, "0123456789", 1));
    }

    private OIHDorcInfo newDorcInfo(String asin, int iog, int marketplace, int gl, String warehouse, long dsiId,
            int qtyAssigned, String shipmentReceiveDate) throws ParseException {

        OIHDorcInfo retVal = new OIHDorcInfo();
        retVal.asin = asin;
        retVal.iog = iog;
        retVal.marketplaceId = marketplace;
        retVal.qtyReceived = qtyAssigned;
        retVal.qtyAssigned = qtyAssigned;
        retVal.gl = gl;
        retVal.warehouse = warehouse;
        retVal.dsiId = new Long(dsiId);

        // assign some default values to rest of them
        retVal.vendor = "VENDO";
        retVal.baseCurrencyCode = "USD";
        retVal.cost = 0;
        retVal.dispositionType = "RETURN";
        retVal.distributorCost = 0.1;
        retVal.distributorId = "DISTRIBUTOR_ID";
        retVal.distributorListPrice = 0.2;
        retVal.distributorOrderDate = sdf.parse("2010-09-20");
        retVal.distributorOrderId = "DISTRIBUTOR_ORDER_ID";
        retVal.distributorShipmentId = "DISTRIBUTOR_SHIPMENT_ID";
        retVal.dorcId = 2L;
        retVal.orderType = 6L;
        retVal.qtyInUse = 0;
        retVal.qtyReturned = 0;
        retVal.shipmentReceivedDate = sdf.parse(shipmentReceiveDate);
        retVal.refundAmount = 0.0;
        retVal.foreignCurrencyCode = "USD";
        retVal.refundAmountForeignCurrency = 123.45;
        retVal.costForeignCurrency = 125.21;
        retVal.distributorCostForeignCurrency = 150.21;
        retVal.distributorListPriceForeignCurrency = 1521.99;

        return retVal;
    }
}