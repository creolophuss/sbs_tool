package com.amazon.oih.dao.inventorysourcingcost;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.amazon.oih.dao.exception.OihPersistenceException;
import com.amazon.oih.dao.repository.DaoFactory;
import com.amazon.oih.dao.repository.RepositoryFactory;

/**
 * 
 * @author mengzang
 * 
 */
public class InventorySourcingCostDaoTest {
    private static InventorySourcingCostDao dao = DaoFactory.getInventorySourcingCostDao(RepositoryFactory.UNIT_TEST);

    private static long runId = 336611;

    private static String scopeId = "US_AMAZON";

    private static String currency = "USD";

    private static String asin = "ZZZZ008844";

    @Before
    public void init() throws OihPersistenceException {
        Logger.getRootLogger().setLevel(Level.OFF);
        dao.deleteAll();// clear the data from the in-memory session
    }

    @Test
    public void testCreate() throws OihPersistenceException {
        InventorySourcingCost cost = new InventorySourcingCost(runId, asin, scopeId, currency, 9.3);
        dao.save(cost);
        Assert.assertTrue(dao.exists(runId, asin, scopeId));
    }

    @Test
    public void testCreateBatch() throws OihPersistenceException {
        List<InventorySourcingCost> costs = new ArrayList<InventorySourcingCost>();
        String asinStart = "ZZZZ";
        int asinNumber = 118844;
        for (int i = 1; i <= 10000; i++) {
            InventorySourcingCost cost = new InventorySourcingCost(runId, asinStart + (asinNumber + i), scopeId,
                    currency, 9.3 * i);
            costs.add(cost);

        }
        dao.save(costs);

        asinNumber = 118844;
        for (int i = 1; i <= 10000; i++) {
            Assert.assertTrue(dao.exists(runId, asinStart + (asinNumber + i), scopeId));
        }
    }

    @Test
    public void testFindOne() throws OihPersistenceException {
        testCreate();
        Assert.assertNotNull(dao.findOne(runId, asin, scopeId));
    }

    @Test
    public void testFindList() throws OihPersistenceException {
        testCreateBatch();
        List<InventorySourcingCost> costs = new ArrayList<InventorySourcingCost>();
        String asinStart = "ZZZZ";
        int asinNumber = 118844;
        for (int i = 1; i <= 10000; i++) {
            InventorySourcingCost cost = new InventorySourcingCost(runId, asinStart + (asinNumber + i), "TestScope1",
                    currency, 9.3 * i);
            costs.add(cost);
            cost = new InventorySourcingCost(runId, asinStart + (asinNumber + i), "TestScope2", currency, 9.3 * i);
            costs.add(cost);
        }
        dao.save(costs);

        asinNumber = 118844;
        for (int i = 1; i <= 10000; i++) {
            Assert.assertTrue(dao.exists(runId, asinStart + (asinNumber + i), "TestScope1"));
        }

        Assert.assertTrue(6 == dao.findList(runId, Arrays.asList("ZZZZ" + 118845, "ZZZZ" + 118847, "ZZZZ" + 118849),
                Arrays.asList("TestScope1", "TestScope2")).size());
        Assert.assertTrue(3 == dao.findList(runId, Arrays.asList("ZZZZ" + 118845, "ZZZZ" + 118847, "ZZZZ" + 118849),
                Arrays.asList("TestScope1")).size());
        Assert.assertTrue(1 == dao.findList(runId, Arrays.asList("ZZZZ" + 118849), Arrays.asList("TestScope1")).size());
        Assert.assertTrue(2 == dao.findList(runId, Arrays.asList("ZZZZ" + 118849),
                Arrays.asList("TestScope1", "TestScope2")).size());
    }

    @Test
    public void testExist() throws OihPersistenceException {
        testCreate();
        Assert.assertTrue(dao.exists(runId, asin, scopeId));
        Assert.assertFalse(dao.exists(runId, "NOASIN", scopeId));
        Assert.assertFalse(dao.exists(runId, asin, "No_Scope"));
        Assert.assertFalse(dao.exists(new Long(0L), asin, scopeId));

    }

    @Test
    public void testDelete() throws OihPersistenceException {
        testCreate();
        dao.delete(new InventorySourcingCost(runId, asin, scopeId, currency, 9.3));
    }
}
