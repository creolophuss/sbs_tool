package com.amazon.oih.dao.hbase.base;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.hadoop.hbase.KeyValue;
import org.apache.hadoop.hbase.client.Put;
import org.junit.Assert;
import org.junit.Test;

import com.amazon.oih.dao.hbase.base.SubKeyAwareHBaseDaoTest.MultiColumnClass;
import com.google.common.collect.Sets;

public class HBaseDaoImplAdaptorTest {
    private SubKeyAwareHBaseDao<MultiColumnClass> dao4DynamicColumn = new SubKeyAwareHBaseDao<MultiColumnClass>(
            MultiColumnClass.class);
    
    @Test 
    public void testConvert() throws IOException {
        dao4DynamicColumn.columnFamily = "info";
        List<MultiColumnClass> testObjs = obtainTestObjs4DynamicColumnName();
        List<Put> generatedPuts = dao4DynamicColumn.convert(testObjs);
        Map<String, String> valueMap = puts2Map(generatedPuts);
        
        //Except column:Dt, all column will be put into HBase.
        Assert.assertEquals(6, valueMap.size());

        Assert.assertEquals("String1,String11", valueMap.get("SDF1:SDF11.St"));
        Assert.assertEquals("0.11", valueMap.get("SDF1:SDF11.Dt"));
        Assert.assertEquals("", valueMap.get("SDF1:SDF11.Null"));
        Assert.assertEquals("String2,String22", valueMap.get("SDF2:SDF22.St"));
        Assert.assertEquals("0.22", valueMap.get("SDF2:SDF22.Dt"));
        Assert.assertEquals("", valueMap.get("SDF2:SDF22.Null"));
    }
    
    @Test
    public void testProjections() throws IOException {
        dao4DynamicColumn.columnFamily = "info";
        List<MultiColumnClass> testObjs = obtainTestObjs4DynamicColumnName();
        dao4DynamicColumn.setProjections(Sets.newHashSet("St", "Null"));
        List<Put> generatedPuts = dao4DynamicColumn.convert(testObjs);
        Map<String, String> valueMap = puts2Map(generatedPuts);
        
        //Except column:Dt, all column will be put into HBase.
        Assert.assertEquals(4, valueMap.size());

        Assert.assertEquals("String1,String11", valueMap.get("SDF1:SDF11.St"));
        Assert.assertFalse(valueMap.containsKey("SDF1:SDF11.Dt"));
        Assert.assertEquals("", valueMap.get("SDF1:SDF11.Null"));
        Assert.assertEquals("String2,String22", valueMap.get("SDF2:SDF22.St"));
        Assert.assertFalse(valueMap.containsKey("SDF2:SDF22.Dt"));
        Assert.assertEquals("", valueMap.get("SDF2:SDF22.Null"));
        
        dao4DynamicColumn.setProjections(Sets.newHashSet("St", "wrongColumn"));
        try {
            dao4DynamicColumn.convert(testObjs);
        } catch (RuntimeException e){
            Assert.assertTrue(true);
            Assert.assertTrue(e.getMessage().contains("wrongColumn"));
            return;
        }
        //Exception should happen, could not arrive here.
        Assert.assertTrue(false);
    }
    
   private Map<String, String> puts2Map(List<Put> generatedPuts){
        Map<String, String> result = new HashMap<String, String>();
        for (Put p : generatedPuts){
            for (List<KeyValue> kvs : p.getFamilyMap().values()){
                for (KeyValue kv : kvs){
                    result.put(new String(kv.getQualifier()), new String(kv.getValue()));
                }
            }
        }
        return result;
    }
    
    private List<MultiColumnClass> obtainTestObjs4DynamicColumnName() {
        MultiColumnClass testObj1 = new MultiColumnClass();
        testObj1.setAsin("ASIN1");
        testObj1.setIog(1);
        testObj1.setFc("SDF1");
        testObj1.setFc1("SDF11");
        testObj1.setValue(0.11);
        testObj1.setStrValue("String1");
        testObj1.setStrValue2("String11");

        MultiColumnClass testObj2 = new MultiColumnClass();
        testObj2.setAsin("ASIN1");
        testObj2.setIog(1);
        testObj2.setFc("SDF2");
        testObj2.setFc1("SDF22");
        testObj2.setValue(0.22);
        testObj2.setStrValue("String2");
        testObj2.setStrValue2("String22");

        List<MultiColumnClass> result = new ArrayList<MultiColumnClass>();
        result.add(testObj1);
        result.add(testObj2);

        return result;
    }
}
