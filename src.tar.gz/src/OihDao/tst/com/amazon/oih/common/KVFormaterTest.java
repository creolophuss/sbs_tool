package com.amazon.oih.common;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.amazon.oih.costs.VendorFCs;

public class KVFormaterTest {
    @Test
    public void testFormat(){
        KVFormater<VendorFCs> formater = new KVFormater<VendorFCs>(VendorFCs.class);
        List<VendorFCs> formatableList = new ArrayList<VendorFCs>();
        VendorFCs fcNewValue = new VendorFCs();
        fcNewValue.setIog(1l);
        fcNewValue.setWarehouseId("SDF1");
        fcNewValue.setMarketplaceId(1l);
        fcNewValue.setGl(15l);
        fcNewValue.setId("id1");
        fcNewValue.setReceiptCost(1d);
        fcNewValue.setRemovalCost(2d);
        fcNewValue.setHoldingCost(3d);
        fcNewValue.setTransferInCost(4d);
        fcNewValue.setTransferOutCost(5d);
        fcNewValue.setDestroyReturnEstimate(null);
        formatableList.add(fcNewValue);
        
        fcNewValue = new VendorFCs();
        fcNewValue.setIog(1l);
        fcNewValue.setWarehouseId("SDF1");
        fcNewValue.setMarketplaceId(1l);
        fcNewValue.setGl(15l);
        fcNewValue.setId("id2");
        fcNewValue.setReceiptCost(44d);
        formatableList.add(fcNewValue);
        
        String output = formater.formatForEdit(formatableList);
        System.out.println("output\n" + output);
        
        VendorFCs orgValue1 = new VendorFCs();
        TrackableKVObj<VendorFCs> trackable1 = new TrackableKVObj<VendorFCs>(orgValue1);
        trackable1.updateBy(fcNewValue);
        
        VendorFCs orgValue2 = new VendorFCs();
        orgValue2.setHoldingCost(100d);
        TrackableKVObj<VendorFCs> trackable2 = new TrackableKVObj<VendorFCs>(orgValue2);
        trackable2.updateBy(fcNewValue);
        
        List<PairBase<TrackableKVObj<VendorFCs>, Boolean>> pairList = new ArrayList<PairBase<TrackableKVObj<VendorFCs>, Boolean>>();
        pairList.add(PairBase.pair(trackable1, false));
        pairList.add(PairBase.pair(trackable2, true));
        output = formater.formatForReview(pairList);
        System.out.println("output\n" + output);
    }
}
