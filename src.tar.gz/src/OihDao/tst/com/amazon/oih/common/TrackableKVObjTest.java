package com.amazon.oih.common;

import java.util.Map;

import junit.framework.Assert;

import org.junit.Test;

import com.amazon.oih.costs.VendorFCs;

public class TrackableKVObjTest {
    @Test
    public void testUpdate(){
        VendorFCs fc = new VendorFCs();
        fc.setDestroyReturnEstimate(0.4444d);
        TrackableKVObj<VendorFCs> trackableObj = new TrackableKVObj<VendorFCs>(fc);
        
        VendorFCs fcNewValue = new VendorFCs();
        fcNewValue.setGl(15l);
        fcNewValue.setId("id1");
        fcNewValue.setReceiptCost(1d);
        fcNewValue.setRemovalCost(2d);
        fcNewValue.setHoldingCost(3d);
        fcNewValue.setTransferInCost(4d);
        fcNewValue.setTransferOutCost(5d);
        fcNewValue.setDestroyReturnEstimate(null);
        
        trackableObj.updateBy(fcNewValue);
        Assert.assertEquals(null, fc.getId());
        Assert.assertEquals(Long.valueOf(15), fc.getGl());
        Assert.assertEquals(1d, fc.getReceiptCost());
        Assert.assertEquals(2d, fc.getRemovalCost());
        Assert.assertEquals(3d, fc.getHoldingCost());
        Assert.assertEquals(4d, fc.getTransferInCost());
        Assert.assertEquals(5d, fc.getTransferOutCost());
        Assert.assertEquals(null, fc.getDestroyReturnEstimate());
        
        Map<String, PairBase<Object, Object>> changes = trackableObj.getChanges();
        Assert.assertEquals(null, changes.get("WarehouseId"));
        Assert.assertEquals(PairBase.pair(15l, null), changes.get("GL"));
        Assert.assertEquals(PairBase.pair(1d, null), changes.get("ReceiptCost"));
        Assert.assertEquals(PairBase.pair(2d, null), changes.get("RemovalCost"));
        Assert.assertEquals(PairBase.pair(3d, null), changes.get("HoldingCost"));
        Assert.assertEquals(PairBase.pair(4d, null), changes.get("TransferInCost"));
        Assert.assertEquals(PairBase.pair(5d, null), changes.get("TransferOutCost"));
        Assert.assertEquals(PairBase.pair(null, 0.4444d), changes.get("DestroyReturnEstimate"));      
    }
}
