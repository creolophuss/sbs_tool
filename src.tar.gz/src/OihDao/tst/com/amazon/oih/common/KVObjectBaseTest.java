package com.amazon.oih.common;

import java.util.Date;
import java.util.Map;

import junit.framework.Assert;

import org.joda.time.DateTime;
import org.junit.Test;

import com.amazon.oih.common.KeyValueBase.NamedValue;
import com.amazon.oih.costs.VendorFCs;
import com.google.common.collect.Sets;

public class KVObjectBaseTest {
    @Test
    public void testUpdate(){
        VendorFCs fc = new VendorFCs();
        Assert.assertNull(fc.getGl());
        KeyValueBase<VendorFCs> kvObj = new KeyValueBase<VendorFCs>(fc);
        kvObj.update("GL", "14");
        kvObj.update("DestroyReturnEstimate", "0.4444");
        Assert.assertEquals(Long.valueOf(14), fc.getGl());
        Assert.assertEquals(Long.valueOf(14), kvObj.getValue("GL"));
        Assert.assertEquals(0.4444d, kvObj.getValue("DestroyReturnEstimate"));
        Assert.assertEquals(0.4444d, fc.getDestroyReturnEstimate());
        
        VendorFCs fcNewValue = new VendorFCs();
        fcNewValue.setGl(15l);
        fcNewValue.setId("id1");
        fcNewValue.setReceiptCost(1d);
        fcNewValue.setRemovalCost(2d);
        fcNewValue.setHoldingCost(3d);
        fcNewValue.setTransferInCost(4d);
        fcNewValue.setTransferOutCost(5d);
        fcNewValue.setDestroyReturnEstimate(null);
        
        kvObj.updateBy(fcNewValue);
        Assert.assertEquals(null, fc.getId());
        Assert.assertEquals(Long.valueOf(15), fc.getGl());
        Assert.assertEquals(1d, fc.getReceiptCost());
        Assert.assertEquals(2d, fc.getRemovalCost());
        Assert.assertEquals(3d, fc.getHoldingCost());
        Assert.assertEquals(4d, fc.getTransferInCost());
        Assert.assertEquals(5d, fc.getTransferOutCost());
        Assert.assertEquals(null, fc.getDestroyReturnEstimate());
        
        Map<String, Object> valueMap = kvObj.getKeyValues();
        Assert.assertEquals(null, valueMap.get("WarehouseId"));
        Assert.assertEquals(Long.valueOf(15), valueMap.get("GL"));
        Assert.assertEquals(1d, valueMap.get("ReceiptCost"));
        Assert.assertEquals(2d, valueMap.get("RemovalCost"));
        Assert.assertEquals(3d, valueMap.get("HoldingCost"));
        Assert.assertEquals(4d, valueMap.get("TransferInCost"));
        Assert.assertEquals(5d, valueMap.get("TransferOutCost"));
        Assert.assertEquals(null, valueMap.get("DestroyReturnEstimate"));
        Assert.assertEquals(Sets.newHashSet("GL", "ReceiptCost", "RemovalCost", "HoldingCost", "TransferInCost", "TransferOutCost", 
                "DestroyReturnEstimate", "IOG", "MarketplaceId", "WarehouseId"), valueMap.keySet());
    }
    
    @Test
    public void testUpdateWithDate(){
        TestObj obj = new TestObj();
        obj.setDate(new Date());
        TestObj updateObj = new TestObj();
        updateObj.setDate(new DateTime().plusYears(100).toDate());
        
        KeyValueBase<TestObj> kvObj = new KeyValueBase<TestObj>(obj);
        kvObj.updateBy(updateObj);        
        Assert.assertEquals(new DateTime().plusYears(100).getYear(), new DateTime(obj.getDate()).getYear());
        
        kvObj.updateBy(new TestObj());
        Assert.assertNull(obj.getDate());
    }
    
    @Test
    public void testSetKV4Column(){
        TestObj obj = new TestObj();
        obj.setDate(new Date());
        TestObj updateObj = new TestObj();
        updateObj.setDate(new DateTime().plusYears(100).toDate());
        
        KeyValueBase<TestObj> kvObj = new KeyValueBase<TestObj>(obj);
        kvObj.setKV4Column(updateObj, "date");       
        Assert.assertEquals(new DateTime().plusYears(100).getYear(), new DateTime(obj.getDate()).getYear());
        
        kvObj.setKV4Column(new TestObj(), "date");
        Assert.assertNull(obj.getDate());
    }
    
    public static class TestObj {
        @NamedValue("date")
        private Date date;

        public TestObj(){}
        
        public Date getDate() {
            return date;
        }

        public void setDate(Date date) {
            this.date = date;
        } 
    }   
}
