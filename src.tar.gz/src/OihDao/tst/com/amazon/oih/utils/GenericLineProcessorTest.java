package com.amazon.oih.utils;

import java.util.ArrayList;
import java.util.List;

import junit.framework.Assert;

import org.junit.Test;

public class GenericLineProcessorTest {
    private GenericLineProcessor tsvLineProcessor = new GenericLineProcessor("\t");

    @Test
    public void testBuildLine() {
        List<String> rawDataList = new ArrayList<String>();
        rawDataList.add("123");
        rawDataList.add("\"45.60\"");
        rawDataList.add("\t78.00");
        String line = tsvLineProcessor.buildLine(rawDataList );
        System.out.println("line=" + line);
        Assert.assertEquals("123\t\"\"\"45.60\"\"\"\t\"\t78.00\"", line);
    }

}
