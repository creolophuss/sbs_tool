package com.amazon.oih.configuration.dao;

import java.util.List;

import junit.framework.Assert;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.support.FileSystemXmlApplicationContext;

import amazon.platform.config.AppConfig;
import amazon.platform.logging.AppConfigLog4jConfigurator;

import com.amazon.oih.configuration.model.GlNameMapping;
import com.amazon.oih.dao.base.NewDaoFactory;

public class TestGLNameMappingDao {
    private int gl = 14;
    private static String REALM = "USAmazon";
    private static String domain = "test";
    private static String name = "Media";
    private static GlNameMappingDao dao = null;
    public static final String APP = "OihDao";
    public static final String APPGROUP = "oih";
    public static final String ROOT = "/tmp";

    @Before
    public void setUp() throws Exception {
        if (!AppConfig.isInitialized()) {
            AppConfigLog4jConfigurator.configureForBootstrap();
            AppConfig.initialize(APP, APPGROUP, new String[] {
                    "--domain=" + domain, "--realm=" + REALM, "--root=" + ROOT
            });
            AppConfigLog4jConfigurator.configureFromAppConfig();
        }

        // mock the applicationContext
        System.getProperties().put("domain", domain);// replace the place holder in the hibernate.xml
        FileSystemXmlApplicationContext appContext = new FileSystemXmlApplicationContext(new String[] {
                "spring-configuration/OihMysqlVendorFlexDb/hibernate.cfg.xml"
        });
        NewDaoFactory.setAppContext(appContext);

        dao = NewDaoFactory.getGlNameMappingDao();
    }

    @Test
    public void testSave() {
        GlNameMapping mapping4Save = new GlNameMapping(gl, REALM, name);
        dao.save(mapping4Save);

        List<GlNameMapping> mappings = dao.findAll();
        Assert.assertEquals(mappings.size(), 1);

        for (GlNameMapping object : mappings) {
            Assert.assertEquals(object.getGl(), mapping4Save.getGl());
            Assert.assertEquals(object.getOrg(), mapping4Save.getOrg());
            Assert.assertEquals(object.getName(), mapping4Save.getName());
        }
    }
}
