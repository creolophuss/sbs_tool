package com.amazon.oih.configuration.dao;

import java.util.List;

import junit.framework.Assert;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.support.FileSystemXmlApplicationContext;

import amazon.platform.config.AppConfig;
import amazon.platform.logging.AppConfigLog4jConfigurator;

import com.amazon.oih.configuration.model.BrandInfo;
import com.amazon.oih.dao.base.NewDaoFactory;

public class TestBrandInfoDao {
    private static BrandInfoDao dao = null;
    public static final String APP = "OihDao";
    public static final String APPGROUP = "oih";
    public static final String ROOT = "/tmp/";
    private static String REALM = "USAmazon";
    private static String domain = "test";
    
    private static String APUB_TYPE = "APUB";


    @Before
    public void setUp() throws Exception {
        if (!AppConfig.isInitialized()) {
            AppConfigLog4jConfigurator.configureForBootstrap();
            AppConfig.initialize(APP, APPGROUP, new String[] {
                    "--domain=" + domain, "--realm=" + REALM, "--root=" + ROOT
            });
            AppConfigLog4jConfigurator.configureFromAppConfig();
        }

        // mock the applicationContext
        System.getProperties().put("domain", domain);// replace the place holder in the hibernate.xml
        FileSystemXmlApplicationContext appContext = new FileSystemXmlApplicationContext(new String[] {
            "spring-configuration/OihMysqlVendorFlexDb/hibernate.cfg.xml"
        });
        NewDaoFactory.setAppContext(appContext);

        dao = NewDaoFactory.getBrandInfoDao();
    }
    
    
    private BrandInfo newInfo(String brand, String type, String key, String value){
        return new BrandInfo(REALM, brand, type, key, value);
    }
    private BrandInfo newApubInfo(String brand){
        return new BrandInfo(REALM, brand, APUB_TYPE, null, null);
    }    
    

    @Test
    public void testSaveAndFind() {
        BrandInfo JP_VENDOR1 = newApubInfo("VENDOR1");
        BrandInfo JP_VENDOR2 = newApubInfo("VENDOR2");
        dao.save(JP_VENDOR1);
        dao.save(JP_VENDOR2);
        dao.save(new BrandInfo("CNAmazon", "VENDOR2", APUB_TYPE, null, null));
        dao.save(newInfo("VENDOR3", "TYPE2","XWOCTIP","1"));
        List<BrandInfo> brandInfos = dao.findAll();
        Assert.assertEquals(4, brandInfos.size());
       
        brandInfos = dao.findAll(REALM);
        Assert.assertEquals(3, brandInfos.size());
        
        brandInfos = dao.findAll("CNAmazon");
        Assert.assertEquals(1, brandInfos.size());            
    }
    
}
