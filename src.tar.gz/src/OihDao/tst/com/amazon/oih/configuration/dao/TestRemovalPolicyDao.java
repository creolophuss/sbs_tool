package com.amazon.oih.configuration.dao;

import java.util.List;

import junit.framework.Assert;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.support.FileSystemXmlApplicationContext;

import amazon.platform.config.AppConfig;
import amazon.platform.logging.AppConfigLog4jConfigurator;

import com.amazon.oih.configuration.model.RemovalPolicy;
import com.amazon.oih.dao.base.NewDaoFactory;

public class TestRemovalPolicyDao {
    private static RemovalPolicyDao dao = null;
    public static final String APP = "OihDao";
    public static final String APPGROUP = "oih";
    public static final String ROOT = "/tmp";
    private int gl = 14;
    private int iog = 1;
    private static String REALM = "USAmazon";
    private static int value = 70;
    private static String domain = "test";
    private static String policyType = "MINIMUL_AVAILABLE_STOCK_ON_HAND";

    @Before
    public void setUp() throws Exception {
        if (!AppConfig.isInitialized()) {
            AppConfigLog4jConfigurator.configureForBootstrap();
            AppConfig.initialize(APP, APPGROUP, new String[] {
                    "--domain=" + domain, "--realm=" + REALM, "--root=" + ROOT
            });
            AppConfigLog4jConfigurator.configureFromAppConfig();
        }

        // mock the applicationContext
        System.getProperties().put("domain", domain);// replace the place holder in the hibernate.xml
        FileSystemXmlApplicationContext appContext = new FileSystemXmlApplicationContext(new String[] {
                "spring-configuration/OihMysqlVendorFlexDb/hibernate.cfg.xml"
        });
        NewDaoFactory.setAppContext(appContext);

        dao = NewDaoFactory.getRemovalPolicyDao();
    }

    @Test
    public void testSave() {
        RemovalPolicy policy4Save = new RemovalPolicy(gl, iog, policyType, value, null, null, REALM);
        dao.save(policy4Save);

        List<RemovalPolicy> policies = dao.findAll();
        Assert.assertEquals(policies.size(), 1);
        RemovalPolicy policy4Retrieve = policies.get(0);
        Assert.assertEquals(policy4Retrieve.getGl(), policy4Save.getGl());
        Assert.assertEquals(policy4Retrieve.getIog(), policy4Save.getIog());
        Assert.assertEquals(policy4Retrieve.getOrg(), policy4Save.getOrg());
        Assert.assertEquals(policy4Retrieve.getWarehouse(), policy4Save.getWarehouse());
        Assert.assertEquals(policy4Retrieve.getValue(), policy4Save.getValue());
        Assert.assertEquals(policy4Retrieve.getOrderType(), policy4Save.getOrderType());
    }    

}
