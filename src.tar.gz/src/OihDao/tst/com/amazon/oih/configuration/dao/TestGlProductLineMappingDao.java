package com.amazon.oih.configuration.dao;

import java.util.List;

import junit.framework.Assert;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.support.FileSystemXmlApplicationContext;

import amazon.platform.config.AppConfig;
import amazon.platform.logging.AppConfigLog4jConfigurator;

import com.amazon.oih.configuration.model.GlProductLineMapping;
import com.amazon.oih.dao.base.NewDaoFactory;

public class TestGlProductLineMappingDao {
    private int gl = 14;
    private static String REALM = "USAmazon";
    private static String domain = "test";
    private static String product_line = "Media";
    private static GlProductLineMappingDao dao = null;
    public static final String APP = "OihDao";
    public static final String APPGROUP = "oih";
    public static final String ROOT = "/tmp";

    @Before
    public void setUp() throws Exception {
        if (!AppConfig.isInitialized()) {
            AppConfigLog4jConfigurator.configureForBootstrap();
            AppConfig.initialize(APP, APPGROUP, new String[] {
                    "--domain=" + domain, "--realm=" + REALM, "--root=" + ROOT
            });
            AppConfigLog4jConfigurator.configureFromAppConfig();
        }

        // mock the applicationContext
        System.getProperties().put("domain", domain);// replace the place holder in the hibernate.xml
        FileSystemXmlApplicationContext appContext = new FileSystemXmlApplicationContext(new String[] {
                "spring-configuration/OihMysqlVendorFlexDb/hibernate.cfg.xml"
        });
        NewDaoFactory.setAppContext(appContext);

        dao = NewDaoFactory.getGlProductLineMappingDao();
    }

    @Test
    public void testSave() {
        GlProductLineMapping mapping = new GlProductLineMapping(gl, REALM, product_line);
        dao.save(mapping);

        List<GlProductLineMapping> mappings = dao.findAll();
        Assert.assertEquals(mappings.size(), 1);
    }
}
