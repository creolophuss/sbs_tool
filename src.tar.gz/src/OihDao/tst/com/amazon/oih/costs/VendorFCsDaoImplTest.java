package com.amazon.oih.costs;

import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import junit.framework.Assert;

import org.junit.Test;

import com.amazon.oih.dao.exception.OihPersistenceException;
import com.amazon.oih.utils.DaoUtil;
import com.google.common.base.Objects;
import com.google.common.collect.Sets;

public class VendorFCsDaoImplTest {
    @SuppressWarnings("rawtypes")
    VendorFCsDaoImpl dao = new VendorFCsDaoImpl(DaoUtil.getAnnotationSessionFactory(
                Arrays.asList((Class) VendorFCs.class, (Class) GLCostDetail.class)));
    
    @Test
    public void testSaveAndLoad() throws OihPersistenceException{
        VendorFCs fcs = new VendorFCs();
        fcs.setIog(1l);
        fcs.setWarehouseId("SDF1");
        fcs.setMarketplaceId(1l);
        fcs.setReceiptCost(10d);
        fcs.setRemovalCost(10d);
        fcs.setTransferInCost(1d);
        fcs.setRealm("USAmazon");
        fcs.setId("id1");

        Set<GLCostDetail> details = new HashSet<GLCostDetail>();
        fcs.setDetailedCostsList4GLs(details);
        GLCostDetail detail = new GLCostDetail();
        detail.setGl(193l);
        detail.setWarehouseId("SDF1");
        detail.setReceiptCost(100d);
        detail.setRemovalCost(1d);
        detail.setHoldingCost(4d);
        detail.setTransferInCost(100d);
        detail.setTransferOutCost(100d);
        detail.setDestroyReturnEstimate(1000d);
        detail.setId("glId1");
        details.add(detail);
        
        GLCostDetail fcdetail = new GLCostDetail();
        fcdetail.setGl(309l);
        fcdetail.setWarehouseId("SDF1");
        fcdetail.setReceiptCost(10000d);
        fcdetail.setId("glId2");
        details.add(fcdetail);
        
        dao.save(fcs);
      
        List<VendorFCs> results = dao.loadAll("USAmazon");
        Assert.assertEquals(3, results.size());
        VendorFCs sdf1 = getByFCGL("SDF1", null, results);
        Assert.assertEquals(2, sdf1.getDetailedCostsList4GLs().size());
        Set<String> fcNameSet = new HashSet<String>();
        Set<Long> glSet = new HashSet<Long>();
        for(GLCostDetail currentDetail : sdf1.getDetailedCostsList4GLs()){
            fcNameSet.add(currentDetail.getWarehouseId());
            glSet.add(currentDetail.getGl());
        }
        Assert.assertEquals(Sets.newHashSet("SDF1"), fcNameSet);
        Assert.assertEquals(Sets.newHashSet(193l, 309l), glSet);
        
        VendorFCs gldetail1 = getByFCGL("SDF1", 193l, results);
        Assert.assertEquals(100d, gldetail1.getReceiptCost());
        Assert.assertEquals(1d, gldetail1.getRemovalCost());
        Assert.assertEquals(4d, gldetail1.getHoldingCost());
        Assert.assertEquals(100d, gldetail1.getTransferInCost());
        Assert.assertEquals(100d, gldetail1.getTransferOutCost() );
        Assert.assertEquals(1000d, gldetail1.getDestroyReturnEstimate());
        VendorFCs gldetail2 = getByFCGL("SDF1", 309l, results);
        Assert.assertEquals(10000d, gldetail2.getReceiptCost());
        Assert.assertEquals(null, gldetail2.getRemovalCost());
        Assert.assertEquals(null, gldetail2.getHoldingCost());
        Assert.assertEquals(null, gldetail2.getTransferInCost());
        Assert.assertEquals(null, gldetail2.getTransferOutCost() );
        Assert.assertEquals(null, gldetail2.getDestroyReturnEstimate());
        
        List<VendorFCs> dbInstances = VendorFCsDaoImpl.constructChangedDBInstance(results, results);
        Assert.assertEquals(1, dbInstances.size());
        Set<GLCostDetail> gldetails = dbInstances.get(0).getDetailedCostsList4GLs();
        Assert.assertEquals(2, gldetails.size());
        for (GLCostDetail gldetail : gldetails){
            if (193l == gldetail.getGl()){
                Assert.assertEquals(100d, gldetail.getReceiptCost());
                Assert.assertEquals(1d, gldetail.getRemovalCost());
                Assert.assertEquals(4d, gldetail.getHoldingCost());
                Assert.assertEquals(100d, gldetail.getTransferInCost());
                Assert.assertEquals(100d, gldetail.getTransferOutCost() );
                Assert.assertEquals(1000d, gldetail.getDestroyReturnEstimate());
            } else {
                Assert.assertEquals(10000d, gldetail.getReceiptCost());
                Assert.assertEquals(null, gldetail.getRemovalCost());
                Assert.assertEquals(null, gldetail.getHoldingCost());
                Assert.assertEquals(null, gldetail.getTransferInCost());
                Assert.assertEquals(null, gldetail.getTransferOutCost() );
                Assert.assertEquals(null, gldetail.getDestroyReturnEstimate());
            }
        }
        
        VendorFCs newGLDetail = new VendorFCs();
        newGLDetail.setIog(2l);
        newGLDetail.setWarehouseId("SDF1");
        newGLDetail.setMarketplaceId(1l);
        newGLDetail.setReceiptCost(10d);
        newGLDetail.setRemovalCost(10d);
        newGLDetail.setTransferInCost(1d);
        newGLDetail.setRealm("USAmazon");

        results.add(newGLDetail);
        try { 
            dbInstances = VendorFCsDaoImpl.constructChangedDBInstance(results, results);
            Assert.assertFalse(true);
        } catch (Exception e){
            Assert.assertTrue(e.getMessage().contains("Not allowd to insert VendrFCs instance"));
        }
        newGLDetail.setGl(14l);
        try { 
            dbInstances = VendorFCsDaoImpl.constructChangedDBInstance(results, results);
            Assert.assertFalse(true);
        } catch (Exception e){
            Assert.assertTrue(e.getMessage().contains("Could not find VendorFCs record for this GLdetail"));
        }
        newGLDetail.setIog(1l);
        
        dbInstances = VendorFCsDaoImpl.constructChangedDBInstance(results, results);
        Assert.assertEquals(1, dbInstances.size());
        Assert.assertEquals("id1", dbInstances.get(0).getId());
        gldetails = dbInstances.get(0).getDetailedCostsList4GLs();
        Assert.assertEquals(3, gldetails.size());
        for (GLCostDetail gldetail : gldetails){
            if (193l == gldetail.getGl()){
                Assert.assertEquals("glId1", gldetail.getId());
                Assert.assertEquals(100d, gldetail.getReceiptCost());
                Assert.assertEquals(1d, gldetail.getRemovalCost());
                Assert.assertEquals(4d, gldetail.getHoldingCost());
                Assert.assertEquals(100d, gldetail.getTransferInCost());
                Assert.assertEquals(100d, gldetail.getTransferOutCost() );
                Assert.assertEquals(1000d, gldetail.getDestroyReturnEstimate());
            } else if (309l == gldetail.getGl()){
                Assert.assertEquals("glId2", gldetail.getId());
                Assert.assertEquals(10000d, gldetail.getReceiptCost());
                Assert.assertEquals(null, gldetail.getRemovalCost());
                Assert.assertEquals(null, gldetail.getHoldingCost());
                Assert.assertEquals(null, gldetail.getTransferInCost());
                Assert.assertEquals(null, gldetail.getTransferOutCost() );
                Assert.assertEquals(null, gldetail.getDestroyReturnEstimate());
            } else {
                Assert.assertTrue(gldetail.getId() != null);
                Assert.assertEquals(new Long(14), gldetail.getGl());
                Assert.assertEquals(10d, gldetail.getReceiptCost());
                Assert.assertEquals(10d, gldetail.getRemovalCost());
                Assert.assertEquals(null, gldetail.getHoldingCost());
                Assert.assertEquals(1d, gldetail.getTransferInCost());
                Assert.assertEquals(null, gldetail.getTransferOutCost() );
                Assert.assertEquals(null, gldetail.getDestroyReturnEstimate());
            }
        }
        dao.save(dbInstances);
        results = dao.loadAll("USAmazon");
        
        Assert.assertEquals(4, results.size());
        VendorFCs fc = getByFCGL("SDF1", null, results);
        Assert.assertEquals("1|1|SDF1", fc.getIdentityNoGL());
        Assert.assertEquals("1|1|SDF1|null", fc.getIdentity());
        Assert.assertEquals("id1", fc.getId());
        Assert.assertEquals(null, fc.getGl());
        Assert.assertEquals(10d, fc.getReceiptCost());
        Assert.assertEquals(10d, fc.getRemovalCost());
        Assert.assertEquals(null, fc.getHoldingCost());
        Assert.assertEquals(1d, fc.getTransferInCost());
        Assert.assertEquals(null, fc.getTransferOutCost() );
        Assert.assertEquals(null, fc.getDestroyReturnEstimate());
        
        VendorFCs gl193 = getByFCGL("SDF1", 193l, results);
        Assert.assertEquals("1|1|SDF1", gl193.getIdentityNoGL());
        Assert.assertEquals("1|1|SDF1|193", gl193.getIdentity());
        Assert.assertEquals("glId1", gl193.getId());
        Assert.assertEquals(100d, gl193.getReceiptCost());
        Assert.assertEquals(1d, gl193.getRemovalCost());
        Assert.assertEquals(4d, gl193.getHoldingCost());
        Assert.assertEquals(100d, gl193.getTransferInCost());
        Assert.assertEquals(100d, gl193.getTransferOutCost() );
        Assert.assertEquals(1000d, gl193.getDestroyReturnEstimate());
        
        VendorFCs gl309 = getByFCGL("SDF1", 309l, results);
        Assert.assertEquals("1|1|SDF1", gl309.getIdentityNoGL());
        Assert.assertEquals("1|1|SDF1|309", gl309.getIdentity());
        Assert.assertEquals("glId2", gl309.getId());
        Assert.assertEquals(10000d, gl309.getReceiptCost());
        Assert.assertEquals(null, gl309.getRemovalCost());
        Assert.assertEquals(null, gl309.getHoldingCost());
        Assert.assertEquals(null, gl309.getTransferInCost());
        Assert.assertEquals(null, gl309.getTransferOutCost() );
        Assert.assertEquals(null, gl309.getDestroyReturnEstimate());
        
        VendorFCs gl14 = getByFCGL("SDF1", 14l, results);
        Assert.assertEquals("1|1|SDF1", gl14.getIdentityNoGL());
        Assert.assertEquals("1|1|SDF1|14", gl14.getIdentity());
        Assert.assertTrue(gl14.getId() != null);
        Assert.assertEquals(new Long(14), gl14.getGl());
        Assert.assertEquals(10d, gl14.getReceiptCost());
        Assert.assertEquals(10d, gl14.getRemovalCost());
        Assert.assertEquals(null, gl14.getHoldingCost());
        Assert.assertEquals(1d, gl14.getTransferInCost());
        Assert.assertEquals(null, gl14.getTransferOutCost() );
        Assert.assertEquals(null, gl14.getDestroyReturnEstimate());
    }
    
    
    
    private VendorFCs getByFCGL(String fcName, Long gl, Collection<VendorFCs> fcList){
        for (VendorFCs fc : fcList){
            if (Objects.equal(fcName, fc.getWarehouseId()) && Objects.equal(gl, fc.getGl())){
                return fc;
            }
        }
        return null;
    }
}
